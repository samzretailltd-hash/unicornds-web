/**
 * Unicorn DS - Compliance Checker v2.0
 * Updated: 23 Apr 2026 — full eBay UK policy coverage
 *
 * Sources:
 *   - Product Safety: ebay.co.uk/help/policies/prohibited-restricted-items/recalled-items-policy?id=4300
 *   - Weapons: ebay.co.uk/help/policies/prohibited-restricted-items/weapons-policy?id=5050
 *   - Knives: ebay.co.uk/help/policies/prohibited-restricted-items/knives-policy?id=5047
 *
 * KEY RULE FOR DROPSHIPPERS:
 *   eBay allows some bladed items WITH age-verified delivery + UK stock.
 *   AliExpress dropshippers CANNOT comply — ships from China, no age verification.
 *   Therefore ALL bladed/sharp items are BLOCKED, not just warned.
 */

const ComplianceChecker = {

  // ═══════════════════════════════════════════════════════
  // eBay UK BLACKLIST (restricted words) — official block-words list
  // Source: eBay UK seller block-words export. Updated 31 May 2026.
  // Listings containing these frequently get blocked/removed.
  // ═══════════════════════════════════════════════════════
  BLACKLIST_VERSION: '31 May 2026',
  BLACKLIST_MODE: 'protective',      // 'general' | 'protective' (protective = broader)
  BLACKLIST_AS_BLOCK: false,         // false = warn (List Anyway) | true = hard block
  EBAY_UK_BLACKLIST: ["18650", "1ml/cc", "2 way radio", "2 way radios", "2-way radio", "2-way radios", "30g 8mm", "32g 8mm", "32g-8mm", "357 battery", "377 battery", "389 battery", "392 battery", "4-mbc", "a76", "absinthe", "ac adapter", "adult toy", "adult toys", "aeroplane launcher", "aerosol", "after shave", "aftershave", "ag10", "ag13", "ag3", "air-gun", "airgun", "airplane launcher", "airsoft gun", "ak47", "ale", "amaretto", "amaro", "ammo", "ammunition", "angle grinder", "angle grinders", "angle-grinder", "angle-grinders", "animal fridge magnets", "antibiotic", "antibiotics", "antiseptic", "aperitif", "aperitivo", "aperol", "aphrodisiac", "appetite suppressant", "apple charger", "aptamil", "arousal", "assault rifle", "awl", "awls", "axe", "axes", "baby cot", "baby cots", "baby doll", "baby door", "baby food", "baby formula", "baby gate", "baby healthcare", "baby lounger", "baby neck pillow", "baby necklace", "baby pillow", "baby play mat", "baby play-pen", "baby playpen", "baby sleep positioner", "baby teething", "baby toy", "baby toys", "baby weighted blanket", "badee al oud", "baileys", "baking cup", "baking cups", "balisong", "bassinet", "bath toy", "bath toys", "baton", "bayonet", "bayonets", "bazooka", "bb gun", "bee venom", "beer", "beers", "beretta", "besque", "best before", "betamethasone", "bike battery charger", "billhook", "billhooks", "bipap", "blade", "blades", "blaster toy", "blind box", "blow up doll", "blow up man", "blowgun", "blown up man", "blowpipe", "blowpipes", "blue formula drops", "bondage", "bottle opener", "bottle openers", "bourbon", "bow rake", "brandy", "breathalyser", "breathalyzer", "brick jointer", "brow gel", "brow gels", "brow-gel", "brow-gels", "building block", "building blocks", "building kit for kids", "butane", "butt plug", "butt plugs", "butt-plug", "butt-plugs", "button batteries", "button battery", "button cell", "button cells", "buttplug", "buttplugs", "cable stripper", "cake box", "cake boxes", "cake slice box", "cake slice boxes", "cake-slice box", "cake-slice boxes", "campari", "can opener", "can openers", "cancer treatment", "cappelletti", "capsule", "capsules", "carpet nail", "carpet nails", "carpet tack", "carpet tacks", "carver", "carvers", "carving", "cat supplement", "cat treat", "cat treats", "cat vitamin", "catheter", "caulking kit", "cbd", "center punch", "centre punch", "chain-saw", "chainsaw", "chainsaws", "champagne", "charger adapter", "charger block", "charging adapter", "charging block", "charging station", "cheese board kit", "cheese board set", "chewing bone", "chip repair", "chisel", "chisels", "chlamydia", "choking hazard", "cider", "ciders", "cigar", "cigarette", "cigarette lighter adapter", "cigarettes", "cigars", "circuit breaker", "cleaver", "cleavers", "clipper", "clippers", "clitoris", "clobetasol", "cocktail", "coin batteries", "coin battery", "coin cell", "coin cells", "cologne", "combustible", "confetti", "constipation", "converter plug", "core remover", "core removers", "corkscrew", "corkscrews", "cot bumper", "cow & gate", "cpap", "cr1220", "cr1620", "cr1632", "cr2016", "cr2025", "cr2032", "cr2450", "creatine", "crib", "crib bumper", "criminal id", "criminal identifier", "criminal-id", "crimp tool", "crimper", "crimping tool", "crimping tools", "crimping-tool", "croker horse", "crop preserver", "crossbow", "crossbows", "cupcake box", "cupcake boxes", "curaçao", "cuticle pusher", "cuticle pushers", "cutlery", "cutter", "cutters", "cutting disc", "cutting discs", "cutting off disc", "cutting off discs", "cutting wheel", "cutting wheels", "cyanide", "dagger", "daggers", "dark spot correcting", "dark spot corrector", "dark spot cream", "dark spot remover", "darts", "dc adapter", "dc converter", "de wormer", "de-wormer", "de-worming", "defence spray", "defense spray", "dental bone", "dental pick", "dental repair", "dental sticks", "dental stix", "deodorant", "derma roller", "dermapen", "dermaplane tool", "dermaplane tools", "dermaplaning tool", "dermaplaning tools", "dermaplaning-blade", "dermaplaning-blades", "dermaplaning-razor", "dermaplaning-razors", "dermaplaning-tool", "dermaplaning-tools", "desktop charger", "dessert box", "dessert boxes", "dessert container", "dessert containers", "dessert packaging", "detox cream", "detox creme", "detox tea", "dewormer", "deworming", "diamond cutting", "diclofenac", "digging", "dildo", "dildos", "dinitrophenol", "dispensing measuring tool", "dispensing measuring tools", "dispensing tool", "dispensing tools", "disposable bowl", "disposable bowls", "disposable cup", "disposable cups", "disposable dinnerware", "disposable tableware", "disposable-bowl", "disposable-bowls", "disposable-cup", "disposable-cups", "disposable-cutlery", "dog chew", "dog chews", "dog shampoo", "dog supplement", "dog treat", "dog treats", "dog vitamin", "double edge", "double edged", "double-edge", "double-edged", "drill bit", "drill bits", "drill set", "drill toy", "drone toy", "duck toy", "dummy clip", "e-cig", "e-cigarette", "ear bud", "ear buds", "ear drop", "ear drops", "ear relief", "earbud", "earbuds", "edged", "electric heater", "electric heaters", "electric meat grinder", "electric meat mincer", "electric zapper", "engraving pen", "engraving pens", "enhancement cream", "enzacamene", "erotica", "etching pen", "etching pens", "ethylene oxide", "expanding beads", "extension lead", "extension leads", "extension plug", "extension plugs", "eye drop", "eye drops", "eye gel", "eye hooks", "eye liner", "eye shadow", "eye wash", "eye-drop", "eye-drops", "eye-liner", "eye-wash", "eyelash extension", "eyeliner", "eyeshadow", "eyeshadows", "facial wand", "facial wands", "facial-hair remover", "facial-hair removers", "fan heater", "fanola", "farb gel", "farb-gel", "fast charger block", "fat burner", "ferrite magnetic", "fidget magnet", "fidget magnets", "fidget pen", "fidget pens", "fidget toy", "fidget toys", "fidget tube", "fidget tubes", "filling repair", "firearm", "flat tire", "flat tyre", "flatware", "flatware set", "flea collar", "flea drops", "flea medicine", "flea treatment", "fleshlight", "fleshlights", "follow on milk", "follow-on milk", "food container", "food containers", "food pot", "food pots", "food processor", "foot file", "foot files", "fork", "forks", "formic acid", "fountain candle", "fountain candles", "freeze spray", "french style iron", "fresh & dry", "gan charger", "garden rake", "garden tool", "garden tools", "garlic tablets", "gin", "glass repair", "glitter craft", "glow stick", "glow sticks", "glucose monitor", "glucose monitoring", "glue trap", "glue traps", "gonorrhea", "gonorrheoa", "gonorrhoea", "grinder", "grinders", "grooming kit", "grooming set", "guillotine", "guillotines", "gummies", "gunsmith", "gunsmithing", "haemorrhoid", "haemorrhoids", "hair dryer", "hair remover", "hair removers", "hair serum", "hair straightener", "hairdryer", "hammer", "hammers", "hand rake", "handclaw", "handclaws", "harpic", "harpo", "hatchet", "hatchets", "hearing aid batteries", "hearing aid battery", "hearing-aid batteries", "hearing-aid battery", "heart valve", "heart valves", "heartworm", "heat alarm", "heat alarms", "heat detector", "heat detectors", "heat-alarm", "heat-alarms", "heat-detector", "heat-detectors", "hedge trimmer", "hedge trimmers", "hemorrhoid", "hemorrhoids", "hemp", "hentai", "herbal", "herbal cream", "herbal remedy", "herbicide", "herbicides", "highchair", "hoe", "hole punch", "hollow punch", "hoof trimmer", "hoof trimmers", "hook & pick", "hook and pick", "hook kit", "hook pick", "hook set", "hook tool", "hubeye", "hyaluronic", "hydrofluoric", "hydroquinone", "hygrometer", "hyperhidrosis", "hypochlorite", "ibs tablets", "ice pick", "ice skates", "ice-pick", "icing smoother", "icing smoothers", "icing spatula", "icing spatulas", "inclined sleeper", "infant cot", "infant cots", "infant formula", "infant milk", "infant-milk", "inflatable man", "infusion pump", "infusion pumps", "inhaler", "injection", "injector", "insect zapper", "insecticide", "insecticides", "ipa", "italian aperitivo", "jagermeister", "javelin", "javelins", "jishaku", "jovan", "juice extractor", "juicer", "jump rope", "jumping rope", "karambit", "karambits", "kct", "kids scooter", "kids scooters", "kids seatbelt", "kids seatbelts", "killer", "kiridashi", "kiridashis", "knife", "knive", "knives", "knuckle duster", "knuckle dusters", "kratom", "kubotan", "kukri", "kukris", "kunkumadi tailam", "landscape rake", "laptop charger", "laptop power supply", "lawn trimmer", "lawn trimmers", "laxative", "laxatives", "leaf & square", "leaf and square", "leaf rake", "led tea light", "led tea lights", "letter opener", "letter openers", "lightning cable", "lightning charger", "limoncello", "lip balm", "lip filler", "lip oil", "lip overnight repair", "lip repair balm", "lipbalm", "lipstick", "lipsticks", "liquer", "liquers", "liqueur", "lithium coin", "lock mechanism", "lock pick", "lock picks", "lockpick", "lockpicks", "lr1130", "lr41", "lr44", "lypsyl", "machete", "machetes", "magazine loader", "magnet toy", "magnet toys", "magnetic ball", "magnetic balls", "magnetic block", "magnetic blocks", "magnetic building", "magnetic chess", "magnetic cube", "magnetic cubes", "magnetic dartboard", "magnetic discovery play set", "magnetic drawing", "magnetic fidget", "magnetic fidget pen", "magnetic fidget pens", "magnetic fishing game", "magnetic fishing toy", "magnetic fishing toys", "magnetic game", "magnetic games", "magnetic letters", "magnetic numbers", "magnetic pacifier", "magnetic play set", "magnetic puzzle", "magnetic puzzles", "magnetic set", "magnetic strategy", "magnetic toy", "magnetic toys", "mail opener", "mail openers", "mallet", "mallets", "manicure set", "manicure sets", "marking gauge", "marsala", "mascara", "masturbator", "masturbators", "mattock", "mattocks", "maul", "mead", "measuring dispenser", "measuring dispensers", "meat thermometer", "meat thermometers", "medicated", "melatonin", "metal rake", "mfi certified", "mice repellent", "mice repeller", "micro needling", "micro-needling", "microneedle", "microneedling", "mini man fridge magnet", "minoxidil", "moccasins", "model tools kit", "moonshine", "mortar jointer", "moth balls", "mounjaro", "mouse deterrent", "mouse repellent", "mouse repeller", "mouse trap", "mouse traps", "mouthwash", "mre", "mres", "multi tool", "multi tools", "multi-plug adapter", "multi-plug adapters", "multi-plug extension", "multi-port charger", "multi-tool", "multi-tools", "multi-vitamin", "multi-vitamins", "multiport charger", "multitool", "multitools", "multivitamin", "multivitamins", "muscle joint pain relief", "muscle pain relief", "nail pusher", "nail pushers", "nature spell", "needle", "needles", "nest pod", "nest sleeper", "nicotine", "nipper", "nippers", "nunchakus", "nunchucks", "nuromol", "nursery cot", "oil burner", "oil filled radiator", "oil filled radiators", "ointement", "ointements", "ointment", "ointments", "omega-3 capsules", "omega-3 supplement", "omega-3 tablets", "ophthalmoscope", "oral solution", "otoscope", "ozempic", "pacemaker", "pacemakers", "pacifier", "pacifier clip", "package opener", "parfum", "party bowl", "party bowls", "party cup", "party cups", "party tableware", "pd charger", "pedicure set", "pedicure sets", "penis", "pepper spray", "pepperspray", "perfume", "perfumes", "permatex", "pest trap", "pest traps", "pesticide", "pesticides", "pet supplement", "pet treat", "pet treats", "pet vitamin", "pet wormer", "phallic", "pick & hook", "pick and hook", "pick axe", "pick axes", "pick hook", "pick kit", "pick set", "pick tool", "pick-axe", "pickaxe", "piles relief", "pills", "pimm's", "pincer", "pincers", "pistol", "pit remover", "pit removers", "pitter remover", "pitter removers", "plastic cup", "plastic cups", "plastic transfer tool", "plastic transfer tools", "playpen", "plier", "pliers", "plug adapter", "plug adapters", "plug adaptor", "plug adaptors", "plug extension", "plug socket adapter", "plug socket adapters", "plug splitter", "poison", "poisons", "pokémon", "polished ferrite", "pour homme", "power adapter", "power brick", "power delivery charger", "precision flow applicator", "pricking iron", "probe", "probes", "probiotic", "probiotics", "prong punch", "prosecco", "protein powder", "pulse oximeter", "puncture", "rake pick", "rake tool", "raking tool", "rat deterrent", "rat repellent", "rat repeller", "ratchet set", "ratchet wrench", "razor", "razor blade", "razor blades", "razor-blade", "razor-blades", "razors", "relay switch", "relief powder", "relieve discomfort", "reline denture set", "reline denture sets", "reline set", "reline sets", "removal kit", "removal patch", "removal pen", "removal pens", "removal tool", "removal tools", "remover tool", "remover tools", "replacement adapter", "replacement charger", "retinol", "retinols", "revolver", "revolvers", "rifle", "rodent control", "rodent deterrent", "rodent repellent", "rodent repeller", "rodenticide", "rosemary oil", "rotary blade", "royal mail", "rubber duck", "rum", "saline solution", "sambuca", "sand art", "saw", "saws", "scaling pick", "scalpel", "scalpels", "schnapps", "scissor", "scissors", "scooter battery charger", "scotch", "scraper", "scrapers", "scraping", "screw extractor", "screwdriver", "screwdrivers", "scribe tool", "scribe tools", "scriber", "scribers", "scribing tool", "scribing tools", "scythe", "scythes", "seat belt", "seatbelt", "security marker", "security markers", "security marking", "self-defence spray", "self-defense spray", "semaglutide", "sensory beads", "sensory box", "sensory direct", "sensory toy", "sensory toys", "serrated", "serration", "sewing kit", "sewing machine", "sex", "sharpening", "shave", "shaver", "shavers", "shaving", "shear", "shears", "sherry", "shotgun", "shovel", "shovels", "shuriken", "shurikens", "sickle", "sickles", "sildenafil", "silverware", "skin bleaching", "skin fading", "skin lightening", "skin whitening", "skin-bleaching", "skin-fading", "skin-lightening", "skin-whitening", "skip rope", "skipping rope", "skullpanda", "slicer", "slicers", "slim patch", "slime", "slimes", "slimming patch", "slingshot", "slingshots", "sma advanced", "sma alfamino", "sma comfort", "smoke alarm", "smoke detector", "smoke detectors", "smoke-alarm", "smoke-detector", "smoke-detectors", "smoothie cup", "smoothie cups", "snips", "socket set", "socket wrench", "soil rake", "sonicare", "sourdough bread making kit", "sourdough starter kit", "sparking candle", "sparking candles", "sparkler", "sparklers", "sparkling candle", "sparkling candles", "speargun", "speculus", "spike", "spikes", "spirulina", "splitting tool", "splitting wedge", "splitting-maul", "splitting-wedge", "squeegee", "squeegees", "sr41", "sr44", "sr626sw", "std kit", "stds kit", "stem remover", "stem removers", "step ladder", "sticky trap", "sticky traps", "stiletto", "stitching iron", "stitching punch", "stool softener", "stout", "strawberry huller", "strawberry hullers", "string bulbs", "string light", "string lights", "string trimmer", "string trimmers", "stroller", "submersible led", "submersible leds", "sunbed cream", "supplement tablets", "suppositories", "suture kit", "suturing kit", "swaddle blanket", "swaddle wrap", "switchblade", "switchblades", "sword", "sword-stick", "swords", "syringe", "syringes", "tabacco", "tactical pick", "tadalafil", "tan cream", "tanning accelerator", "tap bit", "tap bits", "tap set", "tape gun", "taser", "tear gas", "tear-gas", "teargas", "teether", "teething", "teething necklace", "teething ring", "teething toy", "telescopic ladder", "temporary teeth replacement", "temporary tooth replacement", "tension wrench", "tequila", "test strip", "test strips", "thatch rake", "thermocouple", "threading beads", "throwing star", "throwing stars", "thumb tack", "thumb tacks", "thyroid", "tick collar", "tick drops", "tick medicine", "tick treatment", "tire plug", "tire repair", "tirzepatide", "tobacco", "toddler toy", "toddler toys", "toenail kit", "toenail tool", "toilet bowl cleaner", "tooth repair", "toothpick", "toothpicks", "topk", "toy blaster", "toy drill", "toy drone", "toy magnet", "toy magnets", "travel adapter", "travel adapters", "tree trimmer", "tree trimmers", "tretinoin", "trim puller", "trim pullers", "trimethylbenzoyl", "trimmer", "trimmers", "trowel", "trowels", "turmeric face oil", "tweezer", "tweezers", "two way radio", "two way radios", "two-way radio", "two-way radios", "tyre plug", "tyre repair", "ultra sharp", "ultra violet dye", "ultra-sharp", "ultra-violet dye", "universal battery", "universal charger", "unpasteurised", "unpasteurized", "upholster nails", "upholstery nail", "upholstery tack", "upholstery tacks", "uranium-235", "uv marking", "vape", "vaping", "vascular", "vascular graft", "ventricular", "ventricular bypass device", "vermouth", "verruca removal", "verruca remover", "vodka", "waiter's friend", "waiter's friends", "waiters friend", "waiters friends", "walkie talkie", "walkie talkies", "wall charger", "wallpaper kit", "wallpaper tool", "wallpaper trimmer", "wallpapering kit", "wart removal", "wart remover", "watch batteries", "watch battery", "water beads", "waterbeads", "wedger", "weeder tool", "weeder tools", "weeding tool", "weeding tools", "wegovy", "weight loss patch", "weight loss patches", "weight loss tea", "weight loss treatment", "welding", "wentronic", "whiskey", "whiskeys", "whiskies", "whisky", "whitening cream", "window tint", "windscreen repair", "windshield repair", "wine", "wire stripper", "wire strippers", "wireless charger stand", "wireless charging pad", "wood splitter", "wood splitters", "worm", "wormer", "worming", "worms", "wrinkle patch", "wrinkle patches", "wrinkle remover", "yikerz"],
  EBAY_UK_BLACKLIST_STRICT_EXTRA: ["asbestos", "babies", "baby", "battery charger", "cat food", "dog food", "heated", "heater", "heaters", "infant", "infants", "ingrown", "kitten food", "li-ion", "lithium", "moisturiser", "moisturisers", "moisturizer", "moisturizers", "newborn", "newborns", "nursery", "pet food", "puppy food", "sensory", "toddler", "toddlers", "weeder", "weeding"],

  // Generic blade/sharp keywords that trigger eBay's automated scanner
  BLADE_KEYWORDS: [
    'knife', 'knives', 'blade', 'bladed', 'blades',
    'chisel', 'chisels',
    'scraper', 'scrapers', 'putty blade', 'putty knife',
    'cutter', 'box cutter', 'pipe cutter', 'tile cutter', 'glass cutter',
    'razor', 'razors', 'scalpel', 'scalpels',
    'saw', 'saws', 'hole saw', 'hacksaw', 'jigsaw blade', 'saw blade', 'fret saw',
    'coping saw', 'bow saw', 'pruning saw', 'meat saw',
    'axe', 'axes', 'hatchet', 'hatchets', 'tomahawk',
    'machete', 'machetes',
    'sword', 'swords', 'katana', 'samurai',
    'dagger', 'daggers',
    'scissors',
    'shears', 'garden shears', 'pruning shears', 'hedge shears',
    'secateurs', 'pruner', 'pruners', 'loppers',
    'billhook', 'sickle', 'scythe',
    'pickaxe', 'mattock', 'ice pick',
    'chainsaw',
    'planer', 'plane blade',
    'gouge', 'gouges', 'wood gouge',
    'mandoline slicer',
    'pizza cutter', 'pizza wheel',
    'letter opener',
    'straight razor', 'dermaplaning',
    'rotary cutter', 'rotary blade',
    'craft knife', 'craft blade', 'stanley knife', 'snap off blade',
    'utility knife', 'utility blade',
    'multi-tool', 'multitool', 'leatherman',
    'swiss army',
    'spear', 'javelin', 'pike', 'lance', 'halberd',
  ],

  // Illegal weapons — always blocked, criminal offence
  WEAPONS_BANNED: [
    'butterfly knife', 'balisong',
    'switchblade', 'flick knife', 'automatic knife',
    'gravity knife',
    'push dagger', 'push knife',
    'zombie knife', 'zombie blade', 'cyclone knife', 'spiral knife',
    'sword stick', 'sword cane', 'hidden knife', 'disguised knife',
    'knuckle duster', 'knuckleduster', 'brass knuckles', 'brass knuckle',
    'handclaw', 'hand claw',
    'nunchaku', 'nunchucks', 'nunchuk',
    'sansetsukon',
    'throwing star', 'shuriken', 'ninja star',
    'throwing knife', 'throwing axe',
    'blow gun', 'blowgun', 'blowpipe', 'blow dart',
    'dart gun', 'flare gun', 'potato gun', 'spud gun',
    'stun gun', 'taser', 'electroshock',
    'pepper spray', 'mace spray', 'tear gas', 'cs gas', 'cs spray',
    'crossbow', 'crossbows',
    'kusari gama', 'kyoketsu shoge', 'manrikigusari',
    'nightstick', 'baton', 'truncheon', 'blackjack', 'cosh',
    'leaded cane',
    'combat knife', 'tactical knife', 'fighting knife',
    'battle axe', 'spike axe', 'viking axe', 'double headed axe',
  ],

  // NOT bladed — these contain trigger words but are safe
  SAFE_EXCEPTIONS: [
    'wiper blade', 'wiper blades',
    'fan blade', 'fan blades',
    'turbine blade',
    'blade runner', 'blade server', 'shoulder blade',
    'grass blade', 'blade of grass',
    'roller blade', 'rollerblade', 'inline skate',
    'ice skate blade', 'skate blade',
    'mower blade', 'lawn mower blade',
    'strimmer blade', 'trimmer blade',
    'caulk tool', 'caulk nozzle', 'grout tool',
    'squeegee',
  ],

  // Context words: if title contains one of these + a blade keyword → NOT a weapon
  SAFE_CONTEXT: [
    'blender', 'nutribullet', 'vitamix', 'food processor',
    'mixer', 'stand mixer',
    'silicone', 'rubber', 'plastic',
    'caulk', 'caulking', 'grout', 'sealant',
    'ice scraper', 'windscreen', 'windshield',
    'wallpaper',
    'dog', 'cat', 'pet', 'puppy', 'kitten', 'chew toy', 'treat',
    'toy', 'plush', 'stuffed',
    'cake', 'baking', 'kitchen utensil', 'spatula', 'whisk',
    'hair', 'beauty', 'makeup', 'skincare', 'shampoo', 'conditioner',
    'garden', 'plant', 'flower', 'seed',
  ],

  // Product safety — banned categories
  PRODUCT_SAFETY_BLOCKED: [
    'baby lounger', 'infant lounger',
    'cot bumper', 'crib bumper', 'cot bumpers',
    'sleep positioner', 'baby sleep positioner',
    'baby nest', 'sleep nest', 'baby pod',
    'anti-roll', 'anti roll pillow',
    'inclined sleeper', 'infant inclined',
    'baby weighted blanket', 'weighted sleep sack',
    'patting pillow',
    'sids prevention', 'prevent sids', 'anti sids',
    'baby self-feeding', 'self feeding device',
    'baby helmet', 'baby head protector', 'anti-bump helmet',
    '18650 battery', '18650 batteries', '18650 cell',
    'laser pointer', 'laser pen', 'high power laser', 'burning laser',
    'novelty lighter', 'giant lighter', 'toy lighter', 'gun lighter',
  ],

  // CE/UKCA risky — warn only
  CE_RISKY_KEYWORDS: [
    'charger', 'charging cable', 'usb cable', 'power adapter', 'power supply',
    'led light', 'led strip', 'led lamp', 'led bulb',
    'headphones', 'earphones', 'earbuds', 'bluetooth speaker',
    'smart watch', 'smartwatch', 'fitness tracker',
    'drone', 'rc car', 'remote control',
    'hair dryer', 'hair straightener', 'curling iron',
    'electric shaver', 'electric toothbrush',
    'power bank', 'portable charger',
    'lithium battery', 'li-ion battery', 'lipo battery',
    'battery pack', 'rechargeable battery',
    'toy', 'action figure', 'doll', 'plush toy', 'stuffed animal',
    'building blocks', 'lego compatible',
    'baby toy', 'toddler toy', 'infant toy', 'teething',
    'fidget spinner', 'fidget toy', 'slime',
    'safety goggles', 'safety glasses', 'hard hat', 'helmet',
    'hi-vis', 'high visibility',
    'face mask', 'respirator', 'ear defenders',
    'safety boots', 'steel toe',
    'electric scooter', 'e-scooter', 'e-bike', 'ebike',
    'hoverboard', 'segway', 'electric skateboard',
    'angle grinder', 'drill', 'circular saw',
    'pressure washer', 'air compressor',
  ],

  // Brand protection
  PROTECTED_BRANDS: [
    'apple', 'iphone', 'ipad', 'airpods', 'macbook', 'samsung', 'galaxy',
    'google', 'pixel', 'microsoft', 'xbox', 'playstation', 'sony', 'nintendo',
    'huawei', 'oneplus', 'oppo', 'xiaomi', 'bose', 'beats',
    'jbl', 'marshall', 'dyson', 'gopro', 'dji', 'canon', 'nikon',
    'nike', 'adidas', 'puma', 'reebok', 'new balance', 'converse', 'vans',
    'gucci', 'louis vuitton', 'prada', 'chanel', 'hermes', 'burberry',
    'versace', 'balenciaga', 'dior', 'fendi', 'valentino', 'ysl',
    'ralph lauren', 'tommy hilfiger', 'calvin klein', 'armani', 'hugo boss',
    'north face', 'patagonia', 'supreme', 'off-white', 'stone island',
    'canada goose', 'moncler', 'lacoste',
    'rolex', 'omega', 'tag heuer', 'breitling', 'cartier',
    'patek philippe', 'audemars piguet',
    'disney', 'marvel', 'dc comics', 'star wars', 'pokemon',
    'lego', 'barbie', 'hot wheels', 'fisher price', 'hasbro',
    'ray-ban', 'oakley', 'pandora', 'swarovski', 'tiffany',
  ],

  COUNTERFEIT_SIGNALS: [
    'style', 'inspired', 'dupe', 'replica', 'lookalike', 'fake',
    'imitation', 'knock off', 'knockoff', 'copy', 'clone',
  ],

  ACCESSORY_SIGNALS: [
    'compatible', 'for', 'fits', 'works with', 'suitable for',
    'case', 'cover', 'cable', 'charger', 'charging', 'adapter',
    'screen protector', 'tempered glass', 'holder', 'stand', 'mount',
    'strap', 'band', 'replacement', 'aftermarket', 'generic',
    'oem', 'third party', 'universal', 'type',
  ],

  // ═══════════════════════════════════════════════════════
  // HELPER
  // ═══════════════════════════════════════════════════════
  _escapeRe(x) { return x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); },

  _buildBlacklistRegex(list) {
    const terms = list.slice().sort((a, b) => b.length - a.length).map(t => this._escapeRe(t));
    return new RegExp('\\b(?:' + terms.join('|') + ')\\b', 'gi');
  },

  _blacklistMatches(text) {
    let re;
    if (this.BLACKLIST_MODE === 'general') {
      this._reGeneral = this._reGeneral || this._buildBlacklistRegex(this.EBAY_UK_BLACKLIST);
      re = this._reGeneral;
    } else {
      this._reProtective = this._reProtective || this._buildBlacklistRegex(this.EBAY_UK_BLACKLIST.concat(this.EBAY_UK_BLACKLIST_STRICT_EXTRA));
      re = this._reProtective;
    }
    re.lastIndex = 0;
    const found = new Set();
    let m;
    while ((m = re.exec(text)) !== null) {
      found.add(m[0].toLowerCase());
      if (m.index === re.lastIndex) re.lastIndex++;
    }
    return [...found];
  },

  configure(opts) {
    opts = opts || {};
    if (opts.mode === 'general' || opts.mode === 'protective') this.BLACKLIST_MODE = opts.mode;
    if (typeof opts.asBlock === 'boolean') this.BLACKLIST_AS_BLOCK = opts.asBlock;
    this._reGeneral = null; this._reProtective = null; // rebuild on next use
  },

  _isSafeException(text) {
    // Check exact phrase matches
    for (const safe of this.SAFE_EXCEPTIONS) {
      if (text.includes(safe)) return true;
    }
    // Check context words: if title contains "blender" + "blade" → not a weapon
    for (const ctx of this.SAFE_CONTEXT) {
      if (text.includes(ctx)) return true;
    }
    return false;
  },

  // ═══════════════════════════════════════════════════════
  // MAIN CHECK
  // ═══════════════════════════════════════════════════════
  check(productData) {
    const title = (productData.custom_title || productData.title || '').toLowerCase();
    const description = (productData.ai_description || productData.description || '').toLowerCase();
    const combined = title + ' ' + description;

    const result = { safe: true, warnings: [], blocks: [] };

    // 1A: ILLEGAL WEAPONS
    for (const kw of this.WEAPONS_BANNED) {
      const kwRegex = new RegExp('\\b' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b');
      if (kwRegex.test(combined)) {
        result.blocks.push({
          type: 'weapon', severity: 'block', keyword: kw,
          message: '🚫 ILLEGAL WEAPON: "' + kw + '" — banned on eBay, criminal offence to sell',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/weapons-policy?id=5050',
        });
        result.safe = false;
        break;
      }
    }

    // 1B: BLADED/SHARP ITEMS — blocked for dropshippers
    if (result.safe) {
      for (const kw of this.BLADE_KEYWORDS) {
        // Use word boundary regex to avoid false positives
        // e.g. "lance" should NOT match "balance", "ambulance", "surveillance", "freelance"
        const kwRegex = new RegExp('\\b' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b');
        if (kwRegex.test(combined)) {
          if (this._isSafeException(combined)) {
            result.warnings.push({
              type: 'blade_exception', severity: 'info', keyword: kw,
              message: '✅ "' + kw + '" detected but appears non-bladed (safe exception)',
            });
            break;
          }
          result.blocks.push({
            type: 'blade', severity: 'block', keyword: kw,
            message: '🔪 BLADED ITEM: "' + kw + '" — requires age-verified delivery + UK stock. Cannot dropship from AliExpress.',
            policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/knives-policy?id=5047',
          });
          result.safe = false;
          break;
        }
      }
    }

    // 2: PRODUCT SAFETY
    for (const kw of this.PRODUCT_SAFETY_BLOCKED) {
      const kwRegex = new RegExp('\\b' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b');
      if (kwRegex.test(combined)) {
        result.blocks.push({
          type: 'product_safety', severity: 'block', keyword: kw,
          message: '⛔ PRODUCT SAFETY: "' + kw + '" — banned or restricted by eBay',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/recalled-items-policy?id=4300',
        });
        result.safe = false;
        break;
      }
    }

    // 3: CE/UKCA RISKY (warn only)
    const ceMatches = [];
    for (const kw of this.CE_RISKY_KEYWORDS) {
      const kwRegex = new RegExp('\\b' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b');
      if (kwRegex.test(combined)) ceMatches.push(kw);
    }
    if (ceMatches.length > 0) {
      result.warnings.push({
        type: 'ce_ukca', severity: 'warning',
        message: '⚡ CE/UKCA: "' + ceMatches.slice(0, 3).join('", "') + '" — may need CE/UKCA marking.',
        keywords: ceMatches,
      });
    }

    // 4: COUNTERFEIT / BRAND
    const brandMatches = [];
    for (const brand of this.PROTECTED_BRANDS) {
      const regex = new RegExp('\\b' + brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
      if (regex.test(combined)) brandMatches.push(brand);
    }
    if (brandMatches.length > 0) {
      let isAccessory = this.ACCESSORY_SIGNALS.some(s => combined.includes(s));
      let isCounterfeit = this.COUNTERFEIT_SIGNALS.some(s => combined.includes(s));

      if (isCounterfeit && !isAccessory) {
        result.blocks.push({
          type: 'counterfeit', severity: 'block',
          message: '🚫 COUNTERFEIT: "' + brandMatches[0] + '" with fake/replica signals.',
          brands: brandMatches,
        });
        result.safe = false;
      } else if (isAccessory) {
        result.warnings.push({
          type: 'brand_accessory', severity: 'info',
          message: '✅ ACCESSORY: "' + brandMatches[0] + '" — generic accessory, OK to list.',
          brands: brandMatches,
        });
      } else {
        result.warnings.push({
          type: 'brand_detected', severity: 'warning',
          message: '⚠️ BRAND: "' + brandMatches.join('", "') + '" — only list if genuine.',
          brands: brandMatches,
        });
      }
    }

    // 5: VERO
    if (productData._veroChecked && productData._veroBlocked) {
      result.blocks.push({
        type: 'vero', severity: 'block',
        message: '🛑 VERO: "' + productData._veroBrand + '" is VeRO-protected.',
        brands: [productData._veroBrand],
      });
      result.safe = false;
    }

    // 6: eBay UK RESTRICTED WORDS (official block-words list)
    try {
      const blMatches = this._blacklistMatches(combined);
      if (blMatches.length) {
        const blockedKw = new Set(result.blocks.map(b => (b.keyword || '').toLowerCase()).filter(Boolean));
        const filtered = blMatches.filter(w => !blockedKw.has(w));
        if (filtered.length) {
          const shown = filtered.slice(0, 6).join(', ');
          const more = filtered.length > 6 ? ' +' + (filtered.length - 6) + ' more' : '';
          const asBlock = this.BLACKLIST_AS_BLOCK;
          const entry = {
            type: 'ebay_blacklist',
            severity: asBlock ? 'block' : 'warning',
            keywords: filtered,
            message: (asBlock ? '🚫' : '⚠️') + ' eBay UK restricted words: ' + shown + more +
              ' — eBay often blocks/removes listings with these. Remove from title/description or skip. (List ' + this.BLACKLIST_VERSION + ')',
            policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items',
          };
          if (asBlock) { result.blocks.push(entry); result.safe = false; }
          else { result.warnings.push(entry); }
        }
      }
    } catch (e) { /* never let blacklist scan break listing */ }

    return result;
  },

  formatForConsole(result) {
    if (result.safe && result.warnings.length === 0) {
      console.log('[UnicornDS] ✅ Compliance: SAFE');
      return;
    }
    if (result.blocks.length > 0) {
      console.warn('[UnicornDS] 🚨 COMPLIANCE BLOCK:');
      result.blocks.forEach(b => console.warn('[UnicornDS]   ' + b.message));
    }
    if (result.warnings.length > 0) {
      console.warn('[UnicornDS] ⚠️ WARNINGS:');
      result.warnings.forEach(w => console.warn('[UnicornDS]   ' + w.message));
    }
  },

  formatForNotification(result) {
    if (result.safe && result.warnings.length === 0) return null;
    const lines = [];
    result.blocks.forEach(b => lines.push(b.message));
    result.warnings.forEach(w => lines.push(w.message));
    return lines.join('\n');
  },
};

if (typeof module !== 'undefined') module.exports = ComplianceChecker;
