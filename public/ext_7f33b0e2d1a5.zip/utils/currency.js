/**
 * UnicornDS - Canonical currency module (single source of truth).
 *
 * Each seller works in ONE currency: the price shown on the source site
 * (AliExpress/Amazon) is already in the seller's currency, and they list on
 * their local eBay in that same currency. So there is NO conversion — we just
 * parse the number correctly and show the symbol that is already on the page.
 *
 * Fixes the EU comma-decimal bug: "€1,43" was parsed as 143 (100x too high).
 *
 * Exposed ONLY as `self.UDSCurrency` (and module.exports under node). It does
 * NOT define any bare top-level names, so it can be loaded alongside content
 * scripts that already have their own parsePrice()/etc. without collision.
 *
 * decimal 'dot'   -> 1,234.56  (UK/US/AU/CA)  comma = thousands separator
 * decimal 'comma' -> 1.234,56  (EU: DE/FR/ES/IT/NL) dot/space = thousands
 */
(function () {
  'use strict';

  var CURRENCY_META = {
    GBP: { code: 'GBP', symbol: '\u00A3', decimal: 'dot'   },
    USD: { code: 'USD', symbol: '$',      decimal: 'dot'   },
    EUR: { code: 'EUR', symbol: '\u20AC', decimal: 'comma' },
    AUD: { code: 'AUD', symbol: 'A$',     decimal: 'dot'   },
    CAD: { code: 'CAD', symbol: 'C$',     decimal: 'dot'   },
    CHF: { code: 'CHF', symbol: 'CHF',    decimal: 'dot'   },
  };

  function symbolFor(currency) {
    var m = CURRENCY_META[currency];
    return m ? m.symbol : '\u00A3';
  }

  // Detect the currency the price text on the page is written in.
  // Priority: explicit multi-char symbol > single symbol > bare $ (host) > host.
  function detectSourceCurrency(priceText, hostname) {
    var t = String(priceText == null ? '' : priceText);
    var h = String(hostname == null ? '' : hostname).toLowerCase();

    if (/AU?\s*\$/.test(t)) return 'AUD';          // A$ / AU$
    if (/C(?:A|DN)?\s*\$/.test(t)) return 'CAD';   // C$ / CA$ / CDN$
    if (/US\s*\$/.test(t)) return 'USD';
    if (/[\u00A3\uFFE1]/.test(t)) return 'GBP';    // GBP pound or fullwidth pound (AliExpress)
    if (/\u20AC/.test(t)) return 'EUR';            // euro sign

    if (/CHF|\bFr\.?/.test(t)) return 'CHF';     // Swiss franc

    if (/\$/.test(t)) {                            // bare $ is ambiguous -> use host (below)
      return hostCurrency(h, 'USD');
    }
    // No currency symbol in the text -> decide purely from the hostname.
    return hostCurrency(h, 'GBP');
  }

  // Map a marketplace hostname to a currency. Handles BOTH suffix style
  // (www.amazon.de, www.walmart.com, www.walmart.ca, www.ebay.com.au) and
  // subdomain style (fr.aliexpress.com, de.aliexpress.com). Order = most specific first.
  function hostCurrency(h, fallback) {
    h = String(h || '').toLowerCase();
    if (h.indexOf('.co.uk') !== -1 || h.indexOf('uk.') === 0) return 'GBP';
    if (h.indexOf('.com.au') !== -1 || h.indexOf('au.') === 0) return 'AUD';
    if (/(^|\.)ch(\.|$)/.test(h)) return 'CHF';
    if (/\.ca(\.|$)/.test(h) || h.indexOf('ca.') === 0) return 'CAD';
    if (/(^|\.)(de|fr|es|it|nl|pl|be|at|ie)(\.|$)/.test(h)) return 'EUR';
    if (h.indexOf('.com') !== -1 || h.indexOf('.us') !== -1) return 'USD';
    return fallback || 'GBP';
  }

  function inferDecimal(s) {
    var lastComma = s.lastIndexOf(',');
    var lastDot = s.lastIndexOf('.');
    if (lastComma === -1 && lastDot === -1) return 'dot';
    var onlyComma = lastDot === -1 && (s.match(/,/g) || []).length === 1;
    var onlyDot = lastComma === -1 && (s.match(/\./g) || []).length === 1;
    if (onlyComma && /,\d{3}$/.test(s)) return 'dot';   // 1,234 -> dot-style thousands
    if (onlyDot && /\.\d{3}$/.test(s)) return 'comma';  // 1.234 -> comma-style thousands
    return lastComma > lastDot ? 'comma' : 'dot';
  }

  // Parse a price string into a Number. Pass a currency code ('EUR') or a style
  // ('comma'/'dot') when known; otherwise the decimal separator is inferred.
  // Never deletes the decimal separator (that was the EU comma -> 143 bug).
  function parsePrice(input, currencyOrStyle) {
    if (input == null) return 0;
    if (typeof input === 'number') return isNaN(input) ? 0 : input;
    var s = String(input).trim();
    if (!s) return 0;
    s = s.replace(/[^0-9.,]/g, '');           // keep digits + separators only
    if (!s) return 0;

    var decimal;
    if (currencyOrStyle === 'comma' || currencyOrStyle === 'dot') decimal = currencyOrStyle;
    else if (currencyOrStyle && CURRENCY_META[currencyOrStyle]) decimal = CURRENCY_META[currencyOrStyle].decimal;
    else decimal = inferDecimal(s);

    if (decimal === 'comma') {
      s = s.replace(/\./g, '');                 // dots = thousands -> drop
      s = s.replace(',', '.').replace(/,/g, ''); // first comma = decimal, drop any rest
    } else {
      s = s.replace(/,/g, '');                   // commas = thousands -> drop
    }
    var n = parseFloat(s);
    return isNaN(n) ? 0 : Math.round(n * 100) / 100;
  }

  function formatMoney(amount, currency) {
    return symbolFor(currency) + Number(amount || 0).toFixed(2);
  }

  var API = {
    CURRENCY_META: CURRENCY_META,
    symbolFor: symbolFor,
    detectSourceCurrency: detectSourceCurrency,
    parsePrice: parsePrice,
    formatMoney: formatMoney,
    inferDecimal: inferDecimal,
  };

  if (typeof self !== 'undefined') self.UDSCurrency = API;
  else if (typeof globalThis !== 'undefined') globalThis.UDSCurrency = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})();
