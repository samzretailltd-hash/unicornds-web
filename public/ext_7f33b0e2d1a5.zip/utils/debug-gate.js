/**
 * UnicornDS debug gate (MIN-05).
 * Centralises all verbose logging behind ONE switch so production builds stay quiet
 * and don't leak scraped prices / titles / order data into the devtools console.
 *
 * console.warn and console.error are ALWAYS preserved (real problems stay visible).
 *
 * >>> Set UDS_DEBUG = false BEFORE publishing to the Chrome Web Store. <<<
 * (Left true so local/unpacked testing keeps full logs.)
 */
(function () {
  'use strict';
  var UDS_DEBUG = false;   // <-- flip to false for production releases

  var g = (typeof self !== 'undefined') ? self
        : (typeof globalThis !== 'undefined') ? globalThis
        : this;
  try { g.__UDS_DEBUG__ = UDS_DEBUG; } catch (e) {}

  if (!UDS_DEBUG && typeof console !== 'undefined') {
    try {
      var noop = function () {};
      console.log = noop;
      console.info = noop;
      console.debug = noop;
    } catch (e) {}
  }
})();
