/*
 * UnicornDS — Walmart first-party seller detector
 * Decides whether a Walmart product/search item is SOLD & SHIPPED by Walmart.com
 * (first-party) vs a third-party marketplace seller (3P, incl. WFS where a 3P
 * seller is merely *fulfilled* by Walmart).
 *
 * Returns tri-state firstParty:
 *   true  = first-party (Walmart.com) — safe to dropship
 *   false = confirmed third-party seller — strict mode blocks
 *   null  = unknown (no reliable signal) — caller decides (we do NOT block on null)
 *
 * Exposes ONLY self.UDSWmtSeller (no bare globals).
 */
(function () {
  'use strict';

  // Known Walmart first-party seller ids seen in product JSON.
  var WALMART_1P_IDS = ['0', 'F55CDC31AB754BB68FE0B39041159D63'];

  function pick(node, keys) {
    if (!node || typeof node !== 'object') return '';
    for (var i = 0; i < keys.length; i++) {
      var v = node[keys[i]];
      if (v != null && v !== '') return v;
    }
    return '';
  }

  // Signal from the product/search JSON node.
  function fromNode(node) {
    if (!node || typeof node !== 'object') return { firstParty: null, seller: '', type: '' };
    var offer = node.primaryOffer ||
                (Array.isArray(node.offers) ? node.offers[0] : null) ||
                (node.buyBoxSuppression ? null : null) || {};

    var name = String(pick(node, ['sellerName', 'sellerDisplayName']) ||
                      pick(offer, ['sellerName', 'sellerDisplayName']) || '').trim();
    var type = String(pick(node, ['sellerType', 'offerType']) ||
                      pick(offer, ['sellerType', 'offerType']) || '').trim().toUpperCase();
    var id = String(pick(node, ['sellerId']) || pick(offer, ['sellerId']) || '').trim();

    var fp = null;
    if (type === 'INTERNAL') fp = true;
    else if (type === 'EXTERNAL' || type === 'MARKETPLACE' || type === '3P') fp = false;
    else if (/^walmart(\.com)?$/i.test(name)) fp = true;
    else if (id && WALMART_1P_IDS.indexOf(id.toUpperCase()) !== -1) fp = true;
    else if (name) fp = false; // a named non-Walmart seller = third-party
    // else stays null (unknown)

    return { firstParty: fp, seller: name, type: type };
  }

  // Signal from the product page DOM ("Sold and shipped by ..." line).
  function fromDom(text) {
    var t = String(text || '').trim();
    if (!t) return null;
    // First-party: "Sold and shipped by Walmart.com" (sold BY walmart, not just fulfilled)
    if (/sold\s+(and\s+shipped\s+)?by\s+walmart(\.com)?/i.test(t)) {
      return { firstParty: true, seller: 'Walmart.com' };
    }
    // Third-party: "Sold by X" where X isn't Walmart — even if "Fulfilled by Walmart" (WFS)
    var m = t.match(/sold\s+by\s+([^,.;|]+)/i);
    if (m && !/walmart/i.test(m[1])) {
      return { firstParty: false, seller: m[1].trim() };
    }
    return null;
  }

  self.UDSWmtSeller = {
    // node = product/search JSON object; domText optional (product page only).
    detect: function (node, domText) {
      var j = fromNode(node);
      if (j.firstParty === true || j.firstParty === false) return j; // JSON is definitive
      var d = fromDom(domText);
      if (d) return { firstParty: d.firstParty, seller: d.seller || j.seller, type: j.type };
      return j; // { firstParty: null, ... }
    }
  };
})();
