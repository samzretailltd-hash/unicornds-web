/**
 * UnicornDS - Shared Pricing Module (Single Source of Truth)
 *
 * ALL pricing calculations across the extension MUST use this module.
 * No other file should define fvfRates, fee tables, or pricing formulas.
 *
 * Fixes: C1 (8 duplicated fee tables), C2 (inconsistent pricing model),
 *        C3 (price=0 passes profit check), H1 (VAT missing in listing-form),
 *        H8 (bulk lister ignoring per-source settings)
 */

// ═══════════════════════════════════════════════════════
// SINGLE FEE RATE TABLE — update ONLY here
// ═══════════════════════════════════════════════════════
const UDS_FEE_RATES = {
  co_uk: { rate: 0.128, fixed: 0.30, currency: '£'  },  // 12.8% + £0.30
  com:   { rate: 0.132, fixed: 0.30, currency: '$'  },  // 13.25% + $0.30
  de:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // 11% + €0.35
  com_au:{ rate: 0.132, fixed: 0.50, currency: 'A$' },  // 13.2% + A$0.50
  fr:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // 11% + €0.35
  it:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // 11% + €0.35
  es:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // 11% + €0.35
  ca:    { rate: 0.132, fixed: 0.30, currency: 'C$' },  // 13.2% + C$0.30
  nl:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // 11% + €0.35
  at:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // Austria  (EUR)
  be:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // Belgium  (EUR)
  ie:    { rate: 0.11,  fixed: 0.35, currency: '€'  },  // Ireland  (EUR)
  ch:    { rate: 0.11,  fixed: 0.55, currency: 'CHF' },  // Switzerland (CHF)
};

function udsFees(market) {
  return UDS_FEE_RATES[market] || UDS_FEE_RATES.co_uk;
}

// ═══════════════════════════════════════════════════════
// PRICE ROUNDING
// ═══════════════════════════════════════════════════════
function udsApplyPriceRounding(price, style) {
  if (!style || style === 'none') return Math.round(price * 100) / 100;
  const ending = style === '0.95' ? 0.95 : 0.99;
  const floored = Math.floor(price);
  const candidate = floored + ending;
  // If price is already above the candidate (e.g. 19.997 → 20.99 not 19.99)
  return candidate >= price ? candidate : floored + 1 + ending;
}

// ═══════════════════════════════════════════════════════
// INPUT VALIDATION (Fixes C3: price=0 → £0.99 listing)
// ═══════════════════════════════════════════════════════
function udsValidatePrice(price) {
  const p = parseFloat(price);
  if (isNaN(p) || p <= 0) return { valid: false, value: 0, error: 'Price is missing or zero' };
  if (p > 100000) return { valid: false, value: p, error: 'Price exceeds £100,000 — likely a scrape error' };
  return { valid: true, value: p, error: null };
}

function udsValidateTitle(title) {
  const t = (title || '').trim();
  if (!t || t.length < 5) return { valid: false, value: t, error: 'Title is missing or too short (min 5 chars)' };
  if (t.toLowerCase() === 'aliexpress' || t.toLowerCase() === 'amazon') return { valid: false, value: t, error: 'Title is just the platform name — scrape likely failed' };
  return { valid: true, value: t, error: null };
}

// ═══════════════════════════════════════════════════════
// SELL PRICE CALCULATOR (Profit-Based Formula)
// "X% profit" means: after ALL fees, user keeps X% of cost as profit
// Formula: Sell = ((Cost + Shipping) × (1 + profit/100) + fixed_fee) / (1 - FVF_rate - promo/100)
// ═══════════════════════════════════════════════════════
function udsCalculateSellPrice(costPrice, options = {}) {
  const {
    desiredProfit = 25,    // % profit on cost
    promoRate = 10,        // promoted listing ad rate %
    shippingCost = 0,      // supplier shipping cost added to product cost
    vatRate = 0,           // VAT % (for VAT-registered sellers)
    market = 'co_uk',
    roundPrices = false,
    roundingStyle = '0.99',
  } = options;

  const validation = udsValidatePrice(costPrice);
  if (!validation.valid) {
    return { sellPrice: 0, error: validation.error, valid: false };
  }

  const cost = validation.value;
  const fees = udsFees(market);
  const totalCost = cost + (parseFloat(shippingCost) || 0);
  const profitDecimal = (parseFloat(desiredProfit) || 25) / 100;
  const promoDecimal = (isNaN(parseFloat(promoRate)) ? 0 : parseFloat(promoRate)) / 100;
  const denominator = 1 - fees.rate - promoDecimal;

  // Guard against impossible fee combinations (fees > 100% of price)
  if (denominator <= 0) {
    return { sellPrice: 0, error: 'FVF + promo rate exceeds 100% — impossible to profit', valid: false };
  }

  let sellPrice = (totalCost * (1 + profitDecimal) + fees.fixed) / denominator;

  // Apply VAT if set (Fixes H1: VAT was missing in listing-form.js fallback)
  if (vatRate > 0) {
    sellPrice = sellPrice * (1 + vatRate / 100);
  }

  // Apply psychological rounding
  if (roundPrices) {
    sellPrice = udsApplyPriceRounding(sellPrice, roundingStyle);
  } else {
    sellPrice = Math.round(sellPrice * 100) / 100;
  }

  // eBay minimum
  sellPrice = Math.max(sellPrice, 0.99);

  return { sellPrice, totalCost, error: null, valid: true };
}

// ═══════════════════════════════════════════════════════
// PROFIT CALCULATOR
// ═══════════════════════════════════════════════════════
function udsCalculateProfit(sellPrice, costPrice, promoRate = 10, market = 'co_uk', source = 'aliexpress') {
  const fees = udsFees(market);
  const sell = parseFloat(sellPrice) || 0;
  let cost = parseFloat(costPrice) || 0;
  // EU AliExpress import duty (from 1 Jul 2026): flat €3 + VAT (~€3.57) per item
  // type on EU-bound orders under €150. AliExpress only, EU markets only.
  let euDuty = 0;
  const isEu = fees.currency === '€';
  const isAli = !/(amazon|walmart)/i.test(source || '');
  if (isEu && isAli) { euDuty = 3.57; cost += euDuty; }
  const promo = parseFloat(promoRate) || 0;

  const ebayFVF = (sell * fees.rate) + fees.fixed;
  const promoFee = sell * (promo / 100);
  const totalFees = ebayFVF + promoFee;
  const profit = sell - cost - totalFees;
  // Fix C3: if cost is 0, profitPct should be 0, NOT Infinity
  const profitPct = cost > 0 ? (profit / cost * 100) : 0;
  const margin = sell > 0 ? (profit / sell * 100) : 0;

  return {
    sellPrice: sell,
    costPrice: cost,
    ebayFVF: Math.round(ebayFVF * 100) / 100,
    promoFee: Math.round(promoFee * 100) / 100,
    totalFees: Math.round(totalFees * 100) / 100,
    profit: Math.round(profit * 100) / 100,
    profitPct: Math.round(profitPct * 10) / 10,
    margin: Math.round(margin * 10) / 10,
    currency: fees.currency,
    euDuty: Math.round(euDuty * 100) / 100,
    breakdown: `Cost: ${fees.currency}${cost.toFixed(2)} + FVF: ${fees.currency}${ebayFVF.toFixed(2)} + Promo: ${fees.currency}${promoFee.toFixed(2)} = ${fees.currency}${totalFees.toFixed(2)} fees | Profit: ${fees.currency}${profit.toFixed(2)} (${Math.round(profitPct)}% of cost)`,
  };
}

// ═══════════════════════════════════════════════════════
// SETTINGS RESOLVER — resolves per-source settings
// Fixes H8: bulk lister now uses per-source settings
// ═══════════════════════════════════════════════════════
function udsResolvePricingSettings(storageData, source = 'aliexpress') {
  const s = storageData || {};
  const src = (source || '').toLowerCase();
  const isAmazon = src.includes('amazon');
  const isWalmart = src.includes('walmart');

  // Helper: get first valid number, treating 0 as valid (only NaN/undefined/null fall through)
  const num = (...vals) => { for (const v of vals) { const n = parseFloat(v); if (!isNaN(n)) return n; } return undefined; };

  if (isWalmart) {
    return {
      desiredProfit: num(s.unicornds_markup_wmt, s.unicornds_markup) ?? 25,
      promoRate: num(s.unicornds_promo_rate_wmt, s.unicornds_promo_rate, s.unicornds_ad_rate) ?? 0,
      shippingCost: num(s.unicornds_shipping_wmt) ?? 0,
      stockQty: parseInt(s.unicornds_stock_qty_wmt) || parseInt(s.unicornds_stock_qty) || 10,
      vatRate: num(s.unicornds_vat) ?? 0,
      market: s.unicornds_primary_market || 'co_uk',
      roundPrices: !!s.unicornds_round_prices,
      roundingStyle: s.unicornds_rounding_style || '0.99',
    };
  }

  return {
    desiredProfit: isAmazon
      ? (num(s.unicornds_markup_amz, s.unicornds_markup) ?? 25)
      : (num(s.unicornds_markup_ali, s.unicornds_markup) ?? 50),
    promoRate: isAmazon
      ? (num(s.unicornds_promo_rate_amz, s.unicornds_promo_rate, s.unicornds_ad_rate) ?? 0)
      : (num(s.unicornds_promo_rate_ali, s.unicornds_promo_rate, s.unicornds_ad_rate) ?? 0),
    shippingCost: isAmazon
      ? (num(s.unicornds_shipping_amz) ?? 0)
      : (num(s.unicornds_shipping_ali) ?? 0),
    stockQty: isAmazon
      ? (parseInt(s.unicornds_stock_qty_amz) || parseInt(s.unicornds_stock_qty) || 10)
      : (parseInt(s.unicornds_stock_qty_ali) || parseInt(s.unicornds_stock_qty) || 10),
    vatRate: num(s.unicornds_vat) ?? 0,
    market: s.unicornds_primary_market || 'co_uk',
    roundPrices: !!s.unicornds_round_prices,
    roundingStyle: s.unicornds_rounding_style || '0.99',
  };
}

// ═══════════════════════════════════════════════════════
// MARKET DOMAIN RESOLVER (Fixes C5: two domain keys)
// Single function to get eBay domain from market code
// ═══════════════════════════════════════════════════════
const UDS_MARKET_TO_DOMAIN = {
  co_uk: 'co.uk', com: 'com', de: 'de', com_au: 'com.au',
  ca: 'ca', fr: 'fr', it: 'it', es: 'es', nl: 'nl',
  at: 'at', be: 'be', ch: 'ch', ie: 'ie', 'in': 'in',
};

function udsGetEbayDomain(storageData) {
  const s = storageData || {};
  // Priority: unicornds_primary_market > domain > unicornds_ebay_domain > fallback
  const market = s.unicornds_primary_market;
  if (market && UDS_MARKET_TO_DOMAIN[market]) return UDS_MARKET_TO_DOMAIN[market];
  if (s.domain) return s.domain;
  if (s.unicornds_ebay_domain) return s.unicornds_ebay_domain;
  return 'co.uk';
}

// Make available globally for importScripts in service worker
// and for content scripts via chrome.runtime.sendMessage
if (typeof self !== 'undefined') {
  self.UDS_FEE_RATES = UDS_FEE_RATES;
  self.udsFees = udsFees;
  self.udsApplyPriceRounding = udsApplyPriceRounding;
  self.udsValidatePrice = udsValidatePrice;
  self.udsValidateTitle = udsValidateTitle;
  self.udsCalculateSellPrice = udsCalculateSellPrice;
  self.udsCalculateProfit = udsCalculateProfit;
  self.udsResolvePricingSettings = udsResolvePricingSettings;
  self.udsGetEbayDomain = udsGetEbayDomain;
  self.UDS_MARKET_TO_DOMAIN = UDS_MARKET_TO_DOMAIN;
}
