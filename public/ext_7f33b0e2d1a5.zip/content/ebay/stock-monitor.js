/**
 * UnicornDS - Bulk Stock Monitor (Amazon-only, safe)
 * Runs on: eBay Seller Hub active listings pages (loaded after active-listings.js)
 *
 * WHAT IT DOES
 *  - Scans every Amazon-sourced listing on the page (SKU = UDS-AZ-{ASIN} or bare B0 ASIN).
 *  - AliExpress / unknown / MSKU rows are SKIPPED and never touched.
 *  - Detects stock via a STRICT 3-state background check: in_stock / out_of_stock / unknown.
 *  - "unknown" (captcha, block, error, ambiguous) is NEVER acted on.
 *
 * SAFETY MODEL
 *  1. Scan only highlights rows + builds a preview list. Nothing is written on scan.
 *  2. User reviews the preview, then clicks Apply. Only then do we edit quantities.
 *  3. We only SET QUANTITY (0 to remove, N to restock). We NEVER end/delete a listing.
 *  4. Quantity is written through eBay's OWN inline-edit UI (same as editing by hand).
 *  5. Every change is logged (old qty -> new qty) so it can be undone in one click.
 *  6. Throttled + jitter + auto-abort if Amazon starts blocking.
 */
'use strict';

(function () {
  if (window.__udsStockMonitorLoaded) return;
  window.__udsStockMonitorLoaded = true;

  // ── CONFIG ──────────────────────────────────────────────────────────
  const CFG = {
    CHECK_DELAY_MS: 1200,     // base delay between Amazon checks (be gentle)
    CHECK_JITTER_MS: 800,     // random extra delay
    MAX_PER_RUN: 120,         // hard cap of checks per scan
    CONSECUTIVE_BLOCK_ABORT: 4, // stop scan after this many blocks/unknowns-in-a-row
    EDIT_CLICK_WAIT_MS: 1300, // wait after clicking eBay's edit button
    EDIT_SAVE_WAIT_MS: 1600,  // wait after clicking eBay's save button
    APPLY_DELAY_MS: 1200,     // delay between applying each change
    DEFAULT_RESTOCK_QTY: 3,
    STORE_LOG_KEY: 'unicornds_stock_monitor_log',
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const jitter = () => {
    // Deep mode opens a real tab per item, so space checks out more to avoid
    // Amazon captchas. Quick mode can go faster.
    const base = DEEP_MODE ? 3000 : CFG.CHECK_DELAY_MS;
    const extra = DEEP_MODE ? 2000 : CFG.CHECK_JITTER_MS;
    return base + Math.floor(Math.random() * extra);
  };

  // In-memory scan state
  let LAST_SCAN = [];   // array of { itemNumber, sku, title, qty, status, price, reason, action, newQty }
  let SCANNING = false;
  let APPLYING = false;

  // ── ROW READING (self-contained; same selectors as active-listings.js) ──
  function getRows() {
    // Dedupe: the same <tr> can match several selectors, which inflated counts 4x.
    return [...new Set([
      ...document.querySelectorAll('tr.grid-row'),
      ...document.querySelectorAll('[class*="listing-row"]'),
      ...document.querySelectorAll('tr[data-id]'),
    ])];
  }

  function readRow(row) {
    const d = {};
    const titleEl = row.querySelector('div[class*="title__text"]') || row.querySelector('[class*="item-title"]');
    d.title = titleEl ? titleEl.textContent.trim() : '';

    // SKU / custom label. eBay's real column class is shui-dt-column__customLabel.
    // Fall back to older selectors, then to the 4th column by position (header index 3).
    let skuEl = row.querySelector('td[class*="customLabel"]') ||
                row.querySelector('td[class*="listingSKU"]') ||
                row.querySelector('[class*="custom-label"]');
    if (!skuEl) {
      const tds = row.querySelectorAll('td');
      if (tds[3]) skuEl = tds[3]; // "Custom label (SKU)" column
    }
    d.sku = skuEl ? skuEl.textContent.trim() : '';

    const qtyEl = row.querySelector('td[class*="availableQuantity"] [class*="cell-wrapper"]') ||
                  row.querySelector('[class*="available-qty"]');
    if (!qtyEl) {
      const q = row.querySelector('td[class*="availableQuantity"]');
      d.qty = q ? (parseInt(q.textContent.trim().replace(/[^0-9]/g, ''), 10) || 0) : 0;
    } else {
      d.qty = parseInt(qtyEl.textContent.trim().replace(/[^0-9]/g, ''), 10) || 0;
    }

    const idEl = row.querySelector('td[class*="listingId"]');
    if (idEl) {
      d.itemNumber = idEl.textContent.trim();
    } else {
      d.itemNumber = row.getAttribute('data-id') ||
                     (row.querySelector('[data-id]') && row.querySelector('[data-id]').getAttribute('data-id')) || '';
    }

    // Variation / MSKU listing? Title shows "[N variations]" on eBay.
    d.isMsku = /\[\s*\d+\s*variation/i.test(d.title);
    return d;
  }

  function findRowByItemId(itemNumber) {
    if (!itemNumber) return null;
    for (const row of getRows()) {
      const idEl = row.querySelector('td[class*="listingId"]');
      const id = idEl ? idEl.textContent.trim()
                      : (row.getAttribute('data-id') ||
                         (row.querySelector('[data-id]') && row.querySelector('[data-id]').getAttribute('data-id')) || '');
      if (id && id === itemNumber) return row;
    }
    return null;
  }

  // ── SOURCE ROUTING ──────────────────────────────────────────────────
  // Truth source = what UnicornDS RECORDED when it listed the item, stored in
  // unicornds_sku_dictionary (keyed by SKU) and unicornds_variant_map.
  // We do NOT guess from the number format. If the record says 'amazon' (or the
  // SKU is a clear Amazon ASIN), it's Amazon; otherwise it's skipped.
  let SRC_DICT = {};   // sku -> { source, sourceUrl, productId, marketplace }
  let SRC_VMAP = {};   // variantSku -> { source, asin, productId }

  async function loadSourceMaps() {
    const s = await new Promise((r) => chrome.storage.local.get(['unicornds_sku_dictionary', 'unicornds_variant_map'], r));
    SRC_DICT = s.unicornds_sku_dictionary || {};
    SRC_VMAP = s.unicornds_variant_map || {};
  }

  function lookupRecord(sku) {
    if (!sku) return null;
    const clean = sku.replace(/_V\d+$/i, '');
    return SRC_DICT[sku] || SRC_DICT[clean] ||
           SRC_VMAP[sku] || SRC_VMAP[clean] || null;
  }

  // Returns { isAmazon, url } or null (not Amazon / cannot resolve).
  function resolveAmazon(sku, amzDomain) {
    if (!sku) return null;
    const clean = sku.replace(/_V\d+$/i, '');

    // 1) Recorded source wins.
    const rec = lookupRecord(sku);
    if (rec && (rec.source === 'amazon' || (rec.sourceUrl || '').includes('amazon'))) {
      // Prefer a recorded ASIN, else a recorded amazon URL, else build from productId.
      const asin = rec.asin || (clean.match(/\bB0[A-Z0-9]{8}\b/i) || [])[0] || rec.productId;
      if (rec.sourceUrl && rec.sourceUrl.includes('amazon')) return { isAmazon: true, url: rec.sourceUrl };
      if (asin && /^B0[A-Z0-9]{8}$/i.test(asin)) return { isAmazon: true, url: amazonUrl(asin, amzDomain) };
      if (asin) return { isAmazon: true, url: amazonUrl(asin, amzDomain) };
    }
    if (rec && (rec.source === 'aliexpress' || (rec.sourceUrl || '').includes('aliexpress'))) {
      return null; // recorded as AliExpress → not our job
    }

    // 2) No record → fall back to SKU format ONLY if it's an unmistakable Amazon SKU.
    let m = clean.match(/UDS-AZ-([A-Z0-9]{10})/i);
    if (m) return { isAmazon: true, url: amazonUrl(m[1].toUpperCase(), amzDomain) };
    m = clean.match(/^(B0[A-Z0-9]{8})$/i);
    if (m) return { isAmazon: true, url: amazonUrl(m[1].toUpperCase(), amzDomain) };

    return null; // can't confirm Amazon → skip
  }

  function amazonUrl(asin, amzDomain) {
    return `https://www.amazon.${amzDomain}/dp/${asin}?th=1&psc=1`;
  }

  function getAmzDomain(store) {
    const m2d = { com: 'com', co_uk: 'co.uk', de: 'de', com_au: 'com.au', ca: 'ca', fr: 'fr', it: 'it', es: 'es', nl: 'nl' };
    return (store && store.domain) || m2d[store && store.unicornds_primary_market] || 'co.uk';
  }

  // ── ROW HIGHLIGHT ───────────────────────────────────────────────────
  const COLORS = {
    in_stock: '#d1f2b8',      // green
    out_of_stock: '#fdd2da',  // pink/red
    rule_fail: '#fde9c8',     // amber — in stock but fails a rule (never ended)
    unknown: '#eeeeee',       // grey
    checking: '#fff3cd',      // amber
    changed: '#c9e6ff',       // blue (after apply)
  };
  function paintRow(itemNumber, key) {
    const row = findRowByItemId(itemNumber);
    if (row) row.style.backgroundColor = COLORS[key] || '';
  }
  function clearAllPaint() {
    for (const row of getRows()) row.style.backgroundColor = '';
  }

  // Extra stock-removal rules (free shipping / delivery / Prime).
  let CHECK_OPTS = { requireFreeShipping: false, maxDeliveryDays: 0, primeOnly: false };
  let DEEP_MODE = true; // open Amazon page (accurate) vs quick raw-HTML

  const SETTINGS_KEY = 'unicornds_stock_monitor_settings';

  function readRuleOpts() {
    const fs = document.getElementById('uds-sm-freeship');
    const md = document.getElementById('uds-sm-maxdays');
    const pr = document.getElementById('uds-sm-prime');
    const dp = document.getElementById('uds-sm-deep');
    const rq = document.getElementById('uds-sm-restock-qty');
    const ro = document.getElementById('uds-sm-restock-on');
    CHECK_OPTS = {
      requireFreeShipping: fs ? fs.checked : false,
      maxDeliveryDays: md ? (Math.max(0, Math.min(90, parseInt(md.value, 10) || 0))) : 0,
      primeOnly: pr ? pr.checked : false,
    };
    DEEP_MODE = dp ? dp.checked : true;
    // Persist so the toggles stay how you set them next time.
    try {
      chrome.storage.local.set({ [SETTINGS_KEY]: {
        ...CHECK_OPTS, deepMode: DEEP_MODE,
        restockQty: rq ? (parseInt(rq.value, 10) || CFG.DEFAULT_RESTOCK_QTY) : CFG.DEFAULT_RESTOCK_QTY,
        restockOn: ro ? ro.checked : false,
      }});
    } catch (e) {}
    return CHECK_OPTS;
  }

  async function loadSavedSettings() {
    try {
      const s = await new Promise((r) => chrome.storage.local.get(SETTINGS_KEY, r));
      const v = s[SETTINGS_KEY];
      if (!v) return;
      const set = (id, val, prop) => { const el = document.getElementById(id); if (el != null && val != null) el[prop] = val; };
      set('uds-sm-freeship', !!v.requireFreeShipping, 'checked');
      set('uds-sm-maxdays', v.maxDeliveryDays != null ? v.maxDeliveryDays : 0, 'value');
      set('uds-sm-prime', !!v.primeOnly, 'checked');
      if (v.deepMode != null) set('uds-sm-deep', !!v.deepMode, 'checked');
      set('uds-sm-restock-qty', v.restockQty != null ? v.restockQty : CFG.DEFAULT_RESTOCK_QTY, 'value');
      set('uds-sm-restock-on', !!v.restockOn, 'checked');
    } catch (e) {}
  }

  // ── AMAZON CHECK (via background) — deep (tab) or quick (raw HTML) ──
  // Hard client-side timeout so a hung check can never freeze the loop.
  function checkAmazon(url) {
    const msgType = DEEP_MODE ? 'uds_check_amazon_stock_deep' : 'uds_check_amazon_stock';
    const timeoutMs = DEEP_MODE ? 32000 : 18000;
    return new Promise((resolve) => {
      let done = false;
      const finish = (val) => { if (!done) { done = true; resolve(val); } };
      const timer = setTimeout(() => finish({ status: 'unknown', reason: 'timeout', blocked: true }), timeoutMs);
      try {
        chrome.runtime.sendMessage({ type: msgType, url, opts: CHECK_OPTS }, (res) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError || !res) {
            finish({ status: 'unknown', reason: chrome.runtime.lastError?.message || 'no response' });
            return;
          }
          finish(res);
        });
      } catch (e) {
        clearTimeout(timer);
        finish({ status: 'unknown', reason: 'send error: ' + e.message });
      }
    });
  }

  // One automatic retry when Amazon blocks a specific item (captcha), so
  // scattered blocks recover instead of ending up "unclear".
  async function checkAmazonSafe(url) {
    let r = await checkAmazon(url);
    if (r && r.blocked && DEEP_MODE) {
      await sleep(6000);
      r = await checkAmazon(url);
    }
    return r;
  }

  // ── eBay INLINE QUANTITY EDIT (the safe write) ──────────────────────
  // Sets a value on a React-controlled input so the framework registers it.
  function setNativeValue(input, value) {
    const proto = Object.getPrototypeOf(input);
    const desc = Object.getOwnPropertyDescriptor(proto, 'value') ||
                 Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    if (desc && desc.set) desc.set.call(input, value);
    else input.value = value;
  }

  function findQtyInput() {
    return document.querySelector('form[class*="inline-edit-"] input') ||
           document.querySelector('form[class*="quick-edit"] input') ||
           document.querySelector('input[name*="quantity" i]') ||
           document.querySelector('input[type="number"]');
  }

  function findSaveButton(input) {
    let btn = document.querySelector('form[class*="inline-edit-"] button[type="submit"]') ||
              document.querySelector('form[class*="quick-edit-field"] [type="submit"]') ||
              document.querySelector('form[class*="quick-edit"] button[type="submit"]');
    if (!btn && input) {
      const form = input.closest('form');
      if (form) btn = form.querySelector('button[type="submit"], [type="submit"]');
    }
    return btn;
  }

  /**
   * Set quantity on ONE listing through eBay's own inline edit.
   * Re-verifies the row by item id right before writing.
   * Returns { ok, reason }.
   */
  // Poll for a value until it appears or times out.
  function waitFor(fn, ms) {
    return new Promise((resolve) => {
      const start = Date.now();
      let v; try { v = fn(); } catch (e) { v = null; }
      if (v) return resolve(v);
      const iv = setInterval(() => {
        try { v = fn(); } catch (e) { v = null; }
        if (v || Date.now() - start > ms) { clearInterval(iv); resolve(v || null); }
      }, 150);
    });
  }

  // eBay shows Save/Cancel in the row when a cell is being edited.
  function findSaveInRow(row) {
    const btns = [...row.querySelectorAll('button, [role="button"], a')];
    return btns.find((b) => /^\s*save\s*$/i.test(b.textContent || '')) ||
           btns.find((b) => /save/i.test(b.getAttribute && (b.getAttribute('aria-label') || ''))) || null;
  }

  // A synthetic .click() often doesn't trigger React grid editors — fire a full
  // pointer/mouse gesture so eBay's handlers open the inline editor.
  function fireRealClick(el) {
    if (!el) return;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const opts = { bubbles: true, cancelable: true, view: window };
    ['pointerover', 'pointerenter', 'pointerdown', 'mousedown', 'focus', 'pointerup', 'mouseup', 'click'].forEach((t) => {
      try {
        const Ev = (t.startsWith('pointer')) ? (window.PointerEvent || MouseEvent) : (t === 'focus' ? FocusEvent : MouseEvent);
        el.dispatchEvent(new Ev(t, opts));
      } catch (e) { try { el.dispatchEvent(new Event(t, { bubbles: true })); } catch (e2) {} }
    });
  }

  function pressEnter(el) {
    ['keydown', 'keypress', 'keyup'].forEach((t) => {
      try {
        el.dispatchEvent(new KeyboardEvent(t, {
          key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
          charCode: t === 'keypress' ? 13 : 0, bubbles: true, cancelable: true,
        }));
      } catch (e) {}
    });
  }

  async function setRowQuantity(itemNumber, expectedOldQty, newQty) {
    let row = findRowByItemId(itemNumber);
    if (!row) return { ok: false, reason: 'row not on this page' };

    if (readRow(row).qty === newQty) return { ok: true, reason: 'already ' + newQty };

    const cell = row.querySelector('td[class*="availableQuantity"]');
    if (!cell) return { ok: false, reason: 'qty cell not found' };

    // eBay's inline edit trigger. Disabled + title "Not editable" = this listing
    // can't be inline-edited (variation / locked) — report clearly and skip.
    const editBtn = cell.querySelector('button.inline-editable-icon:not([disabled])') ||
                    cell.querySelector('button.icon-btn:not([disabled])');
    if (!editBtn) {
      const disabled = cell.querySelector('button.inline-editable-icon[disabled], button[title="Not editable" i]');
      return { ok: false, reason: disabled ? 'not inline-editable (variation/locked listing)' : 'no edit button in qty cell' };
    }
    editBtn.click();
    fireRealClick(editBtn);

    // The real quantity input: name="members[N][availableQuantity]", aria-label
    // "Edit quantity". Scope to the row; never the page-wide search box.
    const input = await waitFor(() =>
      cell.querySelector('input[name*="availableQuantity" i]') ||
      cell.querySelector('input[aria-label="Edit quantity" i]') ||
      row.querySelector('input[name*="availableQuantity" i]') ||
      row.querySelector('input[aria-label="Edit quantity" i]'), 5000);
    if (!input) return { ok: false, reason: 'quantity input did not open' };

    try { input.focus(); } catch (e) {}
    setNativeValue(input, String(newQty));
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(350);

    // There is NO Save button on this editor — commit by pressing Enter, then
    // blur as a backup (these inline editors save on Enter or focus-out).
    pressEnter(input);
    await sleep(300);
    try { input.blur(); } catch (e) {}
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    input.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    // If a Save button happens to exist on some accounts, click it too.
    const maybeSave = row.querySelector('button.save:not([disabled])');
    if (maybeSave) fireRealClick(maybeSave);
    await sleep(CFG.EDIT_SAVE_WAIT_MS);

    const freshRow = findRowByItemId(itemNumber) || row;
    const finalQty = readRow(freshRow).qty;
    if (finalQty === newQty) return { ok: true, reason: 'saved' };
    return { ok: false, reason: 'save not confirmed (cell shows ' + finalQty + ')' };
  }

  // ── UNDO LOG ────────────────────────────────────────────────────────
  async function appendLog(entries) {
    const s = await new Promise((r) => chrome.storage.local.get(CFG.STORE_LOG_KEY, r));
    const log = s[CFG.STORE_LOG_KEY] || [];
    log.push({ ts: Date.now(), entries });
    // keep last 20 batches
    while (log.length > 20) log.shift();
    await new Promise((r) => chrome.storage.local.set({ [CFG.STORE_LOG_KEY]: log }, r));
  }
  async function getLastLog() {
    const s = await new Promise((r) => chrome.storage.local.get(CFG.STORE_LOG_KEY, r));
    const log = s[CFG.STORE_LOG_KEY] || [];
    return log.length ? log[log.length - 1] : null;
  }
  async function popLastLog() {
    const s = await new Promise((r) => chrome.storage.local.get(CFG.STORE_LOG_KEY, r));
    const log = s[CFG.STORE_LOG_KEY] || [];
    const last = log.pop() || null;
    await new Promise((r) => chrome.storage.local.set({ [CFG.STORE_LOG_KEY]: log }, r));
    return last;
  }

  // ── SCAN ────────────────────────────────────────────────────────────
  // ── SCAN ALL PAGES (walks every page automatically) ─────────────────
  // eBay paginates via ?offset=N&limit=200. We save state to storage, scan the
  // current page, then navigate to the next offset. On reload we resume. This
  // is READ-ONLY across pages (it never writes while paging). Applying stays
  // per-page and manual for safety.
  const RUN_KEY = 'uds_sm_runstate';
  const getLS = (keys) => new Promise((r) => chrome.storage.local.get(keys, r));
  const setLS = (obj) => new Promise((r) => chrome.storage.local.set(obj, r));

  function baseUrl() { return location.origin + location.pathname; }
  function urlOffset() { return parseInt(new URLSearchParams(location.search).get('offset') || '0', 10) || 0; }
  function urlLimit() { return parseInt(new URLSearchParams(location.search).get('limit') || '200', 10) || 200; }
  function readTotalCount() {
    const t = (document.body.innerText || '');
    let m = t.match(/of\s+([\d,]+)\b/);
    if (m) return parseInt(m[1].replace(/,/g, ''), 10);
    m = t.match(/active listings\s*\(([\d,]+)\)/i);
    if (m) return parseInt(m[1].replace(/,/g, ''), 10);
    return null;
  }
  function pageUrl(offset, limit) { return `${baseUrl()}?offset=${offset}&limit=${limit}&sort=title`; }

  async function startScanAll(opts) {
    const store = await getLS(['domain', 'unicornds_primary_market']);
    const amzDomain = getAmzDomain(store);
    const limit = 200;
    const rs = {
      mode: 'scanall', active: true,
      restockEnabled: opts.restockEnabled, restockQty: opts.restockQty,
      amzDomain, results: [], total: readTotalCount(), limit,
      pagesDone: 0, blocks: 0, startedAt: Date.now(), abort: false,
      checkOpts: CHECK_OPTS,
    };
    await setLS({ [RUN_KEY]: rs });
    // Jump to first page to start clean.
    location.href = pageUrl(0, limit);
  }

  async function stopScanAll() {
    const s = await getLS(RUN_KEY);
    const rs = s[RUN_KEY];
    if (rs) { rs.active = false; rs.abort = true; await setLS({ [RUN_KEY]: rs }); }
    SCANNING = false;
    setStatus('Scan-all stopped.');
  }

  async function resumeScanAllIfNeeded() {
    const s = await getLS(RUN_KEY);
    const rs = s[RUN_KEY];
    if (!rs || !rs.active) return false;

    openPanel();
    setStatus('Scan all pages: waiting for this page to load…');

    // Wait for the grid to render.
    let waited = 0;
    while (getRows().length === 0 && waited < 20000) { await sleep(500); waited += 500; }
    if (getRows().length === 0) {
      setStatus('Scan all: page did not load rows, stopping. You can retry.');
      rs.active = false; await setLS({ [RUN_KEY]: rs });
      return true;
    }

    await loadSourceMaps();
    if (rs.checkOpts) CHECK_OPTS = rs.checkOpts; // keep the same rules across pages
    if (!rs.total) rs.total = readTotalCount();
    const offset = urlOffset();
    const limit = rs.limit || urlLimit();

    // Build Amazon targets on this page
    const targets = [];
    for (const row of getRows()) {
      const d = readRow(row);
      if (!d.itemNumber || d.isMsku) continue;
      const az = resolveAmazon(d.sku, rs.amzDomain);
      if (az && az.isAmazon) targets.push({ ...d, url: az.url });
    }

    SCANNING = true;
    const pageNo = Math.floor(offset / limit) + 1;
    const totalPages = rs.total ? Math.ceil(rs.total / limit) : '?';

    for (let i = 0; i < targets.length; i++) {
      if (rs.abort || !SCANNING) break;
      const t = targets[i];
      paintRow(t.itemNumber, 'checking');
      setStatus(`Scan all — page ${pageNo}/${totalPages}: checking ${i + 1}/${targets.length} on this page (${rs.results.length} found so far)`);
      const res = await checkAmazonSafe(t.url);
      const status = res.status || 'unknown';
      let action = 'none', newQty = null;
      if (status === 'out_of_stock' && t.qty > 0) { action = 'set_zero'; newQty = 0; }
      else if (status === 'in_stock' && rs.restockEnabled && t.qty <= 0) { action = 'restock'; newQty = rs.restockQty; }
      rs.results.push({ itemNumber: t.itemNumber, sku: t.sku, title: t.title, qty: t.qty, status, reason: res.reason || '', action, newQty, page: pageNo });
      paintRow(t.itemNumber, status);
      if (res.blocked) rs.blocks++; else rs.blocks = 0;
      if (res.blocked && rs.blocks >= CFG.CONSECUTIVE_BLOCK_ABORT) {
        setStatus('⚠️ Amazon is blocking us. Stopping scan-all. Partial results kept.');
        rs.active = false; rs.abort = true; await setLS({ [RUN_KEY]: rs });
        SCANNING = false; finishScanAll(rs); return true;
      }
      if (i < targets.length - 1 && !rs.abort) await sleep(jitter());
    }
    SCANNING = false;

    rs.pagesDone++;
    await setLS({ [RUN_KEY]: rs });

    const nextOffset = offset + limit;
    if (!rs.abort && rs.total && nextOffset < rs.total) {
      setStatus(`Page ${pageNo}/${totalPages} done. ${rs.results.length} found so far. Loading next page…`);
      await sleep(1500);
      location.href = pageUrl(nextOffset, limit);
      return true;
    }

    // Done.
    rs.active = false;
    await setLS({ [RUN_KEY]: rs });
    finishScanAll(rs);
    return true;
  }

  function finishScanAll(rs) {
    // Load the full cross-page results into LAST_SCAN so the report + per-page apply work.
    LAST_SCAN = rs.results.slice();
    const changes = LAST_SCAN.filter((r) => r.action !== 'none');
    const oos = LAST_SCAN.filter((r) => r.status === 'out_of_stock').length;
    const ins = LAST_SCAN.filter((r) => r.status === 'in_stock').length;
    const rf = LAST_SCAN.filter((r) => r.status === 'rule_fail').length;
    const unk = LAST_SCAN.filter((r) => r.status === 'unknown').length;
    setStatus(`Scan-all finished. ${LAST_SCAN.length} Amazon listings: ${oos} OUT OF STOCK (only these can be ended), ${ins} in stock, ${rf} in stock but fail a rule (NOT ended), ${unk} unclear.`);
    renderResults(true);
  }

  async function runScan(opts) {
    if (SCANNING || APPLYING) return;
    SCANNING = true;
    LAST_SCAN = [];
    clearAllPaint();
    setStatus('Preparing scan…');
    setProgress(0, 0);

    const store = await new Promise((r) => chrome.storage.local.get(['domain', 'unicornds_primary_market'], r));
    const amzDomain = getAmzDomain(store);
    await loadSourceMaps();

    // Build the list of Amazon rows to check
    const rows = getRows();
    const targets = [];
    let skipped = 0;
    for (const row of rows) {
      const d = readRow(row);
      if (!d.itemNumber) { skipped++; continue; }
      if (d.isMsku) { paintRow(d.itemNumber, 'unknown'); skipped++; continue; }
      const az = resolveAmazon(d.sku, amzDomain);
      if (!az || !az.isAmazon) { paintRow(d.itemNumber, 'unknown'); skipped++; continue; } // non-Amazon → skip
      targets.push({ ...d, url: az.url });
    }

    if (!targets.length) {
      setStatus(`No Amazon listings found on this page. (${skipped} skipped)`);
      SCANNING = false;
      return;
    }

    const cap = Math.min(targets.length, CFG.MAX_PER_RUN);
    setStatus(`Scanning ${cap} Amazon listing(s)… ${skipped} skipped (non-Amazon / variations).`);

    let consecutiveBlocks = 0;
    let done = 0;
    let aborted = false;

    for (let i = 0; i < cap; i++) {
      if (!SCANNING) { aborted = true; break; } // user pressed Stop
      const t = targets[i];
      paintRow(t.itemNumber, 'checking');
      setProgress(done, cap);

      const res = await checkAmazonSafe(t.url);
      const status = res.status || 'unknown';
      const price = res.price || '';
      const reason = res.reason || '';

      // Decide the recommended action (but DO NOT apply)
      let action = 'none';
      let newQty = null;
      if (status === 'out_of_stock' && t.qty > 0) {
        action = 'set_zero'; newQty = 0;
      } else if (status === 'in_stock' && opts.restockEnabled && t.qty <= 0) {
        action = 'restock'; newQty = opts.restockQty;
      }

      LAST_SCAN.push({
        itemNumber: t.itemNumber, sku: t.sku, title: t.title,
        qty: t.qty, status, price, reason, action, newQty, asin: t.asin,
      });

      paintRow(t.itemNumber, status);

      // Block back-off logic
      if (res.blocked) consecutiveBlocks++;
      else consecutiveBlocks = 0;
      if (res.blocked && consecutiveBlocks >= CFG.CONSECUTIVE_BLOCK_ABORT) {
        setStatus(`⚠️ Amazon looks like it is blocking us. Stopped early after ${done + 1} checks. Try again later.`);
        aborted = true;
        break;
      }

      done++;
      setProgress(done, cap);
      renderResults();

      if (i < cap - 1 && SCANNING) await sleep(jitter());
    }

    SCANNING = false;
    if (!aborted) {
      const changes = LAST_SCAN.filter((r) => r.action !== 'none').length;
      setStatus(`Scan complete. ${done} checked, ${skipped} skipped. ${changes} change(s) suggested — review below, then Apply.`);
    }
    setProgress(done, cap);
    renderResults();
  }

  // ── APPLY (writes quantities, one at a time) ────────────────────────
  async function applyChanges() {
    if (SCANNING || APPLYING) return;
    const allChanges = LAST_SCAN.filter((r) => r.action !== 'none' && !r.applied);
    if (!allChanges.length) { setStatus('Nothing to apply.'); return; }

    // Only apply changes whose listing row is actually on THIS page (edits need the row on screen).
    const changes = allChanges.filter((c) => !!findRowByItemId(c.itemNumber));
    const offPage = allChanges.length - changes.length;

    if (!changes.length) {
      setStatus(`None of the ${allChanges.length} pending change(s) are on this page. Use the page numbers at the bottom of eBay to go to the page, then Apply again.`);
      return;
    }

    const zeros = changes.filter((c) => c.action === 'set_zero').length;
    const restocks = changes.filter((c) => c.action === 'restock').length;
    const ok = confirm(
      `Apply ${changes.length} change(s) on THIS page?\n\n` +
      `• Set quantity to 0 (remove from sale): ${zeros}\n` +
      `• Restock: ${restocks}\n` +
      (offPage ? `\n${offPage} more change(s) are on other pages — go to those pages and Apply again.\n` : '') +
      `\nThis edits your live listings via eBay's own quantity editor.\n` +
      `Every change is logged so you can Undo.`
    );
    if (!ok) return;

    APPLYING = true;
    const applied = [];
    let i = 0;
    for (const c of changes) {
      if (!APPLYING) break; // user stopped
      i++;
      setStatus(`Applying ${i}/${changes.length}: ${c.action === 'set_zero' ? 'set 0' : 'restock ' + c.newQty} — ${short(c.title)}`);
      const r = await setRowQuantity(c.itemNumber, c.qty, c.newQty);
      if (r.ok) {
        applied.push({ itemNumber: c.itemNumber, sku: c.sku, title: c.title, oldQty: c.qty, newQty: c.newQty });
        paintRow(c.itemNumber, 'changed');
        c.applied = true;
      } else {
        c.applyError = r.reason;
      }
      renderResults();
      await sleep(CFG.APPLY_DELAY_MS);
    }
    APPLYING = false;

    if (applied.length) await appendLog(applied);
    const remaining = LAST_SCAN.filter((r) => r.action !== 'none' && !r.applied).length;
    setStatus(`Done on this page. ${applied.length}/${changes.length} applied.` +
              (remaining ? ` ${remaining} change(s) remain on other pages.` : '') +
              (applied.length ? ' Undo available.' : ''));
    renderResults();
  }

  // ── APPLY ACROSS ALL PAGES (navigates to each page, applies, resumes) ──
  const APPLY_KEY = 'uds_sm_applystate';

  async function startApplyAllPages() {
    if (SCANNING || APPLYING) return;
    const pending = LAST_SCAN.filter((r) => r.action !== 'none' && !r.applied);
    if (!pending.length) { setStatus('Nothing to apply.'); return; }
    const zeros = pending.filter((c) => c.action === 'set_zero').length;
    const restocks = pending.filter((c) => c.action === 'restock').length;
    const ok = confirm(
      `Apply ${pending.length} change(s) across ALL pages?\n\n` +
      `• Set quantity to 0 (remove from sale): ${zeros}\n` +
      `• Restock: ${restocks}\n\n` +
      `The page will move to each page that has a change and apply it using eBay's own quantity editor. ` +
      `Every change is logged so you can Undo.\n\nStart?`
    );
    if (!ok) return;

    const limit = 200;
    const state = {
      active: true, limit, navigations: 0,
      changes: pending.map((c) => ({
        itemNumber: c.itemNumber, sku: c.sku, title: c.title,
        qty: c.qty, newQty: c.newQty, action: c.action,
        page: c.page || (Math.floor(urlOffset() / limit) + 1),
        applied: false, error: null,
      })),
      appliedLog: [],
    };
    await setLS({ [APPLY_KEY]: state });

    const first = state.changes.find((c) => !c.applied);
    const firstPage = first ? first.page : (Math.floor(urlOffset() / limit) + 1);
    const targetOffset = (firstPage - 1) * limit;
    if (targetOffset === urlOffset()) resumeApplyAllIfNeeded();      // already here
    else location.href = pageUrl(targetOffset, limit);
  }

  async function resumeApplyAllIfNeeded() {
    const s = await getLS(APPLY_KEY);
    const st = s[APPLY_KEY];
    if (!st || !st.active) return false;

    openPanel();
    setStatus('Apply all pages: waiting for this page to load…');
    let waited = 0;
    while (getRows().length === 0 && waited < 20000) { await sleep(500); waited += 500; }

    const curPage = Math.floor(urlOffset() / st.limit) + 1;
    APPLYING = true;

    for (const c of st.changes) {
      if (c.applied || c.error) continue;
      const row = findRowByItemId(c.itemNumber);
      if (!row) continue; // not on this page
      setStatus(`Apply all — page ${curPage}: ${c.action === 'set_zero' ? 'set 0' : 'restock ' + c.newQty} — ${short(c.title)}`);
      const r = await setRowQuantity(c.itemNumber, c.qty, c.newQty);
      if (r.ok) {
        c.applied = true;
        st.appliedLog.push({ itemNumber: c.itemNumber, sku: c.sku, title: c.title, oldQty: c.qty, newQty: c.newQty });
        paintRow(c.itemNumber, 'changed');
      } else {
        c.error = r.reason;
      }
      await setLS({ [APPLY_KEY]: st });
      await sleep(CFG.APPLY_DELAY_MS);
    }
    APPLYING = false;

    // Any change that claimed to be on this page but wasn't found → mark done
    // with an error, so we never loop back to this page for it.
    for (const c of st.changes) {
      if (!c.applied && !c.error && c.page === curPage && !findRowByItemId(c.itemNumber)) {
        c.error = 'not found on page ' + curPage + ' (listing moved?)';
      }
    }
    st.navigations = (st.navigations || 0) + 1;
    await setLS({ [APPLY_KEY]: st });

    // Next page that still has an unresolved change.
    const next = st.changes.find((c) => !c.applied && !c.error && c.page && c.page !== curPage);
    if (next && st.navigations < 40) {
      setStatus(`Page ${curPage} done. Moving to page ${next.page}…`);
      await sleep(1200);
      location.href = pageUrl((next.page - 1) * st.limit, st.limit);
      return true;
    }

    // Finished.
    st.active = false;
    await setLS({ [APPLY_KEY]: st });
    if (st.appliedLog.length) await appendLog(st.appliedLog);
    const done = st.changes.filter((c) => c.applied).length;
    const errList = st.changes.filter((c) => c.error);
    // Surface the results (with reasons) in the table so failures are visible.
    LAST_SCAN = st.changes.map((c) => ({
      itemNumber: c.itemNumber, sku: c.sku, title: c.title, qty: c.qty,
      status: c.applied ? 'in_stock' : 'out_of_stock', reason: c.error || 'applied',
      action: c.action, newQty: c.newQty, applied: c.applied, applyError: c.error,
    }));
    renderResults(true);
    const reasons = [...new Set(errList.map((c) => c.error))];
    setStatus(`Apply-all finished. ${done} applied` +
              (errList.length ? `, ${errList.length} could not be applied — ${reasons.join('; ')}` : '') +
              (done ? '. Undo available.' : ''));
    return true;
  }

  async function stopApplyAll() {
    const s = await getLS(APPLY_KEY);
    const st = s[APPLY_KEY];
    if (st) { st.active = false; await setLS({ [APPLY_KEY]: st }); }
  }

  // ── SELECT out-of-stock rows via eBay's own checkboxes ──────────────
  // eBay blocks inline quantity editing on many stores, but its native BULK
  // edit works. We tick the checkboxes of the pending items so the user can run
  // eBay's Edit → Quantity → 0. Checkbox id format: shui-dt-checkone-{itemId}.
  async function selectPendingCheckboxes(actionFilter) {
    const pend = LAST_SCAN.filter((r) => (actionFilter ? r.action === actionFilter : r.action !== 'none') && !r.applied);
    if (!pend.length) { setStatus('Nothing to select — run a scan first.'); return; }
    let selected = 0, otherPage = 0;
    for (const c of pend) {
      const cb = document.getElementById('shui-dt-checkone-' + c.itemNumber) ||
                 document.querySelector('input[name="shui-dt-check"][value="' + c.itemNumber + '"]');
      if (!cb) { otherPage++; continue; }
      if (!cb.checked) {
        fireRealClick(cb);
        if (!cb.checked) { cb.checked = true; cb.dispatchEvent(new Event('change', { bubbles: true })); cb.dispatchEvent(new Event('click', { bubbles: true })); }
      }
      selected++;
      paintRow(c.itemNumber, 'checking');
      await sleep(70);
    }
    setStatus(
      `✅ Selected ${selected} item(s) on this page` +
      (otherPage ? ` (${otherPage} are on other pages — repeat there)` : '') +
      `. Now use eBay's blue "Edit" button → Quantity → set 0 → Submit. eBay applies it to all selected.`
    );
  }

  // ── END OUT-OF-STOCK (per-row action menu → End listing → confirm) ──
  // eBay's End is NOT a bulk-bar button — it lives in each row's "..." menu.
  // This mirrors EcomSniper's proven flow.
  const END_KEY = 'uds_sm_endstate';

  const END_LABELS = [
    'end listing', 'end item', 'angebot beenden', "mettre fin à l'annonce",
    "chiudi l'inserzione", 'finalizar anuncio', 'aanbieding beëindigen',
  ];
  const matchesEnd = (txt) => {
    const t = (txt || '').trim().toLowerCase();
    return END_LABELS.some((l) => t === l || t.startsWith(l));
  };

  // End ONE row via its action menu. Returns { ok, reason }.
  // Tick a checkbox so eBay REGISTERS the selection (enables the Actions button).
  // A plain .click() does not — eBay needs this exact event sequence.
  function tickCheckbox(cb) {
    if (!cb) return;
    ['pointerdown', 'mousedown', 'click'].forEach((t) => {
      try { cb.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })); } catch (e) {}
    });
    cb.checked = true;
    cb.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Tick eBay's own checkboxes for the given items on THIS page.
  async function tickCheckboxes(items) {
    const ticked = [];
    for (const c of items) {
      const cb = document.getElementById('shui-dt-checkone-' + c.itemNumber) ||
                 document.querySelector('input[name="shui-dt-check"][value="' + c.itemNumber + '"]');
      if (!cb) continue;
      if (!cb.checked) tickCheckbox(cb);
      ticked.push(c);
      paintRow(c.itemNumber, 'checking');
      await sleep(80);
    }
    return ticked;
  }
  function untickAll(items) {
    items.forEach((c) => {
      const cb = document.getElementById('shui-dt-checkone-' + c.itemNumber);
      if (cb && cb.checked) { cb.checked = false; cb.dispatchEvent(new Event('change', { bubbles: true })); }
    });
  }

  // Find a button by exact text (used for the bulk action bar: "Actions", "End listings").
  function findButtonByText(labels, root) {
    const scope = root || document;
    const wanted = labels.map((l) => l.toLowerCase());
    return [...scope.querySelectorAll('button, a, [role="menuitem"], [role="button"]')]
      .find((b) => wanted.includes((b.textContent || '').trim().toLowerCase()) && !b.disabled && b.offsetParent !== null) || null;
  }

  // Drive eBay's native bulk End: wait for "Actions" to enable → open it →
  // click "End listings" (a hidden fake-menu-button__item until the menu opens).
  async function bulkEndSelected() {
    const textOf = (b) => (b.textContent || '').trim().toLowerCase();

    // "Actions" starts disabled and enables once eBay registers the selection.
    const actionsBtn = await waitFor(() => {
      const b = [...document.querySelectorAll('button')].find((x) => textOf(x) === 'actions' && !x.disabled && x.offsetParent !== null);
      return b || null;
    }, 6000);
    if (!actionsBtn) return { ok: false, reason: 'Actions button stayed disabled (selection not registered)' };

    fireRealClick(actionsBtn);

    // "End listings" is a fake-menu-button__item, hidden until the menu opens.
    const endBtn = await waitFor(() =>
      [...document.querySelectorAll('button.fake-menu-button__item, [class*="menu-button__item"], [role="menuitem"]')]
        .find((b) => textOf(b) === 'end listings' || textOf(b) === 'end listing'), 4000);
    if (!endBtn) return { ok: false, reason: '"End listings" not found after opening Actions' };
    await sleep(300);
    fireRealClick(endBtn);

    // Confirmation dialog → click the primary "End listing" button.
    // Exact structure (captured): button.btn--primary inside
    // .se-end-listing__footer-actions > .se-end-listing__footer > .se-end-listing > .dialog__content
    const findConfirm = () => {
      // 1) Most specific: the footer-actions primary button.
      let b = document.querySelector('.se-end-listing__footer-actions button.btn--primary, .se-end-listing__footer button.btn--primary, .se-end-listing button.btn--primary');
      if (b && b.offsetParent !== null && !b.disabled) return b;
      // 2) Any primary button inside the end-listing dialog.
      const panel = document.querySelector('.se-end-listing, [class*="se-end-listing"], .dialog__content');
      if (panel) {
        b = [...panel.querySelectorAll('button')].find((x) => x.offsetParent !== null && !x.disabled && /btn--primary|primary/i.test(x.className || ''));
        if (b) return b;
        b = [...panel.querySelectorAll('button')].find((x) => x.offsetParent !== null && !x.disabled && textOf(x) === 'end listing');
        if (b) return b;
      }
      // 3) Global fallback: a visible primary button labelled exactly "End listing".
      b = [...document.querySelectorAll('button.btn--primary')].find((x) => x.offsetParent !== null && !x.disabled && textOf(x) === 'end listing');
      return b || null;
    };

    const confirmBtn = await waitFor(findConfirm, 8000);
    if (!confirmBtn) return { ok: false, reason: 'End dialog opened, but confirm button not matched' };
    await sleep(500);
    fireRealClick(confirmBtn);
    // A moment later, if the dialog is still open, try once more.
    await sleep(800);
    if (findConfirm()) { fireRealClick(findConfirm()); }

    await waitFor(() => document.querySelector('.inline-notice--confirmation, [class*="confirmation"]'), 6000);
    return { ok: true };
  }

  async function endOutOfStockThisPage() {
    if (SCANNING || APPLYING) return;
    const oos = LAST_SCAN.filter((r) => r.status === 'out_of_stock' && !r.ended);
    const onPage = oos.filter((c) => findRowByItemId(c.itemNumber));
    const otherPage = oos.length - onPage.length;
    if (!onPage.length) {
      setStatus(`No out-of-stock items on this page${otherPage ? ` (${otherPage} on other pages)` : ''}.`);
      return;
    }
    const ok = confirm(
      `END ${onPage.length} out-of-stock listing(s) on this page?\n\n` +
      `⚠️ Permanent — relist needed to sell again. Cannot be undone.\n\n` +
      (otherPage ? `${otherPage} more are on other pages.\n\n` : '') + `Proceed?`
    );
    if (!ok) { setStatus('Cancelled.'); return; }

    APPLYING = true;
    setStatus(`Selecting ${onPage.length} item(s)…`);
    const ticked = await tickCheckboxes(onPage);
    if (!ticked.length) { APPLYING = false; setStatus('Could not select any items (checkboxes not found).'); return; }
    setStatus(`Ending ${ticked.length} listing(s) via eBay's bulk End…`);
    const r = await bulkEndSelected();
    APPLYING = false;
    if (r.ok) {
      ticked.forEach((c) => { c.ended = true; paintRow(c.itemNumber, 'changed'); });
      setStatus(`🛑 Ended ${ticked.length} on this page.` + (otherPage ? ` ${otherPage} remain on other pages.` : ''));
    } else {
      untickAll(ticked);
      setStatus(`Selected ${ticked.length}, but ${r.reason}. Nothing ended.`);
    }
    renderResults(true);
  }

  async function startEndAllPages(itemsOverride, skipConfirm) {
    if (SCANNING || APPLYING) return;
    const src = itemsOverride && itemsOverride.length
      ? itemsOverride
      : LAST_SCAN.filter((r) => r.status === 'out_of_stock' && !r.ended);
    if (!src.length) { setStatus('No out-of-stock items to end.'); return; }
    if (!skipConfirm) {
      const ok = confirm(
        `END ${src.length} out-of-stock listing(s) across ALL pages?\n\n` +
        `⚠️ PERMANENT. Each must be relisted to sell again (new item ID, lost watchers/age/ranking). Cannot be undone.\n\n` +
        `The page will sweep through every page and end these items via eBay's own "End listing".\n\nProceed?`
      );
      if (!ok) return;
    }

    const limit = 200;
    const state = {
      active: true, limit, navigations: 0, endedCount: 0,
      total: readTotalCount() || 999999,
      items: src.map((c) => ({ itemNumber: c.itemNumber, title: c.title || '', ended: false, error: null })),
    };
    await setLS({ [END_KEY]: state });
    const stopBtn = document.getElementById('uds-sm-endstop'); if (stopBtn) stopBtn.style.display = '';
    // Sweep from the FIRST page so we can find items whatever page they're on.
    if (urlOffset() === 0) resumeEndAllIfNeeded();
    else location.href = pageUrl(0, limit);
  }

  async function resumeEndAllIfNeeded() {
    const s = await getLS(END_KEY);
    const st = s[END_KEY];
    if (!st || !st.active) return false;

    openPanel();
    const stopBtn = document.getElementById('uds-sm-endstop'); if (stopBtn) stopBtn.style.display = '';
    setStatus('End all pages: waiting for this page to load…');
    let waited = 0;
    while (getRows().length === 0 && waited < 20000) { await sleep(500); waited += 500; }

    const curPage = Math.floor(urlOffset() / st.limit) + 1;
    APPLYING = true;

    // Tick every pending item on this page, then bulk-end them together.
    const onPage = [];
    for (const c of st.items) {
      if (c.ended || c.error) continue;
      const cb = document.getElementById('shui-dt-checkone-' + c.itemNumber) ||
                 document.querySelector('input[name="shui-dt-check"][value="' + c.itemNumber + '"]');
      if (!cb) continue;
      if (!cb.checked) tickCheckbox(cb);
      onPage.push(c);
      paintRow(c.itemNumber, 'checking');
      await sleep(80);
    }

    if (onPage.length) {
      setStatus(`End all — page ${curPage}: ending ${onPage.length} listing(s) via bulk End…`);
      const r = await bulkEndSelected();
      if (r.ok) {
        onPage.forEach((c) => { c.ended = true; st.endedCount++; paintRow(c.itemNumber, 'changed'); });
      } else {
        onPage.forEach((c) => { c.error = r.reason; });
      }
      await sleep(2500); // let eBay process before navigating
    }

    st.navigations = (st.navigations || 0) + 1;
    await setLS({ [END_KEY]: st });
    APPLYING = false;

    // Sweep to the next page while there are still pending items and pages left.
    const pendingLeft = st.items.filter((c) => !c.ended && !c.error).length;
    const nextOffset = urlOffset() + st.limit;
    if (pendingLeft > 0 && st.active && nextOffset < (st.total || 999999) && st.navigations < 60) {
      setStatus(`Page ${curPage} done (${st.endedCount} ended, ${pendingLeft} left). Next page…`);
      await sleep(1500);
      location.href = pageUrl(nextOffset, st.limit);
      return true;
    }

    st.active = false;
    await setLS({ [END_KEY]: st });
    if (stopBtn) stopBtn.style.display = 'none';
    const errs = st.items.filter((c) => c.error).length;
    setStatus(`End-all finished. ${st.endedCount} ended${errs ? ', ' + errs + ' could not be ended' : ''}${pendingLeft ? ', ' + pendingLeft + ' not found' : ''}.`);
    return true;
  }

  async function stopEndAll() {
    const s = await getLS(END_KEY);
    const st = s[END_KEY];
    if (st) { st.active = false; await setLS({ [END_KEY]: st }); }
    APPLYING = false;
    const stopBtn = document.getElementById('uds-sm-endstop'); if (stopBtn) stopBtn.style.display = 'none';
    setStatus('End-all stopped.');
  }

  // ── UNDO (restore quantities from the last batch) ───────────────────
  async function undoLast() {
    if (SCANNING || APPLYING) return;
    const batch = await getLastLog();
    if (!batch || !batch.entries || !batch.entries.length) { setStatus('Nothing to undo.'); return; }
    const ok = confirm(`Undo last batch of ${batch.entries.length} change(s)? This restores the previous quantities.`);
    if (!ok) return;

    APPLYING = true;
    let restored = 0;
    for (let i = 0; i < batch.entries.length; i++) {
      if (!APPLYING) break;
      const e = batch.entries[i];
      setStatus(`Undoing ${i + 1}/${batch.entries.length}: restore ${e.oldQty} — ${short(e.title)}`);
      const r = await setRowQuantity(e.itemNumber, e.newQty, e.oldQty);
      if (r.ok) { restored++; paintRow(e.itemNumber, 'changed'); }
      await sleep(CFG.APPLY_DELAY_MS);
    }
    APPLYING = false;
    if (restored) await popLastLog();
    setStatus(`Undo complete. ${restored}/${batch.entries.length} restored.`);
  }

  // ── UI ──────────────────────────────────────────────────────────────
  const short = (s) => (s || '').slice(0, 48) + ((s || '').length > 48 ? '…' : '');

  function injectStyles() {
    if (document.getElementById('uds-sm-styles')) return;
    const st = document.createElement('style');
    st.id = 'uds-sm-styles';
    st.textContent = `
      #uds-sm-fab {
        position: fixed; right: 18px; bottom: 150px; z-index: 2147483000;
        background: #1E1B4B; color: #fff; border: 2px solid #F59E0B; border-radius: 999px;
        padding: 12px 18px; font: 700 14px/1 system-ui,sans-serif; cursor: pointer;
        box-shadow: 0 4px 18px rgba(0,0,0,.35); display: flex; align-items: center; gap: 8px;
      }
      #uds-sm-fab:hover { background: #2a2566; }
      #uds-sm-overlay {
        position: fixed; inset: 0; z-index: 2147483001; background: rgba(0,0,0,.45);
        display: none; align-items: center; justify-content: center;
      }
      #uds-sm-overlay.open { display: flex; }
      #uds-sm-panel {
        width: min(920px, 94vw); max-height: 88vh; background: #fff; border-radius: 14px;
        display: flex; flex-direction: column; overflow: hidden; font: 13px/1.4 system-ui,sans-serif;
        box-shadow: 0 20px 60px rgba(0,0,0,.4);
      }
      #uds-sm-head {
        background: #1E1B4B; color: #fff; padding: 14px 18px; display: flex; align-items: center; gap: 10px;
      }
      #uds-sm-head b { font-size: 15px; }
      #uds-sm-head .amz { background:#F59E0B; color:#1E1B4B; font-weight:700; padding:2px 8px; border-radius:6px; font-size:11px; }
      #uds-sm-head .x { margin-left: auto; cursor: pointer; font-size: 20px; opacity: .8; }
      #uds-sm-head .x:hover { opacity: 1; }
      #uds-sm-controls { padding: 12px 18px; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; border-bottom: 1px solid #eee; }
      #uds-sm-controls label { display: flex; align-items: center; gap: 6px; color:#333; }
      #uds-sm-controls input[type=number] { width: 60px; padding: 4px 6px; border: 1px solid #ccc; border-radius: 6px; }
      #uds-sm-rules { padding: 8px 18px; display:flex; flex-wrap:wrap; gap:14px; align-items:center; border-bottom:1px solid #eee; background:#faf9ff; font-size:12px; color:#444; }
      #uds-sm-rules .rules-label { font-weight:700; color:#1E1B4B; }
      #uds-sm-rules label { display:flex; align-items:center; gap:6px; }
      #uds-sm-rules input[type=number] { width: 52px; padding: 3px 5px; border:1px solid #ccc; border-radius:6px; }
      #uds-sm-rules .rules-note { color:#c07a00; font-size:11px; }
      .uds-sm-btn { border: none; border-radius: 8px; padding: 8px 14px; font-weight: 600; cursor: pointer; }
      .uds-sm-btn.primary { background: #7C3AED; color: #fff; }
      .uds-sm-btn.primary:hover { background: #6d28d9; }
      .uds-sm-btn.apply { background: #059669; color: #fff; }
      .uds-sm-btn.apply:hover { background: #047857; }
      .uds-sm-btn.apply:disabled { background: #a7d7c5; cursor: not-allowed; }
      .uds-sm-btn.end { background: #dc2626; color: #fff; }
      .uds-sm-btn.end:hover { background: #b91c1c; }
      .uds-sm-btn.end:disabled { background: #e5a3a3; cursor: not-allowed; }
      .uds-sm-btn.ghost { background: #f1f1f4; color: #333; }
      .uds-sm-btn.ghost:hover { background: #e6e6ea; }
      .uds-sm-btn.stop { background: #dc2626; color: #fff; }
      #uds-sm-status { padding: 8px 18px; color: #444; background:#faf9ff; border-bottom: 1px solid #eee; min-height: 18px; }
      #uds-sm-prog { height: 6px; background:#eee; }
      #uds-sm-prog > div { height: 100%; width: 0; background:#7C3AED; transition: width .2s; }
      #uds-sm-results { overflow: auto; padding: 0; }
      #uds-sm-results table { width: 100%; border-collapse: collapse; }
      #uds-sm-results th, #uds-sm-results td { text-align: left; padding: 7px 10px; border-bottom: 1px solid #f0f0f0; vertical-align: top; }
      #uds-sm-results th { position: sticky; top: 0; background:#fff; font-weight:700; color:#555; }
      .uds-tag { display:inline-block; padding:1px 7px; border-radius: 999px; font-size: 11px; font-weight:700; }
      .uds-tag.in_stock { background:#d1f2b8; color:#256029; }
      .uds-tag.out_of_stock { background:#fdd2da; color:#9b1c31; }
      .uds-tag.rule_fail { background:#fde9c8; color:#8a5a00; }
      .uds-tag.unknown { background:#eee; color:#666; }
      .uds-act { font-weight:700; }
      .uds-act.set_zero { color:#dc2626; }
      .uds-act.restock { color:#059669; }
      .uds-act.none { color:#aaa; }
      .uds-applied { color:#2563eb; font-weight:700; }
      .uds-apperr { color:#dc2626; font-size:11px; }
      #uds-sm-foot { padding: 10px 18px; border-top: 1px solid #eee; display:flex; gap:10px; align-items:center; flex-wrap: wrap; }
      #uds-sm-foot .note { color:#888; font-size: 12px; margin-left:auto; }
    `;
    document.head.appendChild(st);
  }

  function buildPanel() {
    if (document.getElementById('uds-sm-overlay')) return;

    const fab = document.createElement('div');
    fab.id = 'uds-sm-fab';
    fab.innerHTML = '📦 Stock Monitor';
    fab.title = 'Bulk check Amazon listings for out of stock (safe: preview before apply)';
    fab.addEventListener('click', openPanel);
    document.body.appendChild(fab);

    const ov = document.createElement('div');
    ov.id = 'uds-sm-overlay';
    ov.innerHTML = `
      <div id="uds-sm-panel">
        <div id="uds-sm-head">
          <b>🦄 Stock Monitor</b><span class="amz">Amazon only</span>
          <span class="x" id="uds-sm-close">×</span>
        </div>
        <div id="uds-sm-controls">
          <button class="uds-sm-btn primary" id="uds-sm-scan">🔍 Scan this page</button>
          <button class="uds-sm-btn primary" id="uds-sm-scanall">🔄 Scan ALL pages</button>
          <button class="uds-sm-btn stop" id="uds-sm-stop" style="display:none">■ Stop</button>
          <label><input type="checkbox" id="uds-sm-restock-on"> Restock back-in-stock items to
            <input type="number" id="uds-sm-restock-qty" min="1" max="999" value="${CFG.DEFAULT_RESTOCK_QTY}"></label>
          <button class="uds-sm-btn ghost" id="uds-sm-debug" title="Show what UnicornDS recorded for the listings on this page">🔧 Debug source</button>
        </div>
        <div id="uds-sm-rules">
          <span class="rules-label">Extra removal rules:</span>
          <label><input type="checkbox" id="uds-sm-freeship"> Require free shipping</label>
          <label>Max delivery days <input type="number" id="uds-sm-maxdays" min="0" max="90" value="0"></label>
          <label><input type="checkbox" id="uds-sm-prime"> Prime only</label>
          <label title="Opens each Amazon page in a background tab to read free shipping, delivery and Prime accurately. Slower but accurate."><input type="checkbox" id="uds-sm-deep" checked> Deep check (opens Amazon — accurate)</label>
        </div>
        <div id="uds-sm-status">Idle. Click “Scan” to check every Amazon listing on this page.</div>
        <div id="uds-sm-prog"><div></div></div>
        <div id="uds-sm-results"></div>
        <div id="uds-sm-foot">
          <button class="uds-sm-btn end" id="uds-sm-end" disabled>🛑 End out-of-stock (this page)</button>
          <button class="uds-sm-btn end" id="uds-sm-endall" disabled>🛑 End out-of-stock (all pages)</button>
          <button class="uds-sm-btn ghost" id="uds-sm-select" disabled title="Fallback: tick eBay checkboxes so you can use eBay's own bulk edit to set quantity to 0">☑️ Select (bulk edit)</button>
          <button class="uds-sm-btn stop" id="uds-sm-endstop" style="display:none">■ Stop</button>
          <span class="note">Ending is permanent — relist needed to sell again. Uses eBay's own End button.</span>
        </div>
      </div>`;
    document.body.appendChild(ov);

    ov.addEventListener('click', (e) => { if (e.target === ov) closePanel(); });
    document.getElementById('uds-sm-close').addEventListener('click', closePanel);

    document.getElementById('uds-sm-scan').addEventListener('click', () => {
      readRuleOpts();
      const restockEnabled = document.getElementById('uds-sm-restock-on').checked;
      const restockQty = Math.max(1, Math.min(999, parseInt(document.getElementById('uds-sm-restock-qty').value, 10) || CFG.DEFAULT_RESTOCK_QTY));
      toggleScanUI(true);
      runScan({ restockEnabled, restockQty }).finally(() => toggleScanUI(false));
    });
    document.getElementById('uds-sm-scanall').addEventListener('click', () => {
      readRuleOpts();
      const restockEnabled = document.getElementById('uds-sm-restock-on').checked;
      const restockQty = Math.max(1, Math.min(999, parseInt(document.getElementById('uds-sm-restock-qty').value, 10) || CFG.DEFAULT_RESTOCK_QTY));
      const ok = confirm('Scan ALL pages?\n\nThis will move through every page of your active listings and check each Amazon item. It can take several minutes and the page will navigate on its own. It only READS during paging — nothing is changed until you press Apply.\n\nStart?');
      if (!ok) return;
      toggleScanUI(true);
      startScanAll({ restockEnabled, restockQty });
    });
    document.getElementById('uds-sm-stop').addEventListener('click', () => { SCANNING = false; APPLYING = false; stopScanAll(); stopApplyAll(); setStatus('Stopping…'); });
    document.getElementById('uds-sm-select').addEventListener('click', () => selectPendingCheckboxes('set_zero'));
    document.getElementById('uds-sm-end').addEventListener('click', endOutOfStockThisPage);
    document.getElementById('uds-sm-endall').addEventListener('click', startEndAllPages);
    document.getElementById('uds-sm-endstop').addEventListener('click', stopEndAll);
    document.getElementById('uds-sm-debug').addEventListener('click', runDebug);

    // Restore the toggles the way the user last set them.
    loadSavedSettings();
  }

  // ── DEBUG: show what UnicornDS recorded for the visible listings ─────
  async function runDebug() {
    const store = await new Promise((r) => chrome.storage.local.get(['domain', 'unicornds_primary_market'], r));
    const amzDomain = getAmzDomain(store);
    await loadSourceMaps();

    const dictN = Object.keys(SRC_DICT).length;
    const vmapN = Object.keys(SRC_VMAP).length;

    const rows = getRows();
    let amazon = 0, ali = 0, none = 0, msku = 0, noSku = 0;
    const samples = [];
    for (const row of rows) {
      const d = readRow(row);
      if (d.isMsku) { msku++; }
      if (!d.sku) noSku++;
      const rec = lookupRecord(d.sku);
      const az = resolveAmazon(d.sku, amzDomain);
      let verdict;
      if (az && az.isAmazon) { verdict = 'AMAZON ✓'; amazon++; }
      else if (rec && (rec.source === 'aliexpress' || (rec.sourceUrl || '').includes('aliexpress'))) { verdict = 'aliexpress'; ali++; }
      else { verdict = 'no record'; none++; }
      if (samples.length < 15) samples.push({ sku: d.sku || '(empty)', recorded: rec ? (rec.source || 'url:' + (rec.sourceUrl || '').slice(0, 30)) : '—', verdict, qty: d.qty });
    }

    const box = document.getElementById('uds-sm-results');
    setStatus(`Recorded data: dictionary=${dictN}, variant_map=${vmapN}. On this page: ${amazon} Amazon, ${ali} AliExpress, ${none} no-record${msku ? ', ' + msku + ' variations' : ''}.`);
    box.innerHTML = `
      <div style="padding:10px 14px;background:#fff8e1;border-bottom:1px solid #f0e6c0;">
        <b>What UnicornDS recorded</b> — dictionary entries: <b>${dictN}</b>, variant map: <b>${vmapN}</b>.<br>
        If both are <b>0</b>, your extension has no source records for these listings (they were listed before the recording code, or by another tool) — so nothing can be matched to Amazon automatically.
      </div>
      <table><thead><tr><th>SKU on listing</th><th>Recorded source</th><th>Verdict</th><th>Qty</th></tr></thead>
      <tbody>${samples.map((s) => `<tr>
        <td>${escapeHtml(s.sku)}</td>
        <td>${escapeHtml(s.recorded)}</td>
        <td>${s.verdict === 'AMAZON ✓' ? '<b style="color:#059669">' + s.verdict + '</b>' : escapeHtml(s.verdict)}</td>
        <td>${s.qty}</td></tr>`).join('')}</tbody></table>`;
    setApplyEnabled(false);
  }

  function toggleScanUI(on) {
    const scan = document.getElementById('uds-sm-scan');
    const stop = document.getElementById('uds-sm-stop');
    if (scan) scan.style.display = on ? 'none' : '';
    if (stop) stop.style.display = on ? '' : 'none';
  }

  function openPanel() { const o = document.getElementById('uds-sm-overlay'); if (o) o.classList.add('open'); }
  function closePanel() { const o = document.getElementById('uds-sm-overlay'); if (o) o.classList.remove('open'); }

  function setStatus(msg) { const el = document.getElementById('uds-sm-status'); if (el) el.textContent = msg; }
  function setProgress(done, total) {
    const bar = document.querySelector('#uds-sm-prog > div');
    if (bar) bar.style.width = total ? Math.round((done / total) * 100) + '%' : '0%';
  }

  function renderResults(crossPage) {
    const box = document.getElementById('uds-sm-results');
    if (!box) return;
    if (!LAST_SCAN.length) { box.innerHTML = ''; setApplyEnabled(false); return; }

    // For a big cross-page report, show the items that need action first.
    const list = crossPage
      ? [...LAST_SCAN].sort((a, b) => (a.action === 'none') - (b.action === 'none'))
      : LAST_SCAN;

    const rows = list.map((r) => {
      const actLabel = r.action === 'set_zero' ? 'Set 0'
                     : r.action === 'restock' ? `Restock ${r.newQty}`
                     : '—';
      const onThisPage = r.action !== 'none' ? (findRowByItemId(r.itemNumber) ? '' : '<small style="color:#c07a00"> (other page)</small>') : '';
      const applied = r.applied ? '<span class="uds-applied">✓ applied</span>' : '';
      const err = r.applyError ? `<span class="uds-apperr">${r.applyError}</span>` : '';
      const pageCol = crossPage ? `<td>${r.page || ''}</td>` : '';
      return `<tr>
        <td>${escapeHtml(short(r.title))}<br><small style="color:#999">${escapeHtml(r.sku || '')}</small></td>
        <td><span class="uds-tag ${r.status}">${r.status.replace('_', ' ')}</span><br><small style="color:#999">${escapeHtml(r.reason || '')}</small></td>
        <td>${r.qty}</td>
        <td class="uds-act ${r.action}">${actLabel}${onThisPage}</td>
        ${pageCol}
        <td>${applied}${err}</td>
      </tr>`;
    }).join('');

    box.innerHTML = `<table>
      <thead><tr><th>Listing</th><th>Status</th><th>Qty</th><th>Action</th>${crossPage ? '<th>Pg</th>' : ''}<th></th></tr></thead>
      <tbody>${rows}</tbody></table>`;

    const changes = LAST_SCAN.filter((r) => r.action !== 'none' && !r.applied).length;
    setApplyEnabled(changes > 0 && !SCANNING && !APPLYING);
  }

  function setApplyEnabled(on) {
    const ids = ['uds-sm-end', 'uds-sm-endall', 'uds-sm-select'];
    ids.forEach((id) => { const el = document.getElementById(id); if (el) el.disabled = !on; });
  }

  function escapeHtml(s) {
    return (s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // Fast Tracker writes { items:[{itemNumber,title}] } to this key, then opens
  // the eBay listings tab. We consume it once and run the End sweep.
  async function pickUpTrackerEndQueue() {
    const es = await getLS(END_KEY);
    if (es[END_KEY] && es[END_KEY].active) return; // don't interrupt a sweep
    const s = await getLS('unicornds_tracker_end_queue');
    const q = s['unicornds_tracker_end_queue'];
    if (!q || !q.items || !q.items.length) return;
    await new Promise((r) => chrome.storage.local.remove('unicornds_tracker_end_queue', r));
    openPanel();
    setStatus(`Fast Tracker sent ${q.items.length} listing(s) to end. Starting…`);
    await sleep(600);
    startEndAllPages(q.items.map((it) => ({ itemNumber: it.itemNumber || it.itemId, title: it.title || '' })), true);
  }

  // ── BOOT ────────────────────────────────────────────────────────────
  // The button must ALWAYS appear on the active listings page. No silent
  // gates. It does nothing until you press Scan, so it is safe to show.
  function mount() {
    if (!document.body) return false;
    injectStyles();
    buildPanel();
    return !!document.getElementById('uds-sm-fab');
  }

  function boot() {
    // Try now, then keep retrying in case Seller Hub renders late or you
    // navigate within it without a full reload.
    if (mount()) { /* shown */ }
    let tries = 0;
    const iv = setInterval(() => {
      tries++;
      if (!document.getElementById('uds-sm-fab')) mount();
      if (document.getElementById('uds-sm-fab') || tries > 40) clearInterval(iv);
    }, 1000);

    // If Seller Hub uses client-side navigation, re-check when the URL changes.
    let lastHref = location.href;
    setInterval(() => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        if (!document.getElementById('uds-sm-fab')) mount();
      }
    }, 1500);

    // If a "Scan ALL pages" run is in progress, continue it on this page.
    setTimeout(() => { resumeScanAllIfNeeded(); }, 1200);
    // If an "End out-of-stock (all pages)" run is in progress, continue it.
    setTimeout(() => { resumeEndAllIfNeeded(); }, 1500);
    // If Fast Tracker queued listings to end, pick them up and start the sweep.
    setTimeout(() => { pickUpTrackerEndQueue(); }, 1800);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
