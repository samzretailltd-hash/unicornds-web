try { chrome.storage.local.get('unicornds_primary_market', s => { self.UDS_ORD_MKT = (s && s.unicornds_primary_market) || 'co_uk'; }); } catch (e) {}
/**
 * UnicornDS - eBay Orders Page
 * - Original feature: scrapes orders awaiting dispatch (for extension orders page)
 * - v7.8 additions: per-order-row buttons to compose pre-filled message to buyer
 *   - AliExpress Message (delivery 3-4 days)
 *   - Amazon Message (delivery 1-2 days)
 *   Auto-fills {buyer} and {store} from order context + user settings.
 */
'use strict';
console.log('[UnicornDS] eBay orders scraper + message buttons loaded');

// --- MESSAGE TEMPLATES ---
const UDS_ORDER_TEMPLATES = {
  aliexpress: (buyer, store) =>
`Hi ${buyer || 'there'},

Thank you so much for your order - we really appreciate your support for our small family-run shop!

We're thrilled to let you know your item is on its way and should be with you within 3 to 4 working days. We'll send you tracking details shortly so you can follow the journey.

If you have any questions or anything at all we can help with, please don't hesitate to reach out - we're always happy to hear from you.

Wishing you a wonderful day,
${store || 'Your Store'}`,

  amazon: (buyer, store) =>
`Hi ${buyer || 'there'},

Thank you so much for your order - we really appreciate your support for our small family-run shop!

We're delighted to let you know your item has been dispatched and should arrive within 1 to 2 working days. We'll send you the tracking details shortly so you can keep an eye on delivery.

If there's anything at all we can help with, please don't hesitate to reach out - we're always here and happy to help.

Wishing you a wonderful day,
${store || 'Your Store'}`,
};

// --- SCRAPER ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'scrape_ebay_orders') {
    setTimeout(() => {
      const orders = scrapeOrders();
      sendResponse({ orders });
    }, 3000);
    return true;
  }
});

function scrapeOrders() {
  const orders = [];
  const orderRows = document.querySelectorAll(
    '.order-info, [data-test-id="order-line-item"], .sold-order-info, tr.order-row, .sh-tbl__row, [class*="order-line"], [class*="OrderLineItem"]'
  );

  orderRows.forEach(row => {
    try {
      const order = {};
      const orderIdEl = row.querySelector('[class*="order-id"] a, [data-test-id="order-id"] a, a[href*="orderId"]');
      if (orderIdEl) order.ebayOrderId = orderIdEl.textContent.trim();
      const buyerEl = row.querySelector(
        '[class*="buyer"] a, [data-test-id="buyer-id"], [class*="Buyer"] a, ' +
        'a[href*="usr/"], [class*="buyer-name"], [class*="buyerName"], ' +
        '[class*="winner"] a, [class*="buyer-id"], ' +
        '[class*="buyer"] span, [class*="buyer"] button'
      );
      order.buyerName = buyerEl ? buyerEl.textContent.trim() : '';
      // Fallback: find any link to eBay user profile
      if (!order.buyerName) {
        const userLink = row.querySelector('a[href*="/usr/"], a[href*="ViewUserInfo"]');
        if (userLink) order.buyerName = userLink.textContent.trim();
      }
      // Guard: an order-ID (e.g. "15-14937-21508") is NOT a buyer name. Clear it so
      // the detail-page fetch can backfill the real name later.
      if (/^\d{1,3}-\d{3,}-\d{3,}$/.test(order.buyerName) || /^\d{6,}$/.test(order.buyerName)) {
        order.buyerName = '';
      }
      const titleEl = row.querySelector('[class*="item-title"] a, [data-test-id="item-title"], a[href*="/itm/"]');
      order.itemTitle = titleEl ? titleEl.textContent.trim() : '';
      if (titleEl && titleEl.href) {
        const match = titleEl.href.match(/\/itm\/(\d+)/);
        if (match) order.itemNumber = match[1];
      }
      const priceEl = row.querySelector(
        '[class*="total"] .sh-bold, [data-test-id="order-total"], ' +
        '[class*="order-price"], [class*="line-item-price"], ' +
        '[class*="item-price"] span, [class*="Amount"] span, ' +
        '.sold-order-info [class*="price"], [class*="total-price"], ' +
        '[class*="orderPrice"], [class*="sold-price"], ' +
        'span[class*="BOLD"], [class*="total"] span'
      );
      if (priceEl) {
        const priceText = priceEl.textContent.replace(/[^0-9.,]/g, '');
        order.soldPrice = parseFloat(priceText.replace(',', '')) || 0;
      }
      // Fallback: scan all spans/divs for £/$/€ pattern
      if (!order.soldPrice) {
        const allEls = row.querySelectorAll('span, div, td');
        for (const el of allEls) {
          const txt = el.textContent.trim();
          // Match currency amounts like £12.99, $45.00, €9.99
          const m = txt.match(/^[£$€]\s?([\d,]+\.\d{2})$/);
          if (m) {
            const val = parseFloat(m[1].replace(',', ''));
            if (val > 0 && val < 10000) {
              order.soldPrice = val;
              break;
            }
          }
        }
      }
      const dateEl = row.querySelector('[class*="date"], [data-test-id="order-date"], time');
      order.soldDate = dateEl ? dateEl.textContent.trim() : '';
      const imgEl = row.querySelector('img[src*="ebayimg"]');
      order.image = imgEl ? imgEl.src : '';
      const statusEl = row.querySelector('[class*="status"], [data-test-id="order-status"]');
      const statusText = statusEl ? statusEl.textContent.trim().toLowerCase() : '';
      // delivered/complete FIRST — rows often contain dispatch text too
      if (statusText.includes('deliver') || statusText.includes('complete')) order.ebayStatus = 'delivered';
      else if (statusText.includes('dispatch') || statusText.includes('ship') || statusText.includes('awaiting') || statusText.includes('post')) order.ebayStatus = 'awaiting_dispatch';
      else if (statusText.includes('paid')) order.ebayStatus = 'paid';
      else order.ebayStatus = statusText;
      if (order.itemTitle) orders.push(order);
    } catch (e) { console.warn('[UnicornDS] Error scraping order row:', e); }
  });

  if (orders.length === 0) {
    const soldItems = document.querySelectorAll('.s-item, li[data-viewport], [class*="sold-item"]');
    soldItems.forEach(item => {
      try {
        const titleEl = item.querySelector('.s-item__title, h3, [role="heading"]');
        const priceEl = item.querySelector('.s-item__price, [class*="price"]');
        const linkEl = item.querySelector('a[href*="/itm/"]');
        const buyerEl = item.querySelector('[class*="buyer"], [class*="winner"], a[href*="/usr/"]');
        if (titleEl && titleEl.textContent.trim() !== 'Shop on eBay') {
          orders.push({
            itemTitle: titleEl.textContent.trim(),
            soldPrice: priceEl ? parseFloat(priceEl.textContent.replace(/[^0-9.,]/g, '')) || 0 : 0,
            itemNumber: linkEl ? linkEl.href.split('/').pop().split('?')[0] : '',
            buyerName: buyerEl ? buyerEl.textContent.trim() : 'eBay Buyer',
            soldDate: new Date().toLocaleDateString((({com:'en-US',co_uk:'en-GB',ca:'en-CA',com_au:'en-AU',de:'de-DE',fr:'fr-FR',it:'it-IT',es:'es-ES',nl:'nl-NL'})[(self.UDS_ORD_MKT||'co_uk')]||'en-GB')),
            ebayStatus: 'awaiting_dispatch',
          });
        }
      } catch (e) { /* skip */ }
    });
  }
  return orders;
}

// --- MESSAGE BUTTON INJECTION ---
function injectStyles() {
  if (document.getElementById('uds-orders-style')) return;
  const s = document.createElement('style');
  s.id = 'uds-orders-style';
  s.textContent = `
    .uds-msg-btns { display: inline-flex; gap: 6px; margin: 4px 0; vertical-align: middle; flex-wrap: wrap; }
    .uds-msg-btn {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600;
      cursor: pointer; border: 1px solid transparent; transition: all 0.15s;
      text-decoration: none; color: #fff !important; white-space: nowrap;
      font-family: inherit;
    }
    .uds-msg-btn.ali { background: #E43225; border-color: #E43225; }
    .uds-msg-btn.ali:hover { background: #c62b1f; transform: translateY(-1px); }
    .uds-msg-btn.amz { background: #FF9900; border-color: #FF9900; color: #111 !important; }
    .uds-msg-btn.amz:hover { background: #e68a00; transform: translateY(-1px); }
    .uds-toast-uds {
      position: fixed; bottom: 20px; right: 20px; background: #7C3AED; color: #fff;
      padding: 10px 16px; border-radius: 8px; font-size: 13px; z-index: 999999;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
  `;
  document.documentElement.appendChild(s);
}

function showToastUds(msg) {
  const t = document.createElement('div');
  t.className = 'uds-toast-uds';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

function getBuyerFromRow(row) {
  const buyerEl = row.querySelector(
    'a[href*="usr/"], [class*="buyer"] a, [data-test-id="buyer-id"], ' +
    '[class*="Buyer"] a, [class*="buyer-name"], [class*="buyerName"], ' +
    '[class*="buyer"] span, [class*="buyer"] button, a[href*="ViewUserInfo"]'
  );
  if (!buyerEl) return '';
  const txt = buyerEl.textContent.trim();
  const parts = txt.split(/\s+/);
  return parts[0] || '';
}

async function copyToClipboard(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch (e) { return false; }
}

async function handleMsgClick(e, source, row) {
  e.preventDefault();
  e.stopPropagation();

  const s = await new Promise(r => chrome.storage.local.get('unicornds_store_name', r));
  const store = s.unicornds_store_name || 'Your Store';
  const buyer = getBuyerFromRow(row);
  const message = UDS_ORDER_TEMPLATES[source](buyer, store);

  const copied = await copyToClipboard(message);

  // SAFETY: only open a real CONTACT/MESSAGE page. Never an order/postage link —
  // those can trigger eBay's dispatch (marks shipped with NO tracking). If no
  // contact link, open eBay's message centre for this buyer instead.
  let openUrl = '';
  const contactLink = row.querySelector(
    'a[href*="/mesgdetl/"], a[href*="contactBuyer"], a[href*="Contact+buyer"], a[href*="ReplyToMessages"]');
  if (contactLink && !/dispatch|postage|label|markshipped|\bship\b/i.test(contactLink.href)) {
    openUrl = contactLink.href;
  }
  if (!openUrl) {
    const buyerLink = row.querySelector('a[href*="usr/"], a[href*="ViewUserInfo"]');
    const buyerId = buyerLink ? (buyerLink.href.match(/usr\/([^?&/]+)/) || [])[1] : '';
    const dom = location.hostname.replace('www.', '');
    openUrl = buyerId
      ? `https://www.${dom}/cnt/ReplyToMessages?recipientId=${encodeURIComponent(buyerId)}`
      : `https://www.${dom}/cnt/Messages`;
  }

  const label = source === 'amazon' ? 'Amazon' : 'AliExpress';
  chrome.runtime.sendMessage({ type: 'openNewTab', url: openUrl });
  showToastUds(copied
    ? `\u2705 Message copied (${label}) — paste into message box (no dispatch)`
    : `Opening message page (${label})`);

  if (!copied) {
    console.log('[UnicornDS] Pre-filled message (copy manually):\n' + message);
  }
}

function injectOrderButtons() {
  injectStyles();
  const rows = document.querySelectorAll(
    '.order-info, [data-test-id="order-line-item"], .sold-order-info, tr.order-row, .sh-tbl__row, [class*="order-line"], [class*="OrderLineItem"]'
  );
  let injected = 0;
  rows.forEach(row => {
    if (row.querySelector('.uds-msg-btns')) return;
    const hasBuyer = !!row.querySelector(
      'a[href*="usr/"], [class*="buyer"] a, [data-test-id="buyer-id"], ' +
      '[class*="Buyer"] a, [class*="buyer-name"], [class*="buyer"] span, a[href*="ViewUserInfo"]'
    );
    if (!hasBuyer) return;

    const wrap = document.createElement('div');
    wrap.className = 'uds-msg-btns';

    const aliBtn = document.createElement('button');
    aliBtn.className = 'uds-msg-btn ali';
    aliBtn.type = 'button';
    aliBtn.textContent = 'AliExpress Msg';
    aliBtn.title = 'Copy AliExpress delivery message (3-4 days) and open buyer contact';
    aliBtn.addEventListener('click', (e) => handleMsgClick(e, 'aliexpress', row));

    const amzBtn = document.createElement('button');
    amzBtn.className = 'uds-msg-btn amz';
    amzBtn.type = 'button';
    amzBtn.textContent = 'Amazon Msg';
    amzBtn.title = 'Copy Amazon delivery message (1-2 days) and open buyer contact';
    amzBtn.addEventListener('click', (e) => handleMsgClick(e, 'amazon', row));

    wrap.appendChild(aliBtn);
    wrap.appendChild(amzBtn);

    const anchor = row.querySelector('[class*="buyer"]') ||
                   row.querySelector('[data-test-id="buyer-id"]') ||
                   row.querySelector('td:last-child') ||
                   row;
    anchor.appendChild(wrap);
    injected++;
  });
  if (injected > 0) console.log('[UnicornDS] Injected message buttons on', injected, 'orders');
}

function udsIsSingleOrderPage() {
  const u = location.href;
  return /\/ord\/details/i.test(u) || /\/mesh\/ord\//i.test(u) || /orderid=/i.test(u);
}

// On the SINGLE order page, attach message buttons next to eBay's "Message buyer".
function udsWaitEl(sel, timeout){return new Promise(function(res){var t0=Date.now();var iv=setInterval(function(){var el=document.querySelector(sel);if(el){clearInterval(iv);res(el);}else if(Date.now()-t0>(timeout||8000)){clearInterval(iv);res(null);}},100);});}

// EcomSniper-style note writer: opens eBay's note dialog, fills it, saves.
async function udsWriteNote(text){
  var edit=document.querySelector('.edit-note');
  var add=document.querySelector('[data-action-id="ADD_NOTE"]');
  if(edit)edit.click(); else if(add)add.click(); else {alert('Could not find eBay note button on this page');return false;}
  var ta=await udsWaitEl('textarea[name="note-content"]',8000);
  if(!ta){alert('Note box did not open');return false;}
  ta.value=text;
  ta.dispatchEvent(new Event('input',{bubbles:true}));
  ta.dispatchEvent(new Event('change',{bubbles:true}));
  await new Promise(r=>setTimeout(r,600));
  var dlg=ta.closest('.lightbox-dialog__window')||document;
  var save=dlg.querySelector('.btn.btn--primary');
  if(save){save.dispatchEvent(new MouseEvent('click',{bubbles:true}));}
  await new Promise(r=>setTimeout(r,600));
  return true;
}

// Read customer first name from the mesh order page (EcomSniper selectors)
function udsFirstName(){
  var el=document.querySelector('.shipping-address .address div')||document.querySelector('.item__buyer-name')||document.querySelector('a[href*="usr/"]');
  var t=el?(el.innerText||el.textContent||'').trim():'';
  var first=t.split(/\s+/)[0]||'there';
  return first.charAt(0).toUpperCase()+first.slice(1).toLowerCase();
}

// Message templates — warm, name + delivery date personalised
function udsMsgTemplates(name, days){
  var d=new Date(); d.setDate(d.getDate()+(days||5));
  var date=d.toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long'});
  return {
    'Order Received':'Hi '+name+',\n\nThank you so much for your order — we really appreciate you supporting our small family-run shop! We are getting it ready for you now and it should arrive by around '+date+'.\n\nAny questions at all, just reply here and we will be happy to help.\n\nWarm wishes',
    'Dispatched':'Hi '+name+',\n\nGreat news — your order is on its way! You can expect it by around '+date+'. Thank you again for shopping with our small family business, it truly means a lot.\n\nIf there is anything you need, just let us know.\n\nWarm wishes',
    'Thank You':'Hi '+name+',\n\nJust a little note to say thank you for your order — we hope you love it! If you have a moment, a positive review helps our small shop so much. And if anything is not quite right, please message us first and we will make it right straight away.\n\nWarm wishes',
    'Slight Delay':'Hi '+name+',\n\nThank you so much for your order and your patience. Due to high demand your item is taking a little longer, but it is on its way and should reach you by around '+date+'. We really appreciate your support for our small shop.\n\nWarm wishes'
  };
}

function injectSingleOrderButtons(){
  if(document.getElementById('uds-order-panel'))return;
  var anchor=document.querySelector('.lineItemCardInfo__itemId')||document.querySelector('.lineItemCardInfo__content .details')||document.querySelector('.item-tile')||document.querySelector('.order-info');

  var name=udsFirstName();
  var panel=document.createElement('div');
  panel.id='uds-order-panel';
  panel.style.cssText='margin:14px 0;padding:16px;background:#1E1B4B;border-radius:14px;font-family:Arial,sans-serif;color:#fff;max-width:520px;box-shadow:0 6px 20px rgba(0,0,0,.25)';
  panel.innerHTML=''
    +'<div style="display:flex;align-items:center;gap:8px;font-weight:800;font-size:15px;margin-bottom:12px">'
    +'<span style="font-size:18px">\uD83E\uDD84</span> UnicornDS Order Helper</div>'
    +'<button id="uds-copy-addr" style="width:100%;background:#7C3AED;color:#fff;border:none;border-radius:10px;padding:11px;font-weight:700;font-size:13px;cursor:pointer;margin-bottom:10px">\uD83D\uDCCB Copy Address + Open AliExpress</button>'
    +'<div style="display:flex;gap:8px;margin-bottom:10px">'
    +'  <input id="uds-note-in" placeholder="Paste AliExpress Order ID" style="flex:1;padding:10px;border-radius:8px;border:none;font-size:13px">'
    +'  <button id="uds-note-save" style="background:#F59E0B;color:#fff;border:none;border-radius:8px;padding:0 16px;font-weight:700;cursor:pointer">Save Note</button>'
    +'</div>'
    +'<div style="background:rgba(255,255,255,.08);border-radius:10px;padding:12px;margin-bottom:6px">'
    +'  <div style="font-size:12px;opacity:.8;margin-bottom:8px">Message '+name+' — delivery in '
    +'    <select id="uds-days" style="border-radius:6px;padding:2px 4px;font-size:12px">'
    +'      <option value="3">3 days</option><option value="5" selected>5 days</option>'
    +'      <option value="7">7 days</option><option value="10">10 days</option><option value="14">14 days</option>'
    +'    </select></div>'
    +'  <div id="uds-tpl-btns" style="display:flex;flex-wrap:wrap;gap:6px"></div>'
    +'</div>';

  if(anchor)anchor.parentElement.insertBefore(panel,anchor.nextSibling);
  else document.body.appendChild(panel);

  // Copy address + open AliExpress
  panel.querySelector('#uds-copy-addr').addEventListener('click',function(){
    try{handleMsgClick(new Event('click'),'aliexpress',document.body);}catch(e){}
    chrome.runtime.sendMessage({type:'openNewTab',url:'https://www.aliexpress.com'});
    showToastUds('Address copied \u2014 paste it into AliExpress');
  });

  // Save note (AliExpress order ID) into eBay note
  panel.querySelector('#uds-note-save').addEventListener('click',async function(){
    var v=panel.querySelector('#uds-note-in').value.trim();
    if(!v){alert('Paste the AliExpress order ID first');return;}
    var btn=this; btn.textContent='Saving...';
    var ok=await udsWriteNote(v);
    btn.textContent=ok?'Saved \u2705':'Failed';
    setTimeout(function(){btn.textContent='Save Note';},2500);
  });

  // Template buttons
  function renderTpls(){
    var days=parseInt(panel.querySelector('#uds-days').value,10);
    var tpls=udsMsgTemplates(name,days);
    var wrap=panel.querySelector('#uds-tpl-btns'); wrap.innerHTML='';
    Object.keys(tpls).forEach(function(k){
      var b=document.createElement('button');
      b.textContent=k;
      b.style.cssText='background:#fff;color:#1E1B4B;border:none;border-radius:8px;padding:8px 12px;font-weight:700;font-size:12px;cursor:pointer';
      b.addEventListener('click',async function(){
        await copyToClipboard(tpls[k]);
        b.textContent='Copied \u2705';
        showToastUds('"'+k+'" copied \u2014 open Message buyer and paste');
        setTimeout(function(){b.textContent=k;},2000);
      });
      wrap.appendChild(b);
    });
  }
  panel.querySelector('#uds-days').addEventListener('change',renderTpls);
  renderTpls();
  console.log('[UnicornDS] Order Helper panel added',anchor?'(in item card)':'(floating)');
}

function startObserver() {
  // Buttons ONLY on the single order detail page, never the orders list.
  if (!udsIsSingleOrderPage()) {
    console.log('[UnicornDS] Orders LIST — message buttons hidden');
    return;
  }
  injectSingleOrderButtons();
  const obs = new MutationObserver(() => {
    clearTimeout(window.__udsOrderBtnTimer);
    window.__udsOrderBtnTimer = setTimeout(injectSingleOrderButtons, 500);
  });
  obs.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(startObserver, 1500);
  // Extra retries for the single order page (React renders "Message buyer" late)
  [2500, 4000, 6000].forEach(t => setTimeout(() => { if (udsIsSingleOrderPage()) injectSingleOrderButtons(); }, t));
} else {
  window.addEventListener('load', () => setTimeout(startObserver, 1500));
  [2500, 4000, 6000].forEach(t => window.addEventListener('load', () => setTimeout(() => { if (udsIsSingleOrderPage()) injectSingleOrderButtons(); }, t)));
}
