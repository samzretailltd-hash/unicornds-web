/**
 * UnicornDS - eBay Order Detail Scraper
 * Runs on: ebay order detail pages
 * Auto-captures: order total, fees, earnings, buyer info
 * Stores data that Order Manager uses for profit calculation
 */
'use strict';

(function() {
  // Only run on order detail pages, not the list page
  if (!location.href.includes('details') && !location.href.includes('orderid') && !location.href.includes('orderId')) return;
  
  // Wait for page to fully load
  setTimeout(scrapeOrderDetail, 3000);

  function scrapeOrderDetail() {
    try {
      const order = {};

      // ── ORDER INFO ──
      const infoItems = document.querySelectorAll('.order-info .info-item');
      infoItems.forEach(item => {
        const label = (item.querySelector('.info-label')?.textContent || '').trim().toLowerCase();
        const value = (item.querySelector('.info-value')?.textContent || '').trim();
        if (label.includes('order') && !label.includes('sales')) {
          order.ebayOrderId = value.replace(/\s+/g, '');
        }
        if (label.includes('sold')) {
          order.soldDate = value;
          // Parse "2 May 2026" format
          const d = new Date(value);
          if (!isNaN(d.getTime())) order.soldDateTs = d.getTime();
        }
        if (label.includes('sales record')) {
          order.salesRecordNo = value;
        }
      });

      // ── BUYER ──
      const buyerDiv = document.querySelector('.buyer');
      if (buyerDiv) {
        // Real name is in first div child
        const nameDiv = buyerDiv.querySelector('div');
        if (nameDiv) order.buyerRealName = nameDiv.textContent.trim();
        // Username is in button.fake-link
        const usernameBtn = buyerDiv.querySelector('button.fake-link');
        if (usernameBtn) order.buyerUsername = usernameBtn.textContent.trim();
        order.buyerName = order.buyerRealName || order.buyerUsername || '';
      }

      // ── ITEM INFO ──
      const itemTitle = document.querySelector('.item-info a[href*="/itm/"], .line-item-title a, [class*="item-title"] a');
      if (itemTitle) {
        order.itemTitle = itemTitle.textContent.trim();
        const itemMatch = itemTitle.href?.match(/\/itm\/(\d+)/);
        if (itemMatch) order.itemNumber = itemMatch[1];
      }

      // ── SKU ──
      const skuEl = document.querySelector('[class*="custom-label"], [class*="sku"], [class*="SKU"]');
      if (skuEl) {
        order.sku = skuEl.textContent.replace(/^(Custom label|SKU)[:\s()]*/i, '').trim();
      }

      // ── WHAT BUYER PAID ──
      const buyerPaid = document.querySelector('.buyer-paid');
      if (buyerPaid) {
        const totalEl = buyerPaid.querySelector('.total .value .sh-bold');
        if (totalEl) {
          const m = totalEl.textContent.match(/[\d]+[.,]\d{2}/);
          order.soldPrice = m ? parseFloat(m[0].replace(',', '.')) : 0;
        }
        // Get subtotal and postage separately
        const dataItems = buyerPaid.querySelectorAll('.data-item');
        dataItems.forEach(item => {
          const label = (item.querySelector('.label')?.textContent || '').toLowerCase();
          const val = item.querySelector('.value')?.textContent || '';
          const amount = val.match(/[\d]+[.,]\d{2}/);
          if (label.includes('subtotal') && amount) order.subtotal = parseFloat(amount[0]);
          if (label.includes('postage') && amount) order.postage = parseFloat(amount[0]);
        });
      }

      // ── WHAT YOU EARNED (fees + earnings) ──
      const earnings = document.querySelector('.earnings');
      if (earnings) {
        // Transaction fees
        const feeItems = earnings.querySelectorAll('.data-item');
        order.fees = [];
        let totalFees = 0;
        feeItems.forEach(item => {
          const label = (item.querySelector('.label')?.textContent || '').trim();
          const val = item.querySelector('.value')?.textContent || '';
          const amount = val.match(/[\d]+[.,]\d{2}/);
          if (amount && !label.toLowerCase().includes('order total')) {
            const fee = parseFloat(amount[0].replace(',', '.'));
            order.fees.push({ label, amount: fee });
            totalFees += fee;
          }
        });
        order.totalFees = totalFees;

        // Order earnings (final amount after fees)
        const earningsTotal = earnings.querySelector('.total .value .sh-bold');
        if (earningsTotal) {
          const m = earningsTotal.textContent.match(/[\d]+[.,]\d{2}/);
          order.ebayEarnings = m ? parseFloat(m[0].replace(',', '.')) : 0;
        }
      }

      // ── SHIPPING INFO ──
      const shippingService = document.querySelector('[class*="shipping-service"], [class*="postage-service"]');
      if (shippingService) order.shippingService = shippingService.textContent.trim();

      // ── DELIVERY ADDRESS ──
      const addressEl = document.querySelector('[class*="ship-to"], [class*="delivery-address"], .address');
      if (addressEl) order.deliveryAddress = addressEl.textContent.trim();

      // ── PHONE ──
      const phoneEl = document.querySelector('[class*="phone"], [class*="Phone"]');
      if (phoneEl) {
        const phoneMatch = phoneEl.textContent.match(/[\d\s+()-]{8,}/);
        if (phoneMatch) order.buyerPhone = phoneMatch[0].trim();
      }

      // ── IMAGE ──
      const img = document.querySelector('.line-item img, [class*="item"] img[src*="ebayimg"]');
      if (img) order.image = img.src;

      // ── QUANTITY ──
      const qtyEl = document.querySelector('[class*="quantity"], [class*="qty"]');
      if (qtyEl) {
        const qtyMatch = qtyEl.textContent.match(/\d+/);
        order.quantity = qtyMatch ? parseInt(qtyMatch[0]) : 1;
      }

      // Only save if we got an order ID
      if (order.ebayOrderId) {
        console.log('[UnicornDS] 📦 Order detail captured:', order.ebayOrderId, 
          '| Sold: £' + (order.soldPrice || 0).toFixed(2),
          '| Fees: £' + (order.totalFees || 0).toFixed(2),
          '| Earnings: £' + (order.ebayEarnings || 0).toFixed(2));

        // Save to storage — merge with existing orders
        chrome.storage.local.get('unicornds_orders', data => {
          const orders = data.unicornds_orders || [];
          
          // Find existing order by ebayOrderId
          const existing = orders.findIndex(o => o.ebayOrderId === order.ebayOrderId);
          
          if (existing >= 0) {
            // Update existing order with detail data
            const updated = { ...orders[existing] };
            updated.soldPrice = order.soldPrice || updated.soldPrice;
            updated.ebayEarnings = order.ebayEarnings;
            updated.totalFees = order.totalFees;
            updated.fees = order.fees;
            updated.buyerName = order.buyerRealName || order.buyerUsername || updated.buyerName;
            updated.buyerUsername = order.buyerUsername || updated.buyerUsername;
            updated.buyerPhone = order.buyerPhone || updated.buyerPhone;
            updated.soldDate = order.soldDate || updated.soldDate;
            updated.soldDateTs = order.soldDateTs || updated.soldDateTs;
            updated.sku = order.sku || updated.sku;
            updated.image = order.image || updated.image;
            updated.quantity = order.quantity || updated.quantity;
            updated.detailScraped = true;
            updated.detailScrapedAt = Date.now();
            orders[existing] = updated;
            console.log('[UnicornDS] 📦 Updated existing order:', order.ebayOrderId);
          } else {
            // Add new order
            orders.unshift({
              id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
              ...order,
              status: 'pending',
              sourceCost: 0,
              trackingNumber: '',
              trackingCarrier: '',
              detailScraped: true,
              detailScrapedAt: Date.now(),
              createdAt: Date.now(),
            });
            console.log('[UnicornDS] 📦 Added new order from detail page:', order.ebayOrderId);
          }
          
          chrome.storage.local.set({ unicornds_orders: orders });
        });
      }
    } catch (e) {
      console.warn('[UnicornDS] Order detail scrape error:', e.message);
    }
  }
})();
