// ============================================================
// Unicorn DS - Amazon Address Form Filler (v7.20)
// Fills Amazon checkout address forms with eBay buyer address
// Supports: amazon.co.uk, .com, .de, .fr, .es, .it, .ca, .com.au
// Pages: /gp/buy/addressselect, /a/addresses/add, /your-account/order-history checkout
// ============================================================

(() => {
  'use strict';
  console.log('[UnicornDS] Amazon address filler loaded on', location.pathname);

  const nativeSet = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  const nativeSelectSet = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set;

  function setVal(input, value) {
    if (!input || value === undefined || value === null) return false;
    input.focus();
    const tracker = input._valueTracker;
    if (tracker) tracker.setValue('');
    if (input.tagName === 'SELECT') {
      nativeSelectSet.call(input, value);
    } else {
      nativeSet.call(input, value);
    }
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }

  function $(selector) { return document.querySelector(selector); }
  function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

  // Map ISO country name to Amazon dropdown value
  const COUNTRY_MAP = {
    'united kingdom': 'GB', 'uk': 'GB', 'great britain': 'GB',
    'united states': 'US', 'usa': 'US',
    'germany': 'DE', 'deutschland': 'DE',
    'france': 'FR',
    'spain': 'ES', 'españa': 'ES',
    'italy': 'IT', 'italia': 'IT',
    'canada': 'CA',
    'australia': 'AU',
    'netherlands': 'NL',
    'ireland': 'IE',
    'belgium': 'BE',
    'poland': 'PL',
  };

  async function fillAmazonAddress(address) {
    if (!address) {
      console.error('[UnicornDS] No address provided');
      return { success: false, error: 'No address' };
    }

    console.log('[UnicornDS] Filling Amazon address:', address);
    const filled = [];
    const skipped = [];

    // Full name (Amazon uses single "Full Name" field)
    const nameInput = $('#address-ui-widgets-enterAddressFullName') ||
                      $('input[name="enterAddressFullName"]') ||
                      $('input[autocomplete="name"]') ||
                      $('#ya-myab-address-form-region input[name*="name" i]');
    const fullName = address.name || (address.firstName + ' ' + address.lastName).trim();
    if (nameInput && fullName) {
      setVal(nameInput, fullName);
      filled.push('Name');
    } else skipped.push('Name');

    // Phone (Amazon phone field)
    const phoneInput = $('#address-ui-widgets-enterAddressPhoneNumber') ||
                       $('input[name="enterAddressPhoneNumber"]') ||
                       $('input[autocomplete="tel"]') ||
                       $('input[type="tel"]');
    if (phoneInput && address.phone) {
      // Amazon accepts full phone with country code
      setVal(phoneInput, address.phone);
      filled.push('Phone');
    } else skipped.push('Phone');

    // Country dropdown (set first so other fields validate against country)
    const countrySelect = $('#address-ui-widgets-countryCode-dropdown-nativeId') ||
                          $('select[name="countryCode"]') ||
                          $('#GLUXCountryListDropdown') ||
                          $('select[autocomplete="country"]');
    if (countrySelect && address.country) {
      const countryCode = COUNTRY_MAP[address.country.toLowerCase().trim()];
      if (countryCode) {
        setVal(countrySelect, countryCode);
        filled.push('Country (' + countryCode + ')');
        // Wait for Amazon to refresh form after country change
        await wait(800);
      } else {
        skipped.push('Country (no match for "' + address.country + '")');
      }
    }

    // Address line 1
    const line1Input = $('#address-ui-widgets-enterAddressLine1') ||
                       $('input[name="addressLine1"]') ||
                       $('input[autocomplete="address-line1"]');
    if (line1Input && address.street1) {
      setVal(line1Input, address.street1);
      filled.push('Street 1');
    } else skipped.push('Street 1');

    // Address line 2 (optional)
    const line2Input = $('#address-ui-widgets-enterAddressLine2') ||
                       $('input[name="addressLine2"]') ||
                       $('input[autocomplete="address-line2"]');
    if (line2Input && address.street2) {
      setVal(line2Input, address.street2);
      filled.push('Street 2');
    }

    // City
    const cityInput = $('#address-ui-widgets-enterAddressCity') ||
                      $('input[name="city"]') ||
                      $('input[autocomplete="address-level2"]');
    if (cityInput && address.city) {
      setVal(cityInput, address.city);
      filled.push('City');
    } else skipped.push('City');

    // State / County (could be input or select)
    const stateInput = $('#address-ui-widgets-enterAddressStateOrRegion') ||
                       $('input[name="stateOrRegion"]') ||
                       $('select[name="stateOrRegion"]') ||
                       $('input[autocomplete="address-level1"]');
    if (stateInput && address.state) {
      setVal(stateInput, address.state);
      filled.push('State');
    }

    // Zip / Postcode
    const zipInput = $('#address-ui-widgets-enterAddressPostalCode') ||
                     $('input[name="postalCode"]') ||
                     $('input[autocomplete="postal-code"]');
    if (zipInput && address.zip) {
      setVal(zipInput, address.zip);
      filled.push('Zip');
    } else skipped.push('Zip');

    console.log('[UnicornDS] Amazon fill result:', { filled, skipped });
    return { success: filled.length > 0, filled, skipped };
  }

  // Floating Paste button (similar to AliExpress)
  function injectPasteButton() {
    // Only show on address forms
    const hasAddressForm = $('#address-ui-widgets-enterAddressFullName') ||
                            $('input[name="addressLine1"]') ||
                            $('input[autocomplete="address-line1"]');
    if (!hasAddressForm) return;

    if (document.getElementById('uds-amazon-paste-btn')) return; // Already injected

    const btn = document.createElement('button');
    btn.id = 'uds-amazon-paste-btn';
    btn.innerHTML = '📋 Paste UDS Address';
    btn.title = 'Click to fill from last copied eBay order address';
    btn.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 99999;
      background: linear-gradient(135deg, #7C3AED, #5B21B6);
      color: white;
      border: 2px solid #F59E0B;
      padding: 14px 22px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0 8px 24px rgba(124,58,237,0.4);
      font-family: Amazon Ember, Arial, sans-serif;
      transition: transform 0.15s, box-shadow 0.15s;
    `;
    btn.onmouseenter = () => {
      btn.style.transform = 'translateY(-2px)';
      btn.style.boxShadow = '0 12px 32px rgba(124,58,237,0.5)';
    };
    btn.onmouseleave = () => {
      btn.style.transform = 'translateY(0)';
      btn.style.boxShadow = '0 8px 24px rgba(124,58,237,0.4)';
    };

    btn.onclick = async () => {
      btn.innerHTML = '⏳ Filling...';
      btn.disabled = true;

      try {
        // Read last copied address from chrome.storage
        const data = await new Promise(r => chrome.storage.local.get('unicornds_last_copied_address', r));
        const address = data.unicornds_last_copied_address;

        if (!address) {
          btn.innerHTML = '❌ No address copied yet';
          setTimeout(() => {
            btn.innerHTML = '📋 Paste UDS Address';
            btn.disabled = false;
          }, 2500);
          return;
        }

        const result = await fillAmazonAddress(address);

        if (result.success) {
          btn.innerHTML = `✅ Filled ${result.filled.length} fields`;
          btn.style.background = 'linear-gradient(135deg, #10B981, #059669)';
          setTimeout(() => {
            btn.innerHTML = '📋 Paste UDS Address';
            btn.style.background = 'linear-gradient(135deg, #7C3AED, #5B21B6)';
            btn.disabled = false;
          }, 3000);
        } else {
          btn.innerHTML = '⚠️ Form not detected';
          setTimeout(() => {
            btn.innerHTML = '📋 Paste UDS Address';
            btn.disabled = false;
          }, 2500);
        }
      } catch (err) {
        console.error('[UnicornDS] Fill error:', err);
        btn.innerHTML = '❌ Error — see console';
        setTimeout(() => {
          btn.innerHTML = '📋 Paste UDS Address';
          btn.disabled = false;
        }, 2500);
      }
    };

    document.body.appendChild(btn);
  }

  // Inject after page load + observe DOM for SPA navigation
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    injectPasteButton();
  } else {
    document.addEventListener('DOMContentLoaded', injectPasteButton);
  }

  // Re-inject on URL change (Amazon SPA)
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(injectPasteButton, 800);
    }
  }).observe(document, { subtree: true, childList: true });

  // Also try periodically (Amazon delays render)
  setInterval(injectPasteButton, 3000);

  // Listen for messages (in case popup wants to trigger fill directly)
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'amazon_fill_address' && msg.address) {
      fillAmazonAddress(msg.address).then(sendResponse);
      return true; // keep channel open for async
    }
  });

})();
