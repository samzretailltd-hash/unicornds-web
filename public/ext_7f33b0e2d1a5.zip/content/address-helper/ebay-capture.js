// ============================================================
// Unicorn DS - eBay Address Capture (v2 — Robust Multi-Layout)
// Works on both /sh/ord/ and /mesh/ord/ layouts
// Strategies: DOM selectors → Structured text parsing → Broad fallback
// ============================================================

(() => {
  'use strict';
  console.log('[UnicornDS] eBay capture v2 loaded on', location.pathname);

  const COUNTRIES = [
    'United Kingdom','United States','Germany','France','Spain','Italy','Netherlands',
    'Belgium','Austria','Switzerland','Sweden','Norway','Denmark','Finland','Ireland',
    'Portugal','Poland','Czech Republic','Australia','New Zealand','Canada','Japan',
    'India','Brazil','Mexico','South Africa','United Arab Emirates','Saudi Arabia',
    'Turkey','China','Singapore','Malaysia','Thailand','Philippines','Indonesia',
    'Pakistan','Bangladesh','Nigeria','South Korea','Vietnam','Hong Kong','Taiwan',
    'Israel','Greece','Hungary','Romania','Bulgaria','Croatia','Slovakia','Slovenia',
    'Lithuania','Latvia','Estonia','Luxembourg','Malta','Cyprus','Iceland',
    'Puerto Rico','Guam','US Virgin Islands'
  ];

  const PHONE_CODES = {
    'United Kingdom':'44','United States':'1','Germany':'49','France':'33',
    'Spain':'34','Italy':'39','Netherlands':'31','Belgium':'32','Austria':'43',
    'Switzerland':'41','Ireland':'353','Australia':'61','Canada':'1','India':'91',
    'Pakistan':'92','Bangladesh':'880','New Zealand':'64','Japan':'81',
    'South Korea':'82','China':'86','Singapore':'65','Malaysia':'60','Brazil':'55',
    'Mexico':'52','South Africa':'27','Turkey':'90','Philippines':'63','Thailand':'66',
    'Indonesia':'62','Vietnam':'84','United Arab Emirates':'971','Saudi Arabia':'966',
    'Israel':'972','Poland':'48','Sweden':'46','Norway':'47','Denmark':'45','Finland':'358',
    'Portugal':'351','Czech Republic':'420','Hungary':'36','Romania':'40','Greece':'30',
    'Puerto Rico':'1','Hong Kong':'852','Taiwan':'886','Nigeria':'234'
  };

  const US_STATE_ABBR = {
    'AL':'Alabama','AK':'Alaska','AZ':'Arizona','AR':'Arkansas','CA':'California',
    'CO':'Colorado','CT':'Connecticut','DE':'Delaware','FL':'Florida','GA':'Georgia',
    'HI':'Hawaii','ID':'Idaho','IL':'Illinois','IN':'Indiana','IA':'Iowa',
    'KS':'Kansas','KY':'Kentucky','LA':'Louisiana','ME':'Maine','MD':'Maryland',
    'MA':'Massachusetts','MI':'Michigan','MN':'Minnesota','MS':'Mississippi',
    'MO':'Missouri','MT':'Montana','NE':'Nebraska','NV':'Nevada','NH':'New Hampshire',
    'NJ':'New Jersey','NM':'New Mexico','NY':'New York','NC':'North Carolina',
    'ND':'North Dakota','OH':'Ohio','OK':'Oklahoma','OR':'Oregon','PA':'Pennsylvania',
    'RI':'Rhode Island','SC':'South Carolina','SD':'South Dakota','TN':'Tennessee',
    'TX':'Texas','UT':'Utah','VT':'Vermont','VA':'Virginia','WA':'Washington',
    'WV':'West Virginia','WI':'Wisconsin','WY':'Wyoming','DC':'District of Columbia'
  };

  // ── STRATEGY 1: DOM-based capture ────────────────────────
  function captureFromDOM() {
    const info = makeEmpty();

    // Selector patterns for the shipping address container
    const addressContainerSelectors = [
      '[data-test-id="shipping-address"]',
      '[data-testid="shipping-address"]',
      '[data-test-id="ship-to-address"]',
      '[data-testid="ship-to-address"]',
      '[data-test-id="delivery-address"]',
      '[data-testid="delivery-address"]',
      '[class*="shipping-address"]',
      '[class*="shippingAddress"]',
      '[class*="ShippingAddress"]',
      '[class*="ship-to"]',
      '[class*="shipTo"]',
      '[class*="deliverTo"]',
      '[class*="deliver-to"]',
      '[class*="buyer-address"]',
      '[class*="buyerAddress"]',
      '[class*="order-address"]',
      'section[aria-label*="ship" i]',
      'section[aria-label*="address" i]',
      'section[aria-label*="deliver" i]',
      'div[aria-label*="ship" i]',
      'div[aria-label*="address" i]',
    ];

    let container = null;
    for (const sel of addressContainerSelectors) {
      container = document.querySelector(sel);
      if (container) {
        console.log('[UnicornDS] DOM: Found container via', sel);
        break;
      }
    }

    if (container) {
      const text = container.innerText.trim();
      return parseAddressBlock(text, info);
    }

    // Find heading/label elements that precede the address
    const allEls = document.querySelectorAll('h2, h3, h4, h5, span, div, label, dt, p, strong, b');
    for (const el of allEls) {
      const t = el.textContent.trim();
      if (/^(Post to|Ship to|Deliver to|Shipping address|Delivery address|Buyer'?s?\s*address|Versandadresse|Lieferadresse|Liefern an|Adresse de livraison|Livrer à|Expédier à)$/i.test(t)) {
        // Walk siblings/parent to find the address content
        const candidates = [
          el.nextElementSibling,
          el.closest('dt')?.nextElementSibling,
          el.parentElement?.nextElementSibling,
          el.parentElement?.querySelector('[class*="value"], [class*="content"], [class*="detail"], dd'),
        ].filter(Boolean);

        for (const addrEl of candidates) {
          if (addrEl === el) continue;
          const addrText = addrEl.innerText.trim();
          if (addrText.length > 5 && addrText.length < 800) {
            console.log('[UnicornDS] DOM: Found address after label "' + t + '"');
            return parseAddressBlock(addrText, info);
          }
        }
      }
    }

    // Look for copy buttons near address data
    const copyBtns = document.querySelectorAll(
      'button[aria-label*="copy" i], button[title*="copy" i], ' +
      '[data-test-id*="copy"], [class*="copy-btn"], [class*="copyBtn"], ' +
      '[class*="copy-icon"], [class*="copyIcon"]'
    );
    for (const btn of copyBtns) {
      const parent = btn.closest('[class*="address"], [class*="ship"], [class*="deliver"]')
        || btn.parentElement?.parentElement?.parentElement;
      if (parent) {
        const text = parent.innerText.trim();
        if (text.length > 10 && text.length < 600 && (
          /[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}/i.test(text) ||
          /\d{5}(-\d{4})?/.test(text) ||
          COUNTRIES.some(c => text.toLowerCase().includes(c.toLowerCase()))
        )) {
          console.log('[UnicornDS] DOM: Found address near copy button');
          return parseAddressBlock(text, info);
        }
      }
    }

    return null;
  }

  // ── STRATEGY 2: Text-based capture (innerText parsing) ───
  function captureFromText() {
    const info = makeEmpty();
    const bodyText = document.body.innerText;

    const markers = [
      { start: /Post\s+to/i, end: /(?:Phone|Buyer selected|Tracking|Add tracking|Dispatch by|Ship by|Order total|Payment|Delivery service|Postage service)/i },
      { start: /Ship\s+to/i, end: /(?:Phone|Buyer selected|Tracking|Add tracking|Dispatch by|Ship by|Order total|Payment|Delivery service|Postage service)/i },
      { start: /Deliver\s+to/i, end: /(?:Phone|Buyer selected|Tracking|Add tracking|Dispatch by|Ship by|Order total|Payment|Delivery service|Postage service)/i },
      { start: /Shipping\s+address/i, end: /(?:Phone|Buyer selected|Tracking|Add tracking|Dispatch by|Ship by|Order total|Payment|Billing|Delivery service|Postage service)/i },
      { start: /Delivery\s+address/i, end: /(?:Phone|Buyer selected|Tracking|Add tracking|Dispatch by|Ship by|Order total|Payment|Billing|Delivery service|Postage service)/i },
      { start: /Buyer['']?s?\s+address/i, end: /(?:Phone|Tracking|Add tracking|Dispatch by|Ship by|Order total|Payment|Delivery service|Postage service)/i },
      // German
      { start: /Versandadresse|Lieferadresse|Liefern an/i, end: /(?:Telefon|Sendungsverfolgung|Käufer|Versanddatum|Zahlung)/i },
      // French
      { start: /Adresse\s+de\s+livraison|Livrer à|Expédier à/i, end: /(?:Téléphone|Suivi|Acheteur|Date d'envoi|Paiement)/i },
      // Spanish
      { start: /Dirección\s+de\s+envío|Enviar a/i, end: /(?:Teléfono|Seguimiento|Comprador|Pago)/i },
    ];

    for (const { start, end } of markers) {
      const startMatch = bodyText.match(start);
      if (!startMatch) continue;

      const afterStart = bodyText.substring(startMatch.index + startMatch[0].length);
      const endMatch = afterStart.match(end);
      const block = endMatch ? afterStart.substring(0, endMatch.index) : afterStart.substring(0, 600);

      if (block.trim().length < 5) continue;

      console.log('[UnicornDS] Text: Found block after "' + startMatch[0] + '"');

      // Extract phone from the boundary or nearby text
      if (endMatch && /phone|telefon|téléphone|teléfono/i.test(endMatch[0])) {
        const afterEnd = afterStart.substring(endMatch.index + endMatch[0].length, endMatch.index + endMatch[0].length + 100);
        const phoneLine = afterEnd.split('\n').map(l => l.trim()).find(l => /[\d\+]/.test(l) && l.length >= 6);
        if (phoneLine) {
          info.phone = normalizePhone(phoneLine);
        }
      }

      // Fallback phone search
      if (!info.phone) {
        const phoneMatch = bodyText.match(/(?:Phone|Telefon|Téléphone|Teléfono)[:\s]*\n?\s*([\+\d][\d\s\-\(\)]{6,20})/i);
        if (phoneMatch) {
          info.phone = normalizePhone(phoneMatch[1]);
        }
      }

      return parseAddressBlock(block, info);
    }

    return null;
  }

  // ── Shared address block parser ──────────────────────────
  function parseAddressBlock(block, info) {
    let lines = block.split('\n')
      .map(l => l.replace(/[\u{1F4CB}\u{2398}\u{D83D}\u{2702}\u{270D}\u{1F4DD}]/gu, '').trim())
      .filter(l => l.length > 1);

    // Remove label/action/noise lines
    lines = lines.filter(l => !/^(Post|Ship|Deliver|Shipping|Delivery|Buyer['']?s?)\s+(to|address)$/i.test(l));
    lines = lines.filter(l => !/^(Copy|Kopieren|Copier|Copiar|copied|Edit|Change)$/i.test(l));
    lines = lines.filter(l => !/^ebay[a-z0-9]+$/i.test(l));
    lines = lines.filter(l => !/^(View order|Print|Cancel|Refund|Contact buyer|Mark as|Dispatch by|Ship by|Add tracking|Tracking number)/i.test(l));
    lines = lines.filter(l => l.replace(/[^\w]/g, '').length > 0);

    console.log('[UnicornDS] Cleaned lines:', lines);
    if (lines.length === 0) return null;

    // Extract and remove phone line if embedded in the block
    let phoneLineIdx = -1;
    for (let i = 0; i < lines.length; i++) {
      // Match "Phone", "Phone:", "Phone number", "Telefon", "Téléphone", "Teléfono", "Mobile", "Tel", "Tel:"
      if (/^(Phone|Phone\s*number|Phone\s*no\.?|Tel\.?|Telephone|Mobile|Telefon|Téléphone|Teléfono|Cellulare|Celular)\s*:?\s*$/i.test(lines[i])) {
        phoneLineIdx = i;
        if (i + 1 < lines.length && /[\d\+]/.test(lines[i + 1])) {
          info.phone = normalizePhone(lines[i + 1]);
        }
        break;
      }
      // Or inline: "Phone: +44 7123 456789" on one line
      const inlineMatch = lines[i].match(/^(?:Phone|Phone\s*number|Tel\.?|Telephone|Mobile|Telefon|Téléphone|Teléfono)\s*:?\s*([\+\d][\d\s\-\(\)]{5,})\s*$/i);
      if (inlineMatch) {
        info.phone = normalizePhone(inlineMatch[1]);
        phoneLineIdx = i;
        break;
      }
    }
    // Also scan for standalone phone-looking line (when no "Phone" label was captured in block)
    if (!info.phone) {
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        // Skip name, country, postcode lines
        if (i === 0) continue;
        // A phone line: starts with + or 0, mostly digits/spaces/hyphens, 7-18 digits total
        const m = line.match(/^(\+?\d[\d\s\-\(\)]{6,20})$/);
        if (m) {
          const digitsOnly = m[1].replace(/\D/g, '');
          if (digitsOnly.length >= 7 && digitsOnly.length <= 15) {
            // Make sure it's not a postcode/zip — postcodes have letters or are 5 digits US
            if (!/[A-Z]/i.test(line) && digitsOnly.length >= 7) {
              info.phone = normalizePhone(m[1]);
              phoneLineIdx = i;
              break;
            }
          }
        }
      }
    }
    const addrLines = phoneLineIdx >= 0 ? lines.slice(0, phoneLineIdx) : [...lines];
    if (addrLines.length === 0) return null;

    // Line 0 = Name
    info.name = addrLines[0];
    const nameParts = info.name.split(/\s+/);
    info.firstName = nameParts[0] || '';
    info.lastName = nameParts.slice(1).join(' ') || info.firstName;

    // Find country (scan from bottom)
    let countryIdx = -1;
    for (let i = addrLines.length - 1; i >= 1; i--) {
      const found = COUNTRIES.find(c =>
        addrLines[i].toLowerCase() === c.toLowerCase() ||
        addrLines[i].toLowerCase().trim() === c.toLowerCase()
      );
      if (found) {
        info.country = found;
        countryIdx = i;
        break;
      }
      // Partial match (country name within a longer line)
      const partial = COUNTRIES.find(c => addrLines[i].toLowerCase().includes(c.toLowerCase()) && addrLines[i].length < c.length + 15);
      if (partial) {
        info.country = partial;
        countryIdx = i;
        break;
      }
    }

    // Find postcode (scan from bottom)
    let postcodeIdx = -1;
    for (let i = addrLines.length - 1; i >= 1; i--) {
      const line = addrLines[i];
      if (i === countryIdx) continue; // skip pure country line

      // UK postcode
      const ukMatch = line.match(/\b([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})\b/i);
      if (ukMatch) {
        info.zip = ukMatch[1].toUpperCase();
        const beforeZip = line.substring(0, line.search(/[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}/i)).replace(/,\s*$/, '').trim();
        if (beforeZip) {
          const cityParts = beforeZip.split(',').map(s => s.trim()).filter(Boolean);
          info.city = cityParts[0];
          if (cityParts.length > 1) info.state = cityParts[cityParts.length - 1];
        }
        postcodeIdx = i;
        break;
      }

      // US zip
      const usMatch = line.match(/\b(\d{5}(-\d{4})?)\b/);
      if (usMatch) {
        info.zip = usMatch[1];
        postcodeIdx = i;
        const beforeZip = line.substring(0, line.indexOf(usMatch[1])).replace(/,\s*$/, '').trim();
        if (beforeZip) {
          const match2 = beforeZip.match(/^(.+?),?\s+([A-Z]{2})$/);
          if (match2) {
            info.city = match2[1].replace(/,\s*$/, '');
            info.state = US_STATE_ABBR[match2[2]] || match2[2];
          } else {
            info.city = beforeZip;
          }
        }
        break;
      }

      // German PLZ
      const deMatch = line.match(/^(\d{5})\s+(.+)/);
      if (deMatch && (!info.country || /Germany|Deutschland/i.test(info.country))) {
        info.zip = deMatch[1];
        info.city = deMatch[2];
        postcodeIdx = i;
        break;
      }

      // Canadian postal code
      const caMatch = line.match(/\b([A-Z]\d[A-Z]\s*\d[A-Z]\d)\b/i);
      if (caMatch) {
        info.zip = caMatch[1].toUpperCase();
        postcodeIdx = i;
        break;
      }

      // Australian 4-digit
      if (/Australia/i.test(info.country || '')) {
        const auMatch = line.match(/\b(\d{4})\b/);
        if (auMatch) {
          info.zip = auMatch[1];
          postcodeIdx = i;
          break;
        }
      }
    }

    // Street = everything between name and postcode/country
    const streetParts = [];
    const endIdx = Math.min(
      postcodeIdx >= 0 ? postcodeIdx : addrLines.length,
      countryIdx >= 0 ? countryIdx : addrLines.length
    );
    for (let i = 1; i < endIdx; i++) {
      const line = addrLines[i];
      if (/^ebay[a-z0-9]+$/i.test(line)) continue;
      if (COUNTRIES.some(c => line.toLowerCase() === c.toLowerCase())) continue;
      streetParts.push(line);
    }
    info.street1 = streetParts.join(', ');

    // If no city yet, try line before postcode
    if (!info.city && postcodeIdx > 1 && !streetParts.includes(addrLines[postcodeIdx - 1])) {
      info.city = addrLines[postcodeIdx - 1];
    }

    // Phone splitting
    splitPhone(info);

    // Default phone code from country
    if (!info.phoneCode && info.country && PHONE_CODES[info.country]) {
      info.phoneCode = '+' + PHONE_CODES[info.country];
    }

    if (!info.name || info.name.length < 2) return null;

    console.log('[UnicornDS] PARSED:', JSON.stringify(info, null, 2));
    return info;
  }

  // ── Phone splitter ───────────────────────────────────────
  function splitPhone(info) {
    if (!info.phone) return;
    const cleaned = info.phone.replace(/[\s\-\(\)]/g, '');
    if (!cleaned.startsWith('+')) return;
    const digits = cleaned.substring(1);
    const codes = Object.values(PHONE_CODES).sort((a, b) => b.length - a.length);
    for (const code of codes) {
      if (digits.startsWith(code)) {
        info.phoneCode = '+' + code;
        info.phoneNumber = digits.substring(code.length);
        return;
      }
    }
    info.phoneCode = '+' + digits.substring(0, 2);
    info.phoneNumber = digits.substring(2);
  }

  function makeEmpty() {
    return {
      name:'', firstName:'', lastName:'', phone:'', phoneCode:'', phoneNumber:'',
      email:'', street1:'', street2:'', zip:'', country:'', state:'', city:''
    };
  }

  // Normalize a raw phone string: strip formatting, keep leading + if present.
  // Does NOT force a leading + when one is absent — a national-format number
  // like "07123 456789" (UK) should stay as "07123456789", not become "+07123...".
  function normalizePhone(raw) {
    if (!raw) return '';
    let s = String(raw).trim();
    const hadPlus = s.startsWith('+');
    s = s.replace(/[\s\-\(\)\.]/g, '');
    if (!hadPlus) s = s.replace(/^\+/, ''); // safety
    return hadPlus ? '+' + s.replace(/^\+/, '') : s;
  }

  // If the main capture didn't find a phone (phone is often OUTSIDE the address
  // block in eBay's DOM), scan the whole document for the "Phone" label and
  // the number that follows it. This is the safety net that catches most cases.
  function findPhoneAtDocumentLevel() {
    try {
      // EcomSniper method: the mesh order page has phone in .phone.ship-itm
      var shipPhone = document.querySelector('.phone.ship-itm');
      if (shipPhone) {
        var pv = shipPhone.querySelector('.info-value') || shipPhone;
        var ptxt = (pv.innerText || pv.textContent || '').trim();
        if (ptxt && /[\d]/.test(ptxt)) return normalizePhone(ptxt);
      }
      const body = document.body.innerText || '';
      // Pattern 1: "Phone\n+44 7123 456789" (label on its own line)
      let m = body.match(/(?:Phone\s*(?:number|no\.?)?|Tel\.?|Telephone|Mobile|Telefon|Téléphone|Teléfono|Cellulare|Celular)\s*:?\s*\n\s*([\+\d][\d\s\-\(\)]{5,20})/i);
      if (m) return normalizePhone(m[1]);
      // Pattern 2: "Phone: +44 7123 456789" (inline)
      m = body.match(/(?:Phone\s*(?:number|no\.?)?|Tel\.?|Telephone|Mobile|Telefon|Téléphone|Teléfono)\s*:\s*([\+\d][\d\s\-\(\)]{5,20})/i);
      if (m) return normalizePhone(m[1]);
      // Pattern 3: tel: link (eBay sometimes renders phone as clickable link)
      const telLink = document.querySelector('a[href^="tel:"]');
      if (telLink) {
        const href = telLink.getAttribute('href') || '';
        const num = href.replace(/^tel:/i, '').trim();
        if (num) return normalizePhone(num);
      }
    } catch (e) { /* ignore */ }
    return '';
  }

  // ── Main capture ─────────────────────────────────────────
  function captureAddress(attempt) {
    console.log('[UnicornDS] Capture attempt', attempt + 1);
    // Strategy 1: DOM selectors
    let result = captureFromDOM();
    if (result && result.name) {
      if (!result.phone) {
        const docPhone = findPhoneAtDocumentLevel();
        if (docPhone) {
          result.phone = docPhone;
          console.log('[UnicornDS] Phone backfilled from document scan:', docPhone);
        } else {
          console.log('[UnicornDS] ⚠️ No phone number found on this page');
        }
      }
      return result;
    }
    // Strategy 2: Text parsing
    result = captureFromText();
    if (result && result.name) {
      if (!result.phone) {
        const docPhone = findPhoneAtDocumentLevel();
        if (docPhone) {
          result.phone = docPhone;
          console.log('[UnicornDS] Phone backfilled from document scan:', docPhone);
        } else {
          console.log('[UnicornDS] ⚠️ No phone number found on this page');
        }
      }
      return result;
    }
    console.log('[UnicornDS] No address found on attempt', attempt + 1);
    return null;
  }

  // ── Message listener with SPA retry ──────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'ping') {
      sendResponse({ loaded: true });
      return;
    }

    if (msg.action === 'captureAddress') {
      const tryCapture = (attempt) => {
        try {
          const result = captureAddress(attempt);
          if (result && result.name) {
            sendResponse({ orderInfo: result, source: 'ebay' });
            return;
          }
          if (attempt < 3) {
            setTimeout(() => tryCapture(attempt + 1), 800 * (attempt + 1));
          } else {
            sendResponse({ orderInfo: null, error: 'Could not find shipping address. Make sure you are on an order detail page (/sh/ord/ or /mesh/ord/).' });
          }
        } catch (e) {
          console.error('[UnicornDS] eBay capture error:', e);
          sendResponse({ orderInfo: null, error: e.message });
        }
      };
      tryCapture(0);
      return true;
    }
  });
})();
