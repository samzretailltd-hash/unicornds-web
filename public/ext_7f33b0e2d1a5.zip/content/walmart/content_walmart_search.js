/**
 * UnicornDS — Walmart Search Scraper (Product Hunter)
 * Runs on: walmart.com/search* and walmart.ca/search*
 *
 * Mirrors content_amazon_search.js: responds to 'hunter_scrape_search'
 * with { products } in the SAME shape the hunter UI expects.
 * Reads the __NEXT_DATA__ searchResult JSON (reliable, no fragile DOM).
 */
(function () {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'hunter_scrape_search') {
      console.log('[UnicornDS] Scraping Walmart search results...');
      const results = scrapeSearch(msg.settings || {});
      console.log('[UnicornDS] Walmart scraped', results.length, 'products, sample:', results[0]);
      sendResponse({ products: results });
    }
    return true;
  });

  function getNextData() {
    const el = document.getElementById('__NEXT_DATA__');
    if (!el || !el.textContent) return null;
    try { return JSON.parse(el.textContent); } catch (_) { return null; }
  }

  // Collect search-result items by walking the JSON for objects that look like products
  function collectItems(root) {
    const items = [];
    const seen = new Set();
    const seenIds = new Set();
    (function walk(node) {
      if (!node || typeof node !== 'object' || seen.has(node)) return;
      seen.add(node);
      if (Array.isArray(node)) { node.forEach(walk); return; }
      const id = node.usItemId || node.id;
      const name = node.name;
      const hasPrice = node.priceInfo || node.price || node.primaryOffer;
      if (id && typeof name === 'string' && name.length > 3 && hasPrice && !seenIds.has(id)) {
        seenIds.add(id);
        items.push(node);
      }
      for (const v of Object.values(node)) walk(v);
    })(root);
    return items;
  }

  function priceOf(it) {
    const p = it.priceInfo?.currentPrice?.price
      ?? it.priceInfo?.linePrice
      ?? (typeof it.price === 'number' ? it.price : null)
      ?? it.primaryOffer?.offerPrice;
    const n = parseFloat(p);
    return isNaN(n) ? 0 : n;
  }

  function imageOf(it) {
    let u = it.imageInfo?.thumbnailUrl || it.image || it.imageUrl || '';
    if (!u) return '';
    if (u.startsWith('//')) u = 'https:' + u;
    return u.split('?')[0] + '?odnHeight=400&odnWidth=400&odnBg=FFFFFF';
  }

  function badgesOf(it) {
    const out = [];
    const b = it.badges;
    if (Array.isArray(b)) b.forEach(x => out.push((x.text || x.key || '').toString()));
    else if (b && typeof b === 'object') {
      (b.flags || b.tags || []).forEach(x => out.push((x.text || x.key || '').toString()));
    }
    if (it.sponsoredProduct || it.isSponsored) out.push('sponsored');
    return out.join(' ').toLowerCase();
  }

  function scrapeSearch(settings) {
    const data = getNextData();
    const product = [];
    if (!data) { console.warn('[UnicornDS] Walmart search: no __NEXT_DATA__'); return product; }

    const host = location.hostname;
    const cur = /walmart\.ca$/i.test(host) ? 'C$' : '$';
    const wmRoot = /walmart\.ca$/i.test(host) ? 'https://www.walmart.ca' : 'https://www.walmart.com';

    const minPrice = parseFloat(settings.minPrice) || 0;
    const maxPrice = parseFloat(settings.maxPrice) || 999999;
    const minReviews = parseInt(settings.minReviews) || 0;
    const maxReviews = parseInt(settings.maxReviews) || 100000000;
    const perTerm = parseInt(settings.productsPerTerm) || 5;

    const items = collectItems(data);
    const products = [];
    let skipped3p = 0;

    for (const it of items) {
      const badgeText = badgesOf(it);
      if (/sponsored/.test(badgeText)) continue;       // skip ads
      if (it.type && String(it.type).toUpperCase() === 'AD') continue;

      // STRICT: only Walmart-fulfilled (first-party). Skip confirmed 3P tiles.
      // Unknown tiles are kept — the product page applies the hard first-party gate.
      const _sd = self.UDSWmtSeller.detect(it, '');
      if (_sd.firstParty === false) { skipped3p++; continue; }

      const itemId = String(it.usItemId || it.id);
      const title = (it.name || '').trim();
      const price = priceOf(it);
      if (price < minPrice || price > maxPrice) continue;

      const reviewCount = parseInt(it.rating?.numberOfReviews ?? it.numberOfReviews ?? 0) || 0;
      if (reviewCount < minReviews || reviewCount > maxReviews) continue;

      const rating = parseFloat(it.rating?.averageRating ?? it.averageRating ?? 0) || 0;
      const isBestSeller = /best\s?seller|popular pick/.test(badgeText);
      const boughtMatch = badgeText.match(/([\d,]+\+?\s*bought)/);
      const canonical = it.canonicalUrl || ('/ip/' + itemId);
      const url = canonical.startsWith('http') ? canonical : (wmRoot + canonical);

      products.push({
        asin: itemId,            // reuse asin slot = Walmart item id (dedupe/existingAsins)
        itemId,
        title,
        price,
        image: imageOf(it),
        reviewCount,
        rating,
        isAmazonChoice: false,
        isBestSeller,
        url,
        productUrl: url,
        source: 'walmart',
        isSponsored: false,
        currencySymbol: cur,
        prime: false,
        stockHint: '',
        boughtText: boughtMatch ? boughtMatch[1] : '',
      });
    }

    // Best first by reviews, then cap to productsPerTerm
    products.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
    if (skipped3p) console.log('[UnicornDS] Walmart hunter: skipped', skipped3p, '3rd-party tiles (strict first-party)');
    return products.slice(0, perTerm);
  }
})();
