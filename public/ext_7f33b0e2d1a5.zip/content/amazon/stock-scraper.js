/**
 * UnicornDS - Amazon live-DOM stock scraper (Deep check)
 * Runs on Amazon /dp/ product pages. Reads the FULLY RENDERED page (so it can
 * see free shipping, delivery date and Prime, which are added by Amazon's JS),
 * and reports a flags object back to the background.
 *
 * The core detector `udsDetectAmazonStock(doc)` is a PURE function (no chrome,
 * no network) so it can be unit-tested against saved Amazon HTML with jsdom.
 * Everything below the ===RUNNER=== marker is the content-script wrapper.
 */
'use strict';

// ===DETECTOR=== (pure, testable — do not use chrome APIs above the RUNNER marker)
function udsDetectAmazonStock(doc) {
  const flags = {
    blocked: false,
    readable: false,
    isPageCorrectlyOpened: false,
    availState: 'unclear',      // 'in' | 'out' | 'unclear'
    availMsg: '',
    hasFreeShipping: false,
    freeShippingKnown: false,
    deliveryDays: null,         // number of days until delivery, or null if unknown
    itemCondition: 'unknown',   // 'used' | 'unknown'
    isEligibleForPrime: false,
    primeKnown: false,
    price: '',
  };

  const bodyText = ((doc.body && doc.body.textContent) || '').toLowerCase();

  // 1) Block / captcha
  const blockMarkers = [
    'enter the characters you see below', 'type the characters you see in this image',
    'to discuss automated access', 'api-services-support@amazon.com',
    'sorry, we just need to make sure you', 'robot check', 'automated access to amazon data',
  ];
  if (blockMarkers.some(m => bodyText.includes(m))) { flags.blocked = true; return flags; }

  // 2) Page opened correctly (product image block present)
  flags.isPageCorrectlyOpened =
    !!doc.querySelector('#imageBlock, #imageBlock_feature_div, #main-image-container, #imgTagWrapperId');

  const availEl = doc.querySelector('#availability');
  const buyboxEl = doc.querySelector('#buybox, #desktop_buybox, #qualifiedBuyBox, #rightCol');
  const addToCart = doc.querySelector('#add-to-cart-button, #buy-now-button, input[name="submit.add-to-cart"], input[name="submit.buy-now"]');
  flags.readable = flags.isPageCorrectlyOpened || !!availEl || !!buyboxEl || !!doc.querySelector('#productTitle');
  if (!flags.readable) return flags;

  // 3) Availability message (normalised)
  let availMsg = '';
  if (availEl) {
    availMsg = (availEl.textContent || '').toLowerCase();
    if (availMsg.indexOf('{') > -1) availMsg = availMsg.substring(0, availMsg.indexOf('{'));
    availMsg = availMsg.replace(/\s+/g, ' ').replace(/\.$/, '').trim();
  }
  flags.availMsg = availMsg;

  const IN_PATTERNS = [
    /^in stock\b/, /^only \d+ left in stock/, /^usually (dispatched|ships)/,
    /available to (ship|dispatch)/, /^in stock soon/,
    /^auf lager/, /^nur noch \d+ auf lager/, /^en stock/, /^disponible/,
    /^disponibilit/, /^op voorraad/, /^nog \d+ op voorraad/,
  ];
  const OUT_PATTERNS = [
    /currently unavailable/, /out of stock/, /temporarily out of stock/,
    /we don't know when or if this item will be back/, /this item is not available/,
    /nicht verf/, /actuellement indisponible/, /non disponibile/, /no disponible/,
  ];
  const isIn = !!availMsg && IN_PATTERNS.some(r => r.test(availMsg)) && !/out of stock|unavailable/.test(availMsg);
  const isOut = !!availMsg && OUT_PATTERNS.some(r => r.test(availMsg));
  if (isOut && !isIn) flags.availState = 'out';
  else if (isIn) flags.availState = 'in';
  else if (addToCart) flags.availState = 'in';   // fallback: buy button present

  // Out-of-stock can live in the buy box / out-of-stock billboard instead of
  // #availability (common on variation products). Check those specifically —
  // NOT the whole page, so other-variation OOS text can't cause false hits.
  if (flags.availState === 'unclear') {
    const oosEl = doc.querySelector('#outOfStock, #exports_desktop_outOfStock_billboard, #availabilityInsideBuyBox_feature_div, #buyBoxAccordion');
    const oosText = (((oosEl && oosEl.textContent) || '') + ' ' + ((buyboxEl && buyboxEl.textContent) || '')).toLowerCase();
    if (/currently unavailable|we don't know when or if this item will be back|this item is not available|no longer available for/.test(oosText)) {
      flags.availState = 'out';
      if (!flags.availMsg) flags.availMsg = 'currently unavailable';
    }
  }

  // 4) Free shipping — read the buy box text. Only "known" if the buy box
  //    actually mentions shipping/delivery at all.
  const buyboxText = buyboxEl ? (buyboxEl.textContent || '').toLowerCase() : '';
  const FREE_SHIP = ['free shipping', 'free delivery', 'gratis lieferung', 'livraison gratuite',
    'spedizione gratuita', 'consegna gratuita', 'envío gratis', 'entrega gratis',
    'gratis verzending', 'gratis bezorging', 'gratis levering'];
  const mentionsShipping = /(shipping|delivery|lieferung|livraison|spedizione|bezorg|verzend|envío|entrega)/i.test(buyboxText);
  flags.freeShippingKnown = mentionsShipping;
  flags.hasFreeShipping = mentionsShipping && FREE_SHIP.some(p => buyboxText.includes(p));

  // 5) Delivery date → days from now (live DOM has the rendered delivery block)
  const delEl =
    doc.querySelector('[data-csa-c-delivery-time]') ||
    doc.querySelector('#mir-layout-DELIVERY_BLOCK-slot-PRIMARY_DELIVERY_MESSAGE_LARGE span[data-csa-c-delivery-time]') ||
    doc.querySelector('#deliveryBlockMessage');
  let deliveryStr = '';
  if (delEl) deliveryStr = delEl.getAttribute('data-csa-c-delivery-time') || delEl.textContent || '';
  if (deliveryStr) {
    const days = udsParseDeliveryDays(deliveryStr);
    if (days != null) flags.deliveryDays = days;
  }

  // 6) Condition — used buy box present, no new section
  if (doc.querySelector('#usedbuyBox') && !doc.querySelector('#buyNewSection')) flags.itemCondition = 'used';

  // 7) Prime — icon or fulfilment program markers (rendered)
  const primeIcon = doc.querySelector('.a-icon-prime, [aria-label*="Prime" i], [data-csa-c-delivery-benefit-program-id]');
  if (primeIcon) {
    flags.primeKnown = true;
    const prog = primeIcon.getAttribute && primeIcon.getAttribute('data-csa-c-delivery-benefit-program-id');
    flags.isEligibleForPrime = !!doc.querySelector('.a-icon-prime') || /cfs|ncp/i.test(prog || '');
  }

  // 8) Price (display only)
  const priceEl = doc.querySelector('#corePrice_feature_div .a-offscreen, #corePriceDisplay_desktop_feature_div .a-offscreen, .a-price .a-offscreen, #priceblock_ourprice');
  if (priceEl) flags.price = (priceEl.textContent || '').trim();

  return flags;
}

// Parse an Amazon delivery string into "days from today". Returns null if unknown.
function udsParseDeliveryDays(str, now) {
  now = now || new Date();
  const s = String(str).trim();
  // ISO date e.g. "2026-08-30"
  let m = s.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (m) {
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    return Math.round((d - stripTime(now)) / 86400000);
  }
  // "Tuesday, 30 August" / "30 August" / "August 30"
  const months = ['january','february','march','april','may','june','july','august','september','october','november','december'];
  const low = s.toLowerCase();
  let day = null, mon = null;
  let dm = low.match(/(\d{1,2})\s+([a-zéûôà]+)/); // "30 august"
  if (dm) { day = +dm[1]; mon = months.findIndex(mn => dm[2].startsWith(mn.slice(0, 3))); }
  if (mon == null || mon < 0) {
    let md = low.match(/([a-zéûôà]+)\s+(\d{1,2})/); // "august 30"
    if (md) { mon = months.findIndex(mn => md[1].startsWith(mn.slice(0, 3))); day = +md[2]; }
  }
  if (day != null && mon != null && mon >= 0) {
    let d = new Date(now.getFullYear(), mon, day);
    if (d < stripTime(now)) d = new Date(now.getFullYear() + 1, mon, day); // year wrap
    return Math.round((d - stripTime(now)) / 86400000);
  }
  return null;
}
function stripTime(d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }

// ===RUNNER=== (content-script wrapper — chrome APIs allowed below here)
(function () {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.onMessage) return;

  // Only act when the background asked this tab to be scraped for stock.
  // (Background opens the tab with #uds-stockcheck so we don't scrape normal browsing.)
  const isCheckTab = location.hash.indexOf('uds-stockcheck') > -1 ||
                     location.search.indexOf('uds_stockcheck=1') > -1;

  async function waitForReady(maxMs) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
      const ready =
        document.querySelector('#availability') ||
        document.querySelector('#add-to-cart-button, #buy-now-button') ||
        document.querySelector('#outOfStock, #exports_desktop_outOfStock_billboard') ||
        /enter the characters you see below/i.test(document.body ? document.body.textContent : '');
      if (ready) break;
      await new Promise(r => setTimeout(r, 300));
    }
    // give the delivery/prime block a moment to settle
    await new Promise(r => setTimeout(r, 1200));
  }

  async function run() {
    try {
      await waitForReady(9000);
      const flags = udsDetectAmazonStock(document);
      chrome.runtime.sendMessage({ type: 'uds_amazon_scrape_result', data: flags });
    } catch (e) {
      chrome.runtime.sendMessage({ type: 'uds_amazon_scrape_result', data: { blocked: false, readable: false, error: e.message } });
    }
  }

  if (isCheckTab) {
    if (document.readyState === 'complete' || document.readyState === 'interactive') run();
    else document.addEventListener('DOMContentLoaded', run);
  }
})();
