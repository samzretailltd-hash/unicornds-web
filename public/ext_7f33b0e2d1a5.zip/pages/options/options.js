/**
 * UnicornDS - Full Settings Page
 */

const KEYS = {
  'market': 'unicornds_primary_market',
  'international': 'unicornds_international',
  'ebayStore': 'unicornds_ebay_store',
  'forceLocation': 'unicornds_force_location',
  'locationCountry': 'unicornds_location_country',
  'locationCity': 'unicornds_location_city',
  'storeName': 'unicornds_store_name',
  'markup': 'unicornds_markup',
  'vat': 'unicornds_vat',
  'adRate': 'unicornds_ad_rate',
  'roundPrices': 'unicornds_round_prices',
  'aiEnabled': 'unicornds_ai_enabled',
  'removeWords': 'unicornds_remove_words',
  'useTemplateImage': 'unicornds_use_template_image',
  'autoCondition': 'unicornds_auto_condition',
  'autoSpecs': 'unicornds_auto_specs',
  'autoPromote': 'unicornds_auto_promote',
  'maxImages': 'unicornds_max_images',
  'forceReturns': 'unicornds_force_returns',
  'returnPolicyId': 'unicornds_return_policy_id',
  'stockQty': 'unicornds_stock_qty',
  'promoRate': 'unicornds_promo_rate',
  'autoApprove': 'unicornds_auto_approve',
};

const $ = id => document.getElementById(id);

// ═══════════════════════════════════════════════════════
// NAV
// ═══════════════════════════════════════════════════════
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.section-content').forEach(s => s.style.display = 'none');
    $('sec-' + btn.dataset.section).style.display = '';
  });
});

// ═══════════════════════════════════════════════════════
// LOAD
// ═══════════════════════════════════════════════════════
function loadSettings() {
  const storageKeys = Object.values(KEYS);
  chrome.storage.local.get([...storageKeys, 'unicornds_email', 'unicornds_membership', 'unicornds_credits', 'unicornds_max_credits'], data => {
    for (const [elId, stKey] of Object.entries(KEYS)) {
      const el = $(elId);
      if (!el) continue;
      const val = data[stKey];
      if (val === undefined) continue;

      if (el.type === 'checkbox') el.checked = val;
      else el.value = val;
    }

    // Account
    $('accEmail').textContent = data.unicornds_email || '-';
    $('accPlan').textContent = (data.unicornds_membership || 'free').charAt(0).toUpperCase() + (data.unicornds_membership || 'free').slice(1);
    $('accUsed').textContent = (data.unicornds_credits || 0) + '/' + (data.unicornds_max_credits || 10);
    $('accVersion').textContent = chrome.runtime.getManifest().version;
    $('version').textContent = 'v' + chrome.runtime.getManifest().version;
  });
}

// ═══════════════════════════════════════════════════════
// SAVE
// ═══════════════════════════════════════════════════════
$('btnSave').addEventListener('click', () => {
  const settings = {};
  for (const [elId, stKey] of Object.entries(KEYS)) {
    const el = $(elId);
    if (!el) continue;
    if (el.type === 'checkbox') settings[stKey] = el.checked;
    else if (el.type === 'number') settings[stKey] = parseFloat(el.value) || 0;
    else settings[stKey] = el.value;
  }

  // Also set domain for backward compatibility
  // Amazon source domain per market (AT/CH buy from amazon.de, IE from amazon.co.uk)
  const marketToDomain = { 'com':'com','co_uk':'co.uk','de':'de','com_au':'com.au','ca':'ca',
    'fr':'fr','it':'it','es':'es','nl':'nl','ie':'co.uk','at':'de','be':'com.be','ch':'de' };
  settings.domain = marketToDomain[settings.unicornds_primary_market] || 'co.uk';

  chrome.storage.local.set(settings, () => {
    $('savedMsg').style.display = 'inline';
    setTimeout(() => $('savedMsg').style.display = 'none', 3000);
  });
});

// ═══════════════════════════════════════════════════════
// EXPORT / IMPORT / RESET
// ═══════════════════════════════════════════════════════
$('btnExportSettings').addEventListener('click', () => {
  chrome.storage.local.get(null, data => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.download = 'unicornds-settings.json';
    link.href = URL.createObjectURL(blob);
    link.click();
  });
});

$('btnImportSettings').addEventListener('click', () => $('importFile').click());
$('importFile').addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const data = JSON.parse(ev.target.result);
      chrome.storage.local.set(data, () => {
        alert('Settings imported! Reloading...');
        loadSettings();
      });
    } catch (err) { alert('Invalid settings file'); }
  };
  reader.readAsText(file);
});

$('btnResetAll').addEventListener('click', () => {
  if (confirm('This will delete ALL settings and data. Are you sure?')) {
    chrome.storage.local.clear(() => {
      alert('All settings reset. Reloading...');
      loadSettings();
    });
  }
});

// ═══════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', loadSettings);
