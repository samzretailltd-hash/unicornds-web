'use strict';
console.log('[UnicornDS] Order Manager v2.0 loaded');

// Resolve eBay and Amazon TLD from the user's primary market (extension pages have no current eBay page)
const UDS_MKT_DOMAIN = { com:'com', co_uk:'co.uk', de:'de', com_au:'com.au', ca:'ca', fr:'fr', it:'it', es:'es', nl:'nl', at:'at', be:'be', ch:'ch', ie:'ie', in:'in' };
function udsMarketDomain(m) { return UDS_MKT_DOMAIN[m] || 'co.uk'; }
// Market-aware date locale (US shows MM/DD, UK shows DD/MM)
const UDS_MKT_LOCALE = { com:'en-US', co_uk:'en-GB', ca:'en-CA', com_au:'en-AU', de:'de-DE',
  fr:'fr-FR', it:'it-IT', es:'es-ES', nl:'nl-NL', ie:'en-IE', at:'de-AT', be:'fr-BE', ch:'de-CH' };
let UDS_MKT = 'co_uk';
try { chrome.storage.local.get('unicornds_primary_market', s => { if (s && s.unicornds_primary_market) UDS_MKT = s.unicornds_primary_market; }); } catch (e) {}
function udsLocale() { return UDS_MKT_LOCALE[UDS_MKT] || 'en-GB'; }


let orders = [];
let currentFilter = 'all';
let dateRange = { from: null, to: null };
let dateRangeDays = 90; // current active range in days, used by sync
let activeOrderId = null;
let searchQuery = '';
let selectedOrderIds = new Set(); // v7.20 — for bulk fulfill

// ═══════════════════════════════════════
// STORAGE
// ═══════════════════════════════════════
async function loadOrders() {
  return new Promise(resolve => {
    chrome.storage.local.get('unicornds_orders', data => {
      orders = data.unicornds_orders || [];
      resolve();
    });
  });
}

function saveOrders() {
  chrome.storage.local.set({ unicornds_orders: orders });
}

// ═══════════════════════════════════════
// DATE HELPERS
// ═══════════════════════════════════════
function parseOrderDate(o) {
  if (o.soldDateTs && !isNaN(o.soldDateTs)) return new Date(o.soldDateTs);
  if (o.soldDate) {
    const s = o.soldDate.trim();

    // Format: "X days ago" / "Yesterday" / "Today"
    if (/today/i.test(s)) return new Date();
    if (/yesterday/i.test(s)) { const d = new Date(); d.setDate(d.getDate() - 1); return d; }
    const agoMatch = s.match(/(\d+)\s*day/i);
    if (agoMatch) { const d = new Date(); d.setDate(d.getDate() - parseInt(agoMatch[1])); return d; }
    const hrMatch = s.match(/(\d+)\s*h(ou)?r/i);
    if (hrMatch) { const d = new Date(); d.setHours(d.getHours() - parseInt(hrMatch[1])); return d; }
    const minMatch = s.match(/(\d+)\s*min/i);
    if (minMatch) { const d = new Date(); d.setMinutes(d.getMinutes() - parseInt(minMatch[1])); return d; }

    // Format: "23 May 2026" / "23 May" (current year)
    const dmyMatch = s.match(/(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
    if (dmyMatch) {
      const d = new Date(`${dmyMatch[2]} ${dmyMatch[1]}, ${dmyMatch[3]}`);
      if (!isNaN(d.getTime())) return d;
    }
    const dmMatch = s.match(/^(\d{1,2})\s+([A-Za-z]+)$/);
    if (dmMatch) {
      const d = new Date(`${dmMatch[2]} ${dmMatch[1]}, ${new Date().getFullYear()}`);
      if (!isNaN(d.getTime())) return d;
    }

    // Format: "Sold 23 May" / "Sold 23 May 2026"
    const soldMatch = s.match(/sold[^\d]*(\d{1,2})\s+([A-Za-z]+)\s*(\d{4})?/i);
    if (soldMatch) {
      const year = soldMatch[3] || new Date().getFullYear();
      const d = new Date(`${soldMatch[2]} ${soldMatch[1]}, ${year}`);
      if (!isNaN(d.getTime())) return d;
    }

    // Format: DD/MM/YYYY
    const slash = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (slash) return new Date(parseInt(slash[3]), parseInt(slash[2]) - 1, parseInt(slash[1]));

    // Fallback: standard Date parse
    const d = new Date(s);
    if (!isNaN(d.getTime())) return d;
  }
  if (o.createdAt) return new Date(o.createdAt);
  return new Date();
}

function filterByDate(list) {
  if (!dateRange.from && !dateRange.to) return list;
  return list.filter(o => {
    const d = parseOrderDate(o);
    // If date is invalid, ALWAYS include the order (don't silently hide it)
    if (!d || isNaN(d.getTime())) return true;
    if (dateRange.from && d < dateRange.from) return false;
    if (dateRange.to) {
      const end = new Date(dateRange.to);
      end.setHours(23, 59, 59, 999);
      if (d > end) return false;
    }
    return true;
  });
}

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  await loadOrders();

  // Recover any orphaned sync result (e.g. user closed page mid-sync)
  await new Promise(resolve => {
    chrome.storage.local.get('ebay_orders_sync_result', data => {
      if (data.ebay_orders_sync_result?.orders?.length) {
        const stats = mergeSyncResult(data.ebay_orders_sync_result.orders);
        console.log('[UnicornDS] Recovered orphaned sync:', stats);
        chrome.storage.local.remove('ebay_orders_sync_result');
        saveOrders();
      }
      resolve();
    });
  });

  // Default: last 90 days
  setDateRange(90);

  renderOrders();
  updateStats();
  updateSummary();

  document.getElementById('syncOrdersBtn').addEventListener('click', syncEbayOrders);
  document.getElementById('addManualBtn').addEventListener('click', () => {
    document.getElementById('manualDate').value = new Date().toISOString().split('T')[0];
    showModal('manualModal');
  });
  document.getElementById('exportCsvBtn').addEventListener('click', exportCSV);
  const _feBtn = document.getElementById('fetchEarningsBtn');
  if (_feBtn) _feBtn.addEventListener('click', fetchAllEarnings);
  document.getElementById('searchBox').addEventListener('input', (e) => {
    searchQuery = e.target.value.trim().toLowerCase();
    renderOrders();
  });
  document.getElementById('cancelManualBtn').addEventListener('click', () => hideModal('manualModal'));
  document.getElementById('saveManualBtn').addEventListener('click', saveManualOrder);
  document.getElementById('cancelTrackingBtn').addEventListener('click', () => hideModal('trackingModal'));
  document.getElementById('saveTrackingBtn').addEventListener('click', saveTracking);
  document.getElementById('cancelCostBtn').addEventListener('click', () => hideModal('costModal'));
  document.getElementById('saveCostBtn').addEventListener('click', saveCost);

  // Filter buttons
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      renderOrders();
      updateStats();
      updateSummary();
    });
  });

  // Date range buttons
  document.querySelectorAll('.date-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const range = btn.dataset.range;
      if (range === 'all') {
        dateRange = { from: null, to: null };
        dateRangeDays = 90; // eBay caps date filter at ~90 days
      } else {
        setDateRange(parseInt(range));
      }
      renderOrders();
      updateStats();
      updateSummary();
    });
  });

  // Custom date apply
  document.getElementById('applyDateBtn').addEventListener('click', () => {
    const from = document.getElementById('dateFrom').value;
    const to = document.getElementById('dateTo').value;
    if (from) dateRange.from = new Date(from);
    if (to) dateRange.to = new Date(to);
    if (from) {
      const fromDate = new Date(from);
      const days = Math.ceil((Date.now() - fromDate.getTime()) / 86400000);
      dateRangeDays = Math.min(Math.max(days, 1), 90);
    }
    document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
    renderOrders();
    updateStats();
    updateSummary();
  });

  // Table action delegation
  document.getElementById('ordersBody').addEventListener('click', handleTableAction);

  // v7.20 — Checkbox selection (event delegation on tbody)
  document.getElementById('ordersBody').addEventListener('change', (e) => {
    if (e.target.classList.contains('order-checkbox')) {
      const id = e.target.dataset.id;
      if (e.target.checked) selectedOrderIds.add(id);
      else selectedOrderIds.delete(id);
      // Toggle row highlight without full re-render
      const row = e.target.closest('tr');
      if (row) row.classList.toggle('row-selected', e.target.checked);
      updateBulkActionBar();
    }
  });

  // v7.20 — Select all checkbox
  document.getElementById('selectAllOrders').addEventListener('change', (e) => {
    const checkboxes = document.querySelectorAll('.order-checkbox');
    checkboxes.forEach(cb => {
      cb.checked = e.target.checked;
      const id = cb.dataset.id;
      if (e.target.checked) selectedOrderIds.add(id);
      else selectedOrderIds.delete(id);
      const row = cb.closest('tr');
      if (row) row.classList.toggle('row-selected', e.target.checked);
    });
    updateBulkActionBar();
  });

  // v7.20 — Bulk fulfill button
  document.getElementById('bulkFulfillBtn').addEventListener('click', bulkFulfillSelected);
  document.getElementById('bulkMarkOrderedBtn').addEventListener('click', bulkMarkOrdered);
  const _bfe = document.getElementById('bulkFetchEarningsBtn');
  if (_bfe) _bfe.addEventListener('click', bulkFetchEarnings);
  document.getElementById('bulkClearBtn').addEventListener('click', () => {
    selectedOrderIds.clear();
    renderOrders();
  });

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.unicornds_orders) {
      orders = changes.unicornds_orders.newValue || [];
      renderOrders();
      updateStats();
      updateSummary();
    }
  });
});

function setDateRange(days) {
  const from = new Date();
  from.setDate(from.getDate() - days);
  from.setHours(0, 0, 0, 0);
  dateRange = { from, to: new Date() };
  dateRangeDays = days;
}

// ═══════════════════════════════════════
// SYNC EBAY ORDERS
// ═══════════════════════════════════════
// ═══════════════════════════════════════
// MERGE SYNC RESULT (shared by sync + page-load recovery)
// ═══════════════════════════════════════
function mergeSyncResult(newOrders) {
  let addedCount = 0;
  let backfillCount = 0;
  (newOrders || []).forEach(order => {
    // Match ONLY on the unique eBay order id. The old fallback (itemNumber + buyerName)
    // collapsed every repeat-sale of the same item with a blank buyer name into ONE row,
    // which is why ~1187 orders showed as ~384. Order id is the only safe key.
    const oidNew = order.ebayOrderIdFull || order.ebayOrderId;
    const existingIdx = oidNew
      ? orders.findIndex(o => (o.ebayOrderIdFull || o.ebayOrderId) === oidNew)
      : -1;
    if (existingIdx === -1) {
      orders.unshift({
        id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        ...order,
        status: order.ebayStatus === 'cancelled' ? 'cancelled'
              : order.ebayStatus === 'delivered' ? 'completed'
              : order.ebayStatus === 'dispatched' ? 'shipped'
              : order.ebayStatus === 'to_dispatch' ? 'pending'
              : 'pending',
        dispatchByDate: order.dispatchByDate || '',
        dispatchedDate: order.dispatchedDate || '',
        sourceCost: order.sourceCost || 0,
        trackingNumber: order.trackingNumber || '',
        trackingCarrier: order.carrier || '',
        amazonOrderId: '',
        soldDateTs: parseOrderDate(order).getTime(),
        createdAt: Date.now(),
      });
      addedCount++;
    } else {
      const existing = orders[existingIdx];
      let changed = false;
      if (order.buyerAddress && !existing.buyerAddress) { existing.buyerAddress = order.buyerAddress; changed = true; }
      if (order.ebayEarnings && !existing.ebayEarnings) { existing.ebayEarnings = order.ebayEarnings; changed = true; }
      if (order.totalFees && !existing.totalFees) { existing.totalFees = order.totalFees; changed = true; }
      if (order.fees && order.fees.length && (!existing.fees || !existing.fees.length)) { existing.fees = order.fees; changed = true; }
      if (order.soldPrice && (!existing.soldPrice || existing.soldPrice === 0)) { existing.soldPrice = order.soldPrice; changed = true; }
      if (order.buyerName && (!existing.buyerName || /^\d{2}-\d{4,5}-\d{4,5}$/.test(existing.buyerName))) { existing.buyerName = order.buyerName; changed = true; }
      // Promote to delivered when eBay now reports it (never downgrade a manual state)
      if (order.ebayStatus === 'delivered' && ['pending', 'shipped', 'ordered'].includes(existing.status)) {
        existing.status = 'completed'; changed = true;
      }
      // Cancelled always wins (buyer cancelled / refunded)
      if (order.ebayStatus === 'cancelled' && existing.status !== 'cancelled') {
        existing.status = 'cancelled'; changed = true;
      }
      // UN-CANCEL: restore orders wrongly cancelled by the old bug
      if (existing.status === 'cancelled' && order.ebayStatus && order.ebayStatus !== 'cancelled') {
        existing.status = order.ebayStatus === 'delivered' ? 'completed'
                        : order.ebayStatus === 'dispatched' ? 'shipped' : 'pending';
        changed = true;
      }
      // Dispatched -> shipped (unless already completed/cancelled)
      if (order.ebayStatus === 'dispatched' && ['pending', 'ordered'].includes(existing.status)) {
        existing.status = 'shipped'; changed = true;
      }
      // Keep the dispatch-by deadline updated while still pending
      if (order.dispatchByDate && existing.dispatchByDate !== order.dispatchByDate && existing.status === 'pending') {
        existing.dispatchByDate = order.dispatchByDate; changed = true;
      }
      if (order.dispatchedDate && !existing.dispatchedDate) { existing.dispatchedDate = order.dispatchedDate; changed = true; }
      // Backfill tracking number + carrier if the scrape found one
      if (order.trackingNumber && !existing.trackingNumber) {
        existing.trackingNumber = order.trackingNumber;
        existing.trackingCarrier = order.carrier || existing.trackingCarrier || '';
        changed = true;
      }
      if (changed) backfillCount++;
    }
  });
  return { addedCount, backfillCount };
}

async function fetchAllEarnings() {
  const btn = document.getElementById('fetchEarningsBtn');
  if (!btn) return;
  const missing = orders.filter(o => o.ebayOrderIdFull && (!o.ebayEarnings || !o.buyerAddress)).length;
  if (missing === 0) { btn.textContent = '✅ All earnings already fetched'; setTimeout(()=>btn.textContent='💰 Fetch All Earnings',3000); return; }
  if (!confirm('This will open ' + missing + ' eBay order pages in the background to fetch earnings + addresses. It can take a few minutes and opens tabs. Continue?')) return;

  btn.disabled = true; btn.textContent = '💰 Fetching 0/' + missing + '...';
  try {
    const { unicornds_ebay_domain, unicornds_primary_market } = await new Promise(r =>
      chrome.storage.local.get(['unicornds_ebay_domain','unicornds_primary_market'], r));
    const domain = unicornds_ebay_domain || udsMarketDomain(unicornds_primary_market);
    chrome.runtime.sendMessage({ type: 'fetch_all_earnings', domain });

    const startTime = Date.now();
    const poll = setInterval(async () => {
      await loadOrders();
      renderOrders(); updateStats();
      const left = orders.filter(o => o.ebayOrderIdFull && (!o.ebayEarnings || !o.buyerAddress)).length;
      const done = Math.max(0, missing - left);
      btn.textContent = '💰 Fetching ' + done + '/' + missing + '...';
      if (left === 0 || Date.now() - startTime > 1800000) {
        clearInterval(poll);
        btn.textContent = left === 0 ? '✅ All earnings fetched' : ('✅ Fetched ' + done + '/' + missing);
        btn.disabled = false;
        setTimeout(() => { btn.textContent = '💰 Fetch All Earnings'; }, 4000);
      }
    }, 4000);
  } catch (e) {
    btn.textContent = '❌ Error'; btn.disabled = false;
    setTimeout(() => { btn.textContent = '💰 Fetch All Earnings'; }, 3000);
  }
}

async function syncEbayOrders() {
  const btn = document.getElementById('syncOrdersBtn');
  btn.textContent = '🔄 Syncing...';
  btn.disabled = true;

  try {
    const { unicornds_ebay_domain, unicornds_primary_market } = await new Promise(r =>
      chrome.storage.local.get(['unicornds_ebay_domain','unicornds_primary_market'], r));
    const domain = unicornds_ebay_domain || udsMarketDomain(unicornds_primary_market);

    chrome.runtime.sendMessage({
      type: 'sync_ebay_orders',
      domain: domain,
      daysBack: dateRangeDays,
    });

    // Poll for results. The background saves PROGRESSIVELY (orders first, then
    // earnings in batches) so we merge every new snapshot and only stop on done.
    const startTime = Date.now();
    let lastSyncedAt = 0, totalAdded = 0, totalBackfill = 0;
    const pollInterval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      // No hard time cap — sync fetches ALL pages, however long it takes.
      // 60-minute absolute safety ceiling only.
      if (elapsed > 3600) {
        clearInterval(pollInterval);
        btn.textContent = (totalAdded || totalBackfill) ? '✅ Synced' : '❌ Timeout — try again';
        btn.disabled = false;
        setTimeout(() => { btn.textContent = '🔄 Sync eBay Orders'; }, 3000);
        return;
      }
      const _mins = Math.floor(elapsed/60), _secs = elapsed%60;
      btn.textContent = '🔄 Syncing ' + _mins + 'm ' + _secs + 's... (' + totalAdded + ' so far)';
      chrome.storage.local.get('ebay_orders_sync_result', data => {
        const result = data.ebay_orders_sync_result;
        if (!result) return;
        // Merge each new snapshot (merge is idempotent — safe to run repeatedly)
        if (result.orders && result.orders.length && result.syncedAt !== lastSyncedAt) {
          lastSyncedAt = result.syncedAt;
          const { addedCount, backfillCount } = mergeSyncResult(result.orders);
          totalAdded += addedCount;
          totalBackfill += backfillCount;
          saveOrders();
          renderOrders();
          updateStats();
          updateSummary();
        }
        // Stop only when the background signals it's finished
        if (result.done) {
          clearInterval(pollInterval);
          chrome.storage.local.remove('ebay_orders_sync_result');
          let msg;
          if (totalAdded > 0 && totalBackfill > 0) msg = `✅ ${totalAdded} new, ${totalBackfill} updated`;
          else if (totalAdded > 0) msg = `✅ ${totalAdded} new orders`;
          else if (totalBackfill > 0) msg = `✅ ${totalBackfill} orders updated`;
          else msg = '✅ All up to date';
          btn.textContent = msg;
          setTimeout(() => {
            btn.textContent = '🔄 Sync eBay Orders';
            btn.disabled = false;
          }, 3000);
        }
      });
    }, 1000);
  } catch (err) {
    console.error('[UnicornDS] Sync error:', err);
    btn.textContent = '🔄 Sync eBay Orders';
    btn.disabled = false;
  }
}

// ═══════════════════════════════════════
// RENDER
// ═══════════════════════════════════════
function renderOrders() {
  const tbody = document.getElementById('ordersBody');
  const empty = document.getElementById('emptyState');

  let filtered = currentFilter === 'all'
    ? orders
    : orders.filter(o => o.status === currentFilter);
  
  // Apply date filter
  filtered = filterByDate(filtered);

  // Apply search filter
  if (searchQuery) {
    filtered = filtered.filter(o => {
      const addr = o.buyerAddress || {};
      const haystack = [
        o.buyerName, o.itemTitle, o.itemNumber, o.ebayOrderId,
        o.trackingNumber, o.amazonOrderId, o.supplierOrderId, o.sku,
        addr.name, addr.street1, addr.city, addr.zip, addr.country, addr.phone,
      ].filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(searchQuery);
    });
  }

  // Sort by date (newest first)
  filtered.sort((a, b) => (b.soldDateTs || b.createdAt || 0) - (a.soldDateTs || a.createdAt || 0));

  // ── Update alert banner: count losses and late orders ──
  updateAlertBanner();

  if (!filtered.length) {
    tbody.innerHTML = '';
    empty.style.display = 'block';
    document.getElementById('monthlySummary').style.display = 'none';
    return;
  }
  empty.style.display = 'none';
  document.getElementById('monthlySummary').style.display = 'grid';

  // v7.20 — Repeat buyer detection: count orders per buyer across ALL orders (not just filtered)
  const buyerOrderCounts = new Map();
  orders.forEach(o => {
    const addr = o.buyerAddress || {};
    // Use street+zip+name as identity (more reliable than ebay buyer ID which changes)
    const key = (addr.name || o.buyerName || '').toLowerCase().trim() + '|' +
                (addr.zip || '').toLowerCase().trim();
    if (key.length > 2) {
      buyerOrderCounts.set(key, (buyerOrderCounts.get(key) || 0) + 1);
    }
  });

  tbody.innerHTML = filtered.map(o => {
    // Profit calc
    const earningsValue = o.ebayEarnings || o.soldPrice || 0;
    const profit = (earningsValue && o.sourceCost)
      ? (earningsValue - o.sourceCost)
      : null;
    const profitClass = profit === null ? 'profit-unknown'
      : profit >= 0 ? 'profit-positive' : 'profit-negative';
    const profitText = profit === null ? '-' : (profit >= 0 ? '+£' : '-£') + Math.abs(profit).toFixed(2);

    // Margin % calc
    let marginText = '-';
    let marginClass = 'margin-low';
    if (profit !== null && earningsValue > 0) {
      const margin = (profit / earningsValue) * 100;
      marginText = (margin >= 0 ? '+' : '') + margin.toFixed(1) + '%';
      if (margin < 0) marginClass = 'margin-negative';
      else if (margin < 15) marginClass = 'margin-low';
      else marginClass = 'margin-positive';
    }

    // Age (days since sold)
    const soldTs = o.soldDateTs || o.createdAt || Date.now();
    const ageDays = Math.floor((Date.now() - soldTs) / 86400000);
    let ageClass = 'age-fresh';
    let ageText = ageDays === 0 ? 'Today' : ageDays + 'd';
    if (o.status === 'pending' && ageDays >= 3) ageClass = 'age-warn';
    if (o.status === 'pending' && ageDays >= 5) ageClass = 'age-late';
    if (o.status === 'shipped' || o.status === 'completed') ageClass = '';

    const d = parseOrderDate(o);
    const date = d.toLocaleDateString(udsLocale(), { day: '2-digit', month: 'short' });
    const statusClass = 'status-' + (o.status || 'pending');

    // ── Dispatch deadline logic ──
    let dispatchInfo = '';   // extra text in the badge
    let isLate = false;
    if (o.status === 'pending' && o.dispatchByDate) {
      const parseShort = (str) => {
        // "4 Aug" -> Date this year (roll to next year if it looks past by >6 months)
        const m = String(str).match(/(\d{1,2})\s+([A-Za-z]{3,})/);
        if (!m) return null;
        const d = new Date(`${m[2]} ${m[1]}, ${new Date().getFullYear()}`);
        return isNaN(d.getTime()) ? null : d;
      };
      const dd = parseShort(o.dispatchByDate);
      if (dd) {
        const today = new Date(); today.setHours(0,0,0,0);
        dd.setHours(23,59,59,999);
        isLate = dd < today;
        dispatchInfo = isLate ? ` · LATE (was ${o.dispatchByDate})` : ` · by ${o.dispatchByDate}`;
      }
    }

    // Cost cell — clickable to edit
    const costText = o.sourceCost ? '£' + o.sourceCost.toFixed(2) : '<span class="add-cost">+ add</span>';
    const earningsText = o.ebayEarnings ? '£' + o.ebayEarnings.toFixed(2) : '<span class="no-data">—</span>';

    // Row classes
    let rowClass = '';
    if (profit !== null && profit < 0) rowClass += ' row-loss';
    if (o.status === 'pending' && ageDays >= 5) rowClass += ' row-late';
    if (isLate) rowClass += ' row-late';

    let actions = '';
    const ebayLink = o.orderUrl || (o.ebayOrderId ? `https://www.ebay.co.uk/sh/ord/details?orderid=${o.ebayOrderId}` : '');
    const addrBtn = o.buyerAddress
      ? `<button class="btn btn-sm btn-info" data-action="copyAddr" data-id="${o.id}" title="Copy address to clipboard + ready for AliExpress">📋</button>`
      : '';
    switch (o.status) {
      case 'pending':
        actions = `
          <button class="btn btn-sm btn-warning" data-action="fulfill" data-id="${o.id}" title="Order from supplier (also copies address)">🛒</button>
          ${addrBtn}
          <button class="btn btn-sm btn-secondary" data-action="tracking" data-id="${o.id}" title="Add tracking">📦</button>
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}" title="Delete">✕</button>`;
        break;
      case 'ordered':
        actions = `
          ${addrBtn}
          <button class="btn btn-sm btn-success" data-action="tracking" data-id="${o.id}" title="Add tracking">📦 Track</button>
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}" title="Delete">✕</button>`;
        break;
      case 'shipped':
        actions = `
          ${addrBtn}
          <button class="btn btn-sm btn-secondary" data-action="complete" data-id="${o.id}" title="Mark complete">✅</button>
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <span style="font-size:10px;color:#10B981">${o.trackingNumber || ''}</span>`;
        break;
      case 'completed':
        actions = `
          ${addrBtn}
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <span style="font-size:10px;color:#6B7280">${o.trackingNumber || '✅'}</span>`;
        break;
    }

    const titleShort = (o.itemTitle || 'Unknown').length > 50
      ? (o.itemTitle || '').substring(0, 50) + '...'
      : (o.itemTitle || 'Unknown');

    // v7.20 — Item image thumbnail (from eBay listing image if available)
    const imgUrl = o.image || o.itemImage || o.imageUrl || '';
    const imgHtml = imgUrl
      ? `<img class="item-thumb" src="${imgUrl}" alt="" loading="lazy" onerror="this.outerHTML='<div class=\\'item-thumb-placeholder\\'>📦</div>'">`
      : `<div class="item-thumb-placeholder">📦</div>`;

    // Buyer display — prefer address name, then real buyerName, then order ID
    const isOrderIdPattern = /^\d{2}-\d{4,5}-\d{4,5}$/.test(o.buyerName || '');
    const buyerDisplay = (o.buyerAddress && o.buyerAddress.name)
      || (o.buyerName && !isOrderIdPattern ? o.buyerName : '')
      || o.ebayOrderId
      || '-';

    // v7.20 — Repeat buyer badge
    const addr = o.buyerAddress || {};
    const buyerKey = (addr.name || o.buyerName || '').toLowerCase().trim() + '|' +
                     (addr.zip || '').toLowerCase().trim();
    const orderCount = buyerKey.length > 2 ? (buyerOrderCounts.get(buyerKey) || 1) : 1;
    let repeatBadge = '';
    if (orderCount >= 3) {
      repeatBadge = `<span class="repeat-buyer-badge high" title="VIP buyer — ${orderCount} orders">🌟 ${orderCount}×</span>`;
    } else if (orderCount === 2) {
      repeatBadge = `<span class="repeat-buyer-badge" title="Repeat buyer — 2nd order">🔄 2×</span>`;
    }

    // Supplier order ID badge (shows if we've ordered from supplier)
    const supplierBadge = o.supplierOrderId
      ? `<span class="supplier-badge" title="${(o.supplierType || 'supplier')}: ${o.supplierOrderId}">📦 ${(o.supplierOrderId.length > 14 ? o.supplierOrderId.substring(0,12) + '…' : o.supplierOrderId)}</span>`
      : '';

    // v7.25 — every synced order is selectable (needed for "Fetch Earnings for Selected").
    // Bulk fulfil still filters to fulfillable orders internally, so this is safe.
    const isSelectable = !!o.ebayOrderIdFull || o.status === 'pending' || o.status === 'ordered';
    const isChecked = selectedOrderIds.has(o.id);
    const checkboxCell = isSelectable
      ? `<input type="checkbox" class="order-checkbox" data-id="${o.id}" ${isChecked ? 'checked' : ''}>`
      : '';
    if (isChecked) rowClass += ' row-selected';

    return `<tr class="${rowClass}">
      <td>${checkboxCell}</td>
      <td>${date}</td>
      <td class="age-cell ${ageClass}">${ageText}</td>
      <td>${buyerDisplay}${repeatBadge}${supplierBadge}</td>
      <td title="${(o.itemTitle || '').replace(/"/g, '&quot;')}">
        <div class="item-cell">
          ${imgHtml}
          <div class="item-text">${titleShort}</div>
        </div>
      </td>
      <td>£${(o.soldPrice || 0).toFixed(2)}</td>
      <td class="${o.ebayEarnings ? 'earnings-value' : ''}">${earningsText}</td>
      <td class="cost-cell" data-action="editCost" data-id="${o.id}">${costText}</td>
      <td class="${profitClass}">${profitText}</td>
      <td class="${marginClass}">${marginText}</td>
      <td><span class="status-badge ${statusClass}${isLate ? ' status-late' : ''}">${
        (o.status === 'pending' && o.dispatchByDate ? 'TO DISPATCH' : (o.status || 'pending').toUpperCase())
      }${dispatchInfo}</span></td>
      <td><div class="actions-cell">${actions}</div></td>
    </tr>`;
  }).join('');

  // v7.20 — Update bulk action bar visibility
  updateBulkActionBar();
}

// ═══════════════════════════════════════
// ALERT BANNER — loss orders + late pending
// ═══════════════════════════════════════
function updateAlertBanner() {
  const banner = document.getElementById('alertBanner');
  if (!banner) return;

  const now = Date.now();
  const inRange = filterByDate(orders);

  const losses = inRange.filter(o => {
    const earnings = o.ebayEarnings || o.soldPrice || 0;
    return o.sourceCost && earnings && (earnings - o.sourceCost) < 0;
  });

  const latePending = inRange.filter(o => {
    if (o.status !== 'pending') return false;
    const ageDays = Math.floor((now - (o.soldDateTs || o.createdAt || now)) / 86400000);
    return ageDays >= 5;
  });

  const lossSum = losses.reduce((s, o) => {
    const earnings = o.ebayEarnings || o.soldPrice || 0;
    return s + (earnings - o.sourceCost);
  }, 0);

  const parts = [];
  if (losses.length > 0) {
    parts.push(`<div class="alert-item">⚠️ <span class="alert-count">${losses.length}</span> orders losing money <span style="color:#FCA5A5;font-weight:700;">(£${Math.abs(lossSum).toFixed(2)} loss)</span></div>`);
  }
  if (latePending.length > 0) {
    parts.push(`<div class="alert-item warn">⏰ <span class="alert-count">${latePending.length}</span> pending orders over 5 days old — fulfill now!</div>`);
  }

  if (parts.length === 0) {
    banner.style.display = 'none';
  } else {
    banner.innerHTML = parts.join('');
    banner.style.display = 'flex';
  }
}

// ═══════════════════════════════════════
// CSV EXPORT
// ═══════════════════════════════════════
function exportCSV() {
  let exportList = currentFilter === 'all' ? orders : orders.filter(o => o.status === currentFilter);
  exportList = filterByDate(exportList);
  if (searchQuery) {
    exportList = exportList.filter(o => {
      const addr = o.buyerAddress || {};
      const hay = [o.buyerName, o.itemTitle, o.itemNumber, o.ebayOrderId, o.trackingNumber, addr.name, addr.city, addr.zip].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(searchQuery);
    });
  }

  if (exportList.length === 0) {
    alert('No orders to export — try changing your filters.');
    return;
  }

  const headers = [
    'Date', 'eBay Order ID', 'Item Number', 'SKU', 'Buyer', 'Item Title',
    'Sold Price', 'eBay Earnings', 'Source Cost', 'Profit', 'Margin %',
    'Status', 'Tracking', 'Carrier', 'Supplier Type', 'Supplier Order ID',
    'Amazon Order ID', 'Source URL',
    'Buyer Name', 'Street 1', 'Street 2', 'City', 'State', 'ZIP', 'Country', 'Phone',
  ];

  const escape = (v) => {
    if (v === null || v === undefined) return '';
    const s = String(v).replace(/"/g, '""');
    return /[",\n]/.test(s) ? `"${s}"` : s;
  };

  const rows = exportList.map(o => {
    const earnings = o.ebayEarnings || o.soldPrice || 0;
    const profit = (earnings && o.sourceCost) ? (earnings - o.sourceCost) : '';
    const margin = (profit !== '' && earnings > 0) ? ((profit / earnings) * 100).toFixed(2) : '';
    const a = o.buyerAddress || {};
    return [
      parseOrderDate(o).toISOString().split('T')[0],
      o.ebayOrderId || '', o.itemNumber || '', o.sku || '',
      o.buyerName || '', o.itemTitle || '',
      (o.soldPrice || 0).toFixed(2),
      o.ebayEarnings ? o.ebayEarnings.toFixed(2) : '',
      o.sourceCost ? o.sourceCost.toFixed(2) : '',
      profit !== '' ? profit.toFixed(2) : '',
      margin,
      o.status || 'pending',
      o.trackingNumber || '', o.trackingCarrier || '',
      o.supplierType || '', o.supplierOrderId || '',
      o.amazonOrderId || '', o.sourceUrl || '',
      a.name || '', a.street1 || '', a.street2 || '',
      a.city || '', a.state || '', a.zip || '', a.country || '', a.phone || '',
    ].map(escape).join(',');
  });

  const csv = headers.join(',') + '\n' + rows.join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' }); // BOM for Excel
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `unicornds-orders-${new Date().toISOString().split('T')[0]}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ═══════════════════════════════════════
// MONTHLY SUMMARY
// ═══════════════════════════════════════
function updateSummary() {
  let filtered = currentFilter === 'all' ? orders : orders.filter(o => o.status === currentFilter);
  filtered = filterByDate(filtered);

  const revenue = filtered.reduce((s, o) => s + (o.soldPrice || 0), 0);
  const totalEarnings = filtered.reduce((s, o) => s + (o.ebayEarnings || o.soldPrice || 0), 0);
  const cost = filtered.reduce((s, o) => s + (o.sourceCost || 0), 0);
  const profit = totalEarnings - cost;
  const count = filtered.length;
  const avg = count > 0 ? profit / count : 0;

  document.getElementById('summaryRevenue').textContent = '£' + revenue.toFixed(2);
  document.getElementById('summaryCost').textContent = '£' + cost.toFixed(2);
  document.getElementById('summaryProfit').textContent = (profit >= 0 ? '£' : '-£') + Math.abs(profit).toFixed(2);
  document.getElementById('summaryProfit').className = 'summary-value ' + (profit >= 0 ? 'profit' : 'loss');
  document.getElementById('summaryCount').textContent = count;
  document.getElementById('summaryAvg').textContent = '£' + avg.toFixed(2);
}

// ═══════════════════════════════════════
// ACTIONS
// ═══════════════════════════════════════
function handleTableAction(e) {
  const el = e.target.closest('[data-action]');
  if (!el) return;

  const action = el.dataset.action;
  const orderId = el.dataset.id;
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  switch (action) {
    case 'fulfill':
      fulfillOrder(order);
      break;
    case 'tracking':
      activeOrderId = orderId;
      document.getElementById('trackingNumber').value = order.trackingNumber || '';
      document.getElementById('amazonOrderId').value = order.amazonOrderId || '';
      document.getElementById('supplierOrderId').value = order.supplierOrderId || order.amazonOrderId || '';
      document.getElementById('supplierCost').value = order.sourceCost || '';
      // Auto-detect supplier from SKU
      let supplierGuess = 'aliexpress';
      const skuStr = (order.sku || '').toUpperCase();
      if (skuStr.includes('AZ-') || skuStr.includes('AMZ-') || /^B0[A-Z0-9]{8}$/i.test(order.sku || '')) {
        supplierGuess = 'amazon';
      }
      document.getElementById('supplierType').value = order.supplierType || supplierGuess;
      showModal('trackingModal');
      break;
    case 'complete':
      order.status = 'completed';
      order.completedAt = Date.now();
      saveOrders();
      renderOrders();
      updateStats();
      updateSummary();
      break;
    case 'delete':
      if (confirm('Delete this order?')) {
        orders = orders.filter(o => o.id !== orderId);
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
      }
      break;
    case 'editCost':
      activeOrderId = orderId;
      document.getElementById('editCostInput').value = order.sourceCost || '';
      document.getElementById('editSourceUrl').value = order.sourceUrl || '';
      showModal('costModal');
      break;
    case 'copyAddr':
      copyAddressForOrder(order, el);
      break;
  }
}

// ═══════════════════════════════════════
// COPY ADDRESS — formats and copies to clipboard + sets orderInfo for AliExpress fill
// ═══════════════════════════════════════
async function copyAddressForOrder(order, btnEl) {
  if (!order.buyerAddress) {
    alert('No address captured for this order. Run sync first.');
    return;
  }
  const a = order.buyerAddress;
  const lines = [
    a.name || `${a.firstName || ''} ${a.lastName || ''}`.trim(),
    a.street1,
    a.street2,
    [a.city, a.state, a.zip].filter(Boolean).join(', '),
    a.country,
    a.phone || (a.phoneCode ? `+${a.phoneCode} ${a.phoneNumber || ''}` : ''),
  ].filter(Boolean).join('\n');

  try {
    await navigator.clipboard.writeText(lines);
  } catch(e) {
    // Fallback for clipboard permission issues
    const ta = document.createElement('textarea');
    ta.value = lines;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  }

  // Also save to orderInfo so the address-helper Paste button on AliExpress works
  chrome.runtime.sendMessage({ action: 'saveOrderInfo', orderInfo: a }, () => {});

  // v7.20 — Save for Amazon fill script to pick up
  chrome.storage.local.set({ unicornds_last_copied_address: a });

  // Visual feedback
  if (btnEl) {
    const original = btnEl.textContent;
    btnEl.textContent = '✅';
    setTimeout(() => { btnEl.textContent = original; }, 1500);
  }
}

function fulfillOrder(order) {
  // ── Auto-copy address to clipboard so user can paste on AliExpress/Amazon ──
  if (order.buyerAddress) {
    const a = order.buyerAddress;
    const lines = [
      a.name || `${a.firstName || ''} ${a.lastName || ''}`.trim(),
      a.street1,
      a.street2,
      [a.city, a.state, a.zip].filter(Boolean).join(', '),
      a.country,
      a.phone || (a.phoneCode ? `+${a.phoneCode} ${a.phoneNumber || ''}` : ''),
    ].filter(Boolean).join('\n');
    try {
      navigator.clipboard.writeText(lines).catch(() => {});
    } catch(e) {}
    // Save to orderInfo so the AliExpress address-helper Paste button works
    chrome.runtime.sendMessage({ action: 'saveOrderInfo', orderInfo: a }, () => {});

    // v7.20 — Save for Amazon fill script
    chrome.storage.local.set({ unicornds_last_copied_address: a });
  }

  // Try to find source URL from SKU
  let url = order.sourceUrl || '';
  
  if (!url && order.sku) {
    // Parse SKU to find source product
    // SKU formats:
    //   UDS-AE-{id}-S{shortSkuId}  → AliExpress variant (NEW)
    //   UDS-AE-{id}                 → AliExpress single product
    //   UDS-AZ-{asin}               → Amazon (variant ASINs encoded per-listing)
    //   UDS-{id}_V{n}               → Legacy variant naming
    const sku = order.sku;

    // ── Check variant map FIRST (most accurate) ──
    chrome.storage.local.get('unicornds_variant_map', (vData) => {
      const variantInfo = (vData.unicornds_variant_map || {})[sku];

      if (variantInfo && variantInfo.source === 'aliexpress' && variantInfo.productId && variantInfo.fullSkuId) {
        // AliExpress variant — use full skuId for auto-select
        const variantUrl = `https://www.aliexpress.com/item/${variantInfo.productId}.html?skuId=${variantInfo.fullSkuId}`;
        console.log('[UnicornDS] Opening AliExpress variant:', JSON.stringify(variantInfo.properties));
        chrome.runtime.sendMessage({ type: 'openNewTab', url: variantUrl });
        order.status = 'ordered';
        order.orderedAt = Date.now();
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
        return;
      }

      if (variantInfo && variantInfo.source === 'amazon' && variantInfo.asin) {
        // Amazon variant — use exact ASIN
        chrome.storage.local.get(['hunter_domain','unicornds_primary_market'], s => {
          const domain = s.hunter_domain || udsMarketDomain(s.unicornds_primary_market);
          const amzUrl = `https://www.amazon.${domain}/dp/${variantInfo.asin}?th=1&psc=1`;
          console.log('[UnicornDS] Opening Amazon variant:', JSON.stringify(variantInfo.properties));
          chrome.runtime.sendMessage({ type: 'openNewTab', url: amzUrl });
        });
        order.status = 'ordered';
        order.orderedAt = Date.now();
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
        return;
      }

      // ── No variant map → fall back to old SKU parsing ──
      let parsedUrl = '';
      if (/(?:UDS-)?(?:AE|ALI)-/i.test(sku)) {
        // SKU may have -S suffix from new format → strip it
        const aliMatch = sku.replace(/-S\d+$/, '').match(/(?:AE-|ALI-)(\d+)/i);
        if (aliMatch) parsedUrl = `https://www.aliexpress.com/item/${aliMatch[1]}.html`;
      } else if (/(?:UDS-)?(?:AZ|AMZ)-/i.test(sku)) {
        const amzMatch = sku.match(/(?:AZ-|AMZ-)([A-Z0-9]+)/i);
        if (amzMatch) {
          chrome.storage.local.get(['hunter_domain','unicornds_primary_market'], s => {
            const domain = s.hunter_domain || udsMarketDomain(s.unicornds_primary_market);
            chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/dp/${amzMatch[1]}?th=1&psc=1` });
          });
          order.status = 'ordered';
          order.orderedAt = Date.now();
          saveOrders();
          renderOrders();
          updateStats();
          updateSummary();
          return;
        }
      } else if (/^\d{10,}$/.test(sku)) {
        parsedUrl = `https://www.aliexpress.com/item/${sku}.html`;
      } else if (/^B0[A-Z0-9]{8}$/i.test(sku)) {
        chrome.storage.local.get(['hunter_domain','unicornds_primary_market'], s => {
          const domain = s.hunter_domain || udsMarketDomain(s.unicornds_primary_market);
          chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/dp/${sku}?th=1&psc=1` });
        });
        order.status = 'ordered';
        order.orderedAt = Date.now();
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
        return;
      }

      if (parsedUrl) {
        chrome.runtime.sendMessage({ type: 'openNewTab', url: parsedUrl });
        order.status = 'ordered';
        order.orderedAt = Date.now();
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
      } else {
        // Last resort: search Amazon by title
        if (order.itemNumber) {
          chrome.storage.local.get('unicornds_listed_products', data => {
            const listed = (data.unicornds_listed_products || {})[order.itemNumber];
            if (listed && listed.sourceUrl) {
              chrome.runtime.sendMessage({ type: 'openNewTab', url: listed.sourceUrl });
            } else if (order.itemTitle) {
              chrome.storage.local.get(['hunter_domain','unicornds_primary_market'], s => {
                const domain = s.hunter_domain || udsMarketDomain(s.unicornds_primary_market);
                const query = encodeURIComponent(order.itemTitle.substring(0, 80));
                chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/s?k=${query}` });
              });
            }
          });
        }
        order.status = 'ordered';
        order.orderedAt = Date.now();
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
      }
    });
    return;
  }
  
  // Try matching with listed products by item number
  if (!url && order.itemNumber) {
    chrome.storage.local.get('unicornds_listed_products', data => {
      const listed = (data.unicornds_listed_products || {})[order.itemNumber];
      if (listed && listed.sourceUrl) {
        chrome.runtime.sendMessage({ type: 'openNewTab', url: listed.sourceUrl });
      } else if (order.itemTitle) {
        // Search Amazon as last resort
        chrome.storage.local.get(['hunter_domain','unicornds_primary_market'], s => {
          const domain = s.hunter_domain || udsMarketDomain(s.unicornds_primary_market);
          const query = encodeURIComponent(order.itemTitle.substring(0, 80));
          chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/s?k=${query}` });
        });
      }
    });
    order.status = 'ordered';
    order.orderedAt = Date.now();
    saveOrders();
    renderOrders();
    updateStats();
    updateSummary();
    return;
  }

  if (url) {
    chrome.runtime.sendMessage({ type: 'openNewTab', url });
  } else if (order.itemTitle) {
    chrome.storage.local.get(['hunter_domain','unicornds_primary_market'], s => {
      const domain = s.hunter_domain || udsMarketDomain(s.unicornds_primary_market);
      const query = encodeURIComponent(order.itemTitle.substring(0, 80));
      chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/s?k=${query}` });
    });
  }

  order.status = 'ordered';
  order.orderedAt = Date.now();
  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
}

function saveCost() {
  const order = orders.find(o => o.id === activeOrderId);
  if (!order) return;

  const cost = parseFloat(document.getElementById('editCostInput').value) || 0;
  const url = document.getElementById('editSourceUrl').value.trim();

  order.sourceCost = cost;
  if (url) order.sourceUrl = url;

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('costModal');
}

function saveTracking() {
  const order = orders.find(o => o.id === activeOrderId);
  if (!order) return;

  const tracking = document.getElementById('trackingNumber').value.trim();
  const carrier = document.getElementById('trackingCarrier').value;
  const supplierId = document.getElementById('supplierOrderId').value.trim();
  const supplierType = document.getElementById('supplierType').value;
  const supplierCostVal = parseFloat(document.getElementById('supplierCost').value);

  // Save supplier info (even if no tracking yet)
  if (supplierId) {
    order.supplierOrderId = supplierId;
    order.supplierType = supplierType;
    // Keep backward-compatible field
    if (supplierType === 'amazon') order.amazonOrderId = supplierId;
    if (!order.orderedAt) order.orderedAt = Date.now();
    if (order.status === 'pending') order.status = 'ordered';
  }
  if (!isNaN(supplierCostVal) && supplierCostVal > 0) {
    order.sourceCost = supplierCostVal;
  }

  // Save tracking only if provided — supplier ID save is independent
  if (tracking) {
    order.trackingNumber = tracking;
    order.trackingCarrier = carrier;
    order.status = 'shipped';
    order.shippedAt = Date.now();

    if (order.ebayOrderId || order.itemNumber) {
      chrome.runtime.sendMessage({
        type: 'upload_tracking_to_ebay',
        orderId: order.ebayOrderId,
        itemNumber: order.itemNumber,
        trackingNumber: tracking,
        carrier: carrier,
      });
    }
  } else if (!supplierId) {
    alert('Enter a tracking number OR a supplier order ID');
    return;
  }

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('trackingModal');
}

// ═══════════════════════════════════════
// MANUAL ORDER
// ═══════════════════════════════════════
function saveManualOrder() {
  const buyer = document.getElementById('manualBuyer').value.trim();
  const title = document.getElementById('manualTitle').value.trim();
  const itemNumber = document.getElementById('manualItemNumber').value.trim();
  const soldPrice = parseFloat(document.getElementById('manualSoldPrice').value) || 0;
  const cost = parseFloat(document.getElementById('manualCost').value) || 0;
  const sourceUrl = document.getElementById('manualSourceUrl').value.trim();
  const dateVal = document.getElementById('manualDate').value;

  if (!title) { alert('Enter an item title'); return; }

  const soldDate = dateVal ? new Date(dateVal) : new Date();

  orders.unshift({
    id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    buyerName: buyer || 'Manual',
    itemTitle: title,
    itemNumber: itemNumber,
    soldPrice: soldPrice,
    sourceCost: cost,
    sourceUrl: sourceUrl,
    status: 'pending',
    trackingNumber: '',
    trackingCarrier: '',
    amazonOrderId: '',
    soldDate: soldDate.toLocaleDateString(udsLocale()),
    soldDateTs: soldDate.getTime(),
    createdAt: Date.now(),
  });

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('manualModal');

  ['manualBuyer', 'manualTitle', 'manualItemNumber', 'manualSoldPrice', 'manualCost', 'manualSourceUrl']
    .forEach(id => document.getElementById(id).value = '');
}

// ═══════════════════════════════════════
// STATS
// ═══════════════════════════════════════
function updateStats() {
  const filtered = filterByDate(orders);
  document.getElementById('pendingCount').textContent = filtered.filter(o => o.status === 'pending').length;
  document.getElementById('orderedCount').textContent = filtered.filter(o => o.status === 'ordered').length;
  document.getElementById('shippedCount').textContent = filtered.filter(o => o.status === 'shipped').length;
  document.getElementById('completedCount').textContent = filtered.filter(o => o.status === 'completed').length;

  const totalProfit = filtered
    .filter(o => o.soldPrice && o.sourceCost)
    .reduce((sum, o) => sum + (o.soldPrice - o.sourceCost), 0);
  document.getElementById('totalProfit').textContent = '£' + totalProfit.toFixed(2);
}

// ═══════════════════════════════════════
// MODAL
// ═══════════════════════════════════════
function showModal(id) { document.getElementById(id).style.display = 'flex'; }
function hideModal(id) { document.getElementById(id).style.display = 'none'; }

// ═══════════════════════════════════════
// v7.20 — BULK FULFILL FEATURES
// ═══════════════════════════════════════
function updateBulkActionBar() {
  const bar = document.getElementById('bulkActionBar');
  const count = selectedOrderIds.size;
  if (count > 0) {
    bar.style.display = 'flex';
    document.getElementById('bulkSelectedCount').textContent = `${count} selected`;
  } else {
    bar.style.display = 'none';
  }
}

async function bulkFetchEarnings() {
  const ids = Array.from(selectedOrderIds);
  const selected = ids.map(id => orders.find(o => o.id === id)).filter(o => o && o.ebayOrderIdFull);
  if (selected.length === 0) { alert('Select some orders first (only eBay-synced orders can be re-fetched).'); return; }

  const btn = document.getElementById('bulkFetchEarningsBtn');
  btn.disabled = true; btn.textContent = '💰 Fetching 0/' + selected.length + '...';
  try {
    const { unicornds_ebay_domain, unicornds_primary_market } = await new Promise(r =>
      chrome.storage.local.get(['unicornds_ebay_domain','unicornds_primary_market'], r));
    const domain = unicornds_ebay_domain || udsMarketDomain(unicornds_primary_market);
    chrome.runtime.sendMessage({ type: 'fetch_all_earnings', domain, orderIds: selected.map(o => o.ebayOrderIdFull) });

    const target = selected.map(o => o.ebayOrderIdFull);
    const startTime = Date.now();
    const poll = setInterval(async () => {
      await loadOrders(); renderOrders(); updateStats();
      const left = orders.filter(o => target.includes(o.ebayOrderIdFull) && (!o.ebayEarnings || !o.buyerAddress)).length;
      const done = Math.max(0, selected.length - left);
      btn.textContent = '💰 Fetching ' + done + '/' + selected.length + '...';
      if (left === 0 || Date.now() - startTime > 600000) {
        clearInterval(poll);
        btn.textContent = left === 0 ? '✅ Done' : ('✅ ' + done + '/' + selected.length);
        btn.disabled = false;
        setTimeout(() => { btn.textContent = '💰 Fetch Earnings for Selected'; }, 4000);
      }
    }, 3000);
  } catch (e) {
    btn.textContent = '❌ Error'; btn.disabled = false;
    setTimeout(() => { btn.textContent = '💰 Fetch Earnings for Selected'; }, 3000);
  }
}

async function bulkFulfillSelected() {
  const ids = Array.from(selectedOrderIds);
  if (ids.length === 0) return;

  // Get the actual order objects
  const ordersToFulfill = ids
    .map(id => orders.find(o => o.id === id))
    .filter(o => o && (o.status === 'pending' || o.status === 'ordered'));

  if (ordersToFulfill.length === 0) {
    alert('No fulfillable orders selected');
    return;
  }

  // Safety: warn for large batches
  if (ordersToFulfill.length > 10) {
    if (!confirm(`This will open ${ordersToFulfill.length} supplier tabs at once. Continue?`)) {
      return;
    }
  }

  // For each order, copy address to clipboard then open supplier URL
  // We stagger by 600ms to give browser breathing room
  let opened = 0;
  let skipped = 0;

  for (let i = 0; i < ordersToFulfill.length; i++) {
    const o = ordersToFulfill[i];
    const url = o.sourceUrl || o.amazonUrl || o.aliexpressUrl;
    if (!url) {
      skipped++;
      continue;
    }

    // Open tab in background
    chrome.tabs.create({ url, active: false });
    opened++;

    // Stagger to avoid Chrome popup blocker / rate issues
    if (i < ordersToFulfill.length - 1) {
      await new Promise(r => setTimeout(r, 600));
    }
  }

  // Show result
  const msg = `✅ Opened ${opened} supplier tab${opened !== 1 ? 's' : ''}` +
              (skipped > 0 ? ` (${skipped} skipped — no supplier URL)` : '');
  showToast(msg);

  // Clear selection
  selectedOrderIds.clear();
  renderOrders();
}

async function bulkMarkOrdered() {
  const ids = Array.from(selectedOrderIds);
  if (ids.length === 0) return;

  let updated = 0;
  ids.forEach(id => {
    const o = orders.find(o => o.id === id);
    if (o && o.status === 'pending') {
      o.status = 'ordered';
      o.orderedAt = Date.now();
      updated++;
    }
  });

  if (updated > 0) {
    saveOrders();
    selectedOrderIds.clear();
    renderOrders();
    updateStats();
    showToast(`✅ ${updated} order${updated !== 1 ? 's' : ''} marked as ordered`);
  }
}

// Simple toast notification
function showToast(message) {
  let toast = document.getElementById('udsToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'udsToast';
    toast.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: linear-gradient(135deg, #7C3AED, #5B21B6);
      color: white;
      padding: 14px 20px;
      border-radius: 10px;
      font-size: 14px;
      font-weight: bold;
      box-shadow: 0 8px 24px rgba(0,0,0,0.4);
      z-index: 10000;
      max-width: 400px;
      transition: opacity 0.3s, transform 0.3s;
    `;
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.style.opacity = '1';
  toast.style.transform = 'translateY(0)';
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
  }, 3500);
}
