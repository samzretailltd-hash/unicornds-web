## 7.23.13
- Code cleanup: removed dead/unused functions left over from the FR debugging (2 in the variation editor, 2 in the listing form). No behaviour change; smaller, cleaner extension.

## 7.23.12
- FR/EU variations: the Code EAN field is a text box, not a dropdown — now types "Does not apply" into each row's EAN input so eBay stops rejecting the listing.

## 7.23.11
- FR/EU variations: fill rows by eBay's exact field markers instead of column position. Fixes SKU (a <textarea>) never filling, and the SKU value being written into the EAN box. EAN now selects "Non applicable" from eBay's dropdown per row.

## 7.23.10
- Item specifics: stop defaulting unmatched dropdowns to the first option (this is what set "Pays d'origine = Afghanistan"). Country fields now default to China/Chine; other unmatched dropdowns are left unset instead of guessing.
- FR/EU variations: stronger Code EAN handling — searches the whole editor and handles eBay's custom dropdown, selecting "Does not apply" per row.

## 7.23.9
- FR/EU variations: the per-row Code EAN field is a dropdown — the extension now selects "Does not apply / Ne s'applique pas" on every row so eBay stops rejecting the listing for a missing EAN.

## 7.23.8
- FR/EU variations: after Continue, the extension now waits for and clicks eBay's "update versions automatically" dialog so the combination rows are generated (was stalling on this step).

## 7.23.7
- Description: fixed raw {"optimized_description":"..."} wrapper and literal \n showing in listings when the AI's JSON reply had quotes/escapes in the HTML. The extractor now always recovers clean HTML and unescapes line breaks (all markets).

## 7.23.6
- Variations rewritten to drive eBay's multi-variation editor by its stable element IDs instead of matching translated button text. Removes pre-picked attributes, always creates our own attribute, and adds each supplier variant as an option — works the same on UK and all EU markets (FR/DE/ES/IT...).

## 7.23.5
- FR/EU variations: now removes eBay's pre-picked attribute tags (e.g. Matière, Epoque) before building variations, so options no longer land on the wrong attribute and an empty attribute can't block "Continue". Added a safety pass before Continue.

## 7.23.4
- FR/EU pricing: prices are now typed with the correct decimal symbol (comma on FR/DE/ES/IT/NL/BE/AT/IE). Fixes prices being inflated (e.g. 12.99 read as 1299) on both the main price field and per-variant variation prices, which also let the variation table save.

## 7.23.3
- FR/EU variations: localized the rest of the MSKU editor (price/quantity/save/save-and-close buttons) and made the price/qty table detection work when eBay renders rows outside a standard tbody. Added a diagnostic when the table is empty.

## 7.23.2
- FR/EU variations: the multi-variation (MSKU) editor now recognises French/German/Spanish/Italian buttons, so variations set up on non-UK markets (was English-only).
- Pricing: profit auto-adjust now uses the correct per-market eBay fees + your real promo rate (was hardcoded UK), and the console now logs market, promo and VAT for each price.

## 7.23.1
- FR/EU markets: fixed duplicate item specifics — the lister no longer creates custom "attributes.X" features for fields that aren't on the eBay form.
- Item specifics: stop stuffing every field with "Does Not Apply"; only fields with real data are filled (required fields still auto-complete).

# UnicornDS — Changelog

## v7.23.0 — 21 Jun 2026
### Added
- **eBay UK restricted-words protection**: built-in block-words list (official eBay UK export, updated 31 May 2026 — 1,197 terms). Listings containing high-risk words (perfume, batteries, baby items, supplements, tools, etc.) are flagged before listing so you can edit or skip them, reducing blocked/removed listings.
- Two protection levels: **Protective** (default, broadest) and **General**. Optional hard-block mode.


All notable changes to the UnicornDS Chrome extension are documented here.

## v7.22.0 — 21 June 2026

### ✨ New
- **Smarter, higher-converting eBay descriptions.** The AI description generator now produces a structured, mobile-first layout: a benefit strip, a clean specifications table, a compatibility/size table, a "Why buy from us" comparison table, and a short buyer FAQ — all proven to lift conversion.
- **Localized trust & support per marketplace.** Every listing ends with a branded delivery / returns / support row in the buyer's own language and region — 🇬🇧 UK support, 🇺🇸 US support, 🇩🇪 Deutschland-Support, 🇫🇷 Support France, and more — matched to the eBay market you sell on.
- **Built-in eBay compliance guard.** A sanitizer strips any banned content (JavaScript, forms, iframes, event handlers) before a description is posted, so listings can't be hidden for active-content violations.

### ⚙️ Notes
- Support-badge wording is configurable — set it to buyer-protection wording if you don't offer live local-language support.

## v7.21.0 — 21 June 2026

### ✨ New
- **Walmart product variations** — size, colour and style options now import automatically, each with its own price and image (multi-variant eBay listings instead of a single variant).
- **Walmart strict mode** — only list products **sold *and shipped* by Walmart.com**. Third-party marketplace sellers (including "Fulfilled by Walmart" / WFS) are detected and blocked, so you avoid unreliable stock, price swings and nested dropshippers. Third-party items are skipped in the product hunter too.
- **Multi-currency support** — correct symbols and decimals for €, $, CHF and C$. Fixes European comma prices (e.g. `€1,43` was being read as `143`).
- **Native-language listings** — titles and descriptions are written in the marketplace's language automatically (German for .de, French for .fr, and so on), based on the eBay market you sell on.

### 🛠 Order Manager fixes
- **Delivered orders now show correctly** — they were getting stuck on "pending" because the status check read dispatch text before delivery. Delivered is now detected first, and re-syncing promotes existing orders to **Completed** when eBay marks them delivered.
- **All your orders import reliably** — orders are now saved progressively during a sync, so a slow or interrupted sync no longer loses everything. Rows that were previously dropped are now kept.
- **More accurate earnings** — the per-order earnings limit was raised (30 → 60 per sync, orders missing earnings fetched first), and the amount parser was fixed so totals over £1,000 are read correctly (e.g. `£1,234.56` is no longer read as `£1.23`).

### ⚙️ Under the hood
- Added eBay fee rates for Austria, Belgium, Ireland and Switzerland (AT, BE, IE, CH).
- Security and stability hardening; quieter console output in production.

---

## v7.20.0 — Previous release
- Walmart support (beta), order count badge on the popup, and earlier improvements.
