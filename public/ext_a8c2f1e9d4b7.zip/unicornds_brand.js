/**
 * UnicornDS - Brand Constants
 * Single source of truth for all branding, colors, and identity.
 * Import this in every file that needs brand references.
 */

const UNICORNDS = {
  // ── Identity ────────────────────────────────────────────
  name:       'UnicornDS',
  fullName:   'UnicornDS',
  tagline:    'Automate Your Dropshipping Empire',
  version:    '2.0.0',
  emoji:      '🦄',

  // ── URLs ─────────────────────────────────────────────────
  website:    'https://unicornds.com',
  support:    'https://unicornds.com/support',
  dashboard:  'https://app.unicornds.com',

  // ── Storage Keys ─────────────────────────────────────────
  // ALL chrome.storage keys use this prefix
  storage: {
    settings:         'unicornds_settings',
    pricingSettings:  'unicornds_pricing_settings',
    safetySettings:   'unicornds_safety_settings',
    skuDictionary:    'unicornds_sku_dictionary',
    ebayToken:        'unicornds_ebay_token',
    membership:       'unicornds_membership',
    credits:          'unicornds_credits',
    onboarded:        'unicornds_onboarded',
    lastProduct:      'unicornds_last_product',
    selectedMarkets:  'unicornds_markets',
    primaryMarket:    'unicornds_primary_market',
    promptTemplate:   'unicornds_prompt_template',
  },

  // ── Colors ───────────────────────────────────────────────
  colors: {
    primary:    '#8b5cf6',   // violet-500
    primaryDark:'#6d28d9',   // violet-700
    primaryLight:'#a78bfa',  // violet-400
    accent:     '#ec4899',   // pink-500
    accentDark: '#be185d',   // pink-700
    success:    '#10b981',   // emerald-500
    warning:    '#f59e0b',   // amber-500
    danger:     '#ef4444',   // red-500
    bgDark:     '#0c0514',   // darkest bg
    bgMid:      '#130b2e',   // card bg
    bgLight:    '#1e1040',   // elevated bg
    border:     '#2d1b69',   // border color
    textPrimary:'#f3f0ff',   // near white with purple tint
    textSecondary:'#a78bfa', // muted purple
    textMuted:  '#6d28d9',   // very muted
  },

  // ── Membership Tiers ─────────────────────────────────────
  tiers: {
    free:     { name: 'Free',     listings: 5,   bulk: false, ai: false },
    starter:  { name: 'Starter',  listings: 50,  bulk: false, ai: true  },
    pro:      { name: 'Pro',      listings: 500, bulk: true,  ai: true  },
    ultimate: { name: 'Ultimate', listings: -1,  bulk: true,  ai: true  },
  },

  // ── Messages ──────────────────────────────────────────────
  messages: {
    notConnected: 'Connect your eBay account in Settings to start listing.',
    noCredits:    'You have no AI credits left. Upgrade your plan to continue.',
    notUltimate:  'This feature requires a Pro or Ultimate plan.',
    veroBlocked:  'This product contains a protected brand name and cannot be listed.',
    lossListing:  'This listing would result in a loss. Adjust your pricing settings.',
  },
};

// Make available globally
if (typeof module !== 'undefined' && module.exports) {
  module.exports = UNICORNDS;
} else {
  window.UNICORNDS = UNICORNDS;
}
