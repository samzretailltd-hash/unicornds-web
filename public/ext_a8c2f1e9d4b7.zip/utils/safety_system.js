/**
 * UnicornDS - Safety System
 * Three modules in one file:
 *   1. RateLimiter   - prevents eBay API bans
 *   2. ListingValidator - pre-flight checks before listing
 *   3. ErrorHandler  - unified error handling + user feedback
 */

// ═══════════════════════════════════════════════════════════
// MODULE 1: RATE LIMITER
// Queues all eBay API calls with intelligent delays
// to prevent triggering eBay's bot detection systems.
// ═══════════════════════════════════════════════════════════

class RateLimiter {
  constructor() {
    this.queues    = {};   // per-endpoint queues
    this.counters  = {};   // call counts per window
    this.windows   = {};   // window start times

    // eBay API limits (conservative - well below actual limits)
    this.limits = {
      'listing_create':    { calls: 5,  windowMs: 60000,  delayMs: 2000  }, // 5/min
      'image_upload':      { calls: 10, windowMs: 60000,  delayMs: 1000  }, // 10/min
      'offer_send':        { calls: 20, windowMs: 60000,  delayMs: 500   }, // 20/min
      'csv_upload':        { calls: 2,  windowMs: 60000,  delayMs: 5000  }, // 2/min
      'csv_download':      { calls: 2,  windowMs: 60000,  delayMs: 5000  }, // 2/min
      'message_send':      { calls: 10, windowMs: 60000,  delayMs: 1000  }, // 10/min
      'default':           { calls: 30, windowMs: 60000,  delayMs: 300   }, // general
    };
  }

  /**
   * Wraps an async function with rate limiting.
   * @param {string}   endpoint - key from this.limits
   * @param {Function} fn       - the async function to throttle
   * @returns {Promise<any>}
   */
  async throttle(endpoint, fn) {
    const limit  = this.limits[endpoint] || this.limits['default'];
    const now    = Date.now();

    // Init window
    if (!this.windows[endpoint] || now - this.windows[endpoint] > limit.windowMs) {
      this.windows[endpoint]  = now;
      this.counters[endpoint] = 0;
    }

    // Check if over limit
    if (this.counters[endpoint] >= limit.calls) {
      const waitMs = limit.windowMs - (now - this.windows[endpoint]);
      console.log(`[RateLimiter] ${endpoint}: limit reached, waiting ${waitMs}ms`);
      await delay(waitMs + 500); // extra buffer
      this.windows[endpoint]  = Date.now();
      this.counters[endpoint] = 0;
    }

    // Inter-call delay
    await delay(limit.delayMs);

    this.counters[endpoint] = (this.counters[endpoint] || 0) + 1;
    return fn();
  }

  /**
   * Checks if an endpoint is currently throttled.
   * @returns {{ throttled: boolean, waitMs: number }}
   */
  status(endpoint) {
    const limit = this.limits[endpoint] || this.limits['default'];
    const now   = Date.now();

    if (!this.windows[endpoint]) return { throttled: false, waitMs: 0 };

    const inWindow = now - this.windows[endpoint] < limit.windowMs;
    const overLimit = this.counters[endpoint] >= limit.calls;

    if (inWindow && overLimit) {
      const waitMs = limit.windowMs - (now - this.windows[endpoint]);
      return { throttled: true, waitMs };
    }

    return { throttled: false, waitMs: 0 };
  }
}

// ═══════════════════════════════════════════════════════════
// MODULE 2: LISTING VALIDATOR
// Runs pre-flight checks before any listing goes live.
// Returns a detailed report with pass/warn/fail per check.
// ═══════════════════════════════════════════════════════════

class ListingValidator {
  constructor(safetySettings = {}) {
    this.safety = {
      veroCheck:        true,
      clothingBlock:    true,
      profitFloor:      true,
      duplicateCheck:   true,
      preListingReview: true,
      ...safetySettings,
    };
  }

  /**
   * Runs all validation checks on a prepared listing.
   * @param {Object} listing - the listing data object
   * @param {Object} options - { veroList, restrictedWords, existingSKUs, pricingResult }
   * @returns {ValidationReport}
   */
  async validate(listing, options = {}) {
    const checks = [];

    // ── 1. Title checks ─────────────────────────────────
    checks.push(this.checkTitleLength(listing.title));
    checks.push(this.checkTitleContent(listing.title));

    if (this.safety.veroCheck && options.veroList) {
      checks.push(this.checkVERO(listing.title, options.veroList));
    }

    if (this.safety.clothingBlock && options.restrictedWords) {
      checks.push(this.checkRestrictedWords(listing.title, options.restrictedWords));
    }

    // ── 2. Price checks ───────────────────────────────────
    if (options.pricingResult) {
      checks.push(this.checkProfitability(options.pricingResult));
    }
    checks.push(this.checkPriceRange(listing.price));

    // ── 3. Image checks ───────────────────────────────────
    checks.push(this.checkImages(listing.images));

    // ── 4. Required fields ────────────────────────────────
    checks.push(this.checkRequiredFields(listing));

    // ── 5. SKU duplicate check ────────────────────────────
    if (this.safety.duplicateCheck && options.existingSKUs) {
      checks.push(this.checkDuplicate(listing.sku, options.existingSKUs));
    }

    // ── 6. Marketplace compatibility ──────────────────────
    checks.push(this.checkMarketplace(listing));

    const passed  = checks.filter(c => c.status === 'pass').length;
    const warnings= checks.filter(c => c.status === 'warn').length;
    const failed  = checks.filter(c => c.status === 'fail').length;

    return {
      checks,
      passed,
      warnings,
      failed,
      canList:   failed === 0,
      mustReview: warnings > 0,
      summary:   this.buildSummary(passed, warnings, failed),
    };
  }

  // ── Individual Checks ────────────────────────────────────

  checkTitleLength(title) {
    if (!title) return { name: 'Title', status: 'fail', message: 'Title is missing' };
    const len = title.trim().length;
    if (len < 20) return { name: 'Title Length', status: 'fail', message: `Title too short: ${len} chars (min 20)` };
    if (len > 80) return { name: 'Title Length', status: 'fail', message: `Title too long: ${len} chars (max 80)` };
    if (len < 40) return { name: 'Title Length', status: 'warn', message: `Title short (${len} chars) - consider adding more keywords` };
    return { name: 'Title Length', status: 'pass', message: `${len} characters ✓` };
  }

  checkTitleContent(title) {
    if (!title) return { name: 'Title Content', status: 'fail', message: 'No title' };
    const lower = title.toLowerCase();
    const spamWords = ['hot sale', 'free shipping', 'best quality', 'new 2024', 'new 2025'];
    const found = spamWords.filter(w => lower.includes(w));
    if (found.length > 0) {
      return { name: 'Title Content', status: 'fail', message: `Contains spam: "${found.join('", "')}"` };
    }
    if (/[!]{2,}/.test(title)) {
      return { name: 'Title Content', status: 'warn', message: 'Multiple exclamation marks found' };
    }
    return { name: 'Title Content', status: 'pass', message: 'Title content clean ✓' };
  }

  checkVERO(title, veroList) {
    if (!title || !veroList?.length) return { name: 'VERO Check', status: 'pass', message: 'No VERO issues' };
    const lower = title.toLowerCase();
    const hits  = veroList.filter(brand =>
      lower.includes(brand.toLowerCase().trim())
    ).slice(0, 3); // show max 3

    if (hits.length > 0) {
      return {
        name: 'VERO Check',
        status: 'fail',
        message: `Protected brand(s) detected: ${hits.join(', ')}`,
        details: hits,
      };
    }
    return { name: 'VERO Check', status: 'pass', message: 'No VERO brands detected ✓' };
  }

  checkRestrictedWords(title, restrictedWords) {
    if (!title || !restrictedWords?.length) {
      return { name: 'Restricted Words', status: 'pass', message: 'No restricted words' };
    }
    const lower = title.toLowerCase();
    const hits  = restrictedWords.filter(w =>
      lower.includes(w.toLowerCase().trim())
    ).slice(0, 3);

    if (hits.length > 0) {
      return {
        name: 'Restricted Words',
        status: 'fail',
        message: `Restricted term(s) in title: "${hits.join('", "')}"`,
        details: hits,
      };
    }
    return { name: 'Restricted Words', status: 'pass', message: 'No restricted words ✓' };
  }

  checkProfitability(pricingResult) {
    if (!pricingResult) return { name: 'Profitability', status: 'warn', message: 'No pricing data' };
    if (!pricingResult.profitable) {
      return { name: 'Profitability', status: 'fail', message: `Loss-making listing! Net profit: ${pricingResult.symbol}${pricingResult.netProfit?.toFixed(2)}` };
    }
    if (!pricingResult.meetsMinMargin) {
      return {
        name: 'Profitability',
        status: 'warn',
        message: `Margin ${pricingResult.profitMargin?.toFixed(1)}% is below your minimum of ${pricingResult.minProfitMargin || 30}%`,
      };
    }
    return {
      name: 'Profitability',
      status: 'pass',
      message: `Margin: ${pricingResult.profitMargin?.toFixed(1)}% · Profit: ${pricingResult.symbol}${pricingResult.netProfit?.toFixed(2)} ✓`,
    };
  }

  checkPriceRange(price) {
    const p = parseFloat(price);
    if (!p || p <= 0) return { name: 'Price', status: 'fail', message: 'Invalid listing price' };
    if (p < 0.99) return { name: 'Price', status: 'fail', message: 'Price below eBay minimum (£0.99)' };
    if (p > 10000) return { name: 'Price', status: 'warn', message: `Very high price (${p}) - please confirm` };
    return { name: 'Price', status: 'pass', message: `Price £${p.toFixed(2)} ✓` };
  }

  checkImages(images) {
    if (!images || images.length === 0) {
      return { name: 'Images', status: 'fail', message: 'No images - eBay requires at least 1 image' };
    }
    if (images.length < 3) {
      return { name: 'Images', status: 'warn', message: `Only ${images.length} image(s) - more images improve conversion` };
    }
    // Check all URLs are eBay-hosted (not AliExpress)
    const nonEbay = images.filter(url => url && !url.includes('ebayimg.com') && !url.includes('i.ebayimg.com'));
    if (nonEbay.length > 0) {
      return { name: 'Images', status: 'warn', message: `${nonEbay.length} image(s) not yet uploaded to eBay` };
    }
    return { name: 'Images', status: 'pass', message: `${images.length} eBay-hosted image(s) ✓` };
  }

  checkRequiredFields(listing) {
    const required = ['title', 'price', 'description', 'sku'];
    const missing  = required.filter(field => !listing[field]);
    if (missing.length > 0) {
      return { name: 'Required Fields', status: 'fail', message: `Missing: ${missing.join(', ')}` };
    }
    return { name: 'Required Fields', status: 'pass', message: 'All required fields present ✓' };
  }

  checkDuplicate(sku, existingSKUs) {
    if (!sku) return { name: 'Duplicate Check', status: 'warn', message: 'No SKU set' };
    if (existingSKUs?.includes(sku)) {
      return { name: 'Duplicate Check', status: 'fail', message: `SKU ${sku} already exists in your active listings` };
    }
    return { name: 'Duplicate Check', status: 'pass', message: 'SKU is unique ✓' };
  }

  checkMarketplace(listing) {
    const valid = ['com', 'co_uk', 'de', 'com_au', 'ca', 'fr', 'es', 'it', 'nl'];
    if (!listing.marketplace || !valid.includes(listing.marketplace)) {
      return { name: 'Marketplace', status: 'fail', message: `Invalid marketplace: ${listing.marketplace}` };
    }
    return { name: 'Marketplace', status: 'pass', message: `Marketplace: ${listing.marketplace} ✓` };
  }

  buildSummary(passed, warnings, failed) {
    if (failed > 0) return `❌ ${failed} issue(s) must be fixed before listing`;
    if (warnings > 0) return `⚠️ ${warnings} warning(s) - review before listing`;
    return `✅ All ${passed} checks passed - ready to list`;
  }
}

// ═══════════════════════════════════════════════════════════
// MODULE 3: ERROR HANDLER
// Centralized error catching, logging, and user notification.
// ═══════════════════════════════════════════════════════════

class ErrorHandler {
  constructor() {
    this.errors = [];  // error log (in-memory)

    // Error type → user-friendly message
    this.messages = {
      EBAY_AUTH_EXPIRED:   'Your eBay session has expired. Please reconnect your account in Settings.',
      EBAY_RATE_LIMIT:     'Too many requests to eBay. UnicornDS will automatically retry in a moment.',
      EBAY_LISTING_FAILED: 'eBay rejected this listing. Check the title and description for policy violations.',
      EBAY_IMAGE_FAILED:   'Image upload to eBay failed. The listing will use the remaining images.',
      ALIEXPRESS_BLOCKED:  'AliExpress blocked the request. Try refreshing the product page.',
      ALIEXPRESS_NO_DATA:  'Could not read product data from this page. Make sure you are on a product page.',
      AI_FAILED:           'AI title generation failed. Please check your internet connection and try again.',
      AI_CREDITS_EMPTY:    'You have no credits remaining. Please upgrade your plan to continue.',
      NETWORK_ERROR:       'Network error. Please check your internet connection.',
      UNKNOWN:             'Something went wrong. Please try again.',
    };
  }

  /**
   * Handles an error - logs it, notifies user, and returns structured info.
   * @param {Error|string} error
   * @param {string}       context - where the error occurred
   * @param {string}       [type]  - error type key
   * @returns {ErrorRecord}
   */
  handle(error, context, type = 'UNKNOWN') {
    const record = {
      id:        Date.now(),
      type,
      context,
      message:   error?.message || String(error),
      friendly:  this.messages[type] || this.messages['UNKNOWN'],
      timestamp: new Date().toISOString(),
      stack:     error?.stack || null,
    };

    this.errors.push(record);
    console.error(`[UnicornDS Error] ${context}:`, record.message);

    // Notify user via Chrome notification if available
    this.notify(record);

    return record;
  }

  /**
   * Wraps an async function with automatic error handling.
   * @param {Function} fn
   * @param {string}   context
   * @param {string}   [type]
   */
  async wrap(fn, context, type) {
    try {
      return await fn();
    } catch (err) {
      return { error: this.handle(err, context, type) };
    }
  }

  /**
   * Sends a Chrome notification to the user.
   */
  notify(record) {
    if (typeof chrome === 'undefined' || !chrome.notifications) return;

    chrome.notifications.create({
      type:    'basic',
      iconUrl: chrome.runtime.getURL('icons/icon48.png'),
      title:   'UnicornDS',
      message: record.friendly,
    });
  }

  /**
   * Determines the error type from a raw error object.
   */
  classify(error) {
    const msg = String(error?.message || error).toLowerCase();
    if (msg.includes('token') || msg.includes('auth') || msg.includes('401')) return 'EBAY_AUTH_EXPIRED';
    if (msg.includes('rate') || msg.includes('429') || msg.includes('too many')) return 'EBAY_RATE_LIMIT';
    if (msg.includes('aliexpress')) return 'ALIEXPRESS_BLOCKED';
    if (msg.includes('credits') || msg.includes('credit')) return 'AI_CREDITS_EMPTY';
    if (msg.includes('anthropic') || msg.includes('claude')) return 'AI_FAILED';
    if (msg.includes('network') || msg.includes('fetch')) return 'NETWORK_ERROR';
    return 'UNKNOWN';
  }

  /**
   * Returns recent errors (last N).
   */
  recent(n = 10) {
    return this.errors.slice(-n);
  }

  /**
   * Clears the error log.
   */
  clear() {
    this.errors = [];
  }
}

// ═══════════════════════════════════════════════════════════
// SHARED UTILITIES
// ═══════════════════════════════════════════════════════════

const delay = ms => new Promise(r => setTimeout(r, ms));

// ═══════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { RateLimiter, ListingValidator, ErrorHandler };
} else {
  window.UnicornDSSafety = { RateLimiter, ListingValidator, ErrorHandler };

  // Create global instances
  window.rateLimiter  = new RateLimiter();
  window.validator    = new ListingValidator();
  window.errorHandler = new ErrorHandler();
}
