/**
 * UnicornDS - Shared Image Utilities (Single Source of Truth)
 *
 * ALL image filtering, placeholder detection, and URL normalization
 * MUST use this module. No other file should define skip/junk patterns.
 *
 * Fixes: H7 (placeholder patterns duplicated in background.js + listing-form.js)
 */

// ═══════════════════════════════════════════════════════
// PLACEHOLDER / JUNK IMAGE DETECTION
// ═══════════════════════════════════════════════════════

const UDS_PLACEHOLDER_PATTERNS = [
  /\/kf\/S906ef2f1/i,         // Known generic AliExpress placeholder
  /\/avatar\//i,              // Store avatar
  /\/store\//i,               // Store logo
  /placeholder/i,
  /default_img/i,
  /no[_-]?image/i,
];

const UDS_JUNK_SIZE_PATTERNS = [
  /\/\d{2,3}x\d{2,3}\.(png|jpg|gif)/i,   // 27x27, 48x48, 56x57 (swatches/icons)
  /\/\d{3}x\d{2}\.(png|jpg)/i,            // 422x42, 232x98 (banners)
  /\/\d{2}x\d{3}\.(png|jpg)/i,            // 42x422 (vertical banners)
];

function udsIsPlaceholderImage(url) {
  if (!url) return true;
  const u = typeof url === 'string' ? url : (url.url || url.src || '');
  if (!u) return true;
  if (UDS_PLACEHOLDER_PATTERNS.some(p => p.test(u))) return true;
  if (UDS_JUNK_SIZE_PATTERNS.some(p => p.test(u))) return true;
  return false;
}

function udsIsVideoUrl(url) {
  if (!url) return false;
  const uLow = url.toLowerCase();
  return uLow.endsWith('.mp4') || uLow.endsWith('.webm') || uLow.endsWith('.mov') || uLow.includes('/video/');
}

// ═══════════════════════════════════════════════════════
// IMAGE URL NORMALIZATION
// ═══════════════════════════════════════════════════════

function udsNormalizeImageUrl(url) {
  if (!url) return '';
  let u = typeof url === 'string' ? url : (url.url || url.src || '');
  if (!u) return '';

  // Add protocol
  if (u.startsWith('//')) u = 'https:' + u;

  // AliExpress: convert thumbnails to HD
  if (u.includes('alicdn.com') || u.includes('aliexpress-media.com')) {
    // Strip size suffixes to get base URL
    if (u.includes('_220x220') || u.includes('_100x100') || u.includes('_50x50')) {
      u = u.replace(/_\d+x\d+q?\d*\.[^/]*$/i, '');
    }
    // Request higher quality
    u = u.replace(/\d+x\d+q\d+/g, '960x960q75');
  }

  // Amazon: convert to high-res
  if (u.includes('amazon') || u.includes('media-amazon')) {
    u = u.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.');
  }

  return u;
}

// ═══════════════════════════════════════════════════════
// PICK BEST IMAGE (for AI vision)
// ═══════════════════════════════════════════════════════

function udsPickBestImage(productData) {
  const allImages = [
    ...(productData.main_hd_images || []),
    ...(productData.images || []),
  ];
  if (!allImages.length) return null;

  for (const img of allImages) {
    if (!img) continue;
    let url = typeof img === 'string' ? img : (img.url || img.src || '');
    if (!url) continue;
    if (udsIsPlaceholderImage(url)) continue;
    return udsNormalizeImageUrl(url);
  }

  // Fallback: use second image (first is often a store icon)
  const fallback = allImages[1] || allImages[0] || null;
  if (fallback) return udsNormalizeImageUrl(fallback);
  return null;
}

// ═══════════════════════════════════════════════════════
// FILTER & DEDUPLICATE IMAGE LIST
// ═══════════════════════════════════════════════════════

function udsFilterImages(images, maxImages = 24) {
  if (!images || !images.length) return [];

  const seenBases = new Set();
  const validImages = [];

  for (const url of images) {
    if (!url) continue;
    let u = typeof url === 'string' ? url : (url.url || '');
    if (!u) continue;

    if (udsIsVideoUrl(u)) continue;
    if (udsIsPlaceholderImage(u)) continue;

    // Deduplicate by base URL
    const base = u.replace(/_\d+x\d+q?\d*\..*$/i, '').replace(/\?.*$/, '').toLowerCase();
    if (seenBases.has(base)) continue;
    seenBases.add(base);

    validImages.push(udsNormalizeImageUrl(u));
  }

  return validImages.slice(0, maxImages);
}

// Make available globally
if (typeof self !== 'undefined') {
  self.UDS_PLACEHOLDER_PATTERNS = UDS_PLACEHOLDER_PATTERNS;
  self.UDS_JUNK_SIZE_PATTERNS = UDS_JUNK_SIZE_PATTERNS;
  self.udsIsPlaceholderImage = udsIsPlaceholderImage;
  self.udsIsVideoUrl = udsIsVideoUrl;
  self.udsNormalizeImageUrl = udsNormalizeImageUrl;
  self.udsPickBestImage = udsPickBestImage;
  self.udsFilterImages = udsFilterImages;
}
