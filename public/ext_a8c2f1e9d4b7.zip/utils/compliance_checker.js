/**
 * Unicorn DS - Compliance Checker v2.0
 * Updated: 23 Apr 2026 — full eBay UK policy coverage
 *
 * Sources:
 *   - Product Safety: ebay.co.uk/help/policies/prohibited-restricted-items/recalled-items-policy?id=4300
 *   - Weapons: ebay.co.uk/help/policies/prohibited-restricted-items/weapons-policy?id=5050
 *   - Knives: ebay.co.uk/help/policies/prohibited-restricted-items/knives-policy?id=5047
 *
 * KEY RULE FOR DROPSHIPPERS:
 *   eBay allows some bladed items WITH age-verified delivery + UK stock.
 *   AliExpress dropshippers CANNOT comply — ships from China, no age verification.
 *   Therefore ALL bladed/sharp items are BLOCKED, not just warned.
 */

const ComplianceChecker = {

  // Generic blade/sharp keywords that trigger eBay's automated scanner
  BLADE_KEYWORDS: [
    'knife', 'knives', 'blade', 'bladed', 'blades',
    'chisel', 'chisels',
    'scraper', 'scrapers', 'putty blade', 'putty knife',
    'cutter', 'box cutter', 'pipe cutter', 'tile cutter', 'glass cutter',
    'razor', 'razors', 'scalpel', 'scalpels',
    'saw', 'saws', 'hole saw', 'hacksaw', 'jigsaw blade', 'saw blade', 'fret saw',
    'coping saw', 'bow saw', 'pruning saw', 'meat saw',
    'axe', 'axes', 'hatchet', 'hatchets', 'tomahawk',
    'machete', 'machetes',
    'sword', 'swords', 'katana', 'samurai',
    'dagger', 'daggers',
    'scissors',
    'shears', 'garden shears', 'pruning shears', 'hedge shears',
    'secateurs', 'pruner', 'pruners', 'loppers',
    'billhook', 'sickle', 'scythe',
    'pickaxe', 'mattock', 'ice pick',
    'chainsaw',
    'planer', 'plane blade',
    'gouge', 'gouges', 'wood gouge',
    'mandoline slicer',
    'pizza cutter', 'pizza wheel',
    'letter opener',
    'straight razor', 'dermaplaning',
    'rotary cutter', 'rotary blade',
    'craft knife', 'craft blade', 'stanley knife', 'snap off blade',
    'utility knife', 'utility blade',
    'multi-tool', 'multitool', 'leatherman',
    'swiss army',
    'spear', 'javelin', 'pike', 'lance', 'halberd',
  ],

  // Illegal weapons — always blocked, criminal offence
  WEAPONS_BANNED: [
    'butterfly knife', 'balisong',
    'switchblade', 'flick knife', 'automatic knife',
    'gravity knife',
    'push dagger', 'push knife',
    'zombie knife', 'zombie blade', 'cyclone knife', 'spiral knife',
    'sword stick', 'sword cane', 'hidden knife', 'disguised knife',
    'knuckle duster', 'knuckleduster', 'brass knuckles', 'brass knuckle',
    'handclaw', 'hand claw',
    'nunchaku', 'nunchucks', 'nunchuk',
    'sansetsukon',
    'throwing star', 'shuriken', 'ninja star',
    'throwing knife', 'throwing axe',
    'blow gun', 'blowgun', 'blowpipe', 'blow dart',
    'dart gun', 'flare gun', 'potato gun', 'spud gun',
    'stun gun', 'taser', 'electroshock',
    'pepper spray', 'mace spray', 'tear gas', 'cs gas', 'cs spray',
    'crossbow', 'crossbows',
    'kusari gama', 'kyoketsu shoge', 'manrikigusari',
    'nightstick', 'baton', 'truncheon', 'blackjack', 'cosh',
    'leaded cane',
    'combat knife', 'tactical knife', 'fighting knife',
    'battle axe', 'spike axe', 'viking axe', 'double headed axe',
  ],

  // NOT bladed — these contain trigger words but are safe
  SAFE_EXCEPTIONS: [
    'wiper blade', 'wiper blades',
    'fan blade', 'fan blades',
    'turbine blade',
    'blade runner', 'blade server', 'shoulder blade',
    'grass blade', 'blade of grass',
    'roller blade', 'rollerblade', 'inline skate',
    'ice skate blade', 'skate blade',
    'mower blade', 'lawn mower blade',
    'strimmer blade', 'trimmer blade',
    'caulk tool', 'caulk nozzle', 'grout tool',
    'squeegee',
  ],

  // Context words: if title contains one of these + a blade keyword → NOT a weapon
  SAFE_CONTEXT: [
    'blender', 'nutribullet', 'vitamix', 'food processor',
    'mixer', 'stand mixer',
    'silicone', 'rubber', 'plastic',
    'caulk', 'caulking', 'grout', 'sealant',
    'ice scraper', 'windscreen', 'windshield',
    'wallpaper',
  ],

  // Product safety — banned categories
  PRODUCT_SAFETY_BLOCKED: [
    'baby lounger', 'infant lounger',
    'cot bumper', 'crib bumper', 'cot bumpers',
    'sleep positioner', 'baby sleep positioner',
    'baby nest', 'sleep nest', 'baby pod',
    'anti-roll', 'anti roll pillow',
    'inclined sleeper', 'infant inclined',
    'baby weighted blanket', 'weighted sleep sack',
    'patting pillow',
    'sids prevention', 'prevent sids', 'anti sids',
    'baby self-feeding', 'self feeding device',
    'baby helmet', 'baby head protector', 'anti-bump helmet',
    '18650 battery', '18650 batteries', '18650 cell',
    'laser pointer', 'laser pen', 'high power laser', 'burning laser',
    'novelty lighter', 'giant lighter', 'toy lighter', 'gun lighter',
  ],

  // CE/UKCA risky — warn only
  CE_RISKY_KEYWORDS: [
    'charger', 'charging cable', 'usb cable', 'power adapter', 'power supply',
    'led light', 'led strip', 'led lamp', 'led bulb',
    'headphones', 'earphones', 'earbuds', 'bluetooth speaker',
    'smart watch', 'smartwatch', 'fitness tracker',
    'drone', 'rc car', 'remote control',
    'hair dryer', 'hair straightener', 'curling iron',
    'electric shaver', 'electric toothbrush',
    'power bank', 'portable charger',
    'lithium battery', 'li-ion battery', 'lipo battery',
    'battery pack', 'rechargeable battery',
    'toy', 'action figure', 'doll', 'plush toy', 'stuffed animal',
    'building blocks', 'lego compatible',
    'baby toy', 'toddler toy', 'infant toy', 'teething',
    'fidget spinner', 'fidget toy', 'slime',
    'safety goggles', 'safety glasses', 'hard hat', 'helmet',
    'hi-vis', 'high visibility',
    'face mask', 'respirator', 'ear defenders',
    'safety boots', 'steel toe',
    'electric scooter', 'e-scooter', 'e-bike', 'ebike',
    'hoverboard', 'segway', 'electric skateboard',
    'angle grinder', 'drill', 'circular saw',
    'pressure washer', 'air compressor',
  ],

  // Brand protection
  PROTECTED_BRANDS: [
    'apple', 'iphone', 'ipad', 'airpods', 'macbook', 'samsung', 'galaxy',
    'google', 'pixel', 'microsoft', 'xbox', 'playstation', 'sony', 'nintendo',
    'huawei', 'oneplus', 'oppo', 'xiaomi', 'bose', 'beats',
    'jbl', 'marshall', 'dyson', 'gopro', 'dji', 'canon', 'nikon',
    'nike', 'adidas', 'puma', 'reebok', 'new balance', 'converse', 'vans',
    'gucci', 'louis vuitton', 'prada', 'chanel', 'hermes', 'burberry',
    'versace', 'balenciaga', 'dior', 'fendi', 'valentino', 'ysl',
    'ralph lauren', 'tommy hilfiger', 'calvin klein', 'armani', 'hugo boss',
    'north face', 'patagonia', 'supreme', 'off-white', 'stone island',
    'canada goose', 'moncler', 'lacoste',
    'rolex', 'omega', 'tag heuer', 'breitling', 'cartier',
    'patek philippe', 'audemars piguet',
    'disney', 'marvel', 'dc comics', 'star wars', 'pokemon',
    'lego', 'barbie', 'hot wheels', 'fisher price', 'hasbro',
    'ray-ban', 'oakley', 'pandora', 'swarovski', 'tiffany',
  ],

  COUNTERFEIT_SIGNALS: [
    'style', 'inspired', 'dupe', 'replica', 'lookalike', 'fake',
    'imitation', 'knock off', 'knockoff', 'copy', 'clone',
  ],

  ACCESSORY_SIGNALS: [
    'compatible', 'for', 'fits', 'works with', 'suitable for',
    'case', 'cover', 'cable', 'charger', 'charging', 'adapter',
    'screen protector', 'tempered glass', 'holder', 'stand', 'mount',
    'strap', 'band', 'replacement', 'aftermarket', 'generic',
    'oem', 'third party', 'universal', 'type',
  ],

  // ═══════════════════════════════════════════════════════
  // HELPER
  // ═══════════════════════════════════════════════════════
  _isSafeException(text) {
    // Check exact phrase matches
    for (const safe of this.SAFE_EXCEPTIONS) {
      if (text.includes(safe)) return true;
    }
    // Check context words: if title contains "blender" + "blade" → not a weapon
    for (const ctx of this.SAFE_CONTEXT) {
      if (text.includes(ctx)) return true;
    }
    return false;
  },

  // ═══════════════════════════════════════════════════════
  // MAIN CHECK
  // ═══════════════════════════════════════════════════════
  check(productData) {
    const title = (productData.custom_title || productData.title || '').toLowerCase();
    const description = (productData.ai_description || productData.description || '').toLowerCase();
    const combined = title + ' ' + description;

    const result = { safe: true, warnings: [], blocks: [] };

    // 1A: ILLEGAL WEAPONS
    for (const kw of this.WEAPONS_BANNED) {
      if (combined.includes(kw)) {
        result.blocks.push({
          type: 'weapon', severity: 'block', keyword: kw,
          message: '🚫 ILLEGAL WEAPON: "' + kw + '" — banned on eBay, criminal offence to sell',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/weapons-policy?id=5050',
        });
        result.safe = false;
        break;
      }
    }

    // 1B: BLADED/SHARP ITEMS — blocked for dropshippers
    if (result.safe) {
      for (const kw of this.BLADE_KEYWORDS) {
        if (combined.includes(kw)) {
          if (this._isSafeException(combined)) {
            result.warnings.push({
              type: 'blade_exception', severity: 'info', keyword: kw,
              message: '✅ "' + kw + '" detected but appears non-bladed (safe exception)',
            });
            break;
          }
          result.blocks.push({
            type: 'blade', severity: 'block', keyword: kw,
            message: '🔪 BLADED ITEM: "' + kw + '" — requires age-verified delivery + UK stock. Cannot dropship from AliExpress.',
            policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/knives-policy?id=5047',
          });
          result.safe = false;
          break;
        }
      }
    }

    // 2: PRODUCT SAFETY
    for (const kw of this.PRODUCT_SAFETY_BLOCKED) {
      if (combined.includes(kw)) {
        result.blocks.push({
          type: 'product_safety', severity: 'block', keyword: kw,
          message: '⛔ PRODUCT SAFETY: "' + kw + '" — banned or restricted by eBay',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/recalled-items-policy?id=4300',
        });
        result.safe = false;
        break;
      }
    }

    // 3: CE/UKCA RISKY (warn only)
    const ceMatches = [];
    for (const kw of this.CE_RISKY_KEYWORDS) {
      if (combined.includes(kw)) ceMatches.push(kw);
    }
    if (ceMatches.length > 0) {
      result.warnings.push({
        type: 'ce_ukca', severity: 'warning',
        message: '⚡ CE/UKCA: "' + ceMatches.slice(0, 3).join('", "') + '" — may need CE/UKCA marking.',
        keywords: ceMatches,
      });
    }

    // 4: COUNTERFEIT / BRAND
    const brandMatches = [];
    for (const brand of this.PROTECTED_BRANDS) {
      const regex = new RegExp('\\b' + brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
      if (regex.test(combined)) brandMatches.push(brand);
    }
    if (brandMatches.length > 0) {
      let isAccessory = this.ACCESSORY_SIGNALS.some(s => combined.includes(s));
      let isCounterfeit = this.COUNTERFEIT_SIGNALS.some(s => combined.includes(s));

      if (isCounterfeit && !isAccessory) {
        result.blocks.push({
          type: 'counterfeit', severity: 'block',
          message: '🚫 COUNTERFEIT: "' + brandMatches[0] + '" with fake/replica signals.',
          brands: brandMatches,
        });
        result.safe = false;
      } else if (isAccessory) {
        result.warnings.push({
          type: 'brand_accessory', severity: 'info',
          message: '✅ ACCESSORY: "' + brandMatches[0] + '" — generic accessory, OK to list.',
          brands: brandMatches,
        });
      } else {
        result.warnings.push({
          type: 'brand_detected', severity: 'warning',
          message: '⚠️ BRAND: "' + brandMatches.join('", "') + '" — only list if genuine.',
          brands: brandMatches,
        });
      }
    }

    // 5: VERO
    if (productData._veroChecked && productData._veroBlocked) {
      result.blocks.push({
        type: 'vero', severity: 'block',
        message: '🛑 VERO: "' + productData._veroBrand + '" is VeRO-protected.',
        brands: [productData._veroBrand],
      });
      result.safe = false;
    }

    return result;
  },

  formatForConsole(result) {
    if (result.safe && result.warnings.length === 0) {
      console.log('[UnicornDS] ✅ Compliance: SAFE');
      return;
    }
    if (result.blocks.length > 0) {
      console.warn('[UnicornDS] 🚨 COMPLIANCE BLOCK:');
      result.blocks.forEach(b => console.warn('[UnicornDS]   ' + b.message));
    }
    if (result.warnings.length > 0) {
      console.warn('[UnicornDS] ⚠️ WARNINGS:');
      result.warnings.forEach(w => console.warn('[UnicornDS]   ' + w.message));
    }
  },

  formatForNotification(result) {
    if (result.safe && result.warnings.length === 0) return null;
    const lines = [];
    result.blocks.forEach(b => lines.push(b.message));
    result.warnings.forEach(w => lines.push(w.message));
    return lines.join('\n');
  },
};

if (typeof module !== 'undefined') module.exports = ComplianceChecker;
