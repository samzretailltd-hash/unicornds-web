/**
 * UnicornDS - AI Title Builder
 * Enhanced with keyword analysis like 
 * Flow: Load Product → Analyze Keywords → Generate Titles → Pick Best
 */

let product = null;
let generatedTitles = [];
let keywords = [];

document.addEventListener('DOMContentLoaded', loadProduct);

// ═══════════════════════════════════════════════════════
// LOAD PRODUCT
// ═══════════════════════════════════════════════════════
function loadProduct() {
  chrome.storage.local.get('unicornds_last_product', (data) => {
    product = data.unicornds_last_product;
    if (!product || !product.title) {
      document.getElementById('productDisplay').innerHTML =
        '<div class="icon">📦</div><p>No product loaded. Scrape a product on AliExpress first.</p>' +
        '<button class="btn btn-secondary" style="margin-top:12px" id="btnReloadProduct">🔄 Reload</button>';
      document.getElementById('btnStart').disabled = true;
      return;
    }

    const imgUrl = (product.images && product.images[0]) || '';
    const imgSrc = imgUrl.startsWith('//') ? 'https:' + imgUrl : imgUrl;
    const specs = (product.filteredItemSpecifics || []).map(s => s.label + ': ' + s.value).join(' • ');

    document.getElementById('productDisplay').innerHTML =
      '<div class="product-header">' +
        (imgSrc ? '<img src="' + imgSrc + '" class="product-img" onerror="this.style.display=\'none\'">' : '') +
        '<div class="product-info">' +
          '<div class="product-title">' + esc(product.title) + '</div>' +
          (specs ? '<div class="product-specs">' + esc(specs) + '</div>' : '') +
        '</div>' +
      '</div>' +
      '<div class="original-title"><strong>Original:</strong> ' + esc(product.title) + '</div>' +
      '<div class="char-count">' + product.title.length + ' characters</div>';

    document.getElementById('btnStart').disabled = false;
    document.getElementById('customTitle').value = product.custom_title || product.cleanedTitle || product.title || '';
    updateCustomCount();
  });
}

// ═══════════════════════════════════════════════════════
// MAIN FLOW - Step by step like 
// ═══════════════════════════════════════════════════════
async function startAnalysis() {
  if (!product) return;

  const btn = document.getElementById('btnStart');
  btn.disabled = true;

  const count = parseInt(document.getElementById('titleCount').value);
  const console = document.getElementById('console');
  console.innerHTML = '';

  // Step 1: Identify product type
  log('🔍 Step 1: Identifying product type...');
  const productType = await callAI(
    'You are a product classification expert. Given this product title, return ONLY the common English product type that a buyer would search for on eBay. One or two words max. No explanation.',
    'Product: ' + product.title
  );
  log('✅ Product type: <strong>' + (productType || 'Unknown') + '</strong>');

  // Step 2: Find buyer search keywords
  log('🔍 Step 2: Analyzing buyer search keywords...');
  const keywordResult = await callAI(
    'You are an eBay SEO expert. For this product, list the top 15 keywords that real eBay buyers search for when looking for this type of item. ' +
    'Think about what a UK/US buyer would type in the eBay search bar. ' +
    'Return JSON: {"search_term": "what buyer searches", "keywords": ["keyword1", "keyword2", ...], "avoid": ["words to avoid"]}',
    'Product: ' + product.title + '\nType: ' + (productType || '') +
    '\nSpecs: ' + (product.filteredItemSpecifics || []).map(s => s.label + ': ' + s.value).join(', '),
    true
  );

  let searchTerm = productType;
  let relevantKeywords = [];
  let avoidWords = [];

  if (keywordResult) {
    try {
      const parsed = JSON.parse(keywordResult);
      searchTerm = parsed.search_term || productType;
      relevantKeywords = parsed.keywords || [];
      avoidWords = parsed.avoid || [];
    } catch (e) {}
  }

  log('✅ Buyer search term: <strong>' + searchTerm + '</strong>');

  // Show keywords
  if (relevantKeywords.length > 0) {
    keywords = relevantKeywords;
    const kwHtml = relevantKeywords.map(k => '<span class="kw-tag">' + esc(k) + '</span>').join('');
    document.getElementById('keywordsSection').style.display = 'block';
    document.getElementById('keywordTags').innerHTML = kwHtml;
    log('✅ Found ' + relevantKeywords.length + ' relevant keywords');
  }

  if (avoidWords.length > 0) {
    log('⚠️ Avoid: ' + avoidWords.join(', '));
  }

  // Step 3: Generate titles using keywords
  log('✨ Step 3: Generating ' + count + ' SEO-optimized titles...');
  const titleResult = await callAI(
    'You are an eBay listing title expert. Generate exactly ' + count + ' unique eBay listing titles.\n' +
    'RULES:\n' +
    '- Max 80 characters each\n' +
    '- Use these high-traffic keywords: ' + relevantKeywords.slice(0, 8).join(', ') + '\n' +
    '- Buyer search term is: "' + searchTerm + '"\n' +
    '- Remove Chinese/unknown brand names\n' +
    '- Remove: Hot Sale, Free Shipping, New Arrival, 1pc, 1pcs\n' +
    '- Keep: material, size, quantity, key features\n' +
    '- Avoid: ' + avoidWords.join(', ') + '\n' +
    '- Use Title Case\n' +
    '- No special characters or emojis\n' +
    '- First title should be the BEST one\n' +
    '- Return JSON: {"titles": ["title1", "title2", ...]}',
    'Product: ' + product.title +
    '\nSpecs: ' + (product.filteredItemSpecifics || []).map(s => s.label + ': ' + s.value).join(', '),
    true
  );

  if (titleResult) {
    try {
      const parsed = JSON.parse(titleResult);
      generatedTitles = parsed.titles || [];
    } catch (e) {
      generatedTitles = titleResult.split('\n').filter(l => l.trim().length > 10)
        .map(l => l.replace(/^\d+[\.\)]\s*/, '').replace(/^["']|["']$/g, '').trim());
    }
    displayTitles();
    log('🎉 Done! Generated ' + generatedTitles.length + ' titles. Pick the best one!');
  } else {
    log('❌ Failed to generate titles. Check your OpenAI API key.');
  }

  btn.disabled = false;
}

// ═══════════════════════════════════════════════════════
// DISPLAY TITLES
// ═══════════════════════════════════════════════════════
function displayTitles() {
  const container = document.getElementById('titleResults');
  container.innerHTML = '';
  document.getElementById('resultsCard').style.display = 'block';

  generatedTitles.forEach((title, i) => {
    const len = title.length;
    const charClass = len <= 70 ? 'ok' : len <= 80 ? 'warn' : 'bad';

    // Highlight keywords in title
    let highlighted = esc(title);
    keywords.forEach(kw => {
      const regex = new RegExp('(' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
      highlighted = highlighted.replace(regex, '<mark>$1</mark>');
    });

    const div = document.createElement('div');
    div.className = 'title-result' + (i === 0 ? ' best' : '');
    div.innerHTML =
      '<div class="title-rank">' + (i === 0 ? '⭐ BEST' : '#' + (i + 1)) + '</div>' +
      '<div class="title-text">' + highlighted + '</div>' +
      '<div class="title-meta">' +
        '<span class="title-chars ' + charClass + '">' + len + '/80</span>' +
        '<div class="title-actions">' +
          '<button class="btn btn-sm btn-secondary" data-copy="' + i + '">📋 Copy</button>' +
          '<button class="btn btn-sm btn-primary" data-use="' + i + '">✅ Use</button>' +
        '</div>' +
      '</div>';

    div.onclick = (e) => {
      if (e.target.tagName === 'BUTTON') return;
      document.querySelectorAll('.title-result').forEach(d => d.classList.remove('selected'));
      div.classList.add('selected');
      document.getElementById('customTitle').value = title;
      updateCustomCount();
    };
    container.appendChild(div);
  });
}

// ═══════════════════════════════════════════════════════
// ACTIONS
// ═══════════════════════════════════════════════════════
function copyTitle(idx) {
  navigator.clipboard.writeText(generatedTitles[idx]);
  showToast('Copied!');
}

function useTitle(idx) { saveTitle(generatedTitles[idx]); }

function copyCustom() {
  const t = document.getElementById('customTitle').value;
  if (t) { navigator.clipboard.writeText(t); showToast('Copied!'); }
}

function useCustom() {
  const t = document.getElementById('customTitle').value;
  if (t) saveTitle(t);
}

function saveTitle(title) {
  if (!product) return;
  product.custom_title = title;
  product.cleanedTitle = title;
  chrome.storage.local.set({ unicornds_last_product: product }, () => {
    showToast('✅ Title saved! Will be used on next listing.');
  });
}

function updateCustomCount() {
  const len = document.getElementById('customTitle').value.length;
  const cls = len <= 70 ? 'ok' : len <= 80 ? 'warn' : 'bad';
  document.getElementById('customCount').className = 'title-chars ' + cls;
  document.getElementById('customCount').textContent = len + '/80';
}

// ═══════════════════════════════════════════════════════
// AI CALL
// ═══════════════════════════════════════════════════════
function callAI(systemPrompt, userMessage, jsonMode) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: 'call_openai', systemPrompt, userMessage, jsonMode: jsonMode || false,
    }, (resp) => {
      if (chrome.runtime.lastError) return resolve(null);
      resolve(resp?.result || null);
    });
  });
}

// ═══════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function log(msg) {
  const el = document.getElementById('console');
  const line = document.createElement('div');
  line.className = 'console-line';
  line.innerHTML = msg;
  el.appendChild(line);
  el.scrollTop = el.scrollHeight;
}

function showToast(msg) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.style.cssText = 'position:fixed;bottom:20px;right:20px;padding:12px 20px;background:#27ae60;color:#fff;border-radius:8px;font-size:13px;font-weight:600;z-index:9999;transition:opacity 0.3s;';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.opacity = '1';
  setTimeout(() => { t.style.opacity = '0'; }, 2000);
}

// ── Event listeners (MV3 CSP - no inline onclick) ──
document.addEventListener('DOMContentLoaded', () => {
  const btnStart = document.getElementById('btnStart');
  if (btnStart) btnStart.addEventListener('click', startAnalysis);
  const btnCopyCustom = document.getElementById('btnCopyCustom');
  if (btnCopyCustom) btnCopyCustom.addEventListener('click', copyCustom);
  const btnUseCustom = document.getElementById('btnUseCustom');
  if (btnUseCustom) btnUseCustom.addEventListener('click', useCustom);
  const btnReload = document.getElementById('btnReloadProduct');
  if (btnReload) btnReload.addEventListener('click', loadProduct);
  // Event delegation for dynamically generated title buttons
  document.addEventListener('click', (e) => {
    const copyBtn = e.target.closest('[data-copy]');
    if (copyBtn) { copyTitle(parseInt(copyBtn.dataset.copy)); return; }
    const useBtn = e.target.closest('[data-use]');
    if (useBtn) { useTitle(parseInt(useBtn.dataset.use)); return; }
  });
});
