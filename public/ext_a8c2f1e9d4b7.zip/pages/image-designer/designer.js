/**
 * UnicornDS - Image Template Designer v2
 *  approach: numbered placeholders → auto-fill with product images
 *
 * NEW in v2:
 *   - Upload images from computer (file picker, multi-select)
 *   - Upload images from URL (logos, badges, watermarks)
 *   - Layer list panel with per-item delete buttons
 *   - Improved delete UX (big red button + keyboard + layer delete)
 */

const SIZE = 1500;
const DISP = 700;
const SC = DISP / SIZE;
let objects = [];
let selected = null;
let drag = false, resize = false;
let offX = 0, offY = 0;
let placeholderCount = 0;
let borderCfg = null;
let canvas, ctx;

document.addEventListener('DOMContentLoaded', init);

function init() {
  canvas = document.getElementById('c');
  canvas.width = DISP; canvas.height = DISP;
  ctx = canvas.getContext('2d');
  render();
  bindEvents();
  loadSavedTemplate();
}

// ═══════════════════════════════════════════════════════
// RENDER
// ═══════════════════════════════════════════════════════
function render() {
  ctx.clearRect(0, 0, DISP, DISP);
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, DISP, DISP);
  objects.forEach(o => drawObj(ctx, o, SC));
  if (borderCfg) { ctx.strokeStyle = borderCfg.color; ctx.lineWidth = borderCfg.thick * SC; ctx.strokeRect(0, 0, DISP, DISP); }
  if (selected) drawSelection();
  renderLayerList();
}

function drawObj(c, o, s) {
  const x=o.x*s, y=o.y*s, w=o.w*s, h=o.h*s;
  c.save(); c.globalAlpha = o.opacity ?? 1;

  if (o.type === 'placeholder') {
    c.fillStyle = '#f0f0f0'; c.fillRect(x,y,w,h);
    c.strokeStyle = '#aaa'; c.lineWidth = 2; c.setLineDash([8,4]); c.strokeRect(x,y,w,h); c.setLineDash([]);
    c.fillStyle = '#888'; c.font = 'bold '+Math.round(40*s)+'px Arial';
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(String(o.num), x+w/2, y+h/2);
  }

  if (o.type === 'image' && o.img) {
    c.save(); c.beginPath(); c.rect(x,y,w,h); c.clip();
    const ia = o.img.width/o.img.height, ba = w/h;
    let dw,dh,dx,dy;
    if (ia>ba) { dh=h; dw=h*ia; dx=x+(w-dw)/2; dy=y; }
    else { dw=w; dh=w/ia; dx=x; dy=y+(h-dh)/2; }
    c.drawImage(o.img, dx, dy, dw, dh);
    c.restore();
  }

  if (o.type === 'banner') {
    c.fillStyle = o.bg || '#e74c3c';
    roundRect(c, x, y, w, h, 6*s); c.fill();
    c.fillStyle = '#fff';
    c.font = 'bold '+Math.round((o.fontSize||48)*s)+'px '+(o.font||'Arial Black');
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(o.text||'', x+w/2, y+h/2);
  }
  c.restore();
}

function drawSelection() {
  const s=SC, o=selected;
  ctx.save(); ctx.strokeStyle='#7C3AED'; ctx.lineWidth=2; ctx.setLineDash([5,3]);
  ctx.strokeRect(o.x*s, o.y*s, o.w*s, o.h*s); ctx.setLineDash([]);
  ctx.fillStyle='#7C3AED';
  ctx.fillRect((o.x+o.w)*s-6, (o.y+o.h)*s-6, 12, 12);
  ctx.restore();
}

function roundRect(c,x,y,w,h,r) {
  c.beginPath(); c.moveTo(x+r,y); c.lineTo(x+w-r,y); c.arcTo(x+w,y,x+w,y+r,r);
  c.lineTo(x+w,y+h-r); c.arcTo(x+w,y+h,x+w-r,y+h,r); c.lineTo(x+r,y+h);
  c.arcTo(x,y+h,x,y+h-r,r); c.lineTo(x,y+r); c.arcTo(x,y,x+r,y,r); c.closePath();
}

// ═══════════════════════════════════════════════════════
// EVENTS
// ═══════════════════════════════════════════════════════
function bindEvents() {
  canvas.addEventListener('mousedown', onDown);
  canvas.addEventListener('mousemove', onMove);
  canvas.addEventListener('mouseup', onUp);

  document.getElementById('btnAddPlaceholder').addEventListener('click', addPlaceholder);
  document.getElementById('btnAddBanner').addEventListener('click', () => {
    const t = document.getElementById('bannerText').value;
    const c = document.getElementById('bannerColor').value;
    if (t) addBanner(t, c);
  });

  document.querySelectorAll('.preset').forEach(b => {
    b.addEventListener('click', () => addBanner(b.dataset.text, b.dataset.bg));
  });

  document.querySelectorAll('.layout-btn').forEach(b => {
    b.addEventListener('click', () => applyLayout(b.dataset.layout));
  });

  document.getElementById('btnBorder').addEventListener('click', () => {
    borderCfg = { color: document.getElementById('borderColor').value, thick: parseInt(document.getElementById('borderThick').value)||20 };
    render();
  });
  document.getElementById('btnNoBorder').addEventListener('click', () => { borderCfg = null; render(); });

  document.getElementById('btnFront').addEventListener('click', () => { if(selected){objects.splice(objects.indexOf(selected),1);objects.push(selected);render();} });
  document.getElementById('btnBack').addEventListener('click', () => { if(selected){objects.splice(objects.indexOf(selected),1);objects.unshift(selected);render();} });
  document.getElementById('btnDup').addEventListener('click', () => {
    if(!selected)return;
    const c={...selected, x:selected.x+30, y:selected.y+30};
    if(selected.type==='placeholder'){placeholderCount++;c.num=placeholderCount;}
    if(c.img) c.img=selected.img;
    // Preserve b64 for image objects so save/load works
    if(selected.b64) c.b64 = selected.b64;
    objects.push(c); selected=c; render(); showProps();
  });
  document.getElementById('btnDel').addEventListener('click', delSelected);

  document.getElementById('opacitySlider').addEventListener('input', e => { if(selected){selected.opacity=parseFloat(e.target.value);render();} });

  document.getElementById('btnSave').addEventListener('click', saveTemplate);
  document.getElementById('btnLoad').addEventListener('click', loadSavedTemplate);
  document.getElementById('btnClear').addEventListener('click', () => { if(confirm('Clear canvas?')){objects=[];selected=null;placeholderCount=0;borderCfg=null;render();showProps();} });
  document.getElementById('btnExport').addEventListener('click', exportPNG);
  document.getElementById('btnTest').addEventListener('click', testTemplate);
  document.getElementById('btnBackEdit').addEventListener('click', () => { document.getElementById('testView').style.display='none'; document.getElementById('canvasWrap').style.display=''; });
  document.getElementById('btnDownloadTest').addEventListener('click', downloadTest);

  // ── Upload from computer ──
  document.getElementById('btnUploadFile').addEventListener('click', () => {
    console.log('[Designer] Upload button clicked - opening file picker');
    document.getElementById('fileInput').click();
  });
  document.getElementById('fileInput').addEventListener('change', (e) => {
    console.log('[Designer] File selected:', e.target.files?.length, 'files');
    handleFileUpload(e);
  });

  // ── Upload from URL ──
  document.getElementById('btnUploadUrl').addEventListener('click', () => {
    console.log('[Designer] URL upload clicked');
    uploadFromUrl();
  });
  document.getElementById('imageUrlInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') uploadFromUrl();
  });

  // ── Keyboard shortcuts ──
  document.addEventListener('keydown', e => {
    if(e.target.tagName==='INPUT'||e.target.tagName==='SELECT'||e.target.tagName==='TEXTAREA')return;
    if(e.key==='Delete'||e.key==='Backspace') delSelected();
  });
}

function pos(e) { const r=canvas.getBoundingClientRect(); return {x:(e.clientX-r.left)/SC, y:(e.clientY-r.top)/SC}; }
function hit(px,py) { for(let i=objects.length-1;i>=0;i--){const o=objects[i];if(px>=o.x&&px<=o.x+o.w&&py>=o.y&&py<=o.y+o.h)return o;} return null; }
function onResize(px,py) { if(!selected)return false; return Math.abs(px-(selected.x+selected.w))<20&&Math.abs(py-(selected.y+selected.h))<20; }

function onDown(e) {
  const p=pos(e);
  if(selected&&onResize(p.x,p.y)){resize=true;return;}
  const o=hit(p.x,p.y); selected=o;
  if(o){drag=true;offX=p.x-o.x;offY=p.y-o.y;showProps();}else{clearProps();}
  render();
}
function onMove(e) {
  const p=pos(e);
  if(drag&&selected){selected.x=Math.max(0,Math.min(p.x-offX,SIZE-selected.w));selected.y=Math.max(0,Math.min(p.y-offY,SIZE-selected.h));render();}
  if(resize&&selected){selected.w=Math.max(50,p.x-selected.x);selected.h=Math.max(50,p.y-selected.y);render();}
  canvas.style.cursor=selected&&onResize(p.x,p.y)?'se-resize':hit(p.x,p.y)?'move':'default';
}
function onUp() { drag=false; resize=false; }

function delSelected() { if(!selected)return; objects=objects.filter(o=>o!==selected); selected=null; clearProps(); render(); }

// Delete by index - used by layer list
function delByIndex(idx) {
  if (idx < 0 || idx >= objects.length) return;
  const wasSelected = objects[idx] === selected;
  objects.splice(idx, 1);
  if (wasSelected) { selected = null; clearProps(); }
  render();
}

// ═══════════════════════════════════════════════════════
// ADD OBJECTS
// ═══════════════════════════════════════════════════════
function addPlaceholder() {
  placeholderCount++;
  const o = { type:'placeholder', num:placeholderCount, x:50+(placeholderCount-1)*30, y:50+(placeholderCount-1)*30, w:400, h:400, opacity:1 };
  objects.push(o); selected=o; render(); showProps();
}

function addBanner(text, bg) {
  const font = document.getElementById('bannerFont').value;
  const fontSize = parseInt(document.getElementById('bannerSize').value)||48;
  ctx.font = 'bold '+fontSize+'px '+font;
  const tw = ctx.measureText(text).width;
  const w = tw/SC + 60, h = fontSize + 30;
  objects.push({ type:'banner', text, bg, font, fontSize, x:(SIZE-w)/2, y:30, w, h, opacity:1 });
  selected = objects[objects.length-1]; render(); showProps();
}

function applyLayout(type) {
  objects = objects.filter(o => o.type !== 'placeholder');
  placeholderCount = 0;
  const g=20, S=SIZE;
  const layouts = {
    '1': [{x:g,y:g,w:S-g*2,h:S-g*2}],
    '2h': [{x:g,y:g,w:(S-g*3)/2,h:S-g*2},{x:(S+g)/2,y:g,w:(S-g*3)/2,h:S-g*2}],
    '2v': [{x:g,y:g,w:S-g*2,h:(S-g*3)/2},{x:g,y:(S+g)/2,w:S-g*2,h:(S-g*3)/2}],
    '3': [{x:g,y:g,w:(S-g*3)*0.6,h:S-g*2},{x:g+(S-g*3)*0.6+g,y:g,w:(S-g*3)*0.4,h:(S-g*3)/2},{x:g+(S-g*3)*0.6+g,y:(S+g)/2,w:(S-g*3)*0.4,h:(S-g*3)/2}],
    '4': [{x:g,y:g,w:(S-g*3)/2,h:(S-g*3)/2},{x:(S+g)/2,y:g,w:(S-g*3)/2,h:(S-g*3)/2},{x:g,y:(S+g)/2,w:(S-g*3)/2,h:(S-g*3)/2},{x:(S+g)/2,y:(S+g)/2,w:(S-g*3)/2,h:(S-g*3)/2}],
  };
  (layouts[type]||layouts['1']).forEach(c => { placeholderCount++; objects.push({type:'placeholder',num:placeholderCount,x:c.x,y:c.y,w:c.w,h:c.h,opacity:1}); });
  selected=null; render();
}

// ═══════════════════════════════════════════════════════
// UPLOAD FROM COMPUTER
// ═══════════════════════════════════════════════════════
function handleFileUpload(e) {
  const files = Array.from(e.target.files);
  console.log('[Designer] handleFileUpload:', files.length, 'files');
  if (!files.length) return;

  files.forEach(file => {
    console.log('[Designer] Processing file:', file.name, file.type, file.size + 'bytes');
    if (!file.type.startsWith('image/')) { console.log('[Designer] Skipped - not an image'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const b64 = ev.target.result;
      console.log('[Designer] File read as base64:', b64.substring(0, 50) + '...');
      const img = new Image();
      img.onload = () => {
        console.log('[Designer] Image loaded:', img.width, 'x', img.height);
        addImageObject(img, b64, file.name);
      };
      img.onerror = () => console.error('[Designer] Image failed to load from base64');
      img.src = b64;
    };
    reader.onerror = () => console.error('[Designer] FileReader error');
    reader.readAsDataURL(file);
  });

  // Reset so same file can be re-selected
  e.target.value = '';
}

// ═══════════════════════════════════════════════════════
// UPLOAD FROM URL
// ═══════════════════════════════════════════════════════
function uploadFromUrl() {
  let url = document.getElementById('imageUrlInput').value.trim();
  if (!url) { alert('Please paste an image URL first.'); return; }

  // Remove any trailing/leading quotes
  url = url.replace(/['"]+$/g, '').replace(/^['"]+/g, '').trim();

  // If it's already a base64 data URL - use it directly, no need to fetch
  if (url.startsWith('data:image')) {
    const img = new Image();
    img.onload = () => {
      addImageObject(img, url, 'pasted-image');
      document.getElementById('imageUrlInput').value = '';
    };
    img.onerror = () => alert('Invalid image data. Make sure you copied the full data URL.');
    img.src = url;
    return;
  }

  // Clean up web URLs
  if (url.startsWith('//')) url = 'https:' + url;
  if (!url.startsWith('http')) url = 'https://' + url;

  document.getElementById('btnUploadUrl').textContent = '⏳';
  document.getElementById('btnUploadUrl').disabled = true;

  // Use background to fetch (avoids CORS)
  chrome.runtime.sendMessage({ type: 'url-to-b64', url }, resp => {
    document.getElementById('btnUploadUrl').textContent = '🔗';
    document.getElementById('btnUploadUrl').disabled = false;

    if (chrome.runtime.lastError) {
      alert('Failed to load image.\n\nError: ' + chrome.runtime.lastError.message);
      return;
    }

    if (!resp || !resp.b64Image) {
      alert('Failed to load image from URL.\n\nPossible reasons:\n• URL doesn\'t point to an image\n• Website blocks direct image access\n• Image format not supported\n\nTry: Right-click the image → "Copy image address" and paste that.\n\nError: ' + (resp?.error || 'No image data returned'));
      return;
    }

    const img = new Image();
    img.onload = () => {
      const name = url.split('/').pop().split('?')[0].substring(0, 30) || 'url-image';
      addImageObject(img, resp.b64Image, name);
      document.getElementById('imageUrlInput').value = '';
    };
    img.onerror = () => {
      alert('Image downloaded but could not be decoded.\n\nThe URL might not be a valid image file.');
    };
    img.src = resp.b64Image;
  });
}

// ═══════════════════════════════════════════════════════
// ADD IMAGE OBJECT - shared by file + URL upload
// ═══════════════════════════════════════════════════════
function addImageObject(img, b64, name) {
  // Scale to fit within canvas, max 400px side
  const maxSide = 400;
  let w, h;
  if (img.width >= img.height) {
    w = Math.min(maxSide, img.width);
    h = w * (img.height / img.width);
  } else {
    h = Math.min(maxSide, img.height);
    w = h * (img.width / img.height);
  }

  const o = {
    type: 'image',
    img: img,
    b64: b64,        // saved for persistence + layer thumbnails
    name: name || 'Image',
    x: (SIZE - w) / 2,
    y: (SIZE - h) / 2,
    w: w,
    h: h,
    opacity: 1,
  };

  objects.push(o);
  selected = o;
  render();
  showProps();
}

// ═══════════════════════════════════════════════════════
// LAYER LIST - shows all objects with per-item delete
// ═══════════════════════════════════════════════════════
function renderLayerList() {
  const container = document.getElementById('layerList');
  if (!container) return;

  if (!objects.length) {
    container.innerHTML = '<p class="muted">No objects yet</p>';
    return;
  }

  container.innerHTML = '';

  // Render top-to-bottom (reverse of array = front to back)
  for (let i = objects.length - 1; i >= 0; i--) {
    const o = objects[i];
    const item = document.createElement('div');
    item.className = 'layer-item' + (o === selected ? ' active' : '');

    // Icon
    const icon = document.createElement('span');
    icon.className = 'layer-icon';
    if (o.type === 'placeholder') icon.textContent = '📐';
    else if (o.type === 'banner') icon.textContent = '📝';
    else if (o.type === 'image') icon.textContent = '🖼';

    // Thumbnail for images
    let thumb = null;
    if (o.type === 'image' && (o.b64 || o.img?.src)) {
      thumb = document.createElement('img');
      thumb.className = 'layer-thumb';
      thumb.src = o.b64 || o.img.src;
    }

    // Name
    const name = document.createElement('span');
    name.className = 'layer-name';
    if (o.type === 'placeholder') name.textContent = 'Placeholder #' + o.num;
    else if (o.type === 'banner') name.textContent = o.text || 'Banner';
    else if (o.type === 'image') name.textContent = o.name || 'Image';

    // Delete button
    const del = document.createElement('button');
    del.className = 'layer-del';
    del.textContent = '✕';
    del.title = 'Delete this element';
    const idx = i;
    del.addEventListener('click', (e) => {
      e.stopPropagation();
      delByIndex(idx);
    });

    // Click to select
    item.addEventListener('click', () => {
      selected = o;
      showProps();
      render();
    });

    item.appendChild(icon);
    if (thumb) item.appendChild(thumb);
    item.appendChild(name);
    item.appendChild(del);
    container.appendChild(item);
  }
}

// ═══════════════════════════════════════════════════════
// PROPERTIES PANEL
// ═══════════════════════════════════════════════════════
function showProps() {
  if(!selected)return;
  const o=selected, p=document.getElementById('props');
  let h='<p style="color:#aaa;font-size:11px">'+o.type+(o.num?' #'+o.num:'')+' ('+Math.round(o.w)+'×'+Math.round(o.h)+')</p>';
  if(o.type==='banner') {
    h+='<label>Text</label><input id="pText" value="'+esc(o.text)+'">';
    h+='<label>BG</label><input type="color" id="pBg" value="'+(o.bg||'#e74c3c')+'">';
    h+='<label>Size</label><input type="number" id="pFs" value="'+(o.fontSize||48)+'">';
  }
  if(o.type==='image') {
    h+='<p style="color:#6BCB77;font-size:10px;margin-bottom:4px">'+esc(o.name||'Image')+'</p>';
    h+='<button id="pReplaceImg" style="width:100%;padding:4px 6px;background:#1a2a1a;border:1px solid #2d5a2d;border-radius:3px;color:#6BCB77;font-size:10px;cursor:pointer;margin-bottom:4px">📁 Replace Image</button>';
    h+='<input type="file" id="pReplaceInput" accept="image/*" style="display:none">';
  }
  h+='<label>X</label><input type="number" id="pX" value="'+Math.round(o.x)+'">';
  h+='<label>Y</label><input type="number" id="pY" value="'+Math.round(o.y)+'">';
  h+='<label>W</label><input type="number" id="pW" value="'+Math.round(o.w)+'">';
  h+='<label>H</label><input type="number" id="pH" value="'+Math.round(o.h)+'">';
  p.innerHTML=h;

  const bind=(id,fn)=>{const el=document.getElementById(id);if(el)el.addEventListener('input',fn);};
  bind('pText',e=>{o.text=e.target.value;render();});
  bind('pBg',e=>{o.bg=e.target.value;render();});
  bind('pFs',e=>{o.fontSize=parseInt(e.target.value);render();});
  bind('pX',e=>{o.x=parseInt(e.target.value);render();});
  bind('pY',e=>{o.y=parseInt(e.target.value);render();});
  bind('pW',e=>{o.w=parseInt(e.target.value);render();});
  bind('pH',e=>{o.h=parseInt(e.target.value);render();});
  document.getElementById('opacitySlider').value=o.opacity??1;

  // Replace image button
  const replBtn = document.getElementById('pReplaceImg');
  const replInput = document.getElementById('pReplaceInput');
  if (replBtn && replInput) {
    replBtn.addEventListener('click', () => replInput.click());
    replInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const b64 = ev.target.result;
        const img = new Image();
        img.onload = () => {
          o.img = img;
          o.b64 = b64;
          o.name = file.name;
          render();
          showProps();
        };
        img.src = b64;
      };
      reader.readAsDataURL(file);
    });
  }
}
function clearProps() { document.getElementById('props').innerHTML='<p class="muted">Click an object to edit</p>'; }
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

// ═══════════════════════════════════════════════════════
// SAVE / LOAD TEMPLATE
// ═══════════════════════════════════════════════════════
function saveTemplate() {
  const data = objects.map(o => {
    const c = {...o};
    delete c.img;  // can't serialize HTMLImageElement

    // Compress large b64 images to keep storage manageable
    // chrome.storage.local has ~5MB limit total
    if (c.b64 && c.b64.length > 500000) {
      // Resize to max 400x400 to save space
      try {
        const tmpCanvas = document.createElement('canvas');
        const maxDim = 400;
        tmpCanvas.width = maxDim; tmpCanvas.height = maxDim;
        const tmpCtx = tmpCanvas.getContext('2d');
        const tmpImg = new Image();
        tmpImg.src = c.b64;
        tmpCtx.drawImage(tmpImg, 0, 0, maxDim, maxDim);
        c.b64 = tmpCanvas.toDataURL('image/jpeg', 0.7);
        console.log('[UnicornDS] Compressed large image:', c.name, '→', (c.b64.length/1024).toFixed(0) + 'KB');
      } catch(e) {}
    }
    return c;
  });
  const tmpl = { objects:data, borderCfg, placeholderCount };

  // Check total size before saving
  const totalSize = JSON.stringify(tmpl).length;
  console.log('[UnicornDS] Template size:', (totalSize/1024).toFixed(0) + 'KB');

  if (totalSize > 4000000) {
    alert('Template too large (' + (totalSize/1024/1024).toFixed(1) + 'MB).\n\nTry using smaller images or fewer uploaded images.\nPlaceholders and banners take almost no space.');
    return;
  }

  chrome.storage.local.set({ unicornds_image_template: tmpl }, () => {
    if (chrome.runtime.lastError) {
      alert('Failed to save template!\n\nError: ' + chrome.runtime.lastError.message + '\n\nTry removing some uploaded images.');
      console.error('[UnicornDS] Save error:', chrome.runtime.lastError.message);
      return;
    }
    const imgCount = data.filter(o=>o.type==='image').length;
    const phCount = data.filter(o=>o.type==='placeholder').length;
    document.getElementById('templateInfo').textContent = '✅ Saved! (' + data.length + ' objects, ' + phCount + ' placeholders, ' + imgCount + ' images, ' + (totalSize/1024).toFixed(0) + 'KB)';
    alert('Template saved! It will auto-apply to your listing images.');
  });
}

function loadSavedTemplate() {
  chrome.storage.local.get('unicornds_image_template', d => {
    const t = d.unicornds_image_template;
    if (!t) { document.getElementById('templateInfo').textContent = 'No saved template'; return; }
    objects = [];
    borderCfg = t.borderCfg || null;
    placeholderCount = t.placeholderCount || 0;

    // Restore objects, rebuilding Image elements from b64
    let loadCount = 0;
    const rawObjects = t.objects || [];
    const total = rawObjects.length;

    if (!total) { render(); return; }

    rawObjects.forEach((raw, idx) => {
      if (raw.type === 'image' && raw.b64) {
        const img = new Image();
        img.onload = () => {
          raw.img = img;
          objects[idx] = raw;
          loadCount++;
          if (loadCount === total) finishLoad();
        };
        img.onerror = () => {
          // Still add it, just without the image data
          objects[idx] = raw;
          loadCount++;
          if (loadCount === total) finishLoad();
        };
        img.src = raw.b64;
      } else {
        objects[idx] = raw;
        loadCount++;
        if (loadCount === total) finishLoad();
      }
    });

    function finishLoad() {
      // Remove any undefined gaps
      objects = objects.filter(Boolean);
      selected = null;
      render();
      document.getElementById('templateInfo').textContent = '✅ Loaded (' + objects.length + ' objects)';
    }
  });
}

// ═══════════════════════════════════════════════════════
// TEST TEMPLATE - preview with product images
// ═══════════════════════════════════════════════════════
async function testTemplate() {
  chrome.storage.local.get(['unicornds_last_product','unicornds_image_template'], async d => {
    const product = d.unicornds_last_product;
    const tmpl = d.unicornds_image_template;
    if (!tmpl) { alert('Save a template first!'); return; }

    const images = product?.images || [];
    if (!images.length) { alert('No product images. Scrape a product on AliExpress first.'); return; }

    document.getElementById('canvasWrap').style.display = 'none';
    document.getElementById('testView').style.display = '';

    const tc = document.getElementById('testCanvas');
    tc.width = DISP; tc.height = DISP;
    const tctx = tc.getContext('2d');

    // Render at display size
    tctx.clearRect(0, 0, DISP, DISP);
    tctx.fillStyle = '#fff';
    tctx.fillRect(0, 0, DISP, DISP);

    // Draw non-placeholder objects first (borders, banners go on top later)
    const banners = [];
    const imageObjs = [];
    for (const o of tmpl.objects) {
      if (o.type === 'placeholder') {
        // Load and draw product image into this placeholder
        const imgIdx = o.num - 1;
        if (imgIdx < images.length) {
          try {
            const img = await loadImg(images[imgIdx]);
            const x=o.x*SC, y=o.y*SC, w=o.w*SC, h=o.h*SC;
            tctx.save(); tctx.beginPath(); tctx.rect(x,y,w,h); tctx.clip();
            const ia=img.width/img.height, ba=w/h;
            let dw,dh,dx,dy;
            if(ia>ba){dh=h;dw=h*ia;dx=x+(w-dw)/2;dy=y;}else{dw=w;dh=w/ia;dx=x;dy=y+(h-dh)/2;}
            tctx.drawImage(img,dx,dy,dw,dh);
            tctx.restore();
          } catch(e) { console.warn('Failed to load image', imgIdx); }
        }
      } else if (o.type === 'banner') {
        banners.push(o);
      } else if (o.type === 'image' && o.b64) {
        imageObjs.push(o);
      }
    }

    // Draw uploaded images (logos, badges)
    console.log('[Designer] Drawing', imageObjs.length, 'uploaded images');
    for (const o of imageObjs) {
      try {
        console.log('[Designer] Loading image:', o.name, 'b64 length:', o.b64?.length || 0);
        const img = await loadB64Img(o.b64);
        const x=o.x*SC, y=o.y*SC, w=o.w*SC, h=o.h*SC;
        console.log('[Designer] Drawing image:', o.name, 'at', Math.round(x), Math.round(y), Math.round(w)+'x'+Math.round(h));
        tctx.save();
        tctx.globalAlpha = o.opacity ?? 1;
        tctx.drawImage(img, x, y, w, h);
        tctx.restore();
        console.log('[Designer] ✅ Image drawn:', o.name);
      } catch(e) { console.error('[Designer] ❌ Failed to draw uploaded image:', o.name, e); }
    }

    // Draw banners on top
    banners.forEach(o => {
      let text = o.text || '';
      if (text === '{{productTitle}}' && product) text = product.custom_title || product.title || '';
      const temp = {...o, text};
      drawObj(tctx, temp, SC);
    });

    // Border
    if (tmpl.borderCfg) {
      tctx.strokeStyle = tmpl.borderCfg.color;
      tctx.lineWidth = tmpl.borderCfg.thick * SC;
      tctx.strokeRect(0, 0, DISP, DISP);
    }
  });
}

function loadImg(url) {
  return new Promise((resolve, reject) => {
    if (url.startsWith('//')) url = 'https:' + url;
    // Use background to fetch (CORS)
    chrome.runtime.sendMessage({ type: 'url-to-b64', url }, resp => {
      if (!resp?.b64Image) return reject('no b64');
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject('load failed');
      img.src = resp.b64Image;
    });
  });
}

function loadB64Img(b64) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject('b64 load failed');
    img.src = b64;
  });
}

function downloadTest() {
  const tc = document.getElementById('testCanvas');
  // Re-render at full size
  const fc = document.createElement('canvas'); fc.width=SIZE; fc.height=SIZE;
  const fctx = fc.getContext('2d');
  // Copy test canvas scaled up
  fctx.drawImage(tc, 0, 0, SIZE, SIZE);
  const link = document.createElement('a');
  link.download = 'unicornds-template-test.png';
  link.href = fc.toDataURL('image/png');
  link.click();
}

// ═══════════════════════════════════════════════════════
// EXPORT PNG
// ═══════════════════════════════════════════════════════
function exportPNG() {
  const fc = document.createElement('canvas'); fc.width=SIZE; fc.height=SIZE;
  const fctx = fc.getContext('2d');
  fctx.fillStyle='#fff'; fctx.fillRect(0,0,SIZE,SIZE);
  objects.forEach(o => drawObj(fctx, o, 1));
  if(borderCfg){fctx.strokeStyle=borderCfg.color;fctx.lineWidth=borderCfg.thick;fctx.strokeRect(0,0,SIZE,SIZE);}
  const link = document.createElement('a');
  link.download = 'unicornds-template.png';
  link.href = fc.toDataURL('image/png');
  link.click();
}
