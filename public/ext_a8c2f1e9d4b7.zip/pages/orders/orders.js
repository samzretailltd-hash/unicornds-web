'use strict';
console.log('[UnicornDS] Order Manager v2.0 loaded');

let orders = [];
let currentFilter = 'all';
let dateRange = { from: null, to: null };
let activeOrderId = null;

// ═══════════════════════════════════════
// STORAGE
// ═══════════════════════════════════════
async function loadOrders() {
  return new Promise(resolve => {
    chrome.storage.local.get('unicornds_orders', data => {
      orders = data.unicornds_orders || [];
      resolve();
    });
  });
}

function saveOrders() {
  chrome.storage.local.set({ unicornds_orders: orders });
}

// ═══════════════════════════════════════
// DATE HELPERS
// ═══════════════════════════════════════
function parseOrderDate(o) {
  if (o.soldDateTs) return new Date(o.soldDateTs);
  if (o.soldDate) {
    // Try DD/MM/YYYY format
    const parts = o.soldDate.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (parts) return new Date(parts[3], parts[2] - 1, parts[1]);
    // Try standard date
    const d = new Date(o.soldDate);
    if (!isNaN(d.getTime())) return d;
  }
  return new Date(o.createdAt || Date.now());
}

function filterByDate(list) {
  if (!dateRange.from && !dateRange.to) return list;
  return list.filter(o => {
    const d = parseOrderDate(o);
    if (dateRange.from && d < dateRange.from) return false;
    if (dateRange.to) {
      const end = new Date(dateRange.to);
      end.setHours(23, 59, 59, 999);
      if (d > end) return false;
    }
    return true;
  });
}

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  await loadOrders();
  
  // Check for any unprocessed sync result (e.g. sync ran before page was open)
  await checkPendingSyncResult();
  
  // Default: last 30 days
  setDateRange(30);
  
  renderOrders();
  updateStats();
  updateSummary();

  document.getElementById('syncOrdersBtn').addEventListener('click', syncEbayOrders);
  document.getElementById('fetchEarningsBtn').addEventListener('click', fetchExactEarnings);
  document.getElementById('exportBtn').addEventListener('click', exportOrdersCSV);
  document.getElementById('importBtn').addEventListener('click', () => document.getElementById('importFile').click());
  document.getElementById('importFile').addEventListener('change', importOrdersCSV);
  document.getElementById('addManualBtn').addEventListener('click', () => {
    document.getElementById('manualDate').value = new Date().toISOString().split('T')[0];
    showModal('manualModal');
  });
  document.getElementById('cancelManualBtn').addEventListener('click', () => hideModal('manualModal'));
  document.getElementById('saveManualBtn').addEventListener('click', saveManualOrder);
  document.getElementById('cancelTrackingBtn').addEventListener('click', () => hideModal('trackingModal'));
  document.getElementById('saveTrackingBtn').addEventListener('click', saveTracking);
  document.getElementById('cancelCostBtn').addEventListener('click', () => hideModal('costModal'));
  document.getElementById('saveCostBtn').addEventListener('click', saveCost);

  // Filter buttons
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      renderOrders();
      updateStats();
      updateSummary();
    });
  });

  // Date range buttons
  document.querySelectorAll('.date-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const range = btn.dataset.range;
      if (range === 'all') {
        dateRange = { from: null, to: null };
      } else {
        setDateRange(parseInt(range));
      }
      renderOrders();
      updateStats();
      updateSummary();
    });
  });

  // Custom date apply
  document.getElementById('applyDateBtn').addEventListener('click', () => {
    const from = document.getElementById('dateFrom').value;
    const to = document.getElementById('dateTo').value;
    if (from) dateRange.from = new Date(from);
    if (to) dateRange.to = new Date(to);
    document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
    renderOrders();
    updateStats();
    updateSummary();
  });

  // Table action delegation
  document.getElementById('ordersBody').addEventListener('click', handleTableAction);

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.unicornds_orders) {
      orders = changes.unicornds_orders.newValue || [];
      renderOrders();
      updateStats();
      updateSummary();
    }
    // Also catch sync results that arrive while page is open but not actively polling
    if (changes.ebay_orders_sync_result && changes.ebay_orders_sync_result.newValue) {
      const result = changes.ebay_orders_sync_result.newValue;
      if (result.orders && result.orders.length > 0) {
        processSyncResult(result.orders);
        chrome.storage.local.remove('ebay_orders_sync_result');
      }
    }
  });
});

function setDateRange(days) {
  const from = new Date();
  from.setDate(from.getDate() - days);
  from.setHours(0, 0, 0, 0);
  dateRange = { from, to: new Date() };
}

// ═══════════════════════════════════════
// SYNC RESULT PROCESSING (shared by poll, page-load, and storage listener)
// ═══════════════════════════════════════
function processSyncResult(newOrders) {
  let addedCount = 0;
  let updatedCount = 0;
  const isOrderId = (name) => /^\d{2}-\d{5}-\d{5}$/.test(name);

  newOrders.forEach(order => {
    const existing = orders.find(o =>
      (o.ebayOrderId && o.ebayOrderId === order.ebayOrderId) ||
      (o.itemNumber && o.itemNumber === order.itemNumber && o.ebayOrderId === order.ebayOrderId)
    );
    if (existing) {
      let changed = false;
      if (order.buyerName && (!existing.buyerName || isOrderId(existing.buyerName))) {
        existing.buyerName = order.buyerName;
        changed = true;
      }
      if (order.buyerUsername && !existing.buyerUsername) { existing.buyerUsername = order.buyerUsername; changed = true; }
      if (order.sku && !existing.sku) { existing.sku = order.sku; changed = true; }
      if (order.variation && !existing.variation) { existing.variation = order.variation; changed = true; }
      if (order.postcode && !existing.postcode) { existing.postcode = order.postcode; changed = true; }
      if (order.quantity && !existing.quantity) { existing.quantity = order.quantity; changed = true; }
      if (order.image && !existing.image) { existing.image = order.image; changed = true; }
      if (order.estimatedEarnings && !existing.estimatedEarnings) { existing.estimatedEarnings = order.estimatedEarnings; changed = true; }
      if (order.estimatedFees && !existing.estimatedFees) { existing.estimatedFees = order.estimatedFees; changed = true; }
      if (order.orderUrl && !existing.orderUrl) { existing.orderUrl = order.orderUrl; changed = true; }
      if (order.promotedListing !== undefined) existing.promotedListing = order.promotedListing;
      if (order.repeatBuyer !== undefined) existing.repeatBuyer = order.repeatBuyer;
      if (order.soldDateTs && !existing.soldDateTs) { existing.soldDateTs = order.soldDateTs; changed = true; }
      if (changed) updatedCount++;
    } else {
      orders.unshift({
        id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        ...order,
        status: order.ebayStatus === 'delivered' ? 'completed' : 'pending',
        sourceCost: order.sourceCost || 0,
        trackingNumber: '',
        trackingCarrier: '',
        amazonOrderId: '',
        soldDateTs: parseOrderDate(order).getTime(),
        createdAt: Date.now(),
      });
      addedCount++;
    }
  });

  if (addedCount > 0 || updatedCount > 0) {
    saveOrders();
  }
  renderOrders();
  updateStats();
  updateSummary();

  console.log('[UnicornDS] Sync merged:', addedCount, 'new,', updatedCount, 'updated, total:', orders.length);
  return { addedCount, updatedCount };
}

async function checkPendingSyncResult() {
  return new Promise(resolve => {
    chrome.storage.local.get('ebay_orders_sync_result', data => {
      const result = data.ebay_orders_sync_result;
      if (result && result.orders && result.orders.length > 0) {
        console.log('[UnicornDS] Found pending sync result:', result.orders.length, 'orders');
        processSyncResult(result.orders);
        chrome.storage.local.remove('ebay_orders_sync_result');
      }
      resolve();
    });
  });
}

// ═══════════════════════════════════════
// SYNC EBAY ORDERS
// ═══════════════════════════════════════
async function syncEbayOrders() {
  const btn = document.getElementById('syncOrdersBtn');
  btn.textContent = '🔄 Syncing...';
  btn.disabled = true;

  try {
    const { unicornds_ebay_domain } = await new Promise(r =>
      chrome.storage.local.get('unicornds_ebay_domain', r));
    const domain = unicornds_ebay_domain || 'co.uk';

    chrome.runtime.sendMessage({
      type: 'sync_ebay_orders',
      domain: domain,
    });

    // Poll for results (multi-page sync can take up to 2 min)
    const startTime = Date.now();
    let dotCount = 0;
    const pollInterval = setInterval(() => {
      if (Date.now() - startTime > 120000) {
        clearInterval(pollInterval);
        btn.textContent = '❌ Timeout — try again';
        btn.disabled = false;
        setTimeout(() => { btn.textContent = '🔄 Sync eBay Orders'; }, 3000);
        return;
      }
      // Animate the syncing text
      dotCount = (dotCount + 1) % 4;
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      btn.textContent = '🔄 Syncing' + '.'.repeat(dotCount + 1) + ` (${elapsed}s)`;
      
      chrome.storage.local.get('ebay_orders_sync_result', data => {
        const result = data.ebay_orders_sync_result;
        if (result && result.syncedAt > startTime) {
          clearInterval(pollInterval);
          chrome.storage.local.remove('ebay_orders_sync_result');

          const { addedCount, updatedCount } = processSyncResult(result.orders || []);

          let msg = '';
          if (addedCount > 0 && updatedCount > 0) msg = `✅ ${addedCount} new, ${updatedCount} updated`;
          else if (addedCount > 0) msg = `✅ ${addedCount} new orders`;
          else if (updatedCount > 0) msg = `✅ ${updatedCount} orders updated`;
          else msg = '✅ All up to date';
          btn.textContent = msg;
          setTimeout(() => {
            btn.textContent = '🔄 Sync eBay Orders';
            btn.disabled = false;
          }, 3000);
        }
      });
    }, 1000);
  } catch (err) {
    console.error('[UnicornDS] Sync error:', err);
    btn.textContent = '🔄 Sync eBay Orders';
    btn.disabled = false;
  }
}

// ═══════════════════════════════════════
// FETCH EXACT EARNINGS
// ═══════════════════════════════════════
async function fetchExactEarnings() {
  const btn = document.getElementById('fetchEarningsBtn');

  // If already fetching, send stop signal
  if (btn.dataset.fetching === 'true') {
    chrome.runtime.sendMessage({ type: 'fetch_exact_earnings', action: 'stop' });
    btn.textContent = '⏹ Stopping...';
    btn.dataset.fetching = 'false';
    return;
  }

  const needCount = orders.filter(o => o.ebayOrderId && !o.ebayEarnings && !o.detailScraped).length;

  if (needCount === 0) {
    btn.textContent = '✅ All earnings fetched';
    setTimeout(() => { btn.textContent = '📊 Fetch Exact Earnings'; }, 3000);
    return;
  }

  btn.textContent = `⏹ Stop (0/${Math.min(needCount, 30)})`;
  btn.dataset.fetching = 'true';

  const { unicornds_ebay_domain } = await new Promise(r =>
    chrome.storage.local.get('unicornds_ebay_domain', r));

  chrome.runtime.sendMessage({
    type: 'fetch_exact_earnings',
    domain: unicornds_ebay_domain || 'co.uk',
    limit: 30,
  });

  // Poll for progress
  const startTime = Date.now();
  const pollInterval = setInterval(() => {
    if (Date.now() - startTime > 600000) {
      clearInterval(pollInterval);
      btn.textContent = '📊 Fetch Exact Earnings';
      btn.dataset.fetching = 'false';
      return;
    }

    chrome.storage.local.get('earnings_fetch_progress', data => {
      const p = data.earnings_fetch_progress;
      if (!p) return;

      if (p.complete && p.syncedAt > startTime) {
        clearInterval(pollInterval);
        chrome.storage.local.remove('earnings_fetch_progress');
        btn.textContent = p.done > 0 ? `✅ ${p.done} orders updated` : '✅ All done';
        btn.dataset.fetching = 'false';
        setTimeout(() => { btn.textContent = '📊 Fetch Exact Earnings'; }, 4000);
        loadOrders().then(() => {
          renderOrders();
          updateStats();
          updateSummary();
        });
      } else if (!p.complete) {
        btn.textContent = `⏹ Stop (${p.done}/${p.total})`;
      }
    });
  }, 2000);
}

// ═══════════════════════════════════════
// EXPORT ORDERS TO CSV (opens in Excel)
// ═══════════════════════════════════════
function exportOrdersCSV() {
  const filtered = filterByDate(orders);
  if (!filtered.length) {
    alert('No orders to export');
    return;
  }

  const headers = [
    'Date', 'Buyer Name', 'Buyer Username', 'Item Title', 'eBay Order ID',
    'Item Number', 'SKU', 'Sold Price', 'Earnings', 'Estimated Earnings',
    'Source Cost', 'Profit', 'Status', 'eBay Status', 'Tracking Number',
    'Carrier', 'Amazon Order ID', 'Source URL', 'Variation', 'Postcode',
    'Quantity', 'Promoted Listing', 'Repeat Buyer'
  ];

  const rows = filtered.map(o => {
    const earnings = o.ebayEarnings || o.estimatedEarnings || 0;
    const profit = (earnings && o.sourceCost) ? (earnings - o.sourceCost) : 0;
    const d = parseOrderDate(o);
    const date = d.toLocaleDateString('en-GB');

    return [
      date,
      o.buyerName || '',
      o.buyerUsername || '',
      o.itemTitle || '',
      o.ebayOrderId || '',
      o.itemNumber || '',
      o.sku || '',
      (o.soldPrice || 0).toFixed(2),
      (o.ebayEarnings || 0).toFixed(2),
      (o.estimatedEarnings || 0).toFixed(2),
      (o.sourceCost || 0).toFixed(2),
      profit.toFixed(2),
      o.status || 'pending',
      o.ebayStatus || '',
      o.trackingNumber || '',
      o.trackingCarrier || '',
      o.amazonOrderId || '',
      o.sourceUrl || '',
      o.variation || '',
      o.postcode || '',
      o.quantity || 1,
      o.promotedListing ? 'Yes' : 'No',
      o.repeatBuyer ? 'Yes' : 'No'
    ];
  });

  // BOM for Excel UTF-8 support + CSV content
  const csvContent = '\uFEFF' + [headers, ...rows]
    .map(row => row.map(cell => {
      const str = String(cell);
      // Escape cells with commas, quotes, or newlines
      return str.includes(',') || str.includes('"') || str.includes('\n')
        ? '"' + str.replace(/"/g, '""') + '"'
        : str;
    }).join(','))
    .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStr = new Date().toISOString().split('T')[0];
  a.href = url;
  a.download = `UnicornDS_Orders_${dateStr}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ═══════════════════════════════════════
// IMPORT ORDERS FROM CSV
// ═══════════════════════════════════════
function importOrdersCSV(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(event) {
    try {
      const text = event.target.result;
      const lines = text.split(/\r?\n/).filter(line => line.trim());
      if (lines.length < 2) {
        alert('File is empty or has no data rows');
        return;
      }

      // Parse header row
      const headers = parseCSVLine(lines[0]).map(h => h.trim().toLowerCase());

      // Map header names to our fields
      const colMap = {};
      const mappings = {
        'date': 'soldDate', 'sold date': 'soldDate',
        'buyer name': 'buyerName', 'buyer': 'buyerName',
        'buyer username': 'buyerUsername', 'username': 'buyerUsername',
        'item title': 'itemTitle', 'item': 'itemTitle', 'title': 'itemTitle', 'product': 'itemTitle',
        'ebay order id': 'ebayOrderId', 'order id': 'ebayOrderId', 'order number': 'ebayOrderId',
        'item number': 'itemNumber', 'item id': 'itemNumber',
        'sku': 'sku',
        'sold price': 'soldPrice', 'price': 'soldPrice', 'sold': 'soldPrice', 'sale price': 'soldPrice',
        'earnings': 'ebayEarnings',
        'estimated earnings': 'estimatedEarnings',
        'source cost': 'sourceCost', 'cost': 'sourceCost', 'product cost': 'sourceCost',
        'status': 'status',
        'ebay status': 'ebayStatus',
        'tracking number': 'trackingNumber', 'tracking': 'trackingNumber',
        'carrier': 'trackingCarrier',
        'amazon order id': 'amazonOrderId',
        'source url': 'sourceUrl', 'source link': 'sourceUrl', 'url': 'sourceUrl',
        'variation': 'variation',
        'postcode': 'postcode', 'post code': 'postcode', 'zip': 'postcode',
        'quantity': 'quantity', 'qty': 'quantity',
      };

      headers.forEach((h, i) => {
        if (mappings[h]) colMap[i] = mappings[h];
      });

      if (!colMap || Object.keys(colMap).length === 0) {
        alert('Could not recognise column headers. Use the exported CSV as a template.');
        return;
      }

      // Parse data rows
      let addedCount = 0;
      let skippedCount = 0;

      for (let i = 1; i < lines.length; i++) {
        const cells = parseCSVLine(lines[i]);
        if (cells.length < 3) continue;

        const row = {};
        Object.entries(colMap).forEach(([idx, field]) => {
          row[field] = (cells[parseInt(idx)] || '').trim();
        });

        // Must have at least an item title
        if (!row.itemTitle) { skippedCount++; continue; }

        // Parse numeric fields
        const soldPrice = parseFloat(row.soldPrice) || 0;
        const sourceCost = parseFloat(row.sourceCost) || 0;
        const ebayEarnings = parseFloat(row.ebayEarnings) || 0;
        const quantity = parseInt(row.quantity) || 1;

        // Check for duplicate
        const isDupe = orders.some(o =>
          (row.ebayOrderId && o.ebayOrderId === row.ebayOrderId) ||
          (o.itemTitle === row.itemTitle && o.buyerName === row.buyerName &&
           Math.abs((o.soldPrice || 0) - soldPrice) < 0.01)
        );
        if (isDupe) { skippedCount++; continue; }

        // Parse date
        let soldDateTs = Date.now();
        if (row.soldDate) {
          // Try DD/MM/YYYY
          const dmy = row.soldDate.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
          if (dmy) soldDateTs = new Date(dmy[3], dmy[2] - 1, dmy[1]).getTime();
          else {
            const d = new Date(row.soldDate);
            if (!isNaN(d.getTime())) soldDateTs = d.getTime();
          }
        }

        // Map status
        let status = 'pending';
        const st = (row.status || '').toLowerCase();
        if (['completed', 'delivered'].includes(st)) status = 'completed';
        else if (['shipped', 'dispatched'].includes(st)) status = 'shipped';
        else if (['ordered'].includes(st)) status = 'ordered';

        orders.unshift({
          id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
          buyerName: row.buyerName || '',
          buyerUsername: row.buyerUsername || '',
          itemTitle: row.itemTitle,
          ebayOrderId: row.ebayOrderId || '',
          itemNumber: row.itemNumber || '',
          sku: row.sku || '',
          soldPrice,
          ebayEarnings: ebayEarnings || undefined,
          sourceCost,
          status,
          ebayStatus: row.ebayStatus || '',
          trackingNumber: row.trackingNumber || '',
          trackingCarrier: row.trackingCarrier || '',
          amazonOrderId: row.amazonOrderId || '',
          sourceUrl: row.sourceUrl || '',
          variation: row.variation || '',
          postcode: row.postcode || '',
          quantity,
          soldDate: row.soldDate || new Date().toLocaleDateString('en-GB'),
          soldDateTs,
          createdAt: Date.now(),
          importedFrom: 'csv',
        });
        addedCount++;
      }

      if (addedCount > 0) {
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
      }

      alert(`Import complete: ${addedCount} orders added, ${skippedCount} skipped (duplicates or empty)`);
    } catch (err) {
      console.error('[UnicornDS] Import error:', err);
      alert('Error importing file: ' + err.message);
    }
  };

  reader.readAsText(file);
  // Reset file input so same file can be re-imported
  e.target.value = '';
}

// CSV line parser (handles quoted fields with commas)
function parseCSVLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"' && line[i + 1] === '"') {
        current += '"';
        i++;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        current += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        result.push(current);
        current = '';
      } else {
        current += ch;
      }
    }
  }
  result.push(current);
  return result;
}

// ═══════════════════════════════════════
// RENDER
// ═══════════════════════════════════════
function renderOrders() {
  const tbody = document.getElementById('ordersBody');
  const empty = document.getElementById('emptyState');

  let filtered = currentFilter === 'all'
    ? orders
    : orders.filter(o => o.status === currentFilter);
  
  // Apply date filter
  filtered = filterByDate(filtered);

  // Sort by date (newest first)
  filtered.sort((a, b) => (b.soldDateTs || b.createdAt || 0) - (a.soldDateTs || a.createdAt || 0));

  if (!filtered.length) {
    tbody.innerHTML = '';
    empty.style.display = 'block';
    document.getElementById('monthlySummary').style.display = 'none';
    return;
  }
  empty.style.display = 'none';
  document.getElementById('monthlySummary').style.display = 'grid';

  tbody.innerHTML = filtered.map(o => {
    // Calculate profit: use eBay earnings (after fees) > estimated earnings > sold price
    const earningsValue = o.ebayEarnings || o.estimatedEarnings || 0;
    const profit = (earningsValue && o.sourceCost)
      ? (earningsValue - o.sourceCost).toFixed(2)
      : null;
    const profitClass = profit === null ? 'profit-unknown'
      : parseFloat(profit) >= 0 ? 'profit-positive' : 'profit-negative';
    const profitText = profit === null ? '-' : (parseFloat(profit) >= 0 ? '+£' : '-£') + Math.abs(parseFloat(profit)).toFixed(2);

    const d = parseOrderDate(o);
    const date = d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
    const statusClass = 'status-' + (o.status || 'pending');

    // Cost cell — clickable to edit
    const costText = o.sourceCost ? '£' + o.sourceCost.toFixed(2) : '<span class="add-cost">+ add</span>';

    // Earnings cell — shows real earnings, then estimated, then nothing
    let earningsText;
    if (o.ebayEarnings) {
      earningsText = '£' + o.ebayEarnings.toFixed(2);
    } else if (o.estimatedEarnings) {
      earningsText = '<span title="Estimated (12.8% FVF + £0.30)">~£' + o.estimatedEarnings.toFixed(2) + '</span>';
    } else {
      earningsText = '<span class="no-data">—</span>';
    }

    let actions = '';
    const ebayLink = o.orderUrl || (o.ebayOrderId ? `https://www.ebay.co.uk/sh/ord/details?orderid=${o.ebayOrderId}` : '');
    switch (o.status) {
      case 'pending':
        actions = `
          <button class="btn btn-sm btn-warning" data-action="fulfill" data-id="${o.id}" title="Order from supplier">🛒</button>
          <button class="btn btn-sm btn-secondary" data-action="tracking" data-id="${o.id}" title="Add tracking">📦</button>
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}" title="Delete">✕</button>`;
        break;
      case 'ordered':
        actions = `
          <button class="btn btn-sm btn-success" data-action="tracking" data-id="${o.id}" title="Add tracking">📦 Track</button>
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}" title="Delete">✕</button>`;
        break;
      case 'shipped':
        actions = `
          <button class="btn btn-sm btn-secondary" data-action="complete" data-id="${o.id}" title="Mark complete">✅</button>
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <span style="font-size:10px;color:#10B981">${o.trackingNumber || ''}</span>`;
        break;
      case 'completed':
        actions = `
          ${ebayLink ? `<a href="${ebayLink}" target="_blank" class="btn btn-sm btn-info" title="View on eBay">👁</a>` : ''}
          <span style="font-size:10px;color:#6B7280">${o.trackingNumber || '✅'}</span>`;
        break;
    }

    const titleShort = (o.itemTitle || 'Unknown').length > 50
      ? (o.itemTitle || '').substring(0, 50) + '...'
      : (o.itemTitle || 'Unknown');

    return `<tr>
      <td>${date}</td>
      <td>${(o.buyerName && !/^\d{2}-\d{5}-\d{5}$/.test(o.buyerName)) ? o.buyerName : (o.buyerUsername || '-')}</td>
      <td title="${(o.itemTitle || '').replace(/"/g, '&quot;')}">${titleShort}</td>
      <td>£${(o.soldPrice || 0).toFixed(2)}</td>
      <td class="${o.ebayEarnings ? 'earnings-value' : ''}">${earningsText}</td>
      <td class="cost-cell" data-action="editCost" data-id="${o.id}">${costText}</td>
      <td class="${profitClass}">${profitText}</td>
      <td><span class="status-badge ${statusClass}">${(o.status || 'pending').toUpperCase()}</span></td>
      <td><div class="actions-cell">${actions}</div></td>
    </tr>`;
  }).join('');
}

// ═══════════════════════════════════════
// MONTHLY SUMMARY
// ═══════════════════════════════════════
function updateSummary() {
  let filtered = currentFilter === 'all' ? orders : orders.filter(o => o.status === currentFilter);
  filtered = filterByDate(filtered);

  const revenue = filtered.reduce((s, o) => s + (o.soldPrice || 0), 0);
  const totalEarnings = filtered.reduce((s, o) => s + (o.ebayEarnings || o.estimatedEarnings || o.soldPrice || 0), 0);
  const totalFees = filtered.reduce((s, o) => s + (o.totalFees || o.estimatedFees || 0), 0);
  const cost = filtered.reduce((s, o) => s + (o.sourceCost || 0), 0);
  const profit = totalEarnings - cost;
  const count = filtered.length;
  const avg = count > 0 ? profit / count : 0;

  document.getElementById('summaryRevenue').textContent = '£' + revenue.toFixed(2);
  document.getElementById('summaryCost').textContent = '£' + cost.toFixed(2);
  document.getElementById('summaryProfit').textContent = (profit >= 0 ? '£' : '-£') + Math.abs(profit).toFixed(2);
  document.getElementById('summaryProfit').className = 'summary-value ' + (profit >= 0 ? 'profit' : 'loss');
  document.getElementById('summaryCount').textContent = count;
  document.getElementById('summaryAvg').textContent = '£' + avg.toFixed(2);
}

// ═══════════════════════════════════════
// ACTIONS
// ═══════════════════════════════════════
function handleTableAction(e) {
  const el = e.target.closest('[data-action]');
  if (!el) return;

  const action = el.dataset.action;
  const orderId = el.dataset.id;
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  switch (action) {
    case 'fulfill':
      fulfillOrder(order);
      break;
    case 'tracking':
      activeOrderId = orderId;
      document.getElementById('trackingNumber').value = order.trackingNumber || '';
      document.getElementById('amazonOrderId').value = order.amazonOrderId || '';
      showModal('trackingModal');
      break;
    case 'complete':
      order.status = 'completed';
      order.completedAt = Date.now();
      saveOrders();
      renderOrders();
      updateStats();
      updateSummary();
      break;
    case 'delete':
      if (confirm('Delete this order?')) {
        orders = orders.filter(o => o.id !== orderId);
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
      }
      break;
    case 'editCost':
      activeOrderId = orderId;
      document.getElementById('editCostInput').value = order.sourceCost || '';
      document.getElementById('editSourceUrl').value = order.sourceUrl || '';
      showModal('costModal');
      break;
  }
}

function fulfillOrder(order) {
  // Try to find source URL from SKU
  let url = order.sourceUrl || '';
  
  if (!url && order.sku) {
    // Parse SKU to find source product
    // SKU formats: UDS-AE-{aliexpressId}, UDS-AMZ-{asin}, ALI-{id}-{date}
    const sku = order.sku;
    if (sku.includes('AE-') || sku.includes('ALI-') || sku.includes('ali-')) {
      // AliExpress product
      const aliMatch = sku.match(/(?:AE-|ALI-)(\d+)/i);
      if (aliMatch) {
        url = `https://www.aliexpress.com/item/${aliMatch[1]}.html`;
      }
    } else if (sku.includes('AMZ-') || sku.includes('amz-')) {
      // Amazon product
      const amzMatch = sku.match(/(?:AMZ-)([A-Z0-9]+)/i);
      if (amzMatch) {
        chrome.storage.local.get('hunter_domain', s => {
          const domain = s.hunter_domain || 'co.uk';
          chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/dp/${amzMatch[1]}` });
        });
        order.status = 'ordered';
        order.orderedAt = Date.now();
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
        return;
      }
    }
  }
  
  // Try matching with listed products by item number
  if (!url && order.itemNumber) {
    chrome.storage.local.get('unicornds_listed_products', data => {
      const listed = (data.unicornds_listed_products || {})[order.itemNumber];
      if (listed && listed.sourceUrl) {
        chrome.runtime.sendMessage({ type: 'openNewTab', url: listed.sourceUrl });
      } else if (order.itemTitle) {
        // Search Amazon as last resort
        chrome.storage.local.get('hunter_domain', s => {
          const domain = s.hunter_domain || 'co.uk';
          const query = encodeURIComponent(order.itemTitle.substring(0, 80));
          chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/s?k=${query}` });
        });
      }
    });
    order.status = 'ordered';
    order.orderedAt = Date.now();
    saveOrders();
    renderOrders();
    updateStats();
    updateSummary();
    return;
  }

  if (url) {
    chrome.runtime.sendMessage({ type: 'openNewTab', url });
  } else if (order.itemTitle) {
    chrome.storage.local.get('hunter_domain', s => {
      const domain = s.hunter_domain || 'co.uk';
      const query = encodeURIComponent(order.itemTitle.substring(0, 80));
      chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/s?k=${query}` });
    });
  }

  order.status = 'ordered';
  order.orderedAt = Date.now();
  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
}

function saveCost() {
  const order = orders.find(o => o.id === activeOrderId);
  if (!order) return;

  const cost = parseFloat(document.getElementById('editCostInput').value) || 0;
  const url = document.getElementById('editSourceUrl').value.trim();

  order.sourceCost = cost;
  if (url) order.sourceUrl = url;

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('costModal');
}

function saveTracking() {
  const order = orders.find(o => o.id === activeOrderId);
  if (!order) return;

  const tracking = document.getElementById('trackingNumber').value.trim();
  const carrier = document.getElementById('trackingCarrier').value;
  const amazonId = document.getElementById('amazonOrderId').value.trim();

  if (!tracking) { alert('Enter a tracking number'); return; }

  order.trackingNumber = tracking;
  order.trackingCarrier = carrier;
  order.amazonOrderId = amazonId;
  order.status = 'shipped';
  order.shippedAt = Date.now();

  if (order.ebayOrderId || order.itemNumber) {
    chrome.runtime.sendMessage({
      type: 'upload_tracking_to_ebay',
      orderId: order.ebayOrderId,
      itemNumber: order.itemNumber,
      trackingNumber: tracking,
      carrier: carrier,
    });
  }

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('trackingModal');
}

// ═══════════════════════════════════════
// MANUAL ORDER
// ═══════════════════════════════════════
function saveManualOrder() {
  const buyer = document.getElementById('manualBuyer').value.trim();
  const title = document.getElementById('manualTitle').value.trim();
  const itemNumber = document.getElementById('manualItemNumber').value.trim();
  const soldPrice = parseFloat(document.getElementById('manualSoldPrice').value) || 0;
  const cost = parseFloat(document.getElementById('manualCost').value) || 0;
  const sourceUrl = document.getElementById('manualSourceUrl').value.trim();
  const dateVal = document.getElementById('manualDate').value;

  if (!title) { alert('Enter an item title'); return; }

  const soldDate = dateVal ? new Date(dateVal) : new Date();

  orders.unshift({
    id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    buyerName: buyer || 'Manual',
    itemTitle: title,
    itemNumber: itemNumber,
    soldPrice: soldPrice,
    sourceCost: cost,
    sourceUrl: sourceUrl,
    status: 'pending',
    trackingNumber: '',
    trackingCarrier: '',
    amazonOrderId: '',
    soldDate: soldDate.toLocaleDateString('en-GB'),
    soldDateTs: soldDate.getTime(),
    createdAt: Date.now(),
  });

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('manualModal');

  ['manualBuyer', 'manualTitle', 'manualItemNumber', 'manualSoldPrice', 'manualCost', 'manualSourceUrl']
    .forEach(id => document.getElementById(id).value = '');
}

// ═══════════════════════════════════════
// STATS
// ═══════════════════════════════════════
function updateStats() {
  const filtered = filterByDate(orders);
  document.getElementById('pendingCount').textContent = filtered.filter(o => o.status === 'pending').length;
  document.getElementById('orderedCount').textContent = filtered.filter(o => o.status === 'ordered').length;
  document.getElementById('shippedCount').textContent = filtered.filter(o => o.status === 'shipped').length;
  document.getElementById('completedCount').textContent = filtered.filter(o => o.status === 'completed').length;

  const totalProfit = filtered
    .filter(o => (o.ebayEarnings || o.estimatedEarnings || o.soldPrice) && o.sourceCost)
    .reduce((sum, o) => sum + ((o.ebayEarnings || o.estimatedEarnings || o.soldPrice) - o.sourceCost), 0);
  document.getElementById('totalProfit').textContent = '£' + totalProfit.toFixed(2);
}

// ═══════════════════════════════════════
// MODAL
// ═══════════════════════════════════════
function showModal(id) { document.getElementById(id).style.display = 'flex'; }
function hideModal(id) { document.getElementById(id).style.display = 'none'; }
