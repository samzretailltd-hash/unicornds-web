'use strict';
console.log('[UnicornDS] Order Manager v2.0 loaded');

let orders = [];
let currentFilter = 'all';
let dateRange = { from: null, to: null };
let activeOrderId = null;

// ═══════════════════════════════════════
// STORAGE
// ═══════════════════════════════════════
async function loadOrders() {
  return new Promise(resolve => {
    chrome.storage.local.get('unicornds_orders', data => {
      orders = data.unicornds_orders || [];
      resolve();
    });
  });
}

function saveOrders() {
  chrome.storage.local.set({ unicornds_orders: orders });
}

// ═══════════════════════════════════════
// DATE HELPERS
// ═══════════════════════════════════════
function parseOrderDate(o) {
  if (o.soldDateTs) return new Date(o.soldDateTs);
  if (o.soldDate) {
    // Try DD/MM/YYYY format
    const parts = o.soldDate.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (parts) return new Date(parts[3], parts[2] - 1, parts[1]);
    // Try standard date
    const d = new Date(o.soldDate);
    if (!isNaN(d.getTime())) return d;
  }
  return new Date(o.createdAt || Date.now());
}

function filterByDate(list) {
  if (!dateRange.from && !dateRange.to) return list;
  return list.filter(o => {
    const d = parseOrderDate(o);
    if (dateRange.from && d < dateRange.from) return false;
    if (dateRange.to) {
      const end = new Date(dateRange.to);
      end.setHours(23, 59, 59, 999);
      if (d > end) return false;
    }
    return true;
  });
}

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  await loadOrders();
  
  // Default: last 30 days
  setDateRange(30);
  
  renderOrders();
  updateStats();
  updateSummary();

  document.getElementById('syncOrdersBtn').addEventListener('click', syncEbayOrders);
  document.getElementById('addManualBtn').addEventListener('click', () => {
    document.getElementById('manualDate').value = new Date().toISOString().split('T')[0];
    showModal('manualModal');
  });
  document.getElementById('cancelManualBtn').addEventListener('click', () => hideModal('manualModal'));
  document.getElementById('saveManualBtn').addEventListener('click', saveManualOrder);
  document.getElementById('cancelTrackingBtn').addEventListener('click', () => hideModal('trackingModal'));
  document.getElementById('saveTrackingBtn').addEventListener('click', saveTracking);
  document.getElementById('cancelCostBtn').addEventListener('click', () => hideModal('costModal'));
  document.getElementById('saveCostBtn').addEventListener('click', saveCost);

  // Filter buttons
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      renderOrders();
      updateStats();
      updateSummary();
    });
  });

  // Date range buttons
  document.querySelectorAll('.date-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const range = btn.dataset.range;
      if (range === 'all') {
        dateRange = { from: null, to: null };
      } else {
        setDateRange(parseInt(range));
      }
      renderOrders();
      updateStats();
      updateSummary();
    });
  });

  // Custom date apply
  document.getElementById('applyDateBtn').addEventListener('click', () => {
    const from = document.getElementById('dateFrom').value;
    const to = document.getElementById('dateTo').value;
    if (from) dateRange.from = new Date(from);
    if (to) dateRange.to = new Date(to);
    document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
    renderOrders();
    updateStats();
    updateSummary();
  });

  // Table action delegation
  document.getElementById('ordersBody').addEventListener('click', handleTableAction);

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.unicornds_orders) {
      orders = changes.unicornds_orders.newValue || [];
      renderOrders();
      updateStats();
      updateSummary();
    }
  });
});

function setDateRange(days) {
  const from = new Date();
  from.setDate(from.getDate() - days);
  from.setHours(0, 0, 0, 0);
  dateRange = { from, to: new Date() };
}

// ═══════════════════════════════════════
// SYNC EBAY ORDERS
// ═══════════════════════════════════════
async function syncEbayOrders() {
  const btn = document.getElementById('syncOrdersBtn');
  btn.textContent = '🔄 Syncing...';
  btn.disabled = true;

  try {
    const { unicornds_ebay_domain } = await new Promise(r =>
      chrome.storage.local.get('unicornds_ebay_domain', r));
    const domain = unicornds_ebay_domain || 'co.uk';

    chrome.runtime.sendMessage({
      type: 'sync_ebay_orders',
      domain: domain,
    });

    // Poll for results
    const startTime = Date.now();
    const pollInterval = setInterval(() => {
      if (Date.now() - startTime > 35000) {
        clearInterval(pollInterval);
        btn.textContent = '❌ Timeout — try again';
        btn.disabled = false;
        setTimeout(() => { btn.textContent = '🔄 Sync eBay Orders'; }, 3000);
        return;
      }
      chrome.storage.local.get('ebay_orders_sync_result', data => {
        const result = data.ebay_orders_sync_result;
        if (result && result.syncedAt > startTime) {
          clearInterval(pollInterval);
          chrome.storage.local.remove('ebay_orders_sync_result');

          const newOrders = result.orders || [];
          let addedCount = 0;

          newOrders.forEach(order => {
            const exists = orders.some(o =>
              (o.ebayOrderId && o.ebayOrderId === order.ebayOrderId) ||
              (o.itemNumber && o.itemNumber === order.itemNumber && o.buyerName === order.buyerName)
            );
            if (!exists) {
              orders.unshift({
                id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
                ...order,
                status: order.ebayStatus === 'delivered' ? 'completed' : 'pending',
                sourceCost: order.sourceCost || 0,
                trackingNumber: '',
                trackingCarrier: '',
                amazonOrderId: '',
                soldDateTs: parseOrderDate(order).getTime(),
                createdAt: Date.now(),
              });
              addedCount++;
            }
          });

          if (addedCount > 0) {
            saveOrders();
          }
          renderOrders();
          updateStats();
          updateSummary();

          btn.textContent = addedCount > 0 ? `✅ ${addedCount} new orders` : '✅ All up to date';
          setTimeout(() => {
            btn.textContent = '🔄 Sync eBay Orders';
            btn.disabled = false;
          }, 3000);
        }
      });
    }, 1000);
  } catch (err) {
    console.error('[UnicornDS] Sync error:', err);
    btn.textContent = '🔄 Sync eBay Orders';
    btn.disabled = false;
  }
}

// ═══════════════════════════════════════
// RENDER
// ═══════════════════════════════════════
function renderOrders() {
  const tbody = document.getElementById('ordersBody');
  const empty = document.getElementById('emptyState');

  let filtered = currentFilter === 'all'
    ? orders
    : orders.filter(o => o.status === currentFilter);
  
  // Apply date filter
  filtered = filterByDate(filtered);

  // Sort by date (newest first)
  filtered.sort((a, b) => (b.soldDateTs || b.createdAt || 0) - (a.soldDateTs || a.createdAt || 0));

  if (!filtered.length) {
    tbody.innerHTML = '';
    empty.style.display = 'block';
    document.getElementById('monthlySummary').style.display = 'none';
    return;
  }
  empty.style.display = 'none';
  document.getElementById('monthlySummary').style.display = 'grid';

  tbody.innerHTML = filtered.map(o => {
    const profit = (o.soldPrice && o.sourceCost)
      ? (o.soldPrice - o.sourceCost).toFixed(2)
      : null;
    const profitClass = profit === null ? 'profit-unknown'
      : parseFloat(profit) >= 0 ? 'profit-positive' : 'profit-negative';
    const profitText = profit === null ? '-' : (parseFloat(profit) >= 0 ? '+£' : '-£') + Math.abs(parseFloat(profit)).toFixed(2);

    const d = parseOrderDate(o);
    const date = d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
    const statusClass = 'status-' + (o.status || 'pending');

    // Cost cell — clickable to edit
    const costText = o.sourceCost ? '£' + o.sourceCost.toFixed(2) : '<span class="add-cost">+ add</span>';

    let actions = '';
    switch (o.status) {
      case 'pending':
        actions = `
          <button class="btn btn-sm btn-warning" data-action="fulfill" data-id="${o.id}">🛒</button>
          <button class="btn btn-sm btn-secondary" data-action="tracking" data-id="${o.id}">📦</button>
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}">✕</button>`;
        break;
      case 'ordered':
        actions = `
          <button class="btn btn-sm btn-success" data-action="tracking" data-id="${o.id}">📦 Track</button>
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}">✕</button>`;
        break;
      case 'shipped':
        actions = `
          <button class="btn btn-sm btn-secondary" data-action="complete" data-id="${o.id}">✅</button>
          <span style="font-size:10px;color:#10B981">${o.trackingNumber || ''}</span>`;
        break;
      case 'completed':
        actions = `<span style="font-size:10px;color:#6B7280">${o.trackingNumber || '✅'}</span>`;
        break;
    }

    const titleShort = (o.itemTitle || 'Unknown').length > 50
      ? (o.itemTitle || '').substring(0, 50) + '...'
      : (o.itemTitle || 'Unknown');

    return `<tr>
      <td>${date}</td>
      <td>${o.buyerName || '-'}</td>
      <td title="${(o.itemTitle || '').replace(/"/g, '&quot;')}">${titleShort}</td>
      <td>£${(o.soldPrice || 0).toFixed(2)}</td>
      <td class="cost-cell" data-action="editCost" data-id="${o.id}">${costText}</td>
      <td class="${profitClass}">${profitText}</td>
      <td><span class="status-badge ${statusClass}">${(o.status || 'pending').toUpperCase()}</span></td>
      <td><div class="actions-cell">${actions}</div></td>
    </tr>`;
  }).join('');
}

// ═══════════════════════════════════════
// MONTHLY SUMMARY
// ═══════════════════════════════════════
function updateSummary() {
  let filtered = currentFilter === 'all' ? orders : orders.filter(o => o.status === currentFilter);
  filtered = filterByDate(filtered);

  const revenue = filtered.reduce((s, o) => s + (o.soldPrice || 0), 0);
  const cost = filtered.reduce((s, o) => s + (o.sourceCost || 0), 0);
  const profit = revenue - cost;
  const count = filtered.length;
  const avg = count > 0 ? profit / count : 0;

  document.getElementById('summaryRevenue').textContent = '£' + revenue.toFixed(2);
  document.getElementById('summaryCost').textContent = '£' + cost.toFixed(2);
  document.getElementById('summaryProfit').textContent = (profit >= 0 ? '£' : '-£') + Math.abs(profit).toFixed(2);
  document.getElementById('summaryProfit').className = 'summary-value ' + (profit >= 0 ? 'profit' : 'loss');
  document.getElementById('summaryCount').textContent = count;
  document.getElementById('summaryAvg').textContent = '£' + avg.toFixed(2);
}

// ═══════════════════════════════════════
// ACTIONS
// ═══════════════════════════════════════
function handleTableAction(e) {
  const el = e.target.closest('[data-action]');
  if (!el) return;

  const action = el.dataset.action;
  const orderId = el.dataset.id;
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  switch (action) {
    case 'fulfill':
      fulfillOrder(order);
      break;
    case 'tracking':
      activeOrderId = orderId;
      document.getElementById('trackingNumber').value = order.trackingNumber || '';
      document.getElementById('amazonOrderId').value = order.amazonOrderId || '';
      showModal('trackingModal');
      break;
    case 'complete':
      order.status = 'completed';
      order.completedAt = Date.now();
      saveOrders();
      renderOrders();
      updateStats();
      updateSummary();
      break;
    case 'delete':
      if (confirm('Delete this order?')) {
        orders = orders.filter(o => o.id !== orderId);
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
      }
      break;
    case 'editCost':
      activeOrderId = orderId;
      document.getElementById('editCostInput').value = order.sourceCost || '';
      document.getElementById('editSourceUrl').value = order.sourceUrl || '';
      showModal('costModal');
      break;
  }
}

function fulfillOrder(order) {
  // Try to find source URL from SKU
  let url = order.sourceUrl || '';
  
  if (!url && order.sku) {
    // Parse SKU to find source product
    // SKU formats: UDS-AE-{aliexpressId}, UDS-AMZ-{asin}, ALI-{id}-{date}
    const sku = order.sku;
    if (sku.includes('AE-') || sku.includes('ALI-') || sku.includes('ali-')) {
      // AliExpress product
      const aliMatch = sku.match(/(?:AE-|ALI-)(\d+)/i);
      if (aliMatch) {
        url = `https://www.aliexpress.com/item/${aliMatch[1]}.html`;
      }
    } else if (sku.includes('AMZ-') || sku.includes('amz-')) {
      // Amazon product
      const amzMatch = sku.match(/(?:AMZ-)([A-Z0-9]+)/i);
      if (amzMatch) {
        chrome.storage.local.get('hunter_domain', s => {
          const domain = s.hunter_domain || 'co.uk';
          chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/dp/${amzMatch[1]}` });
        });
        order.status = 'ordered';
        order.orderedAt = Date.now();
        saveOrders();
        renderOrders();
        updateStats();
        updateSummary();
        return;
      }
    }
  }
  
  // Try matching with listed products by item number
  if (!url && order.itemNumber) {
    chrome.storage.local.get('unicornds_listed_products', data => {
      const listed = (data.unicornds_listed_products || {})[order.itemNumber];
      if (listed && listed.sourceUrl) {
        chrome.runtime.sendMessage({ type: 'openNewTab', url: listed.sourceUrl });
      } else if (order.itemTitle) {
        // Search Amazon as last resort
        chrome.storage.local.get('hunter_domain', s => {
          const domain = s.hunter_domain || 'co.uk';
          const query = encodeURIComponent(order.itemTitle.substring(0, 80));
          chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/s?k=${query}` });
        });
      }
    });
    order.status = 'ordered';
    order.orderedAt = Date.now();
    saveOrders();
    renderOrders();
    updateStats();
    updateSummary();
    return;
  }

  if (url) {
    chrome.runtime.sendMessage({ type: 'openNewTab', url });
  } else if (order.itemTitle) {
    chrome.storage.local.get('hunter_domain', s => {
      const domain = s.hunter_domain || 'co.uk';
      const query = encodeURIComponent(order.itemTitle.substring(0, 80));
      chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.amazon.${domain}/s?k=${query}` });
    });
  }

  order.status = 'ordered';
  order.orderedAt = Date.now();
  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
}

function saveCost() {
  const order = orders.find(o => o.id === activeOrderId);
  if (!order) return;

  const cost = parseFloat(document.getElementById('editCostInput').value) || 0;
  const url = document.getElementById('editSourceUrl').value.trim();

  order.sourceCost = cost;
  if (url) order.sourceUrl = url;

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('costModal');
}

function saveTracking() {
  const order = orders.find(o => o.id === activeOrderId);
  if (!order) return;

  const tracking = document.getElementById('trackingNumber').value.trim();
  const carrier = document.getElementById('trackingCarrier').value;
  const amazonId = document.getElementById('amazonOrderId').value.trim();

  if (!tracking) { alert('Enter a tracking number'); return; }

  order.trackingNumber = tracking;
  order.trackingCarrier = carrier;
  order.amazonOrderId = amazonId;
  order.status = 'shipped';
  order.shippedAt = Date.now();

  if (order.ebayOrderId || order.itemNumber) {
    chrome.runtime.sendMessage({
      type: 'upload_tracking_to_ebay',
      orderId: order.ebayOrderId,
      itemNumber: order.itemNumber,
      trackingNumber: tracking,
      carrier: carrier,
    });
  }

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('trackingModal');
}

// ═══════════════════════════════════════
// MANUAL ORDER
// ═══════════════════════════════════════
function saveManualOrder() {
  const buyer = document.getElementById('manualBuyer').value.trim();
  const title = document.getElementById('manualTitle').value.trim();
  const itemNumber = document.getElementById('manualItemNumber').value.trim();
  const soldPrice = parseFloat(document.getElementById('manualSoldPrice').value) || 0;
  const cost = parseFloat(document.getElementById('manualCost').value) || 0;
  const sourceUrl = document.getElementById('manualSourceUrl').value.trim();
  const dateVal = document.getElementById('manualDate').value;

  if (!title) { alert('Enter an item title'); return; }

  const soldDate = dateVal ? new Date(dateVal) : new Date();

  orders.unshift({
    id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    buyerName: buyer || 'Manual',
    itemTitle: title,
    itemNumber: itemNumber,
    soldPrice: soldPrice,
    sourceCost: cost,
    sourceUrl: sourceUrl,
    status: 'pending',
    trackingNumber: '',
    trackingCarrier: '',
    amazonOrderId: '',
    soldDate: soldDate.toLocaleDateString('en-GB'),
    soldDateTs: soldDate.getTime(),
    createdAt: Date.now(),
  });

  saveOrders();
  renderOrders();
  updateStats();
  updateSummary();
  hideModal('manualModal');

  ['manualBuyer', 'manualTitle', 'manualItemNumber', 'manualSoldPrice', 'manualCost', 'manualSourceUrl']
    .forEach(id => document.getElementById(id).value = '');
}

// ═══════════════════════════════════════
// STATS
// ═══════════════════════════════════════
function updateStats() {
  const filtered = filterByDate(orders);
  document.getElementById('pendingCount').textContent = filtered.filter(o => o.status === 'pending').length;
  document.getElementById('orderedCount').textContent = filtered.filter(o => o.status === 'ordered').length;
  document.getElementById('shippedCount').textContent = filtered.filter(o => o.status === 'shipped').length;
  document.getElementById('completedCount').textContent = filtered.filter(o => o.status === 'completed').length;

  const totalProfit = filtered
    .filter(o => o.soldPrice && o.sourceCost)
    .reduce((sum, o) => sum + (o.soldPrice - o.sourceCost), 0);
  document.getElementById('totalProfit').textContent = '£' + totalProfit.toFixed(2);
}

// ═══════════════════════════════════════
// MODAL
// ═══════════════════════════════════════
function showModal(id) { document.getElementById(id).style.display = 'flex'; }
function hideModal(id) { document.getElementById(id).style.display = 'none'; }
