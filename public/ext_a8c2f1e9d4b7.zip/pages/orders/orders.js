'use strict';
console.log('[UnicornDS] Order Manager loaded');

let orders = [];
let currentFilter = 'all';

// ═══════════════════════════════════════
// STORAGE
// ═══════════════════════════════════════
async function loadOrders() {
  return new Promise(resolve => {
    chrome.storage.local.get('unicornds_orders', data => {
      orders = data.unicornds_orders || [];
      resolve();
    });
  });
}

function saveOrders() {
  chrome.storage.local.set({ unicornds_orders: orders });
}

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  await loadOrders();
  renderOrders();
  updateStats();

  document.getElementById('syncOrdersBtn').addEventListener('click', syncEbayOrders);
  document.getElementById('addManualBtn').addEventListener('click', () => showModal('manualModal'));
  document.getElementById('cancelManualBtn').addEventListener('click', () => hideModal('manualModal'));
  document.getElementById('saveManualBtn').addEventListener('click', saveManualOrder);
  document.getElementById('cancelTrackingBtn').addEventListener('click', () => hideModal('trackingModal'));
  document.getElementById('saveTrackingBtn').addEventListener('click', saveTracking);

  // Filter buttons
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      renderOrders();
    });
  });

  // Table action delegation
  document.getElementById('ordersBody').addEventListener('click', handleTableAction);

  // Listen for new orders from scanner
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.unicornds_orders) {
      orders = changes.unicornds_orders.newValue || [];
      renderOrders();
      updateStats();
    }
  });
});

// ═══════════════════════════════════════
// SYNC EBAY ORDERS
// ═══════════════════════════════════════
async function syncEbayOrders() {
  const btn = document.getElementById('syncOrdersBtn');
  btn.textContent = '🔄 Syncing...';
  btn.disabled = true;

  try {
    const { unicornds_ebay_domain } = await new Promise(r =>
      chrome.storage.local.get('unicornds_ebay_domain', r));
    const domain = unicornds_ebay_domain || 'co.uk';

    // Open eBay seller hub orders page in background
    chrome.runtime.sendMessage({
      type: 'sync_ebay_orders',
      domain: domain,
    });

    // Poll for results
    const startTime = Date.now();
    const pollInterval = setInterval(() => {
      if (Date.now() - startTime > 30000) {
        clearInterval(pollInterval);
        btn.textContent = '🔄 Sync eBay Orders';
        btn.disabled = false;
        return;
      }
      chrome.storage.local.get('ebay_orders_sync_result', data => {
        const result = data.ebay_orders_sync_result;
        if (result && result.syncedAt > startTime) {
          clearInterval(pollInterval);
          chrome.storage.local.remove('ebay_orders_sync_result');

          const newOrders = result.orders || [];
          let addedCount = 0;

          newOrders.forEach(order => {
            // Deduplicate by eBay order ID or item number
            const exists = orders.some(o =>
              (o.ebayOrderId && o.ebayOrderId === order.ebayOrderId) ||
              (o.itemNumber && o.itemNumber === order.itemNumber && o.buyerName === order.buyerName)
            );
            if (!exists) {
              orders.unshift({
                id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
                ...order,
                status: 'pending',
                trackingNumber: '',
                trackingCarrier: '',
                amazonOrderId: '',
                createdAt: Date.now(),
              });
              addedCount++;
            }
          });

          if (addedCount > 0) {
            saveOrders();
            renderOrders();
            updateStats();
          }

          btn.textContent = `✅ ${addedCount} new orders`;
          setTimeout(() => {
            btn.textContent = '🔄 Sync eBay Orders';
            btn.disabled = false;
          }, 2000);
        }
      });
    }, 1000);
  } catch (err) {
    console.error('[UnicornDS] Sync error:', err);
    btn.textContent = '🔄 Sync eBay Orders';
    btn.disabled = false;
  }
}

// ═══════════════════════════════════════
// RENDER
// ═══════════════════════════════════════
function renderOrders() {
  const tbody = document.getElementById('ordersBody');
  const empty = document.getElementById('emptyState');

  const filtered = currentFilter === 'all'
    ? orders
    : orders.filter(o => o.status === currentFilter);

  if (!filtered.length) {
    tbody.innerHTML = '';
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  tbody.innerHTML = filtered.map((o, idx) => {
    const profit = (o.soldPrice && o.sourceCost)
      ? (o.soldPrice - o.sourceCost).toFixed(2)
      : null;
    const profitClass = profit === null ? 'profit-unknown'
      : parseFloat(profit) >= 0 ? 'profit-positive' : 'profit-negative';
    const profitText = profit === null ? '-' : (parseFloat(profit) >= 0 ? '+£' : '-£') + Math.abs(profit);

    const date = o.soldDate || new Date(o.createdAt || Date.now()).toLocaleDateString('en-GB');
    const statusClass = 'status-' + (o.status || 'pending');

    let actions = '';
    switch (o.status) {
      case 'pending':
        actions = `
          <button class="btn btn-sm btn-warning" data-action="fulfill" data-id="${o.id}">🛒 Fulfill</button>
          <button class="btn btn-sm btn-secondary" data-action="tracking" data-id="${o.id}">📦 Tracking</button>
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}">✕</button>`;
        break;
      case 'ordered':
        actions = `
          <button class="btn btn-sm btn-success" data-action="tracking" data-id="${o.id}">📦 Add Tracking</button>
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${o.id}">✕</button>`;
        break;
      case 'shipped':
        actions = `
          <button class="btn btn-sm btn-secondary" data-action="complete" data-id="${o.id}">✅ Complete</button>
          <span style="font-size:10px;color:#10B981">${o.trackingNumber || ''}</span>`;
        break;
      case 'completed':
        actions = `<span style="font-size:10px;color:#6B7280">${o.trackingNumber || 'Done'}</span>`;
        break;
    }

    const titleShort = (o.itemTitle || 'Unknown').length > 60
      ? (o.itemTitle || '').substring(0, 60) + '...'
      : (o.itemTitle || 'Unknown');

    return `<tr>
      <td>${date}</td>
      <td>${o.buyerName || '-'}</td>
      <td title="${(o.itemTitle || '').replace(/"/g, '&quot;')}">${titleShort}</td>
      <td>£${(o.soldPrice || 0).toFixed(2)}</td>
      <td>${o.sourceCost ? '£' + o.sourceCost.toFixed(2) : '-'}</td>
      <td class="${profitClass}">${profitText}</td>
      <td><span class="status-badge ${statusClass}">${(o.status || 'pending').toUpperCase()}</span></td>
      <td><div class="actions-cell">${actions}</div></td>
    </tr>`;
  }).join('');
}

// ═══════════════════════════════════════
// ACTIONS
// ═══════════════════════════════════════
let activeOrderId = null;

function handleTableAction(e) {
  const btn = e.target.closest('button');
  if (!btn) return;

  const action = btn.dataset.action;
  const orderId = btn.dataset.id;
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  switch (action) {
    case 'fulfill':
      fulfillOrder(order);
      break;
    case 'tracking':
      activeOrderId = orderId;
      document.getElementById('trackingNumber').value = order.trackingNumber || '';
      document.getElementById('amazonOrderId').value = order.amazonOrderId || '';
      showModal('trackingModal');
      break;
    case 'complete':
      order.status = 'completed';
      order.completedAt = Date.now();
      saveOrders();
      renderOrders();
      updateStats();
      break;
    case 'delete':
      if (confirm('Delete this order?')) {
        orders = orders.filter(o => o.id !== orderId);
        saveOrders();
        renderOrders();
        updateStats();
      }
      break;
  }
}

function fulfillOrder(order) {
  // If we have a source URL, open it
  if (order.sourceUrl) {
    chrome.runtime.sendMessage({ type: 'openNewTab', url: order.sourceUrl });
  } else if (order.itemTitle) {
    // Search Amazon for the product title
    chrome.storage.local.get('hunter_domain', s => {
      const domain = s.hunter_domain || 'co.uk';
      const query = encodeURIComponent(order.itemTitle.substring(0, 80));
      chrome.runtime.sendMessage({
        type: 'openNewTab',
        url: `https://www.amazon.${domain}/s?k=${query}`
      });
    });
  }

  // Mark as ordered
  order.status = 'ordered';
  order.orderedAt = Date.now();
  saveOrders();
  renderOrders();
  updateStats();
}

function saveTracking() {
  const order = orders.find(o => o.id === activeOrderId);
  if (!order) return;

  const tracking = document.getElementById('trackingNumber').value.trim();
  const carrier = document.getElementById('trackingCarrier').value;
  const amazonId = document.getElementById('amazonOrderId').value.trim();

  if (!tracking) { alert('Enter a tracking number'); return; }

  order.trackingNumber = tracking;
  order.trackingCarrier = carrier;
  order.amazonOrderId = amazonId;
  order.status = 'shipped';
  order.shippedAt = Date.now();

  // Upload tracking to eBay
  if (order.ebayOrderId || order.itemNumber) {
    chrome.runtime.sendMessage({
      type: 'upload_tracking_to_ebay',
      orderId: order.ebayOrderId,
      itemNumber: order.itemNumber,
      trackingNumber: tracking,
      carrier: carrier,
    });
  }

  saveOrders();
  renderOrders();
  updateStats();
  hideModal('trackingModal');
}

// ═══════════════════════════════════════
// MANUAL ORDER
// ═══════════════════════════════════════
function saveManualOrder() {
  const buyer = document.getElementById('manualBuyer').value.trim();
  const title = document.getElementById('manualTitle').value.trim();
  const itemNumber = document.getElementById('manualItemNumber').value.trim();
  const soldPrice = parseFloat(document.getElementById('manualSoldPrice').value) || 0;
  const cost = parseFloat(document.getElementById('manualCost').value) || 0;
  const sourceUrl = document.getElementById('manualSourceUrl').value.trim();

  if (!title) { alert('Enter an item title'); return; }

  orders.unshift({
    id: 'order_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    buyerName: buyer || 'Manual',
    itemTitle: title,
    itemNumber: itemNumber,
    soldPrice: soldPrice,
    sourceCost: cost,
    sourceUrl: sourceUrl,
    status: 'pending',
    trackingNumber: '',
    trackingCarrier: '',
    amazonOrderId: '',
    soldDate: new Date().toLocaleDateString('en-GB'),
    createdAt: Date.now(),
  });

  saveOrders();
  renderOrders();
  updateStats();
  hideModal('manualModal');

  // Clear form
  ['manualBuyer', 'manualTitle', 'manualItemNumber', 'manualSoldPrice', 'manualCost', 'manualSourceUrl']
    .forEach(id => document.getElementById(id).value = '');
}

// ═══════════════════════════════════════
// STATS
// ═══════════════════════════════════════
function updateStats() {
  document.getElementById('pendingCount').textContent = orders.filter(o => o.status === 'pending').length;
  document.getElementById('orderedCount').textContent = orders.filter(o => o.status === 'ordered').length;
  document.getElementById('shippedCount').textContent = orders.filter(o => o.status === 'shipped').length;

  const totalProfit = orders
    .filter(o => o.soldPrice && o.sourceCost)
    .reduce((sum, o) => sum + (o.soldPrice - o.sourceCost), 0);
  document.getElementById('totalProfit').textContent = '£' + totalProfit.toFixed(2);
}

// ═══════════════════════════════════════
// MODAL
// ═══════════════════════════════════════
function showModal(id) { document.getElementById(id).style.display = 'flex'; }
function hideModal(id) { document.getElementById(id).style.display = 'none'; }
