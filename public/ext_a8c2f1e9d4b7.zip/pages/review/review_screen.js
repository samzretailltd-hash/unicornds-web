// ─────────────────────────────────────────────────────────
// UNICORNDS REVIEW SCREEN
// ─────────────────────────────────────────────────────────

let listing    = null;
let validation = null;
let pricing    = null;
let activeTitle = '';

// Currency symbols per marketplace
const SYMBOLS = { com:'$', co_uk:'£', de:'€', com_au:'A$', ca:'C$', fr:'€', es:'€', it:'€', nl:'€' };

// ── Load data from storage ─────────────────────────────
async function loadData() {
  try {
    let data;
    if (typeof chrome !== 'undefined' && chrome.storage) {
      const stored = await chrome.storage.local.get(['pendingListing','pendingValidation','pendingPricing']);
      listing    = stored.pendingListing;
      validation = stored.pendingValidation;
      pricing    = stored.pendingPricing;
    }

    if (!listing) {
      // Dev mode - use demo data
      listing    = getDemoListing();
      validation = getDemoValidation();
      pricing    = getDemoPricing();
    }

    render();
  } catch (err) {
    document.getElementById('loadingState').innerHTML =
      `<div style="color:var(--danger);">❌ Failed to load listing data: ${err.message}</div>`;
  }
}

// ── Render everything ──────────────────────────────────
function render() {
  document.getElementById('loadingState').style.display = 'none';
  document.getElementById('mainLayout').style.display   = 'grid';

  renderProductInfo();
  renderTitles();
  renderImages();
  renderPricing();
  renderValidation();
  renderQuickStats();

  // Set initial active title
  activeTitle = listing.titleOptions?.find(t => t.title === listing.title)?.title
    || listing.title || '';
  document.getElementById('listingPrice').value = listing.price || '';
  document.getElementById('quantityInput').value = listing.quantity || 1;
  document.getElementById('skuInput').value      = listing.sku || '';
}

function renderProductInfo() {
  const sym = SYMBOLS[listing.marketplace] || '$';
  const img = listing.images?.[0] || '';

  const thumb = document.getElementById('productThumb');
  if (img) { thumb.src = img; thumb.onerror = () => thumb.style.display = 'none'; }

  setText('productId',      `Product ID: ${listing.productId || '-'}`);
  setText('aliexpressTitle', listing.cleanedTitle || listing.title || '-');
  setText('alipriceDisplay', `${sym}${listing.aliexpressPrice || '?'} on AliExpress`);
  setText('marketplaceDisplay', listing.marketplace?.toUpperCase() || '-');
}

function renderTitles() {
  const container = document.getElementById('titleOptions');
  container.innerHTML = '';
  const titles = listing.titleOptions || [{ title: listing.title, valid: true, charCount: (listing.title||'').length, strategy: 'Original' }];

  titles.slice(0, 6).forEach((t, i) => {
    const isRec = t.title === listing.title;
    const chars = t.title?.length || 0;
    const pct   = (chars / 80) * 100;
    const cls   = chars < 40 ? 'warn' : chars > 80 ? 'over' : '';

    const div = document.createElement('div');
    div.className = 'title-option' + (isRec ? ' active' : '');
    div.innerHTML = `
      ${isRec ? '<div class="rec-badge">Recommended</div>' : ''}
      <div class="title-text">${esc(t.title || '')}</div>
      <div class="title-meta">
        <span class="chars">${chars}/80 chars</span>
        <span class="strategy">${t.strategy || ''}</span>
        <span>${t.valid ? '<span class="tag tag-pass">✓ Valid</span>' : '<span class="tag tag-fail">⚠ Issues</span>'}</span>
      </div>
      <div class="char-bar"><div class="char-fill ${cls}" style="width:${Math.min(pct,100)}%"></div></div>
    `;
    div.addEventListener('click', () => selectTitle(t.title, div));
    container.appendChild(div);
  });

  updateTitleCharCount(listing.title || '');
}

function selectTitle(title, el) {
  activeTitle = title;
  document.querySelectorAll('.title-option').forEach(d => d.classList.remove('active'));
  el.classList.add('active');
  updateTitleCharCount(title);
  recalcPricing();
}

function updateTitleCharCount(title) {
  const len = (title || '').length;
  const el  = document.getElementById('titleCharCount');
  el.textContent = len;
  el.style.color = len > 80 ? 'var(--danger)' : len < 40 ? 'var(--warning)' : 'var(--success)';
}

function applyCustomTitle() {
  const val = document.getElementById('customTitleInput').value.trim();
  if (!val) return;
  activeTitle = val;
  document.querySelectorAll('.title-option').forEach(d => d.classList.remove('active'));
  updateTitleCharCount(val);
}

document.getElementById('btnApplyCustomTitle')?.addEventListener('click', applyCustomTitle);

document.getElementById('customTitleInput')?.addEventListener('input', e => {
  const len = e.target.value.length;
  const el  = document.getElementById('customCharCounter');
  el.textContent = `${len}/80`;
  el.className   = `char-counter ${len > 80 ? 'bad' : len < 40 ? 'warn' : 'ok'}`;
});

function renderImages() {
  const grid   = document.getElementById('imagesGrid');
  const images = listing.images || [];
  grid.innerHTML = '';

  images.forEach((url, i) => {
    const div = document.createElement('div');
    div.className = 'img-thumb' + (i === 0 ? ' main' : '');

    const isEbay = url?.includes('ebayimg.com') || url?.includes('i.ebayimg.com');
    div.innerHTML = `
      <img src="${esc(url)}" alt="Image ${i+1}" loading="lazy">
      ${isEbay ? '<div class="ebay-badge">✓</div>' : ''}
    `;
    div.addEventListener('click', () => {
      document.querySelectorAll('.img-thumb').forEach(d => d.classList.remove('main'));
      div.classList.add('main');
    });
    grid.appendChild(div);
  });

  const ebayCount = images.filter(u => u?.includes('ebayimg.com')).length;
  setText('imageCount', `${ebayCount}/${images.length}`);
}

function renderPricing() {
  const p    = pricing?.cheapestVariant || pricing;
  if (!p) return;

  const sym  = p.symbol || SYMBOLS[listing.marketplace] || '$';

  document.getElementById('priceCurrency').textContent = sym;
  document.getElementById('listingPrice').value        = p.suggestedListingPrice?.toFixed(2) || listing.price;

  const breakdown = document.getElementById('priceBreakdown');
  breakdown.innerHTML = `
    <div class="price-stat ${p.meetsMinMargin ? 'good' : 'warn'}">
      <div class="val">${sym}${p.netProfit?.toFixed(2) || '?'}</div>
      <div class="lbl">Net Profit</div>
    </div>
    <div class="price-stat ${p.meetsMinMargin ? 'good' : 'warn'}">
      <div class="val">${p.profitMargin?.toFixed(1) || '?'}%</div>
      <div class="lbl">Margin</div>
    </div>
    <div class="price-stat">
      <div class="val">${sym}${p.totalEbayFees?.toFixed(2) || '?'}</div>
      <div class="lbl">eBay Fees</div>
    </div>
  `;
}

function recalcPricing() {
  const newPrice = parseFloat(document.getElementById('listingPrice').value);
  if (!newPrice || !pricing) return;
  const p   = pricing?.cheapestVariant || pricing;
  if (!p) return;
  const sym = p.symbol || '$';
  const fee = newPrice * (p.fvfRate / 100) + (p.perOrderFee || 0);
  const profit = newPrice - (p.totalCost || 0) - fee;
  const margin = (profit / newPrice) * 100;
  setText('statProfit', `${sym}${profit.toFixed(2)}`);
  setText('statMargin',  `${margin.toFixed(1)}%`);
  document.getElementById('statProfit').style.color = profit > 0 ? 'var(--success)' : 'var(--danger)';
  document.getElementById('statMargin').style.color = margin > 20 ? 'var(--success)' : 'var(--warning)';
}

document.getElementById('listingPrice')?.addEventListener('input', recalcPricing);

function renderValidation() {
  if (!validation) return;

  const bar   = document.getElementById('summaryBar');
  const list  = document.getElementById('checkList');
  const badge = document.getElementById('validationBadge');
  const btn   = document.getElementById('btnList');

  // Summary bar
  const cls   = validation.failed > 0 ? 'fail' : validation.warnings > 0 ? 'warn' : 'pass';
  bar.className = `summary-bar ${cls}`;
  bar.textContent = validation.summary;

  badge.innerHTML = validation.failed > 0
    ? `<span class="tag tag-fail">${validation.failed} Failed</span>`
    : validation.warnings > 0
      ? `<span class="tag tag-warn">${validation.warnings} Warnings</span>`
      : `<span class="tag tag-pass">All Checks Passed</span>`;

  // Enable list button only if can list
  btn.disabled = !validation.canList;
  if (!validation.canList) {
    btn.textContent = `❌ Fix ${validation.failed} Issue(s) First`;
  } else if (validation.warnings > 0) {
    btn.textContent = `⚠️ List Anyway (${validation.warnings} Warning${validation.warnings > 1 ? 's' : ''})`;
  } else {
    btn.textContent = '🚀 List on eBay Now';
  }

  // Check items
  list.innerHTML = '';
  validation.checks?.forEach(check => {
    const icons = { pass: '✅', warn: '⚠️', fail: '❌' };
    const div   = document.createElement('div');
    div.className = `check-item ${check.status}`;
    div.innerHTML = `
      <span class="check-icon">${icons[check.status] || '•'}</span>
      <div>
        <div class="check-name">${esc(check.name)}</div>
        <div class="check-msg">${esc(check.message)}</div>
      </div>
    `;
    list.appendChild(div);
  });
}

function renderQuickStats() {
  const p   = pricing?.cheapestVariant || pricing;
  const sym = p?.symbol || SYMBOLS[listing.marketplace] || '$';
  if (p) {
    setText('statCost',        `${sym}${p.aliexpressPrice?.toFixed(2) || '?'}`);
    setText('statFvf',         `${sym}${p.totalEbayFees?.toFixed(2) || '?'} (${p.fvfRate}%)`);
    setText('statProfit',      `${sym}${p.netProfit?.toFixed(2) || '?'}`);
    setText('statMargin',      `${p.profitMargin?.toFixed(1) || '?'}%`);
    document.getElementById('statProfit').style.color = p.netProfit > 0 ? 'var(--success)' : 'var(--danger)';
    document.getElementById('statMargin').style.color = p.meetsMinMargin ? 'var(--success)' : 'var(--warning)';
  }
  const ebayCount = (listing.images || []).filter(u => u?.includes('ebayimg.com')).length;
  setText('statMarketplace', listing.marketplace?.toUpperCase() || '-');
  setText('statImages',      `${ebayCount}/${(listing.images||[]).length} on eBay`);
}

// ── Actions ────────────────────────────────────────────
document.getElementById('btnList').addEventListener('click', async () => {
  const finalListing = buildFinalListing();

  showSubmitting('Submitting to eBay…', 'This usually takes 5–15 seconds');

  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({
      type:    'listing_review_decision',
      approved: true,
      listing:  finalListing,
    }, () => {
      updateSubmitting('🎉 Listed Successfully!', 'Your listing is now live on eBay');
      setTimeout(() => window.close(), 2000);
    });
  } else {
    // Dev mode
    setTimeout(() => {
      updateSubmitting('🎉 Listed Successfully!', 'Demo mode - not actually listed');
      setTimeout(() => hideSubmitting(), 2000);
    }, 1500);
  }
});

document.getElementById('btnSaveDraft').addEventListener('click', async () => {
  const finalListing = buildFinalListing();
  if (typeof chrome !== 'undefined' && chrome.storage) {
    const drafts = (await chrome.storage.local.get('unicornds_drafts')).unicornds_drafts || [];
    drafts.push({ ...finalListing, savedAt: new Date().toISOString() });
    await chrome.storage.local.set({ unicornds_drafts: drafts });
  }
  alert('✅ Draft saved! You can resume from the main popup.');
});

document.getElementById('btnCancel').addEventListener('click', () => {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ type: 'listing_review_decision', approved: false });
  }
  window.close();
});

// ── Build final listing object ─────────────────────────
function buildFinalListing() {
  return {
    ...listing,
    title:     activeTitle || listing.title,
    price:     document.getElementById('listingPrice').value,
    quantity:  parseInt(document.getElementById('quantityInput').value) || 1,
    condition: document.getElementById('conditionSelect').value,
    sku:       document.getElementById('skuInput').value,
    reviewedAt: new Date().toISOString(),
  };
}

// ── Overlay helpers ────────────────────────────────────
function showSubmitting(title, msg) {
  setText('submittingTitle', title);
  setText('submittingMsg', msg);
  document.getElementById('submittingOverlay').classList.remove('hidden');
}
function updateSubmitting(title, msg) {
  setText('submittingTitle', title);
  setText('submittingMsg', msg);
  document.querySelector('.progress-dots').style.display = 'none';
}
function hideSubmitting() {
  document.getElementById('submittingOverlay').classList.add('hidden');
  document.querySelector('.progress-dots').style.display = '';
}

// ── Utility ────────────────────────────────────────────
function setText(id, text) { const el = document.getElementById(id); if (el) el.textContent = text; }
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// ── Demo data (dev mode) ───────────────────────────────
function getDemoListing() {
  return {
    productId:'DEMO-001', marketplace:'co_uk',
    title:'LED Desk Lamp USB Rechargeable Foldable 3 Brightness Eye Protection',
    cleanedTitle:'LED Desk Lamp USB Rechargeable Foldable Eye Protection',
    aliexpressPrice:'8.99', price:'24.99', quantity:1, sku:'AE-UK-1005006123456789',
    images:['https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200','https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=200'],
    titleOptions:[
      {title:'LED Desk Lamp USB Rechargeable Foldable 3 Brightness Eye Protection',charCount:68,valid:true,strategy:'Type + Spec'},
      {title:'Rechargeable LED Desk Lamp Foldable Touch Dimmer Eye Care Study Light',charCount:70,valid:true,strategy:'USP-first'},
      {title:'USB LED Study Lamp Rechargeable Foldable 3 Colour Modes Bedroom Office',charCount:71,valid:true,strategy:'Use Case'},
    ],
  };
}
function getDemoValidation() {
  return {
    checks:[
      {name:'Title Length',  status:'pass', message:'68 characters ✓'},
      {name:'Title Content', status:'pass', message:'Title content clean ✓'},
      {name:'VERO Check',    status:'pass', message:'No VERO brands detected ✓'},
      {name:'Profitability', status:'pass', message:'Margin: 42.1% · Profit: £10.52 ✓'},
      {name:'Images',        status:'warn', message:'2 images - more images improve conversion'},
      {name:'Required Fields',status:'pass',message:'All required fields present ✓'},
      {name:'Duplicate Check',status:'pass',message:'SKU is unique ✓'},
    ],
    passed:6, warnings:1, failed:0, canList:true, mustReview:true,
    summary:'⚠️ 1 warning - review before listing',
  };
}
function getDemoPricing() {
  return { cheapestVariant:{ symbol:'£', aliexpressPrice:8.99, suggestedListingPrice:24.99, netProfit:10.52, profitMargin:42.1, totalEbayFees:3.50, fvfRate:12.8, perOrderFee:0.30, totalCost:8.99, meetsMinMargin:true } };
}

// ── Init ───────────────────────────────────────────────
loadData();