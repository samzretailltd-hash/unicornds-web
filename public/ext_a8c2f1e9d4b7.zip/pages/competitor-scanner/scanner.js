/**
 * UnicornDS - Competitor Scanner
 * Scans eBay seller stores to find what they sell
 */

console.log('[UnicornDS] Competitor Scanner loaded');

let items = [];
let isRunning = false;
let scanPosition = 0;
let concurrency = 1;
let priceSortAsc = true;
let lastScanCount = 0;
let lastScanDone = 0;
let processedScanBatches = new Set();

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  const data = await chrome.storage.local.get([
    'scanner_items', 'scanner_position', 'ebayCompetitors',
    'scanner_domain', 'scanner_type', 'scanner_ipp', 'scanner_concurrency', 'scanner_autoclose',
    'scanner_get_sold_history', 'scanner_sold_time_range'
  ]);

  if (data.scanner_items?.length) {
    items = data.scanner_items;
    renderResults();
  }
  scanPosition = data.scanner_position || 0;

  // Load saved competitors into textarea
  if (data.ebayCompetitors?.length) {
    document.getElementById('sellerInput').value = data.ebayCompetitors.join('\n');
    document.getElementById('savedCount').textContent = data.ebayCompetitors.length;
  }
  updateSellerCount();

  // Restore settings
  if (data.scanner_domain) document.getElementById('ebayDomain').value = data.scanner_domain;
  if (data.scanner_type) document.getElementById('scanType').value = data.scanner_type;
  if (data.scanner_ipp) document.getElementById('itemsPerPage').value = data.scanner_ipp;
  if (data.scanner_autoclose != null) document.getElementById('autoClose').checked = data.scanner_autoclose;
  // C3: Restore sold history settings
  if (data.scanner_get_sold_history) {
    document.getElementById('getSoldHistory').checked = true;
    document.getElementById('soldHistoryRange').style.display = 'block';
  }
  if (data.scanner_sold_time_range) document.getElementById('soldTimeRange').value = data.scanner_sold_time_range;

  concurrency = data.scanner_concurrency || 1;
  document.querySelectorAll('.thread-btn').forEach(b => {
    b.classList.toggle('active', parseInt(b.dataset.threads) === concurrency);
  });

  setupListeners();
});

// ═══════════════════════════════════════
// LISTENERS
// ═══════════════════════════════════════
function setupListeners() {
  document.getElementById('sellerInput').addEventListener('input', updateSellerCount);
  document.getElementById('runBtn').addEventListener('click', startScan);
  document.getElementById('stopBtn').addEventListener('click', stopScan);
  document.getElementById('resetBtn').addEventListener('click', resetScan);
  document.getElementById('loadSavedBtn').addEventListener('click', loadSavedSellers);

  document.querySelectorAll('.thread-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.thread-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      concurrency = parseInt(btn.dataset.threads);
      chrome.storage.local.set({ scanner_concurrency: concurrency });
    });
  });

  // Settings auto-save
  ['ebayDomain', 'scanType', 'itemsPerPage', 'autoClose', 'getSoldHistory', 'soldTimeRange'].forEach(id => {
    document.getElementById(id).addEventListener('change', saveSettings);
  });

  // C3: Show/hide time range based on sold history toggle
  document.getElementById('getSoldHistory').addEventListener('change', (e) => {
    document.getElementById('soldHistoryRange').style.display = e.target.checked ? 'block' : 'none';
    saveSettings();
  });

  // Results
  document.getElementById('exportCsvBtn').addEventListener('click', exportCSV);
  document.getElementById('sendHunterBtn').addEventListener('click', sendToHunter);
  document.getElementById('sendBulkBtn').addEventListener('click', sendToBulkLister);
  document.getElementById('clearResultsBtn').addEventListener('click', clearResults);
  document.getElementById('selectAll').addEventListener('change', (e) => {
    document.querySelectorAll('.row-check').forEach(cb => cb.checked = e.target.checked);
  });
  document.getElementById('filterResults').addEventListener('input', () => { currentPage = 1; renderResults(); });
  document.getElementById('filterSeller').addEventListener('change', () => { currentPage = 1; renderResults(); });
  document.getElementById('sortPriceBtn').addEventListener('click', () => {
    items.sort((a, b) => priceSortAsc ? a.price - b.price : b.price - a.price);
    priceSortAsc = !priceSortAsc;
    currentPage = 1;
    renderResults();
  });

  // Pagination buttons
  document.getElementById('prevPageBtn').addEventListener('click', () => {
    if (currentPage > 1) { currentPage--; renderResults(); }
  });
  document.getElementById('nextPageBtn').addEventListener('click', () => {
    currentPage++;
    renderResults();
  });

  // Event delegation for result table buttons (MV3 CSP compliant)
  document.getElementById('resultsBody').addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const idx = parseInt(btn.dataset.idx);
    if (isNaN(idx)) return;
    if (btn.classList.contains('btn-amazon')) searchAmazon(idx);
    if (btn.classList.contains('btn-copy')) copyItem(idx);
  });

  // Poll storage for scanner batch results
  setInterval(async () => {
    const allData = await chrome.storage.local.get(null);

    for (const key of Object.keys(allData)) {
      if (key.startsWith('scanner_batch_') && !processedScanBatches.has(key)) {
        processedScanBatches.add(key);
        const batch = allData[key];
        console.log('[UnicornDS] Scanner: processing batch', key, batch.items?.length, 'items');
        handleResults(batch);
        chrome.storage.local.remove(key);
      }
    }

    const sd = allData.scanner_seller_done || 0;
    if (sd > lastScanDone) {
      lastScanDone = sd;
      chrome.storage.local.remove('scanner_page_progress');
      onSellerComplete();
    }

    // Show page-by-page progress
    const pp = allData.scanner_page_progress;
    if (pp && isRunning) {
      const statusEl = document.getElementById('currentSeller');
      const moreText = pp.hasMore ? ' (scanning...)' : ' (done)';
      statusEl.textContent = `${pp.seller} — Page ${pp.page}: ${pp.itemsSoFar} items${moreText}`;
    }
  }, 1000);
}

// ═══════════════════════════════════════
// SAVE / LOAD
// ═══════════════════════════════════════
function saveSettings() {
  chrome.storage.local.set({
    scanner_domain: document.getElementById('ebayDomain').value,
    scanner_type: document.getElementById('scanType').value,
    scanner_ipp: document.getElementById('itemsPerPage').value,
    scanner_autoclose: document.getElementById('autoClose').checked,
    scanner_get_sold_history: document.getElementById('getSoldHistory').checked,
    scanner_sold_time_range: parseInt(document.getElementById('soldTimeRange').value) || 30,
  });
}

function saveSellers() {
  const sellers = getSellers();
  chrome.storage.local.set({ ebayCompetitors: sellers });
}

function saveItems() {
  chrome.storage.local.set({ scanner_items: items });
}

function getSellers() {
  return document.getElementById('sellerInput').value
    .split('\n').map(s => s.trim().toLowerCase()).filter(s => s.length > 0)
    .filter((s, i, arr) => arr.indexOf(s) === i); // dedupe
}

function updateSellerCount() {
  document.getElementById('sellerCount').textContent = getSellers().length;
}

async function loadSavedSellers() {
  const { ebayCompetitors } = await chrome.storage.local.get('ebayCompetitors');
  if (ebayCompetitors?.length) {
    const current = getSellers();
    const merged = [...new Set([...current, ...ebayCompetitors])];
    document.getElementById('sellerInput').value = merged.join('\n');
    updateSellerCount();
  }
}

// ═══════════════════════════════════════
// SCAN CONTROL
// ═══════════════════════════════════════
let inFlight = 0;   // how many sellers are currently being scanned
let totalSent = 0;  // total sellers dispatched so far

function startScan() {
  const sellers = getSellers();
  if (!sellers.length) { alert('Enter at least one seller username.'); return; }

  isRunning = true;
  scanPosition = 0;
  inFlight = 0;
  totalSent = 0;
  saveSellers();
  saveSettings();
  updateButtons();
  chrome.storage.local.get(null, (allData) => {
    const keysToRemove = Object.keys(allData).filter(k => k.startsWith('scanner_batch_'));
    if (keysToRemove.length) chrome.storage.local.remove(keysToRemove);
  });
  chrome.storage.local.set({ scanner_seller_done: 0 });
  lastScanDone = 0;
  processedScanBatches = new Set();
  document.getElementById('progressSection').style.display = 'block';
  console.log(`[UnicornDS] Scanner: starting with concurrency=${concurrency} for ${sellers.length} sellers`);
  dispatchWorkers(sellers);
}

function stopScan() {
  isRunning = false;
  chrome.storage.local.set({ scanner_position: scanPosition });
  updateButtons();
}

function resetScan() {
  isRunning = false;
  scanPosition = 0;
  inFlight = 0;
  totalSent = 0;
  chrome.storage.local.set({ scanner_position: 0 });
  document.getElementById('progressSection').style.display = 'none';
  updateButtons();
}

function updateButtons() {
  document.getElementById('runBtn').disabled = isRunning;
  document.getElementById('stopBtn').disabled = !isRunning;
}

function updateProgress(current, total, seller) {
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('progressLabel').textContent = `${current} / ${total}`;
  document.getElementById('currentSeller').textContent = seller + (concurrency > 1 ? ` (${inFlight} active)` : '');
}

// ═══════════════════════════════════════
// CONCURRENT DISPATCH (P0-4 fix)
// ═══════════════════════════════════════
// Worker pool: dispatches up to `concurrency` sellers in parallel.
// Each dispatch sends scanner_scan_seller to background, which opens
// a tab and scrapes. The poll loop detects completion via
// scanner_seller_done timestamp bumps and decrements inFlight.
// Next seller is dispatched when inFlight < concurrency.
async function dispatchWorkers(sellers) {
  const domain = document.getElementById('ebayDomain').value;
  const scanType = document.getElementById('scanType').value;
  const ipp = document.getElementById('itemsPerPage').value;
  const autoClose = document.getElementById('autoClose').checked;

  for (let i = 0; i < sellers.length; i++) {
    // Wait until there's a free slot
    while (inFlight >= concurrency && isRunning) {
      await new Promise(r => setTimeout(r, 300));
    }
    if (!isRunning) break;

    const seller = sellers[i];
    let url;
    if (scanType === 'sold') {
      url = `https://www.ebay.${domain}/sch/i.html?_dkr=1&_ssn=${encodeURIComponent(seller)}&_ipg=${ipp}&LH_Sold=1&_sop=13`;
    } else {
      url = `https://www.ebay.${domain}/sch/i.html?_dkr=1&_ssn=${encodeURIComponent(seller)}&_ipg=${ipp}&_sop=16`;
    }

    inFlight++;
    totalSent++;
    updateProgress(totalSent, sellers.length, seller);
    console.log(`[UnicornDS] Scanner: dispatching seller ${seller} (${totalSent}/${sellers.length}, ${inFlight} in flight)`);

    chrome.runtime.sendMessage({
      type: 'scanner_scan_seller',
      url,
      seller,
      autoClose,
    });
  }

  // Wait for all remaining in-flight to complete
  while (inFlight > 0 && isRunning) {
    await new Promise(r => setTimeout(r, 500));
  }
  isRunning = false;
  updateButtons();
  document.getElementById('currentSeller').textContent = 'Scan complete!';
  console.log('[UnicornDS] Scanner: all sellers done');
}

// Called by the poll loop when scanner_seller_done timestamp bumps.
// This is the signal that background finished one seller's scan.
function onSellerComplete() {
  scanPosition++;
  inFlight = Math.max(0, inFlight - 1);
  chrome.storage.local.set({ scanner_position: scanPosition });
  console.log(`[UnicornDS] Scanner: seller done (position ${scanPosition}, ${inFlight} still in flight)`);
}

// ═══════════════════════════════════════
// HANDLE RESULTS
// ═══════════════════════════════════════
function handleResults(data) {
  if (!data?.items?.length) return;

  const newItems = data.items.map(item => ({
    ...item,
    seller: data.seller || '',
    scannedAt: Date.now(),
  }));

  items = items.concat(newItems);
  saveItems();
  renderResults();
  updateSellerFilter();

  // C3: If "Get Sold History" is enabled, queue purchase history lookups
  if (document.getElementById('getSoldHistory')?.checked) {
    const days = parseInt(document.getElementById('soldTimeRange')?.value) || 30;
    fetchPurchaseHistoryBatch(newItems, days);
  }
}

// ═══════════════════════════════════════
// C3: PURCHASE HISTORY — Total Sold Lookup
// ═══════════════════════════════════════
// For each item, opens /bin/purchaseHistory?item={itemId} in background,
// scrapes the purchase history table, counts rows within the time range.
async function fetchPurchaseHistoryBatch(itemsToFetch, days) {
  const domain = document.getElementById('ebayDomain').value || 'co.uk';
  const itemsWithIds = itemsToFetch.filter(i => i.itemNumber);
  if (!itemsWithIds.length) return;

  console.log(`[UnicornDS] C3: Fetching sold history for ${itemsWithIds.length} items (last ${days} days)`);

  for (const item of itemsWithIds) {
    if (!isRunning) break;
    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage({
          type: 'scanner_get_purchase_history',
          itemId: item.itemNumber,
          domain,
          days,
        }, (resp) => {
          if (chrome.runtime.lastError) {
            resolve({ totalSold: 0, error: chrome.runtime.lastError.message });
          } else {
            resolve(resp || { totalSold: 0 });
          }
        });
      });

      item.totalSold = result.totalSold || 0;
      console.log(`[UnicornDS] C3: item ${item.itemNumber} → ${item.totalSold} sold in ${days}d`);

      // Update the Sold column in the table
      const soldCell = document.querySelector(`[data-item-sold="${item.itemNumber}"]`);
      if (soldCell) soldCell.textContent = item.totalSold > 0 ? item.totalSold : '-';

    } catch (e) {
      console.warn(`[UnicornDS] C3: history fetch error for ${item.itemNumber}:`, e.message);
    }

    // Small delay between requests to avoid rate limiting
    await new Promise(r => setTimeout(r, 500));
  }

  saveItems();
  renderResults();
  console.log('[UnicornDS] C3: Purchase history batch complete');
}

function updateSellerFilter() {
  const select = document.getElementById('filterSeller');
  const sellers = [...new Set(items.map(i => i.seller).filter(Boolean))];
  const current = select.value;
  select.innerHTML = '<option value="">All Sellers</option>';
  sellers.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s;
    opt.textContent = s + ' (' + items.filter(i => i.seller === s).length + ')';
    select.appendChild(opt);
  });
  select.value = current;
}

// ═══════════════════════════════════════
// RENDER (with pagination)
// ═══════════════════════════════════════
const ITEMS_PER_PAGE = 100;
let currentPage = 1;

function renderResults() {
  const tbody = document.getElementById('resultsBody');
  const empty = document.getElementById('emptyState');
  const titleFilter = (document.getElementById('filterResults').value || '').toLowerCase();
  const sellerFilter = document.getElementById('filterSeller').value;
  const domain = document.getElementById('ebayDomain').value;

  let filtered = items;
  if (titleFilter) filtered = filtered.filter(i => (i.title || '').toLowerCase().includes(titleFilter));
  if (sellerFilter) filtered = filtered.filter(i => i.seller === sellerFilter);

  document.getElementById('resultCount').textContent = items.length;
  const hasItems = items.length > 0;
  document.getElementById('exportCsvBtn').disabled = !hasItems;
  document.getElementById('sendHunterBtn').disabled = !hasItems;
  document.getElementById('sendBulkBtn').disabled = !hasItems;
  document.getElementById('clearResultsBtn').disabled = !hasItems;

  if (!filtered.length) {
    tbody.innerHTML = '';
    empty.style.display = items.length ? 'none' : 'block';
    document.getElementById('paginationControls').style.display = 'none';
    return;
  }
  empty.style.display = 'none';

  // Pagination
  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  const startIdx = (currentPage - 1) * ITEMS_PER_PAGE;
  const pageItems = filtered.slice(startIdx, startIdx + ITEMS_PER_PAGE);

  // Show pagination controls
  const pagCtrl = document.getElementById('paginationControls');
  if (totalPages > 1) {
    pagCtrl.style.display = 'flex';
    document.getElementById('pageInfo').textContent = `Page ${currentPage} of ${totalPages} (${filtered.length} items)`;
    document.getElementById('prevPageBtn').disabled = currentPage <= 1;
    document.getElementById('nextPageBtn').disabled = currentPage >= totalPages;
  } else {
    pagCtrl.style.display = filtered.length > 0 ? 'flex' : 'none';
    document.getElementById('pageInfo').textContent = `${filtered.length} items`;
    document.getElementById('prevPageBtn').disabled = true;
    document.getElementById('nextPageBtn').disabled = true;
  }

  tbody.innerHTML = pageItems.map((item, i) => {
    const realIdx = startIdx + i;
    const url = item.url || (item.itemNumber ? `https://www.ebay.${domain}/itm/${item.itemNumber}` : '#');
    const soldDisplay = item.sold ? item.sold.toLocaleString() : (item.soldText || '-');
    const qtyDisplay = item.qty ? item.qty.toLocaleString() : '-';
    const watchDisplay = item.watchers ? item.watchers.toLocaleString() : '-';
    return `<tr>
      <td class="col-check"><input type="checkbox" class="row-check" data-index="${realIdx}"></td>
      <td class="col-img">${item.image ? `<img src="${item.image}" loading="lazy">` : ''}</td>
      <td class="col-title"><a href="${url}" target="_blank">${item.title || '-'}</a></td>
      <td class="col-price">${item.price != null ? '£' + item.price.toFixed(2) : '-'}</td>
      <td class="col-seller">${item.seller || '-'}</td>
      <td class="col-sold">${soldDisplay}</td>
      <td class="col-qty">${qtyDisplay}</td>
      <td class="col-watch">${watchDisplay}</td>
      <td class="col-actions">
        <button class="action-btn btn-amazon" data-idx="${realIdx}">Amazon</button>
        <button class="action-btn btn-copy" data-idx="${realIdx}">Copy</button>
      </td>
    </tr>`;
  }).join('');
}

// ═══════════════════════════════════════
// ACTIONS
// ═══════════════════════════════════════
window.searchAmazon = function(idx) {
  const item = items[idx];
  if (!item) return;
  let q = item.title || '';
  if (q.length > 80) q = q.substring(0, q.lastIndexOf(' ', 80));
  chrome.storage.local.get('hunter_domain', (r) => {
    const domain = r.hunter_domain || 'co.uk';
    chrome.runtime.sendMessage({
      type: 'search-on-amazon',
      searchQuery: q,
      options: { isTabActive: true, sort: 'reviews', domain },
      itemData: item,
    });
  });
};

window.copyItem = function(idx) {
  const item = items[idx];
  if (!item) return;
  navigator.clipboard.writeText(JSON.stringify(item, null, 2));
};

function exportCSV() {
  if (!items.length) return;
  const rows = [['Title', 'Price', 'Seller', 'Sold', 'Qty', 'Watchers', 'Shipping', 'Item Number', 'Image', 'URL'].join(',')];
  items.forEach(item => {
    rows.push([
      '"' + (item.title || '').replace(/"/g, '""') + '"',
      item.price || '',
      '"' + (item.seller || '') + '"',
      item.sold || '',
      item.qty || '',
      item.watchers || '',
      '"' + (item.shipping || '').replace(/"/g, '""') + '"',
      item.itemNumber || '',
      item.image || '',
      item.url || '',
    ].join(','));
  });
  const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'unicornds_competitor_scan_' + new Date().toISOString().slice(0, 10) + '.csv';
  a.click();
}

function sendToBulkLister() {
  // Get selected items or all if none selected
  const selected = document.querySelectorAll('.row-check:checked');
  let list = selected.length ? Array.from(selected).map(cb => items[parseInt(cb.dataset.index)]) : items;

  // Collect eBay item URLs
  const urls = list.map(i => i.url).filter(Boolean);
  if (!urls.length) { alert('No items with URLs to send.'); return; }

  // Store URLs for bulk lister to pick up
  chrome.storage.local.set({ bulk_lister_urls: urls }, () => {
    console.log('[UnicornDS] Scanner: sent', urls.length, 'URLs to Bulk Lister');
    // Open bulk lister
    chrome.runtime.sendMessage({ type: 'openBulkLister' });
  });
}

function sendToHunter() {
  const selected = document.querySelectorAll('.row-check:checked');
  let list = selected.length ? Array.from(selected).map(cb => items[parseInt(cb.dataset.index)]) : items;
  const titles = list.map(i => {
    let t = i.title || '';
    if (t.length > 80) t = t.substring(0, t.lastIndexOf(' ', 80));
    return t;
  }).filter(Boolean);
  if (!titles.length) return;
  chrome.storage.local.set({ hunter_terms: titles });
  chrome.runtime.sendMessage({ type: 'openProductHunter' });
}

function clearResults() {
  if (!confirm('Clear all scanned items?')) return;
  items = [];
  saveItems();
  renderResults();
}
