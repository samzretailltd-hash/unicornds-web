    // ═══════════════════════════════════════
    // REVOLUT PAYMENT LINKS
    // Replace these with your actual Revolut payment link URLs
    // ═══════════════════════════════════════
    const PAYMENT_LINKS = {
      starter_monthly:  'https://checkout.revolut.com/pay/16f2e850-7c62-401c-b3ca-6e04393c4662',
      starter_annual:   'https://checkout.revolut.com/pay/71cbbe09-f034-4d30-8e79-cd63cb4a38f1',
      growth_monthly:   'https://checkout.revolut.com/pay/844d5b5b-1a88-4b26-8905-e2a31818d9b5',
      growth_annual:    'https://checkout.revolut.com/pay/23f8c251-f608-49aa-be38-554027c34c0e',
      empire_monthly:   'https://checkout.revolut.com/pay/9fd277e9-b27f-4861-b119-59ac406d6a12',
      empire_annual:    'https://checkout.revolut.com/pay/132e796b-84d7-4e5e-b2ca-8efa22e5fabc',
    };

    const PLANS = [
      {
        id: 'free', name: 'Free', monthly: 0, annual: 0,
        listings: '10 listings/month',
        features: [
          { text: 'Single lister (Amazon + AliExpress)', status: 'yes' },
          { text: 'eBay research buttons (basic)', status: 'yes' },
          { text: 'Product Hunter (3 searches/day)', status: 'ltd' },
          { text: 'Competitor Scanner', status: 'no' },
          { text: 'Stock Checker', status: 'no' },
          { text: 'Bulk Lister', status: 'no' },
          { text: 'AI titles', status: 'no' },
          { text: 'Image Designer', status: 'no' },
          { text: 'Tracker + Send Offers', status: 'no' },
        ],
      },
      {
        id: 'starter', name: 'Starter', monthly: 29.99, annual: 287.88,
        listings: '500 listings/month',
        features: [
          { text: 'Everything in Free, plus:', status: 'yes' },
          { text: 'Product Hunter (unlimited)', status: 'yes' },
          { text: 'All eBay research buttons', status: 'yes' },
          { text: 'Extract titles + CSV export', status: 'yes' },
          { text: 'Competitor Scanner (5/day)', status: 'ltd' },
          { text: 'Stock Checker (20/day)', status: 'ltd' },
          { text: 'Bulk Lister (1 tab)', status: 'ltd' },
          { text: 'AI titles', status: 'no' },
          { text: 'Image Designer', status: 'no' },
        ],
      },
      {
        id: 'growth', name: 'Growth', monthly: 59.99, annual: 575.88,
        listings: '1,500 listings/month', popular: true,
        features: [
          { text: 'Everything in Starter, plus:', status: 'yes' },
          { text: 'Bulk Lister (5 concurrent)', status: 'yes' },
          { text: 'AI titles (GPT-4o)', status: 'yes' },
          { text: 'Competitor Scanner (unlimited)', status: 'yes' },
          { text: 'Stock Checker (unlimited)', status: 'yes' },
          { text: 'Image Designer', status: 'yes' },
          { text: 'Tracker + Send Offers', status: 'yes' },
          { text: 'VERO protection', status: 'yes' },
          { text: 'Hunt speed (3 concurrent tabs)', status: 'yes' },
        ],
      },
      {
        id: 'empire', name: 'Empire', monthly: 99.99, annual: 959.88,
        listings: '3,000 listings/month',
        features: [
          { text: 'Everything in Growth, plus:', status: 'yes' },
          { text: 'Bulk Lister (10 concurrent)', status: 'yes' },
          { text: 'Hunt speed (5 concurrent tabs)', status: 'yes' },
          { text: 'MSKU builder', status: 'yes' },
          { text: 'Purchase history checker', status: 'yes' },
          { text: 'Auto-order pipeline', status: 'yes' },
          { text: 'Multi-account support', status: 'yes' },
          { text: 'Priority AI (faster)', status: 'yes' },
          { text: 'Priority support', status: 'yes' },
        ],
      },
    ];

    let isAnnual = false;
    let currentTier = 'free';

    // Load user's current tier
    // Render immediately with default (free)
    renderPlans();

    // Then try to load actual tier from storage
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(null, (data) => {
        // Try multiple possible keys for tier
        const tier = data.unicornds_user_tier
          || data.unicornds_membership
          || (data.user && data.user.tier)
          || 'free';

        // Map old tier names to new
        const tierMap = { ultimate: 'empire', pro: 'growth', paid: 'starter' };
        currentTier = tierMap[tier] || tier;

        document.getElementById('currentTierLabel').textContent =
          currentTier.charAt(0).toUpperCase() + currentTier.slice(1);

        if (data.unicornds_usage) {
          const u = data.unicornds_usage;
          document.getElementById('usageLabel').textContent =
            ' - ' + (u.listings_this_month || 0) + ' listings used this month';
        }
        renderPlans(); // Re-render with actual tier
      });
    }

    // Toggle billing
    document.getElementById('billingToggle').addEventListener('click', () => {
      isAnnual = !isAnnual;
      document.getElementById('toggleSwitch').classList.toggle('on', isAnnual);
      document.getElementById('monthlyLabel').classList.toggle('active', !isAnnual);
      document.getElementById('annualLabel').classList.toggle('active', isAnnual);
      renderPlans();
    });

    function renderPlans() {
      const grid = document.getElementById('plansGrid');
      grid.innerHTML = PLANS.map(plan => {
        const isCurrent = plan.id === currentTier;
        const price = isAnnual ? (plan.annual / 12).toFixed(2) : plan.monthly.toFixed(2);
        const annualTotal = isAnnual ? plan.annual.toFixed(2) : '';
        const paymentKey = plan.id + '_' + (isAnnual ? 'annual' : 'monthly');
        const paymentUrl = PAYMENT_LINKS[paymentKey] || '';

        const currentIdx = PLANS.findIndex(p => p.id === currentTier);
        const planIdx = PLANS.findIndex(p => p.id === plan.id);
        const isUpgrade = planIdx > currentIdx;
        const isDowngrade = planIdx < currentIdx;

        let btnClass = 'primary';
        let btnText = 'Upgrade to ' + plan.name;
        let btnDisabled = false;

        if (isCurrent) {
          btnClass = 'current'; btnText = '✓ Current Plan'; btnDisabled = true;
        } else if (plan.id === 'free' && !isCurrent) {
          btnClass = 'downgrade'; btnText = 'Downgrade to Free';
        } else if (isDowngrade) {
          btnClass = 'downgrade'; btnText = 'Switch to ' + plan.name;
        } else if (plan.id === 'empire') {
          btnClass = 'gold'; btnText = 'Go Empire 👑';
        }

        const icons = { yes: '✓', no: '✗', ltd: '~' };

        return `
          <div class="card ${plan.popular ? 'popular' : ''} ${isCurrent ? 'active' : ''}">
            <h2>${plan.name}</h2>
            <div class="price">
              ${plan.monthly === 0 ? 'Free' : '£' + price + '<small>/mo</small>'}
            </div>
            <div class="annual-price">
              ${isAnnual && plan.annual > 0 ? '£' + annualTotal + '/year' : ''}
            </div>
            <div class="listings">${plan.listings}</div>
            <ul class="features">
              ${plan.features.map(f => `
                <li>
                  <span class="ck ${f.status}">${icons[f.status]}</span>
                  <span>${f.text}</span>
                </li>
              `).join('')}
            </ul>
            <button
              class="btn-upgrade ${btnClass}"
              ${btnDisabled ? 'disabled' : ''}
              ${paymentUrl && !btnDisabled ? 'data-url="' + paymentUrl + '"' : ''}
              data-plan="${plan.id}"
              data-action="${isCurrent ? 'current' : isDowngrade ? 'downgrade' : 'upgrade'}"
            >${btnText}</button>
          </div>
        `;
      }).join('');
    }

    // Event delegation for upgrade buttons
    document.getElementById('plansGrid').addEventListener('click', (e) => {
      const btn = e.target.closest('.btn-upgrade');
      if (!btn || btn.disabled) return;

      const url = btn.dataset.url;
      const plan = btn.dataset.plan;
      const action = btn.dataset.action;

      if (plan === 'free') {
        if (confirm('Are you sure you want to downgrade to Free?\n\nYour current plan features will remain active until the end of your billing period.\n\nTo cancel, please email: support@unicornds.io')) {
          alert('Please email support@unicornds.io to process your cancellation.');
        }
        return;
      }

      if (action === 'downgrade') {
        if (!confirm('Switch to ' + plan.charAt(0).toUpperCase() + plan.slice(1) + '?\n\nYour new plan will start from your next billing date.')) {
          return;
        }
      }

      if (!url) {
        alert('Payment link not available. Please contact support.');
        return;
      }

      window.open(url, '_blank');
    });
