// ──────────────────────────────────────────────────────────
// UPDATED PAGE CONTROLLER - Handles AliExpress + Amazon SKUs
// ──────────────────────────────────────────────────────────

const SKU = window.AliexpressSKUManager;

// ── Tab switching ──────────────────────────────────────
document.querySelectorAll('.source-tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.source-tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.panel).classList.add('active');
  });
});

// ── Helpers ────────────────────────────────────────────
function getSKUList() {
  return document.getElementById('skus').value
    .split('\n').map((s) => s.trim()).filter(Boolean);
}

function updateStats(skuList) {
  const ali  = skuList.filter((s) => SKU?.isAliexpressSKU(s)).length;
  const ama  = skuList.filter((s) => SKU?.isAmazonSKU(s)).length;
  const dupes = SKU ? SKU.findDuplicateSKUs(skuList).duplicateCount : 0;

  document.getElementById('statTotal').textContent  = skuList.length;
  document.getElementById('statUnique').textContent = skuList.length - dupes;
  document.getElementById('statDupes').textContent  = dupes;
  document.getElementById('statAli').textContent    = ali;
  document.getElementById('statAma').textContent    = ama;
  document.getElementById('total-skus').textContent = skuList.length;
}

// ── Remove duplicates ──────────────────────────────────
document.getElementById('remove-duplicates').addEventListener('click', () => {
  const skus   = getSKUList();
  const unique = [...new Set(skus.map((s) => s.toUpperCase()))];
  document.getElementById('skus').value = unique.join('\n');
  updateStats(unique);
});

// ── Import & find duplicates ───────────────────────────
document.getElementById('import-skus').addEventListener('click', () => {
  const imported = document.getElementById('add-skus').value
    .split('\n').map((s) => s.trim()).filter(Boolean);

  const existing = getSKUList();
  const all      = [...existing, ...imported];

  // Update main list
  document.getElementById('skus').value = all.join('\n');
  updateStats(all);

  if (!SKU) return;

  // Find duplicates
  const { duplicates, totalDupes } = SKU.findDuplicateSKUs(all);
  const dupeSKUs = Object.keys(duplicates);

  document.getElementById('duplicate-skus').value  = dupeSKUs.join('\n');
  document.getElementById('total-duplicate-skus').textContent = dupeSKUs.length;
  document.getElementById('duplicate-batch-total').textContent =
    Math.ceil(dupeSKUs.length / 10);
});

// ── Copy to clipboard ──────────────────────────────────
document.getElementById('save-skus').addEventListener('click', () => {
  const btn = document.getElementById('save-skus');
  navigator.clipboard.writeText(document.getElementById('skus').value);
  btn.textContent = '✅ Copied!';
  btn.classList.add('copied');
  setTimeout(() => { btn.textContent = '📋 Copy to Clipboard'; btn.classList.remove('copied'); }, 2000);
});

// ── Export dictionary CSV ──────────────────────────────
document.getElementById('export-dictionary')?.addEventListener('click', async () => {
  if (!SKU) return;
  const csv = await SKU.exportDictionaryAsCSV();
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `unicornds-dictionary-${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

// ── Open duplicates in eBay ────────────────────────────
document.getElementById('open-duplicate-skus-10')?.addEventListener('click', () => {
  const dupes  = document.getElementById('duplicate-skus').value.split('\n').filter(Boolean);
  const batch  = parseInt(document.getElementById('duplicate-batch-number').value) || 1;
  const start  = (batch - 1) * 10;
  const toOpen = dupes.slice(start, start + 10);

  toOpen.forEach((sku) => {
    const parsed = SKU?.parseSKU(sku);
    let url;
    if (parsed?.source === 'aliexpress') {
      url = `https://www.aliexpress.com/item/${parsed.productId}.html`;
    } else {
      url = `https://www.amazon.com/dp/${sku}`;
    }
    chrome.tabs.create({ url, active: false });
  });
});

// ── Converter: IDs → SKUs ──────────────────────────────
document.getElementById('convert-ids-to-skus')?.addEventListener('click', () => {
  if (!SKU) return;
  const input = document.getElementById('product-ids-input').value;
  const mkt   = document.getElementById('mkt-select').value;
  document.getElementById('product-ids-results').value =
    SKU.convertProductIdsToSKUs(input, mkt);
});

// ── Converter: SKUs → IDs ──────────────────────────────
document.getElementById('convert-skus-to-ids')?.addEventListener('click', () => {
  if (!SKU) return;
  const input = document.getElementById('skus-to-ids-input').value;
  document.getElementById('skus-to-ids-results').value =
    SKU.convertSKUsToProductIds(input);
});

// ── Converter: URLs → SKUs ─────────────────────────────
document.getElementById('convert-urls-to-skus')?.addEventListener('click', () => {
  if (!SKU) return;
  const mkt = document.getElementById('mkt-select').value;
  const lines = document.getElementById('urls-input').value.split('\n').filter(Boolean);
  document.getElementById('urls-results').value = lines
    .map((url) => SKU.urlToSKU(url.trim(), mkt) || `INVALID: ${url}`)
    .join('\n');
});

// ── Amazon ASIN validator ──────────────────────────────
document.getElementById('convert-asins-to-skus')?.addEventListener('click', () => {
  const lines = document.getElementById('asins-to-skus').value.split('\n').filter(Boolean);
  document.getElementById('asins-to-skus-results').value = lines.map((line) => {
    const asin = line.trim().toUpperCase();
    return SKU?.isAmazonSKU(asin)
      ? `✅ ${asin} - valid Amazon ASIN (use as-is for eBay SKU)`
      : `❌ ${asin} - not a valid Amazon ASIN`;
  }).join('\n');
});

// ── Dictionary stats ───────────────────────────────────
async function loadDictionaryStats() {
  if (!SKU) return;
  const stats = await SKU.getDictionaryStats();
  const panel = document.getElementById('dictionaryStatsPanel');
  panel.innerHTML = `
    <div style="display:flex; gap:12px; flex-wrap:wrap; font-size:13px;">
      <span>📦 <strong>${stats.total}</strong> total SKUs</span>
      <span>🔴 <strong>${stats.aliexpress}</strong> AliExpress</span>
      <span>🟠 <strong>${stats.amazon}</strong> Amazon</span>
      <span style="color:#28a745;">✅ <strong>${stats.listedOnEbay}</strong> listed on eBay</span>
      <span style="color:#d97706;">⏳ <strong>${stats.notYetListed}</strong> not yet listed</span>
    </div>
    <div style="margin-top:8px; font-size:12px; color:#888;">
      By marketplace: ${Object.entries(stats.byMarketplace).map(([k,v]) => `${k}: ${v}`).join(' | ') || 'none'}
    </div>
  `;
}

document.getElementById('refreshStats')?.addEventListener('click', loadDictionaryStats);

// ── Dictionary search ──────────────────────────────────
document.getElementById('dictSearchBtn')?.addEventListener('click', async () => {
  if (!SKU) return;
  const query  = document.getElementById('dictSearch').value.trim();
  const result = document.getElementById('dictSearchResult');

  // Try direct SKU lookup
  let entry = await SKU.lookupSKU(query);

  // If not found, try productId lookup
  if (!entry) {
    const byId = await SKU.lookupByProductId(query);
    if (byId.length > 0) {
      result.innerHTML = `<strong>${byId.length} entries found for Product ID ${query}:</strong><br>` +
        byId.map((e) => `
          <div style="margin:6px 0; padding:8px; background:#f9f9f9; border-radius:4px;">
            <strong>${e.sku}</strong> - ${e.cleanedTitle || e.title || '-'}<br>
            <span style="font-size:11px; color:#888;">
              Listed: ${e.ebayListingId || 'Not yet'} |
              eBay price: ${e.ebayPrice ? '$'+e.ebayPrice : '-'} |
              Added: ${e.dateAdded?.slice(0,10) || '-'}
            </span>
          </div>
        `).join('');
      return;
    }
    result.innerHTML = `<span style="color:#888;">No entry found for: ${query}</span>`;
    return;
  }

  result.innerHTML = `
    <div style="padding:10px; background:#f0fff4; border:1px solid #b2dfdb; border-radius:6px;">
      <strong>${entry.sku}</strong><br>
      <table style="font-size:12px; margin-top:8px; border-collapse:collapse;">
        ${[
          ['Source',       entry.source],
          ['Product ID',   entry.productId],
          ['Marketplace',  entry.marketplace],
          ['Variant',      entry.variantValue || 'N/A'],
          ['Title',        entry.cleanedTitle || entry.title || '-'],
          ['Ali Price',    entry.aliexpressPrice ? '$'+entry.aliexpressPrice : '-'],
          ['eBay Listing', entry.ebayListingId || 'Not listed yet'],
          ['eBay Price',   entry.ebayPrice ? '$'+entry.ebayPrice : '-'],
          ['Added',        entry.dateAdded?.slice(0,10) || '-'],
        ].map(([k,v]) => `<tr><td style="padding:2px 12px 2px 0; color:#888;">${k}</td><td>${v}</td></tr>`).join('')}
      </table>
      ${entry.aliexpressUrl ? `<a href="${entry.aliexpressUrl}" target="_blank" style="font-size:11px;">View on AliExpress ↗</a>` : ''}
    </div>
  `;
});

document.getElementById('clearDictBtn')?.addEventListener('click', async () => {
  if (!confirm('Clear the entire SKU dictionary? This cannot be undone.')) return;
  await chrome.storage.local.remove('unicornds_sku_dictionary');
  loadDictionaryStats();
});

// ── Init ────────────────────────────────────────────────
loadDictionaryStats();

// ── Start Scanning — scrapes SKUs from eBay Seller Hub Active Listings ──
document.getElementById('fetch-skus').addEventListener('click', async () => {
  const btn = document.getElementById('fetch-skus');
  const pageNum = parseInt(document.getElementById('page-number').value) || 1;
  const perPage = parseInt(document.getElementById('results-per-page-select').value) || 200;

  btn.textContent = '⏳ Scanning...';
  btn.disabled = true;

  try {
    // Find eBay Seller Hub tab
    const tabs = await chrome.tabs.query({ url: '*://*.ebay.*/sh/lst/active*' });
    let targetTab = tabs[0];

    if (!targetTab) {
      // Try broader eBay match
      const allEbayTabs = await chrome.tabs.query({ url: '*://*.ebay.*/*' });
      targetTab = allEbayTabs.find(t =>
        t.url.includes('/sh/lst') || t.url.includes('/sh/ovw') || t.url.includes('seller')
      );
    }

    if (!targetTab) {
      alert('Please open your eBay Seller Hub Active Listings page first, then try again.\n\nGo to: eBay → Seller Hub → Listings → Active');
      btn.textContent = '▶ Start Scanning';
      btn.disabled = false;
      return;
    }

    // Navigate to correct page with results per page
    const baseUrl = targetTab.url.split('?')[0];
    const newUrl = `${baseUrl}?limit=${perPage}&offset=${(pageNum - 1) * perPage}`;
    await chrome.tabs.update(targetTab.id, { url: newUrl });

    // Wait for page to load
    await new Promise(resolve => setTimeout(resolve, 4000));

    // Inject scraping script
    const results = await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      func: () => {
        const skus = [];

        // Method 1: Table rows with Custom Label column
        const rows = document.querySelectorAll(
          'tr[data-test-id], .sh-tbl__row, [class*="listing-row"], tbody tr'
        );

        rows.forEach(row => {
          // Look for custom label/SKU in the row
          const cells = row.querySelectorAll('td, [class*="cell"]');
          cells.forEach(cell => {
            const text = cell.textContent.trim();
            // Match Amazon ASINs (B0...) or AliExpress IDs (AE-...)
            if (/^B0[A-Z0-9]{8,}$/i.test(text)) {
              skus.push(text.toUpperCase());
            } else if (/^AE-/i.test(text)) {
              skus.push(text);
            }
          });

          // Also check data attributes
          const sku = row.getAttribute('data-sku') || row.getAttribute('data-custom-label') || '';
          if (sku && (sku.startsWith('B0') || sku.startsWith('AE-'))) {
            skus.push(sku);
          }
        });

        // Method 2: Look for SKU labels directly
        if (skus.length === 0) {
          const allText = document.body.innerText;
          const asinMatches = allText.match(/\bB0[A-Z0-9]{8,}\b/g) || [];
          const aeMatches = allText.match(/\bAE-\d+-\d+(?:-\d+)?\b/g) || [];
          skus.push(...asinMatches, ...aeMatches);
        }

        // Method 3: Check listing detail links for custom label info
        document.querySelectorAll('[class*="custom-label"], [class*="customLabel"], [class*="sku"]').forEach(el => {
          const text = el.textContent.trim();
          if (text) skus.push(text);
        });

        return [...new Set(skus)];
      }
    });

    const skus = results[0]?.result || [];
    const textarea = document.getElementById('skus');
    const existing = textarea.value.split('\n').filter(Boolean);
    const allSkus = [...new Set([...existing, ...skus])];

    textarea.value = allSkus.join('\n');
    updateStats(allSkus);

    // Save to storage for duplicate detection across extension
    chrome.storage.local.set({ unicornds_listed_skus: allSkus });

    btn.textContent = `✅ Found ${skus.length} SKUs (page ${pageNum})`;
    setTimeout(() => { btn.textContent = '▶ Start Scanning'; }, 3000);

  } catch (err) {
    console.error('[UnicornDS] Scan error:', err);
    btn.textContent = '❌ Scan failed — check console';
    setTimeout(() => { btn.textContent = '▶ Start Scanning'; }, 3000);
  }

  btn.disabled = false;
});

// ── From File Exchange — paste CSV from eBay File Exchange download ──
document.getElementById('fetch-skus-from-file-exchange').addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.csv,.txt,.tsv';
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const text = await file.text();
    const lines = text.split('\n');
    const skus = [];

    // Find Custom Label / SKU column
    const header = lines[0]?.toLowerCase() || '';
    const cols = header.split(/[,\t]/);
    let skuCol = cols.findIndex(c => c.includes('custom label') || c.includes('sku') || c.includes('customlabel'));

    if (skuCol === -1) {
      // Try to find ASINs/AE-IDs anywhere in the file
      for (const line of lines) {
        const asinMatches = line.match(/\bB0[A-Z0-9]{8,}\b/gi) || [];
        const aeMatches = line.match(/\bAE-\d+-\d+(?:-\d+)?\b/gi) || [];
        skus.push(...asinMatches.map(s => s.toUpperCase()), ...aeMatches);
      }
    } else {
      for (let i = 1; i < lines.length; i++) {
        const cells = lines[i].split(/[,\t]/);
        const sku = cells[skuCol]?.trim().replace(/^["']|["']$/g, '');
        if (sku) skus.push(sku);
      }
    }

    const unique = [...new Set(skus)];
    const textarea = document.getElementById('skus');
    const existing = textarea.value.split('\n').filter(Boolean);
    const allSkus = [...new Set([...existing, ...unique])];

    textarea.value = allSkus.join('\n');
    updateStats(allSkus);
    chrome.storage.local.set({ unicornds_listed_skus: allSkus });

    alert(`Imported ${unique.length} SKUs from file.`);
  };
  input.click();
});

// ── Clear SKUs ──────────────────────────────────────────
document.getElementById('clear-skus').addEventListener('click', () => {
  document.getElementById('skus').value = '';
  updateStats([]);
});