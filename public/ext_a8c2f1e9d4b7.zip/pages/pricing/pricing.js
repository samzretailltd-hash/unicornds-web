// Pricing Settings Panel - UI Controller
// Connects to window.AliexpressPricing from aliexpress_pricing.js

(function () {
  const pricing = window.AliexpressPricing;
  if (!pricing) {
    console.error('[UnicornDS] AliexpressPricing not loaded');
    return;
  }

  const fields = {
    markupMultiplier:  document.getElementById('markupMultiplier'),
    minProfitMargin:   document.getElementById('minProfitMargin'),
    roundingStyle:     document.getElementById('roundingStyle'),
    hasEbayStore:      document.getElementById('hasEbayStore'),
    shippingCostToYou: document.getElementById('shippingCostToYou'),
    returnCostBuffer:  document.getElementById('returnCostBuffer'),
    vatRate:           document.getElementById('vatRate'),
  };

  const previewPrice   = document.getElementById('previewAliPrice');
  const previewResult  = document.getElementById('pricingPreviewResult');
  const saveBtn        = document.getElementById('savePricingBtn');
  const resetBtn       = document.getElementById('resetPricingBtn');
  const saveStatus     = document.getElementById('pricingSaveStatus');

  // ── Load saved settings on open ──────────────────────
  pricing.loadPricingSettings().then((settings) => {
    fields.markupMultiplier.value  = settings.markupMultiplier;
    fields.minProfitMargin.value   = settings.minProfitMargin;
    fields.roundingStyle.value     = settings.roundingStyle;
    fields.hasEbayStore.checked    = settings.hasEbayStore;
    fields.shippingCostToYou.value = settings.shippingCostToYou;
    fields.returnCostBuffer.value  = settings.returnCostBuffer;
    fields.vatRate.value           = settings.vatRate;
    updatePreview();
  });

  // ── Live preview updates ──────────────────────────────
  function getFormSettings() {
    return {
      markupMultiplier:  parseFloat(fields.markupMultiplier.value),
      minProfitMargin:   parseFloat(fields.minProfitMargin.value),
      roundingStyle:     fields.roundingStyle.value,
      hasEbayStore:      fields.hasEbayStore.checked,
      shippingCostToYou: parseFloat(fields.shippingCostToYou.value) || 0,
      returnCostBuffer:  parseFloat(fields.returnCostBuffer.value)  || 0,
      vatRate:           parseFloat(fields.vatRate.value)            || 0,
    };
  }

  function updatePreview() {
    const aliPrice = parseFloat(previewPrice.value);
    if (!aliPrice || aliPrice <= 0) {
      previewResult.innerHTML = '';
      return;
    }
    try {
      const result = pricing.calculatePrice(aliPrice, 'com', getFormSettings());
      previewResult.innerHTML = `
        <strong>List at: ${result.formattedPrice}</strong> &nbsp;|&nbsp;
        Profit: $${result.netProfit.toFixed(2)} &nbsp;|&nbsp;
        Margin: <span style="color:${result.meetsMinMargin ? '#28a745' : '#dc3545'}">
          ${result.profitMargin.toFixed(1)}%
        </span>
        ${result.warnings.length ? `<br><span style="color:#856404">⚠️ ${result.warnings[0]}</span>` : ''}
      `;
    } catch (e) {
      previewResult.textContent = 'Enter a valid price to preview';
    }
  }

  Object.values(fields).forEach((el) => el.addEventListener('input', updatePreview));
  previewPrice.addEventListener('input', updatePreview);

  // ── Save ─────────────────────────────────────────────
  saveBtn.addEventListener('click', async () => {
    try {
      await pricing.savePricingSettings(getFormSettings());
      showStatus('✅ Settings saved!', 'success');
    } catch (err) {
      showStatus('❌ Save failed: ' + err.message, 'error');
    }
  });

  // ── Reset to defaults ─────────────────────────────────
  resetBtn.addEventListener('click', () => {
    const d = pricing.DEFAULT_SETTINGS;
    fields.markupMultiplier.value  = d.markupMultiplier;
    fields.minProfitMargin.value   = d.minProfitMargin;
    fields.roundingStyle.value     = d.roundingStyle;
    fields.hasEbayStore.checked    = d.hasEbayStore;
    fields.shippingCostToYou.value = d.shippingCostToYou;
    fields.returnCostBuffer.value  = d.returnCostBuffer;
    fields.vatRate.value           = d.vatRate;
    updatePreview();
    showStatus('↩️ Reset to defaults', 'success');
  });

  function showStatus(msg, type) {
    saveStatus.textContent = msg;
    saveStatus.className   = `save-status ${type}`;
    setTimeout(() => { saveStatus.className = 'save-status hidden'; }, 3000);
  }
})();