/**
 * UnicornDS - Product Hunter
 * Amazon product research tool for eBay sellers
 * Modelled on 's Product Finder architecture
 */

console.log('[UnicornDS] Product Hunter loaded');

// ═══════════════════════════════════════
// STATE
// ═══════════════════════════════════════
let products = [];
let isRunning = false;
let huntPosition = 0;
let concurrency = 1;
let priceSortAsc = true;
let reviewSortAsc = false;
let lastProcessedCount = 0; // legacy, kept for compat
let lastTermComplete = 0;
let processedBatches = new Set();

// ═══════════════════════════════════════
// INIT - Load saved state
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  const data = await chrome.storage.local.get([
    'hunter_products', 'hunter_position', 'hunter_terms',
    'hunter_domain', 'hunter_minPrice', 'hunter_maxPrice',
    'hunter_minReviews', 'hunter_maxReviews', 'hunter_productsPerTerm',
    'hunter_concurrency', 'hunter_sortBy', 'hunter_primeOnly', 'hunter_amazonIsSeller',
    'hunter_prioritizeChoice', 'hunter_prioritizeBestSeller',
    'hunter_removeBooks', 'hunter_veroProtection', 'hunter_duplicateProtection',
    'hunter_restrictedWords', 'hunter_minStock'
  ]);

  // Restore products
  if (data.hunter_products && data.hunter_products.length) {
    products = data.hunter_products;
    renderResults();
  }

  // Restore position
  huntPosition = data.hunter_position || 0;

  // Restore search terms
  if (data.hunter_terms && data.hunter_terms.length) {
    document.getElementById('searchTerms').value = data.hunter_terms.join('\n');
  }
  updateTermCount();

  // Restore settings
  if (data.hunter_domain) document.getElementById('amazonDomain').value = data.hunter_domain;
  if (data.hunter_minPrice != null) document.getElementById('minPrice').value = data.hunter_minPrice;
  if (data.hunter_maxPrice != null) document.getElementById('maxPrice').value = data.hunter_maxPrice;
  if (data.hunter_minReviews != null) document.getElementById('minReviews').value = data.hunter_minReviews;
  if (data.hunter_maxReviews != null) document.getElementById('maxReviews').value = data.hunter_maxReviews;
  if (data.hunter_productsPerTerm != null) document.getElementById('productsPerTerm').value = data.hunter_productsPerTerm;
  if (data.hunter_sortBy) document.getElementById('sortBy').value = data.hunter_sortBy;
  if (data.hunter_primeOnly != null) document.getElementById('primeOnly').checked = data.hunter_primeOnly;
  if (data.hunter_amazonIsSeller != null) document.getElementById('amazonIsSeller').checked = data.hunter_amazonIsSeller;
  if (data.hunter_prioritizeChoice != null) document.getElementById('prioritizeChoice').checked = data.hunter_prioritizeChoice;
  if (data.hunter_prioritizeBestSeller != null) document.getElementById('prioritizeBestSeller').checked = data.hunter_prioritizeBestSeller;
  if (data.hunter_removeBooks != null) document.getElementById('removeBooks').checked = data.hunter_removeBooks;
  if (data.hunter_veroProtection != null) document.getElementById('veroProtection').checked = data.hunter_veroProtection;
  if (data.hunter_duplicateProtection != null) document.getElementById('duplicateProtection').checked = data.hunter_duplicateProtection;
  if (data.hunter_restrictedWords) document.getElementById('restrictedWords').value = data.hunter_restrictedWords.join('\n');
  if (data.hunter_minStock != null) document.getElementById('minStock').value = data.hunter_minStock;

  // Restore concurrency
  concurrency = data.hunter_concurrency || 1;
  document.querySelectorAll('.thread-btn').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.threads) === concurrency);
  });

  // Setup event listeners
  setupListeners();
});

// ═══════════════════════════════════════
// EVENT LISTENERS
// ═══════════════════════════════════════
function setupListeners() {
  // Search terms
  document.getElementById('searchTerms').addEventListener('input', () => {
    updateTermCount();
    saveTerms();
  });

  // Hunt controls
  document.getElementById('huntBtn').addEventListener('click', startHunt);
  document.getElementById('pauseBtn').addEventListener('click', pauseHunt);
  document.getElementById('resumeBtn').addEventListener('click', resumeHunt);
  document.getElementById('stopBtn').addEventListener('click', stopHunt);

  // Thread selector
  document.querySelectorAll('.thread-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.thread-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      concurrency = parseInt(btn.dataset.threads);
      chrome.storage.local.set({ hunter_concurrency: concurrency });
    });
  });

  // Settings auto-save
  const settingIds = [
    'amazonDomain', 'minPrice', 'maxPrice', 'minReviews', 'maxReviews',
    'productsPerTerm', 'sortBy', 'primeOnly', 'amazonIsSeller', 'prioritizeChoice',
    'prioritizeBestSeller', 'removeBooks', 'veroProtection',
    'duplicateProtection', 'restrictedWords'
  ];
  settingIds.forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener('change', saveSettings);
    if (el.type === 'text' || el.tagName === 'TEXTAREA') {
      el.addEventListener('input', saveSettings);
    }
  });

  // Results actions
  document.getElementById('exportCsvBtn').addEventListener('click', exportCSV);
  document.getElementById('transferBulkBtn').addEventListener('click', transferToBulk);
  document.getElementById('clearResultsBtn').addEventListener('click', clearResults);
  document.getElementById('selectAll').addEventListener('change', toggleSelectAll);

  // Results filtering/sorting
  document.getElementById('filterResults').addEventListener('input', renderResults);
  document.getElementById('sortPriceBtn').addEventListener('click', () => {
    products.sort((a, b) => priceSortAsc ? a.price - b.price : b.price - a.price);
    priceSortAsc = !priceSortAsc;
    renderResults();
  });
  document.getElementById('sortReviewsBtn').addEventListener('click', () => {
    products.sort((a, b) => reviewSortAsc ? a.reviewCount - b.reviewCount : b.reviewCount - a.reviewCount);
    reviewSortAsc = !reviewSortAsc;
    renderResults();
  });

  // C2: VERO filter toggle
  document.getElementById('veroFilter').addEventListener('change', renderResults);

  // C1: Min stock apply (DESTRUCTIVE — permanently deletes items below threshold)
  document.getElementById('applyMinStockBtn').addEventListener('click', () => {
    const minVal = parseInt(document.getElementById('headerMinStock').value) || 0;
    if (minVal <= 0) return;
    const before = products.length;
    // Only delete items that have been verified AND are below threshold.
    // Unverified items (no stockInfo) are kept.
    products = products.filter(p => {
      if (!p.stockInfo) return true;  // not verified yet — keep
      return p.stockInfo.quantity >= minVal;
    });
    const removed = before - products.length;
    if (removed > 0) {
      console.log(`[UnicornDS] Min Stock filter: deleted ${removed} items below ${minVal} stock`);
      chrome.storage.local.set({ hunter_products: products });
      renderResults();
    } else {
      console.log('[UnicornDS] Min Stock filter: no items to remove');
    }
  });

  // C1: Sync header min stock ↔ settings min stock on load
  const settingsMinStock = document.getElementById('minStock');
  const headerMinStock = document.getElementById('headerMinStock');
  if (settingsMinStock && headerMinStock) {
    headerMinStock.value = settingsMinStock.value || '';
    settingsMinStock.addEventListener('change', () => { headerMinStock.value = settingsMinStock.value; });
    headerMinStock.addEventListener('change', () => { settingsMinStock.value = headerMinStock.value; saveSettings(); });
  }

  // Poll storage for new batch results (each batch has unique key)
  let processedBatches = new Set();

  setInterval(async () => {
    const allData = await chrome.storage.local.get(null);

    // Find all hunter_batch_* keys
    for (const key of Object.keys(allData)) {
      if (key.startsWith('hunter_batch_') && !processedBatches.has(key)) {
        processedBatches.add(key);
        const batch = allData[key];
        console.log('[UnicornDS] Hunter: processing batch', key, batch.products?.length, 'products');
        handleSearchResults(batch);
        // Clean up the batch key
        chrome.storage.local.remove(key);
      }
    }

    // Check for term complete
    const tc = allData.hunter_term_complete || 0;
    if (tc > lastTermComplete) {
      lastTermComplete = tc;
      onTermComplete();
    }
  }, 1000);
}

// ═══════════════════════════════════════
// SAVE / LOAD
// ═══════════════════════════════════════
function saveSettings() {
  chrome.storage.local.set({
    hunter_domain: document.getElementById('amazonDomain').value,
    hunter_minPrice: parseFloat(document.getElementById('minPrice').value) || 0,
    hunter_maxPrice: parseFloat(document.getElementById('maxPrice').value) || 100,
    hunter_minReviews: parseInt(document.getElementById('minReviews').value) || 0,
    hunter_maxReviews: parseInt(document.getElementById('maxReviews').value) || 100000,
    hunter_productsPerTerm: parseInt(document.getElementById('productsPerTerm').value) || 5,
    hunter_sortBy: document.getElementById('sortBy').value,
    hunter_primeOnly: document.getElementById('primeOnly').checked,
    hunter_amazonIsSeller: document.getElementById('amazonIsSeller').checked,
    hunter_prioritizeChoice: document.getElementById('prioritizeChoice').checked,
    hunter_prioritizeBestSeller: document.getElementById('prioritizeBestSeller').checked,
    hunter_removeBooks: document.getElementById('removeBooks').checked,
    hunter_veroProtection: document.getElementById('veroProtection').checked,
    hunter_duplicateProtection: document.getElementById('duplicateProtection').checked,
    hunter_restrictedWords: document.getElementById('restrictedWords').value.split('\n').filter(w => w.trim()),
    hunter_minStock: parseInt(document.getElementById('minStock').value) || 0,
  });
}

function saveTerms() {
  const terms = getTerms();
  chrome.storage.local.set({ hunter_terms: terms });
}

function saveProducts() {
  chrome.storage.local.set({ hunter_products: products });
}

function getTerms() {
  return document.getElementById('searchTerms').value
    .split('\n')
    .map(t => t.trim())
    .filter(t => t.length > 0);
}

function updateTermCount() {
  document.getElementById('totalTerms').textContent = getTerms().length;
}

// ═══════════════════════════════════════
// HUNT CONTROL
// ═══════════════════════════════════════
async function startHunt() {
  const terms = getTerms();
  if (!terms.length) {
    alert('Please enter at least one search term.');
    return;
  }

  isRunning = true;
  huntPosition = 0;
  updateButtons();
  saveSettings();
  saveTerms();

  // Clear old batch keys and reset
  chrome.storage.local.get(null, (allData) => {
    const keysToRemove = Object.keys(allData).filter(k => k.startsWith('hunter_batch_'));
    if (keysToRemove.length) chrome.storage.local.remove(keysToRemove);
  });
  chrome.storage.local.set({ hunter_term_complete: 0 });
  lastTermComplete = 0;
  if (typeof processedBatches !== 'undefined') processedBatches = new Set();

  document.getElementById('progressSection').style.display = 'block';
  activeHunts = 0;
  launchNextTerms(terms);
}

function pauseHunt() {
  isRunning = false;
  chrome.storage.local.set({ hunter_position: huntPosition });
  updateButtons();
}

function resumeHunt() {
  const terms = getTerms();
  if (huntPosition >= terms.length) {
    document.getElementById('currentTerm').textContent = 'Hunt complete!';
    return;
  }
  isRunning = true;
  activeHunts = 0;
  updateButtons();
  document.getElementById('progressSection').style.display = 'block';
  launchNextTerms(terms);
}

function stopHunt() {
  isRunning = false;
  huntPosition = 0;
  chrome.storage.local.set({ hunter_position: 0 });
  document.getElementById('progressSection').style.display = 'none';
  updateButtons();
}

function updateButtons() {
  document.getElementById('huntBtn').disabled = isRunning;
  document.getElementById('pauseBtn').disabled = !isRunning;
  document.getElementById('resumeBtn').disabled = isRunning;
  document.getElementById('stopBtn').disabled = !isRunning;
}

function updateProgress(current, total, term) {
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('progressLabel').textContent = `${current} / ${total}`;
  document.getElementById('currentTerm').textContent = term;
}

// ═══════════════════════════════════════
// HUNT PROCESSING (concurrent)
// ═══════════════════════════════════════
let activeHunts = 0;

function getHuntSettings() {
  return {
    domain: document.getElementById('amazonDomain').value,
    minPrice: parseFloat(document.getElementById('minPrice').value) || 0,
    maxPrice: parseFloat(document.getElementById('maxPrice').value) || 9999,
    minReviews: parseInt(document.getElementById('minReviews').value) || 0,
    maxReviews: parseInt(document.getElementById('maxReviews').value) || 100000,
    productsPerTerm: parseInt(document.getElementById('productsPerTerm').value) || 5,
    sortBy: document.getElementById('sortBy').value,
    primeOnly: document.getElementById('primeOnly').checked,
    amazonIsSeller: document.getElementById('amazonIsSeller').checked,
    removeBooks: document.getElementById('removeBooks').checked,
    veroProtection: document.getElementById('veroProtection').checked,
    duplicateProtection: document.getElementById('duplicateProtection').checked,
    restrictedWords: document.getElementById('restrictedWords').value.split('\n').filter(w => w.trim()),
    existingAsins: products.map(p => p.asin).filter(Boolean),
  };
}

function launchNextTerms(terms) {
  if (!isRunning) return;

  const settings = getHuntSettings();

  // Launch terms up to concurrency limit
  while (activeHunts < concurrency && huntPosition < terms.length) {
    const term = terms[huntPosition];
    huntPosition++;
    activeHunts++;

    updateProgress(huntPosition, terms.length, term);

    chrome.runtime.sendMessage({
      type: 'hunter_search',
      keyword: term,
      settings: settings,
    });
  }
}

function onTermComplete() {
  activeHunts = Math.max(0, activeHunts - 1);

  const terms = getTerms();
  if (isRunning && huntPosition < terms.length) {
    // Launch next term(s) to fill concurrency slots
    setTimeout(() => launchNextTerms(terms), 800 + Math.random() * 700);
  } else if (activeHunts === 0) {
    // All done
    isRunning = false;
    updateButtons();
    document.getElementById('currentTerm').textContent = 'Hunt complete!';
    chrome.storage.local.set({ hunter_position: huntPosition });
  }
}

// ═══════════════════════════════════════
// VERO BRAND LIST
// ═══════════════════════════════════════
let veroBrands = [];

async function loadVeroList() {
  try {
    // Always load fresh from file to ensure clean data (no \r issues)
    const resp = await fetch(chrome.runtime.getURL('data/VeroList.txt'));
    const text = await resp.text();
    veroBrands = text.replace(/\r/g, '').split('\n').map(b => b.trim().toLowerCase()).filter(Boolean);
    chrome.storage.local.set({ unicornds_vero_brands: veroBrands });
    console.log('[UnicornDS] Loaded', veroBrands.length, 'VERO brands');
  } catch (e) {
    // Fallback to cache if fetch fails
    try {
      const cached = await new Promise(r => chrome.storage.local.get('unicornds_vero_brands', s => r(s.unicornds_vero_brands)));
      if (cached && cached.length) veroBrands = cached.map(b => b.replace(/\r/g, ''));
    } catch (e2) { /* ignore */ }
    console.warn('[UnicornDS] VERO list load error:', e);
  }
}

function checkVero(title) {
  if (!veroBrands.length || !title) return false;
  const lower = title.toLowerCase().replace(/[-–—]/g, ' ').replace(/\s+/g, ' ');
  const titleNoDash = title.toLowerCase().replace(/\s+/g, '');

  // Accessory signals — if title says "for GoPro" or "compatible with Nike", it's an accessory, not counterfeit
  const accessoryWords = [
    'for', 'fits', 'compatible', 'works with', 'suitable for', 'designed for',
    'mount', 'case', 'cover', 'strap', 'band', 'holder', 'stand', 'bracket',
    'bag', 'pouch', 'sleeve', 'skin', 'protector', 'guard', 'bumper',
    'cable', 'charger', 'adapter', 'dock', 'cradle', 'hub',
    'replacement', 'aftermarket', 'generic', 'third party', 'oem',
    'screen protector', 'tempered glass', 'film', 'sticker', 'decal',
    'tripod', 'selfie stick', 'gimbal', 'stabilizer', 'ring light',
    'remote', 'controller', 'joystick', 'keyboard', 'mouse pad',
    'filter', 'lens', 'cap', 'hood',
  ];
  const isAccessory = accessoryWords.some(w => lower.includes(w));

  return veroBrands.some(brand => {
    const brandLower = brand.toLowerCase().replace(/[-–—]/g, ' ').replace(/\s+/g, ' ');
    const brandNoDash = brand.toLowerCase().replace(/\s+/g, '');

    let matched = false;

    // Multi-word brand: check if title contains it
    if (brandLower.includes(' ')) {
      matched = lower.includes(brandLower);
    } else {
      // Single word: check exact word boundary
      const escaped = brandLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp('\\b' + escaped + '\\b', 'i');
      if (regex.test(lower)) matched = true;
      // Also check concatenated form (Faber-Castell → fabercastell)
      if (!matched && brandNoDash.length > 3 && titleNoDash.includes(brandNoDash)) matched = true;
    }

    // If brand matched but title looks like an accessory, skip VERO flag
    if (matched && isAccessory) {
      console.log('[UnicornDS] VERO skip (accessory): "' + brand + '" in "' + title.substring(0, 50) + '"');
      return false;
    }

    return matched;
  });
}

// Load VERO list on startup
loadVeroList();

// ═══════════════════════════════════════
// HANDLE RESULTS FROM CONTENT SCRIPT
// ═══════════════════════════════════════
function handleSearchResults(data) {
  if (!data || !data.products || !data.products.length) return;
  console.log('[UnicornDS] handleSearchResults: received', data.products.length, 'raw products');

  const settings = {
    minReviews: parseInt(document.getElementById('minReviews').value) || 0,
    maxReviews: parseInt(document.getElementById('maxReviews').value) || 100000,
    removeBooks: document.getElementById('removeBooks').checked,
    duplicateProtection: document.getElementById('duplicateProtection').checked,
    restrictedWords: document.getElementById('restrictedWords').value.split('\n').map(w => w.trim().toLowerCase()).filter(Boolean),
    prioritizeChoice: document.getElementById('prioritizeChoice').checked,
    prioritizeBestSeller: document.getElementById('prioritizeBestSeller').checked,
    veroProtection: document.getElementById('veroProtection').checked,
  };

  let newProducts = data.products;

  // Filter by reviews
  newProducts = newProducts.filter(p =>
    p.reviewCount >= settings.minReviews && p.reviewCount <= settings.maxReviews
  );

  // Filter books
  if (settings.removeBooks) {
    newProducts = newProducts.filter(p => {
      const title = (p.title || '').toLowerCase();
      return !title.includes('paperback') && !title.includes('hardcover') && !title.includes('kindle');
    });
  }

  // Filter restricted words
  if (settings.restrictedWords.length) {
    newProducts = newProducts.filter(p => {
      const title = (p.title || '').toLowerCase();
      return !settings.restrictedWords.some(w => title.includes(w));
    });
  }

  // Duplicate protection
  if (settings.duplicateProtection) {
    const existingAsins = new Set(products.map(p => p.asin));
    newProducts = newProducts.filter(p => !existingAsins.has(p.asin));
  }

  // VERO check - mark but don't remove (user can see and decide)
  newProducts.forEach(p => {
    p.isVero = checkVero(p.title);
  });

  // If VERO protection enabled, remove VERO products
  if (settings.veroProtection) {
    newProducts = newProducts.filter(p => !p.isVero);
  }

  // Prioritise Amazon's Choice and Best Sellers
  if (settings.prioritizeChoice || settings.prioritizeBestSeller) {
    newProducts.sort((a, b) => {
      const aScore = (settings.prioritizeChoice && a.isAmazonChoice ? 2 : 0) +
                     (settings.prioritizeBestSeller && a.isBestSeller ? 1 : 0);
      const bScore = (settings.prioritizeChoice && b.isAmazonChoice ? 2 : 0) +
                     (settings.prioritizeBestSeller && b.isBestSeller ? 1 : 0);
      return bScore - aScore;
    });
  }

  // Add search term tag + demand score
  newProducts.forEach(p => {
    p.searchTerm = data.keyword || '';
    p.addedAt = Date.now();
    // DEMAND SCORE: reviews × rating normalized, with badges as multipliers
    // Score 0-100: hot (70+), warm (40-69), cold (<40)
    const reviews = p.reviewCount || 0;
    const rating = p.rating || 0;
    const reviewScore = Math.min(reviews / 500, 1) * 40;     // 0-40 points (500+ reviews = max)
    const ratingScore = (rating / 5) * 25;                    // 0-25 points
    const badgeBonus = (p.isAmazonChoice ? 15 : 0) + (p.isBestSeller ? 15 : 0); // 0-30 points
    const boughtBonus = p.boughtText ? 10 : 0;                // 10 if "X bought in past month"
    p.demandScore = Math.min(Math.round(reviewScore + ratingScore + badgeBonus + boughtBonus), 100);
  });

  products = products.concat(newProducts);
  console.log('[UnicornDS] Total products after adding:', products.length);
  saveProducts();
  renderResults();
}

// ═══════════════════════════════════════
// PAGINATION
// ═══════════════════════════════════════
let currentPage = 1;
const PRODUCTS_PER_PAGE = 50;

// ═══════════════════════════════════════
// RENDER RESULTS TABLE (with pagination)
// ═══════════════════════════════════════
function renderResults() {
  const tbody = document.getElementById('resultsBody');
  const empty = document.getElementById('emptyState');
  const filter = (document.getElementById('filterResults').value || '').toLowerCase();

  let filtered = filter
    ? products.filter(p => (p.title || '').toLowerCase().includes(filter))
    : [...products];

  // C2: VERO filter
  const veroFilterVal = document.getElementById('veroFilter')?.value || 'all';
  if (veroFilterVal === 'hide-vero') {
    filtered = filtered.filter(p => !p.isVero);
  } else if (veroFilterVal === 'vero-only') {
    filtered = filtered.filter(p => p.isVero);
  }

  // C2: Update VERO counter in results header
  const veroTotal = products.filter(p => p.isVero).length;
  const veroCounter = document.getElementById('veroCounter');
  const veroCountEl = document.getElementById('veroCount');
  if (veroCounter && veroCountEl) {
    if (veroTotal > 0) {
      veroCounter.style.display = 'inline-flex';
      veroCountEl.textContent = veroTotal;
    } else {
      veroCounter.style.display = 'none';
    }
  }

  // Filter by min stock (only applies to verified products) — view filter from settings sidebar
  const minStock = parseInt(document.getElementById('minStock').value) || 0;
  if (minStock > 0) {
    filtered = filtered.filter(p => {
      // If product has been verified and stock is below minimum, hide it
      if (p.stockInfo && p.stockInfo.quantity < minStock) return false;
      return true; // show unverified products (stock unknown yet)
    });
  }

  document.getElementById('resultCount').textContent = filtered.length + (filtered.length !== products.length ? ' / ' + products.length : '');

  const hasProducts = products.length > 0;
  document.getElementById('exportCsvBtn').disabled = !hasProducts;
  document.getElementById('verifyAllBtn').disabled = !hasProducts;
  document.getElementById('transferBulkBtn').disabled = !hasProducts;
  document.getElementById('clearResultsBtn').disabled = !hasProducts;

  if (!filtered.length) {
    tbody.innerHTML = '';
    empty.style.display = products.length ? 'none' : 'block';
    if (products.length && filter) {
      empty.style.display = 'block';
      empty.querySelector('p').textContent = 'No products match your filter';
    }
    renderPagination(0);
    return;
  }

  empty.style.display = 'none';
  const domain = document.getElementById('amazonDomain').value;

  // Pagination
  const totalPages = Math.ceil(filtered.length / PRODUCTS_PER_PAGE);
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  const startIdx = (currentPage - 1) * PRODUCTS_PER_PAGE;
  const pageItems = filtered.slice(startIdx, startIdx + PRODUCTS_PER_PAGE);

  tbody.innerHTML = pageItems.map((p, pageIdx) => {
    const i = startIdx + pageIdx;
    const amazonUrl = p.asin ? `https://www.amazon.${domain}/dp/${p.asin}` : '#';
    const imgSrc = p.image || '';
    const badge = p.isVero
      ? '<span class="badge badge-vero">⚠️ VERO</span>'
      : p.isAmazonChoice
        ? '<span class="badge badge-choice">Choice</span>'
        : p.isBestSeller
          ? '<span class="badge badge-bestseller">Best Seller</span>'
          : '';
    const primeBadge = p.prime ? '<span style="font-size:9px;background:#00A8E1;color:#fff;padding:1px 5px;border-radius:3px;font-weight:700;margin-left:2px">Prime</span>' : '';
    const boughtBadge = p.boughtText ? `<br><span style="font-size:9px;color:#F59E0B">${p.boughtText}</span>` : '';
    const rating = p.rating ? '⭐ ' + p.rating : '';
    const price = p.price != null ? p.currencySymbol + p.price.toFixed(2) : '-';
    const reviews = p.reviewCount != null ? p.reviewCount.toLocaleString() : '-';
    // Stock: show verified data, or stock hint from search, or dash
    let stockDisplay = '-';
    if (p.stockText) {
      stockDisplay = p.stockText;
    } else if (p.stockHint) {
      stockDisplay = `<span style="color:#F59E0B;font-size:11px">${p.stockHint}</span>`;
    }

    return `<tr>
      <td class="col-check"><input type="checkbox" class="row-check" data-index="${i}"></td>
      <td class="col-img">${imgSrc ? `<img src="${imgSrc}" alt="" loading="lazy">` : ''}</td>
      <td class="col-title"><a href="${amazonUrl}" target="_blank" title="${(p.title || '').replace(/"/g, '&quot;')}">${p.title || 'Untitled'}</a>${boughtBadge}</td>
      <td class="col-price">${price}</td>
      <td class="col-reviews">${reviews}</td>
      <td class="col-rating">${rating}</td>
      <td class="col-badge">${badge}${primeBadge}</td>
      <td class="col-demand">${(() => {
        const ds = p.demandScore || 0;
        const color = ds >= 70 ? '#10B981' : ds >= 40 ? '#F59E0B' : '#6b7280';
        const label = ds >= 70 ? '🔥' : ds >= 40 ? '🌤' : '❄️';
        return '<span style="color:' + color + ';font-weight:700;font-size:12px" title="Demand score: ' + ds + '/100">' + label + ' ' + ds + '</span>';
      })()}</td>
      <td class="col-stock" id="stock-${p.asin}">${stockDisplay}</td>
      <td class="col-actions">
        <button class="action-btn btn-verify" data-asin="${p.asin}">Verify</button>
        <button class="action-btn list-btn btn-list" data-asin="${p.asin}">List</button>
        <button class="action-btn btn-view" data-asin="${p.asin}" data-url="${amazonUrl}">View</button>
        <button class="action-btn btn-delete" data-index="${i}" title="Remove">✕</button>
      </td>
    </tr>`;
  }).join('');

  renderPagination(filtered.length);
}

function renderPagination(totalItems) {
  let paginationEl = document.getElementById('paginationBar');
  if (!paginationEl) {
    paginationEl = document.createElement('div');
    paginationEl.id = 'paginationBar';
    paginationEl.style.cssText = 'display:flex;justify-content:center;align-items:center;gap:8px;padding:12px;';
    const tableWrap = document.querySelector('.table-wrap');
    if (tableWrap) tableWrap.appendChild(paginationEl);
  }

  const totalPages = Math.ceil(totalItems / PRODUCTS_PER_PAGE);
  if (totalPages <= 1) { paginationEl.innerHTML = ''; return; }

  let html = `<span style="color:#a5a0cc;font-size:12px;">Page ${currentPage} of ${totalPages} (${totalItems} products)</span>`;
  html += `<button class="btn btn-sm page-btn" data-page="1" ${currentPage === 1 ? 'disabled' : ''}>«</button>`;
  html += `<button class="btn btn-sm page-btn" data-page="${currentPage - 1}" ${currentPage === 1 ? 'disabled' : ''}>‹</button>`;

  for (let p = Math.max(1, currentPage - 2); p <= Math.min(totalPages, currentPage + 2); p++) {
    html += `<button class="btn btn-sm page-btn ${p === currentPage ? 'btn-primary' : ''}" data-page="${p}">${p}</button>`;
  }

  html += `<button class="btn btn-sm page-btn" data-page="${currentPage + 1}" ${currentPage === totalPages ? 'disabled' : ''}>›</button>`;
  html += `<button class="btn btn-sm page-btn" data-page="${totalPages}" ${currentPage === totalPages ? 'disabled' : ''}>»</button>`;
  paginationEl.innerHTML = html;
}

// ═══════════════════════════════════════
// EVENT DELEGATION (MV3 CSP compliant)
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  // Results table button clicks
  document.getElementById('resultsBody').addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;

    if (btn.classList.contains('btn-verify')) {
      verifyStock(btn.dataset.asin);
    } else if (btn.classList.contains('btn-list')) {
      listOnEbay(btn.dataset.asin);
    } else if (btn.classList.contains('btn-view')) {
      chrome.tabs.create({ url: btn.dataset.url, active: true });
    } else if (btn.classList.contains('btn-delete')) {
      const idx = parseInt(btn.dataset.index);
      if (!isNaN(idx) && idx >= 0 && idx < products.length) {
        products.splice(idx, 1);
        saveProducts();
        renderResults();
      }
    }
  });

  // Pagination clicks
  document.addEventListener('click', (e) => {
    const pageBtn = e.target.closest('.page-btn');
    if (pageBtn && pageBtn.dataset.page) {
      currentPage = parseInt(pageBtn.dataset.page);
      renderResults();
      document.querySelector('.table-wrap')?.scrollTo(0, 0);
    }
  });

  // Verify All Stock button
  const verifyAllBtn = document.getElementById('verifyAllBtn');
  if (verifyAllBtn) {
    verifyAllBtn.addEventListener('click', verifyAllStock);
  }
});

// ═══════════════════════════════════════
// ACTIONS
// ═══════════════════════════════════════
function listOnEbay(asin) {
  const domain = document.getElementById('amazonDomain').value;
  const url = `https://www.amazon.${domain}/dp/${asin}?th=1&psc=1`;
  // Open Amazon product page - existing content script will handle listing UI
  chrome.tabs.create({ url: url, active: true });
}

// ═══════════════════════════════════════
// STOCK VERIFICATION
// ═══════════════════════════════════════
function verifyStock(asin) {
  const cell = document.getElementById('stock-' + asin);
  if (cell) cell.innerHTML = '<span style="color:#F59E0B">⏳ Checking...</span>';

  const domain = document.getElementById('amazonDomain').value;
  chrome.runtime.sendMessage({
    type: 'verify_stock',
    asin: asin,
    domain: domain,
  });

  // Poll for result
  const pollKey = 'stock_check_' + asin;
  const startTime = Date.now();
  const pollInterval = setInterval(() => {
    if (Date.now() - startTime > 25000) {
      clearInterval(pollInterval);
      if (cell) cell.innerHTML = '<span style="color:#EF4444">Timeout</span>';
      return;
    }
    chrome.storage.local.get(pollKey, (data) => {
      const result = data[pollKey];
      if (result && result.checkedAt > startTime) {
        clearInterval(pollInterval);
        chrome.storage.local.remove(pollKey);

        const product = products.find(p => p.asin === asin);
        if (product) {
          product.stockInfo = result;
          product.stockText = result.quantityText;
        }

        if (cell) {
          if (result.inStock) {
            const qtyColor = result.quantity <= 5 ? '#EF4444' : result.quantity <= 20 ? '#F59E0B' : '#10B981';
            cell.innerHTML = `<span style="color:${qtyColor};font-weight:700">${result.quantityText}</span>`;
            // Seller type badge
            const sType = result.sellerType || '';
            if (sType === 'Amazon 1P') {
              cell.innerHTML += `<br><span style="font-size:9px;background:#FF9900;color:#111;padding:1px 5px;border-radius:3px;font-weight:700">Amazon 1P</span>`;
            } else if (sType === 'FBA') {
              cell.innerHTML += `<br><span style="font-size:9px;background:#232F3E;color:#FF9900;padding:1px 5px;border-radius:3px;font-weight:700;border:1px solid #FF9900">FBA</span>`;
            } else if (sType === 'FBM+Prime') {
              cell.innerHTML += `<br><span style="font-size:9px;background:#00A8E1;color:#fff;padding:1px 5px;border-radius:3px;font-weight:700">FBM+Prime</span>`;
            } else if (sType === 'FBM') {
              cell.innerHTML += `<br><span style="font-size:9px;background:#6B7280;color:#fff;padding:1px 5px;border-radius:3px;font-weight:700">FBM</span>`;
            } else if (result.seller) {
              cell.innerHTML += `<br><span style="font-size:9px;color:#9CA3AF">${result.seller}</span>`;
            }
            if (result.prime && sType !== 'FBM+Prime') cell.innerHTML += ' <span style="font-size:9px;color:#2563EB">Prime</span>';
          } else {
            cell.innerHTML = '<span style="color:#EF4444;font-weight:700">❌ Out of Stock</span>';
          }
        }
      }
    });
  }, 1000);
}

function verifyAllStock() {
  let delay = 0;
  products.forEach((p) => {
    if (p.asin && !p.stockInfo) {
      setTimeout(() => verifyStock(p.asin), delay);
      delay += 3000;
    }
  });
}

function transferToBulk() {
  const selected = getSelectedProducts();
  const domain = document.getElementById('amazonDomain').value;
  const minStock = parseInt(document.getElementById('minStock').value) || 0;
  const veroEnabled = document.getElementById('veroProtection').checked;

  // Filter out VERO products
  let safe = selected;
  let veroSkipped = 0;
  if (veroEnabled) {
    safe = selected.filter(p => {
      if (checkVero(p.title)) {
        veroSkipped++;
        return false;
      }
      return true;
    });
  }

  // Filter by min stock (only if product has been verified)
  let stockSkipped = 0;
  if (minStock > 0) {
    safe = safe.filter(p => {
      if (p.stockInfo && p.stockInfo.quantity < minStock) {
        stockSkipped++;
        return false;
      }
      return true; // include unverified products (stock unknown)
    });
  }

  const links = safe.map(p => `https://www.amazon.${domain}/dp/${p.asin}`).filter(Boolean);

  if (!links.length) {
    let msg = 'No products to transfer.';
    if (veroSkipped) msg += ' ' + veroSkipped + ' VERO brands skipped.';
    if (stockSkipped) msg += ' ' + stockSkipped + ' low stock skipped.';
    alert(msg);
    return;
  }

  let confirmMsg = 'Transfer ' + links.length + ' products to Bulk Lister?';
  if (veroSkipped) confirmMsg += '\n⚠️ ' + veroSkipped + ' VERO brands removed.';
  if (stockSkipped) confirmMsg += '\n📦 ' + stockSkipped + ' below ' + minStock + ' stock removed.';

  if (veroSkipped || stockSkipped) {
    console.log('[UnicornDS] Transfer: ' + links.length + ' safe, ' + veroSkipped + ' VERO skipped, ' + stockSkipped + ' low stock skipped');
  }

  chrome.runtime.sendMessage({
    type: 'openBulkUploadPage',
    amazonLinks: links,
  });
}

function getSelectedProducts() {
  const checks = document.querySelectorAll('.row-check:checked');
  if (checks.length) {
    return Array.from(checks).map(c => products[parseInt(c.dataset.index)]);
  }
  // If none selected, use all
  return products;
}

function toggleSelectAll(e) {
  document.querySelectorAll('.row-check').forEach(cb => {
    cb.checked = e.target.checked;
  });
}

function exportCSV() {
  if (!products.length) return;

  const domain = document.getElementById('amazonDomain').value;
  const headers = ['Title', 'ASIN', 'Price', 'Currency', 'Reviews', 'Rating', 'Badge', 'Image', 'Amazon URL', 'Search Term'];
  const rows = products.map(p => [
    `"${(p.title || '').replace(/"/g, '""')}"`,
    p.asin || '',
    p.price || '',
    p.currencySymbol || '',
    p.reviewCount || '',
    p.rating || '',
    p.isAmazonChoice ? 'Amazon Choice' : p.isBestSeller ? 'Best Seller' : '',
    p.image || '',
    p.asin ? `https://www.amazon.${domain}/dp/${p.asin}` : '',
    `"${(p.searchTerm || '').replace(/"/g, '""')}"`,
  ]);

  const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `unicornds_hunt_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function clearResults() {
  if (!confirm('Clear all results? This cannot be undone.')) return;
  products = [];
  saveProducts();
  renderResults();
}
