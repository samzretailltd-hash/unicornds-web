# UnicornDS Extension Bible
## Last Updated: 2026-04-26 (Session 5)

---

## 1. PROJECT OVERVIEW

**Product:** UnicornDS — Chrome extension for eBay dropshipping sellers
**Version:** 7.11.2
**Owner:** Zohaib Hassan (samzretailltd@gmail.com), Manchester UK
**Company:** SamZ Retail Ltd, trading as UnicornDS
**Brand Colors:** Dark navy (#1E1B4B), Purple (#7C3AED), Gold (#F59E0B)

### Tech Stack
- Chrome Extension (Manifest V3)
- JavaScript (vanilla, no framework)
- Firebase (auth, Firestore, storage)
- Next.js website on Vercel
- Stripe payments
- OpenAI GPT-4o API (via proxy)

### Repository Locations
- Extension codebase: `/home/claude/unicornds/` (47 JS files, ~16K lines)
- Website repo: `/home/claude/unicornds-web/` (Next.js)
- GitHub: `github.com/samzretailltd-hash/unicornds-web`
- Vercel project: `prj_KXccdV5UZ0QihcCe93Te9XvjTzpc`
- Vercel team: `team_lK5WijCNyifjGfvofnicK81f`

### User's eBay Account
- 2-year-old account, 9K+ sold items, 4K+ active listings
- Growth plan (125-130/1500 listings used)
- eBay UK primary, expanding to US/DE/FR/AU/CA

---

## 2. CRITICAL ARCHITECTURE — THE LISTING FLOW

This is the most complex flow and where most bugs happen. Every developer MUST understand this before making changes.

### Flow: Bulk Lister → eBay Listing

```
bulk-lister.js (UI page)
  → sends "list_to_ebay" to background.js
  → background.js scrapes Amazon/AliExpress product
  → background.js calls GPT-4o for title, description, item specifics
  → background.js opens eBay tab: /sl/prelist/suggest
  → monitorTabNavigation() watches tab URL changes:
      /suggest → /identify → /lstng
  → sendDataToListingForm() sends product data to listing-form.js
  → listing-form.js fills eBay form (price, images, specs, description)
  → listing-form.js clicks submit
  → eBay navigates to /sl/success
  → ⚠️ listing-form.js DIES here (content script only matches /lstng)
  → background.js SUCCESS WATCHER detects /sl/success URL
  → Sets unicornds_bulk_done in chrome.storage
  → bulk-lister.js picks up the signal, moves to next product
```

### CRITICAL: Content Script Lifecycle
- `listing-form.js` runs ONLY on `/lstng?*` pages
- When eBay navigates to `/sl/success`, the content script is KILLED
- ANY success detection MUST happen in background.js, not listing-form.js
- The background success watcher (fire-and-forget async) monitors the tab URL
- If tab URL contains `/sl/success` → set `unicornds_bulk_done` → close tab

### CRITICAL: Variable Scoping
- The `product` variable in bulk_scrape_product handler is declared at line ~2270
- NEVER declare `let product` inside an if/else block — it shadows the outer variable
- AliExpress scraping was broken for weeks because `let product = null;` inside the `else if (source === 'aliexpress')` block shadowed the outer `product`
- The outer code saw `null` even though the inner block had valid data
- FIX: Use `product = null;` (no `let`) inside conditional blocks

---

## 3. BUGS FIXED (with root causes) — LEARN FROM THESE

### Bug 1: Description Missing on eBay Listings
- **Root cause:** DOM insertion (checkbox+textarea) was unreliable — eBay's React re-renders wiped textarea content
- **Fix:** API PUT to eBay's draft endpoint as primary method
- **File:** `content/ebay/listing-form.js` PHASE 3
- **Side effect caused:** Page reload after API PUT, which led to Bug 2

### Bug 2: Bulk Lister Hangs After Submit
- **Root cause:** Description API PUT causes page reload. Content script dies when eBay navigates from `/lstng` to `/sl/success`. Dead script = no completion signal = bulk lister waits forever.
- **Fix:** Background success watcher in `background.js` monitors tab URL independently
- **File:** `background.js` after `monitorTabNavigation()`
- **Key code:** Fire-and-forget async that polls `chrome.tabs.get(tabId)` every 1s for 3 minutes
- **RULE:** NEVER rely on content scripts for cross-page state. Always have background.js as fallback.

### Bug 3: Profit Too Low — Listings Fail Instead of Auto-Adjust
- **Root cause:** Price rounds to £X.99 which drops below 30% minimum → profit floor check FAILS the listing
- **Fix:** Auto-adjust price UP to meet minimum profit instead of failing
- **File:** `background.js` profit floor guard (around line 1928)
- **Formula:** `adjustedPrice = Math.ceil((cost * (1 + minProfit/100) + 0.30) / (1 - 0.128 - promoRate/100)) - 0.01`
- **RULE:** NEVER fail a listing for a fixable problem. Auto-correct and log.

### Bug 4: Title Truncation — Dangling Words
- **Root cause:** `smartTruncateTitle()` cut at word boundary but left dangling prepositions like "Easy to", "for", "with"
- **Fix:** Regex removes dangling words (to, for, in, on, with, easy, the, a, etc.) up to 3 deep
- **File:** `background.js` `smartTruncateTitle()` function
- **RULE:** After any string truncation, ALWAYS clean up dangling words.

### Bug 5: Compliance False Positives — "lance" blocking dog toys
- **Root cause:** `combined.includes('lance')` matches substrings: "balance", "ambulance", "surveillance", "freelance"
- **Fix:** Word boundary regex `\blance\b` for ALL compliance keyword checks
- **File:** `utils/compliance_checker.js` — ALL keyword checks (weapons, blades, safety, CE marking)
- **Also added:** Safe context words (dog, cat, pet, toy, cake, garden, beauty, etc.)
- **RULE:** NEVER use `.includes()` for keyword matching. ALWAYS use `\b` word boundary regex.

### Bug 6: AliExpress Bulk Scraping Always Fails
- **Root cause:** `let product = null;` at line 2355 creates a shadowed variable inside `else if (source === 'aliexpress')` block. All scraping assigns to inner variable. Outer code sees null.
- **Fix:** Remove `let` → `product = null;` (uses outer variable)
- **File:** `background.js` bulk_scrape_product handler
- **RULE:** NEVER declare `let` inside conditional blocks when the variable is used outside. Check for variable shadowing.

### Bug 7: Fee Click Causes Page Reload
- **Root cause:** Before clicking fee confirmation, code did `updateDraftAPI()` to re-save description. This caused page reload, losing the fee button.
- **Fix:** Removed the unnecessary description re-save before fee click
- **File:** `content/ebay/listing-form.js` fee confirmation section
- **RULE:** NEVER do API calls that cause page reloads during the submit flow.

---

## 4. CODE PATTERNS — DO AND DON'T

### DO:
- Use background.js for any cross-page state monitoring
- Use chrome.storage for communication between background ↔ content scripts
- Use word boundary regex (`\b`) for keyword matching
- Auto-fix problems instead of failing (profit too low → adjust price)
- Test the FULL flow: scrape → fill → submit → success → next product
- Check variable scoping — avoid `let` inside conditional blocks
- Keep timeouts reasonable: 3 min submit cap, 5 min per-item cap
- Add safe context words when compliance blocks legitimate products

### DON'T:
- Don't rely on content scripts for cross-page state (they die on navigation)
- Don't use `.includes()` for keyword matching (substring false positives)
- Don't do API calls that cause page reloads during submit flow
- Don't declare `let` variables inside if/else when used outside the block
- Don't set timeouts longer than 5 minutes for non-variant items
- Don't fail listings for fixable problems (profit, rounding, etc.)
- Don't fix one bug without tracing the full downstream flow

---

## 5. CURRENT TIMEOUTS

| Component | Timeout | Purpose |
|-----------|---------|---------|
| Submit sanity cap | 3 min | Max time waiting for eBay to confirm listing |
| Per-item timeout | 5 min base + 1 min/variant | Max time for entire listing process |
| Background success watcher | 3 min | Watches tab URL for /sl/success |
| Stock check | 25 sec | Amazon stock verification |
| eBay sold check | 25 sec | eBay sold listings scrape |
| AliExpress page load wait | 8 sec | Wait before scraping |
| Amazon page load wait | 5 sec | Wait before scraping |
| Content script polling | 15 sec | Polling storage for scraped data |

---

## 6. KEY FILES AND THEIR ROLES

| File | Lines | Role |
|------|-------|------|
| `background.js` | ~4600 | Service worker — ALL business logic, API calls, tab management |
| `content/ebay/listing-form.js` | ~2100 | Fills eBay listing form, handles submit, fee confirmation |
| `pages/bulk-lister/bulk-lister.js` | ~640 | Bulk listing UI, queue management, worker pool |
| `content/aliexpress/content-aliexpress.js` | ~1150 | AliExpress product scraping, floating button |
| `content/amazon/content_amazon.js` | ~1800 | Amazon product scraping, UnicornDS overlay |
| `pages/product-hunter/hunter.js` | ~930 | Product Hunter search, eBay sold check |
| `utils/compliance_checker.js` | ~340 | Weapons/blade/safety compliance checks |
| `utils/pricing_module.js` | ~200 | Shared pricing formulas |
| `utils/safety_system.js` | ~150 | Age restriction checks |

---

## 7. AI PROMPTS (GPT-4o)

### Title Prompt (background.js ~line 1072)
- Thinks like an eBay BUYER, not AliExpress seller
- "car phone holder" not "suction cup cell phone windshield mount"
- First 3 words = most important for Cassini
- 80 characters max, Title Case, separated by " - "
- Generates 3 titles, scores each, picks best
- Returns JSON with keywords, titles, scores

### Description Prompt (background.js ~line 1218)
- Mobile-first HTML (max-width:800px, inline styles)
- Mandatory trust signals: Fast Dispatch, 30-Day Returns, UK Support
- "Perfect For" section with use cases
- No tables (break on mobile), no fluff words
- 300-500 words, keyword synergy with title

---

## 8. DEPLOYMENT WORKFLOW

### Extension Update
1. Make code changes in `/home/claude/unicornds/`
2. Run `node -c file.js` to verify syntax
3. Build zip: `zip -r UnicornDS_v7_11_2_BugFixes.zip . -x "*.DS_Store"`
4. Copy to website: `cp zip /home/claude/unicornds-web/public/ext_a8c2f1e9d4b7.zip`
5. Build website zip with extension + any website changes
6. User downloads, unzips into `~/Desktop/unicornds-web/`
7. User runs: `git add -A && git commit -m "message" && git push origin main`
8. Vercel auto-deploys from GitHub
9. User reloads extension in `chrome://extensions`

### Website Deployment
- Auto-deploys on git push to main
- Vercel project: `prj_KXccdV5UZ0QihcCe93Te9XvjTzpc`
- Production URL: unicornds.io / www.unicornds.io

---

## 9. PENDING ITEMS (as of Session 5)

- [ ] Test bulk lister with 3-5 products to verify all fixes work together
- [ ] Listing sniping flow (one-click relist from eBay competitor listing)
- [ ] Telegram community group at t.me/unicornds
- [ ] Stripe: Remove 14-day trial from product price settings
- [ ] Firebase SMTP for branded password reset emails
- [ ] Firebase Storage upgrade
- [ ] TikTok video scripts (30 specific scripts offered)
- [ ] Website pricing schema.org JSON-LD still shows old prices (£23.99)
- [ ] Website homepage Revolut checkout links (only /pricing updated to Stripe)
- [ ] Card verification gate — user may want changes
- [ ] Other language translations (DE, FR, ES) need updating for new features
- [ ] eBay sold check needs testing (new feature)
- [ ] Demand Score needs testing on real products

---

## 10. MISTAKES LOG — WHAT WENT WRONG AND WHY

### Session 5 Chain Reaction (2026-04-26)
1. Fixed description missing → used API PUT → caused page reload
2. Page reload → content script dies on navigation → bulk lister hangs
3. Reduced timeouts → band-aid, not real fix
4. Added background success watcher → proper fix
5. Fee click had unnecessary description re-save → removed
6. Profit check was failing instead of auto-adjusting → fixed
7. Compliance used substring matching → false positives → fixed with word boundary
8. AliExpress had shadowed variable → all scrapes failing → one-word fix

**Lesson:** Every change to listing-form.js or background.js MUST be traced through the complete flow: scrape → AI → fill form → submit → fee → success → next product. A change at any point can break downstream steps.

**Rule for future sessions:** Before making ANY change to the listing flow:
1. Identify which files are affected
2. Trace what happens when the page reloads
3. Trace what happens when the content script dies
4. Trace what happens when the tab navigates
5. Check variable scoping in any conditional blocks
6. Test with at least 2-3 products before shipping
