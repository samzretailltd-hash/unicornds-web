/**
 * UnicornDS - Background Service Worker
 *
 * The listing flow (verified from  background.bundle.js):
 *   1. AliExpress sends {type:'list_to_ebay', product_data:{...}}
 *   2. Background opens https://www.ebay.{domain}/sl/prelist/suggest
 *   3. prelist-suggest.js types title → clicks Continue → sends clicked_go_list_an_item
 *   4. Background calls identifyProductPageEbay - waits for /sl/prelist/identify
 *   5. prelist-identify.js clicks "Continue without match" → sends clicked_continued_without_matching
 *   6. Background waits for tab to navigate to /lstng?...
 *   7. listing-form.js receives insert_ebay_data → fills everything
 */

// Import shared modules (single source of truth)
try { importScripts('utils/pricing.js'); } catch(e) { console.warn('[UnicornDS] Pricing module not loaded:', e.message); }
try { importScripts('utils/images.js'); } catch(e) { console.warn('[UnicornDS] Images module not loaded:', e.message); }
try { importScripts('utils/compliance_checker.js'); } catch(e) { console.warn('[UnicornDS] Compliance checker not loaded:', e.message); }

console.log('[UnicornDS] Background service worker starting...');

// ═══════════════════════════════════════════════════════
// TIER ENFORCEMENT - Cached Gatekeeper System
// ═══════════════════════════════════════════════════════
const CF_BASE = 'https://us-central1-unicorn-ds-7f831.cloudfunctions.net';

// Local tier-to-limits fallback (used when Cloud Function doesn't return full limits)
const TIER_LIMITS_FALLBACK = {
  trial:    { listings_per_month: 100,  hunter_searches_per_day: 999, competitor_scans_per_day: 3,  stock_checks_per_day: 10, bulk_concurrent: 1,  ai_titles: true,  image_designer: false, tracker: false, send_offers: false },
  expired:  { listings_per_month: 0,    hunter_searches_per_day: 1,   competitor_scans_per_day: 0,  stock_checks_per_day: 0,  bulk_concurrent: 0,  ai_titles: false, image_designer: false, tracker: false, send_offers: false },
  free:     { listings_per_month: 10,   hunter_searches_per_day: 3, competitor_scans_per_day: 0,  stock_checks_per_day: 0,  bulk_concurrent: 0,  ai_titles: false, image_designer: false, tracker: false, send_offers: false },
  starter:  { listings_per_month: 500,  hunter_searches_per_day: 999, competitor_scans_per_day: 5, stock_checks_per_day: 20, bulk_concurrent: 1,  ai_titles: true, image_designer: false, tracker: false, send_offers: false },
  growth:   { listings_per_month: 1500, hunter_searches_per_day: 999, competitor_scans_per_day: 999, stock_checks_per_day: 999, bulk_concurrent: 5, ai_titles: true, image_designer: true, tracker: true, send_offers: true },
  empire:   { listings_per_month: 3000, hunter_searches_per_day: 999, competitor_scans_per_day: 999, stock_checks_per_day: 999, bulk_concurrent: 10, ai_titles: true, image_designer: true, tracker: true, send_offers: true },
  // Old tier names mapped to new
  pro:      { listings_per_month: 1500, hunter_searches_per_day: 999, competitor_scans_per_day: 999, stock_checks_per_day: 999, bulk_concurrent: 5, ai_titles: true, image_designer: true, tracker: true, send_offers: true },
  ultimate: { listings_per_month: 3000, hunter_searches_per_day: 999, competitor_scans_per_day: 999, stock_checks_per_day: 999, bulk_concurrent: 10, ai_titles: true, image_designer: true, tracker: true, send_offers: true },
};

// Cached user profile (refreshed on startup + every 5 min)
let userProfile = null; // { tier, limits, usage, fetched_at }

async function getAuthToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get('unicornds_session', (data) => {
      const session = data.unicornds_session;
      if (!session || !session.idToken) { resolve(null); return; }
      if (session.expiresAt && Date.now() > session.expiresAt - 300000) {
        fetch('https://securetoken.googleapis.com/v1/token?key=AIzaSyCOLnljoCmGWKCseXTSJv0zYVJhLUGVhN4', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ grant_type: 'refresh_token', refresh_token: session.refreshToken })
        }).then(r => r.json()).then(d => {
          if (d.id_token) {
            session.idToken = d.id_token;
            session.refreshToken = d.refresh_token;
            session.expiresAt = Date.now() + parseInt(d.expires_in) * 1000;
            chrome.storage.local.set({ unicornds_session: session });
            resolve(d.id_token);
          } else resolve(session.idToken);
        }).catch(() => resolve(session.idToken));
      } else resolve(session.idToken);
    });
  });
}

// Fetch full profile from Cloud Function and cache it
async function refreshUserProfile() {
  const token = await getAuthToken();
  if (!token) { userProfile = null; return; }
  try {
    const res = await fetch(`${CF_BASE}/getUserProfile`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: {} })
    });
    if (res.ok) {
      const json = await res.json();
      // onCall wraps response in { result: ... }
      const raw = json.result || json;
      userProfile = raw;
      userProfile.fetched_at = Date.now();
      // Ensure limits are complete - LOCAL fallback based on tier takes priority
      const tier = (userProfile.tier || 'trial').toLowerCase();
      const fallback = TIER_LIMITS_FALLBACK[tier] || TIER_LIMITS_FALLBACK.trial;
      userProfile.limits = { ...fallback };
      userProfile.usage = userProfile.usage || {};
      // Map Firebase tokensUsed to listings_this_month for gateAction
      if (userProfile.tokensUsed !== undefined) {
        userProfile.usage.listings_this_month = userProfile.tokensUsed;
      }
      // Calculate remaining credits
      const totalCredits = userProfile.tokensTotal || fallback.listings_per_month;
      const usedCredits = userProfile.tokensUsed || 0;
      chrome.storage.local.set({ 
        unicornds_tier: userProfile.tier,
        unicornds_profile: userProfile,
        unicornds_credits: Math.max(0, totalCredits - usedCredits),
        unicornds_tokens_used: usedCredits,
      });
      console.log('[UnicornDS] Profile refreshed:', userProfile.tier, 
        'listings:', userProfile.usage?.listings_this_month, '/', userProfile.limits?.listings_per_month,
        'bulk:', userProfile.limits?.bulk_concurrent);
    }
  } catch (err) {
    console.warn('[UnicornDS] Profile refresh failed:', err.message);
  }
}

// Load cached profile from storage on startup
async function loadCachedProfile() {
  return new Promise(resolve => {
    chrome.storage.local.get('unicornds_profile', data => {
      if (data.unicornds_profile) {
        userProfile = data.unicornds_profile;
        // Ensure limits are complete from fallback
        const tier = (userProfile.tier || 'free').toLowerCase();
        const fallback = TIER_LIMITS_FALLBACK[tier] || TIER_LIMITS_FALLBACK.free;
        userProfile.limits = { ...fallback, ...(userProfile.limits || {}) };
        userProfile.usage = userProfile.usage || {};
      }
      resolve();
    });
  });
}

// Check if action is allowed (synchronous check against cache)
function isActionAllowed(action) {
  if (!userProfile || !userProfile.limits) {
    // No profile loaded = not logged in. Block EVERYTHING.
    return { allowed: false, reason: 'Please log in to UnicornDS first.' };
  }
  
  const limits = userProfile.limits;
  const usage = userProfile.usage || {};
  
  switch (action) {
    case 'listing': {
      const used = usage.listings_this_month || 0;
      const limit = limits.listings_per_month || 10;
      if (used >= limit) return { allowed: false, reason: `Monthly listing limit reached (${used}/${limit}). Upgrade for more listings.` };
      return { allowed: true, reason: '', remaining: limit - used };
    }
    case 'hunter_search': {
      const used = usage.hunter_searches_today || 0;
      const limit = limits.hunter_searches_per_day || 3;
      if (used >= limit) return { allowed: false, reason: `Daily search limit reached (${used}/${limit}). Upgrade for unlimited searches.` };
      return { allowed: true, reason: '', remaining: limit - used };
    }
    case 'competitor_scan': {
      const limit = limits.competitor_scans_per_day || 0;
      if (limit === 0) return { allowed: false, reason: 'Competitor Scanner requires Starter plan or above.' };
      const used = usage.competitor_scans_today || 0;
      if (used >= limit) return { allowed: false, reason: `Daily scan limit reached (${used}/${limit}).` };
      return { allowed: true, reason: '', remaining: limit - used };
    }
    case 'stock_check': {
      const limit = limits.stock_checks_per_day || 0;
      if (limit === 0) return { allowed: false, reason: 'Stock Checker requires Starter plan or above.' };
      const used = usage.stock_checks_today || 0;
      if (used >= limit) return { allowed: false, reason: `Daily stock check limit reached (${used}/${limit}).` };
      return { allowed: true, reason: '', remaining: limit - used };
    }
    case 'bulk_lister': {
      if (!limits.bulk_concurrent || limits.bulk_concurrent === 0) return { allowed: false, reason: 'Bulk Lister requires Starter plan or above.' };
      return { allowed: true, reason: '' };
    }
    case 'ai_title': {
      if (!limits.ai_titles) return { allowed: false, reason: 'AI Titles require Growth plan or above.' };
      return { allowed: true, reason: '' };
    }
    case 'image_designer': {
      if (!limits.image_designer) return { allowed: false, reason: 'Image Designer requires Growth plan or above.' };
      return { allowed: true, reason: '' };
    }
    case 'tracker': {
      if (!limits.tracker) return { allowed: false, reason: 'Listing Tracker requires Growth plan or above.' };
      return { allowed: true, reason: '' };
    }
    case 'send_offers': {
      if (!limits.send_offers) return { allowed: false, reason: 'Send Offers requires Growth plan or above.' };
      return { allowed: true, reason: '' };
    }
    case 'orders_sync': {
      // Orders Sync is a premium feature — gate on same flag as tracker (Growth+).
      if (!limits.tracker) return { allowed: false, reason: 'Orders Sync requires Growth plan or above.' };
      return { allowed: true, reason: '' };
    }
    case 'address_helper': {
      // Address Helper (Growth+ per product spec).
      if (!limits.tracker) return { allowed: false, reason: 'Address Helper requires Growth plan or above.' };
      return { allowed: true, reason: '' };
    }
    default:
      return { allowed: true, reason: '' };
  }
}

// Increment usage locally (actual deduction happens via deductCredits on success)
async function incrementUsage(action) {
  // Local optimistic increment only — Firebase deduction happens in deductCredits
  // No server call here — checkAction Cloud Function doesn't exist
  // The real server-side deduction is in deductCredit (called on listing success)
  console.log('[UnicornDS] Usage incremented locally for:', action);
}

// Gate function - call before any metered action
// Returns true if allowed, false if blocked (and shows notification)
function gateAction(action, sendResponse) {
  const check = isActionAllowed(action);
  if (!check.allowed) {
    console.log(`[UnicornDS] ⛔ BLOCKED: ${action} - ${check.reason}`);
    showUpgradeNotification(action, check.reason);
    if (sendResponse) sendResponse({ error: check.reason, upgrade: true, blocked: true });
    return false;
  }
  console.log(`[UnicornDS] ✅ ALLOWED: ${action} (remaining: ${check.remaining || '∞'})`);
  // Increment usage in background (non-blocking)
  incrementUsage(action);
  // Update local cache optimistically
  if (userProfile && userProfile.usage) {
    if (action === 'listing') userProfile.usage.listings_this_month = (userProfile.usage.listings_this_month || 0) + 1;
    if (action === 'hunter_search') userProfile.usage.hunter_searches_today = (userProfile.usage.hunter_searches_today || 0) + 1;
    if (action === 'competitor_scan') userProfile.usage.competitor_scans_today = (userProfile.usage.competitor_scans_today || 0) + 1;
    if (action === 'stock_check') userProfile.usage.stock_checks_today = (userProfile.usage.stock_checks_today || 0) + 1;
  }
  return true;
}

// Show upgrade notification
function showUpgradeNotification(action, reason) {
  const messages = {
    listing: '📦 Listing limit reached! Upgrade to list more products.',
    hunter_search: '🔍 Daily search limit reached! Upgrade for unlimited searches.',
    competitor_scan: '🕵️ Competitor Scanner requires Starter plan or above.',
    stock_check: '📊 Stock Checker requires Starter plan or above.',
    bulk_lister: '⚡ Bulk Lister requires Starter plan or above.',
    ai_title: '🤖 AI Titles require Growth plan or above.',
    image_designer: '🎨 Image Designer requires Growth plan or above.',
    tracker: '📈 Listing Tracker requires Growth plan or above.',
    send_offers: '💌 Send Offers requires Growth plan or above.',
    orders_sync: '📦 Orders Sync requires Growth plan or above.',
    address_helper: '📮 Address Helper requires Growth plan or above.',
  };
  const msg = messages[action] || reason || 'Upgrade your plan to use this feature.';
  chrome.notifications.create('tier_' + action + '_' + Date.now(), {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'UnicornDS - Upgrade Required',
    message: msg,
  });
}

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith('tier_')) {
    chrome.tabs.create({ url: chrome.runtime.getURL('pages/upgrade/upgrade.html') });
    chrome.notifications.clear(notificationId);
  }
});

// ── Startup: load cache + refresh profile ──
loadCachedProfile().then(() => refreshUserProfile());

// ── Refresh profile every 5 minutes ──
setInterval(() => refreshUserProfile(), 5 * 60 * 1000);

// ── Refresh when user logs in/out ──
chrome.storage.onChanged.addListener((changes) => {
  if (changes.unicornds_session) {
    console.log('[UnicornDS] Session changed - refreshing profile');
    setTimeout(() => refreshUserProfile(), 500);
  }
});

// ═══════════════════════════════════════════════════════
// PRODUCT HUNTER - Amazon Search URL Builder
// ═══════════════════════════════════════════════════════
function buildAmazonSearchUrl(keyword, settings = {}) {
  const domain = settings.domain || 'co.uk';
  let url = `https://www.amazon.${domain}/s?k=${encodeURIComponent(keyword)}`;

  // Price range
  const minP = settings.minPrice ? Math.round(settings.minPrice * 100) : null;
  const maxP = settings.maxPrice ? Math.round(settings.maxPrice * 100) : null;
  if (minP && maxP) url += `&rh=p_36%3A${minP}-${maxP}`;
  else if (minP) url += `&rh=p_36%3A${minP}-`;
  else if (maxP) url += `&rh=p_36%3A-${maxP}`;

  // Prime / Free shipping
  if (settings.primeOnly) {
    if (domain === 'com') url += '%2Cp_85%3A2470955011';
    else if (domain === 'ca') url += '%2Cp_85%3A5690392011';
    else if (domain === 'co.uk') url += '%2Cp_76%3A419158031';
    else if (domain === 'de') url += '%2Cp_76%3A419122031';
    else if (domain === 'fr') url += '%2Cp_76%3A895451031';
    else if (domain === 'it') url += '%2Cp_76%3A895475031';
    else if (domain === 'es') url += '%2Cp_76%3A895462031';
    else if (domain === 'com.au') url += '%2Cp_n_prime_domestic%3A6845356051';
  }

  // Amazon as seller filter (excludes 3rd party sellers)
  if (settings.amazonIsSeller) {
    if (domain === 'com') url += '%2Cp_n_feature_forty-seven_browse-bin%3A24677333011';
    else if (domain === 'ca') url += '%2Cp_6%3AA3DWYIK6Y9EEQB';
    else if (domain === 'co.uk') url += '%2Cp_6%3AA3P5ROKL5A1OLE';
    else if (domain === 'de') url += '%2Cp_6%3AA3JWKAKR8XB7XF';
    else if (domain === 'fr') url += '%2Cp_6%3AA1X6FK5RDHNB96';
    else if (domain === 'it') url += '%2Cp_6%3AA11IL2PNWYAJU7';
    else if (domain === 'es') url += '%2Cp_6%3AA1AT7YVPFBWXBL';
  }

  // Sort
  const sort = settings.sortBy || 'reviews';
  if (sort === 'reviews') url += '&s=review-count-rank';
  else if (sort === 'price-asc') url += '&s=price-asc-rank';
  else if (sort === 'price-desc') url += '&s=price-desc-rank';
  // 'featured' = default Amazon sort, no param needed

  return url;
}

// ═══════════════════════════════════════════════════════
// eBay LISTING API HEADER CAPTURE ( approach)
// Intercepts eBay's own listing_draft API calls to capture
// session headers (CSRF tokens, cookies, etc.)
// These headers are forwarded to the content script for
// making PUT requests to fill item specifics via API.
// ═══════════════════════════════════════════════════════
let ebayApiHeaders = {};  // tabId → headers array
let headerLoggedTabs = {}; // tabId → true (only log first capture per tab)

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (details.tabId > 0) {
      ebayApiHeaders[details.tabId] = details.requestHeaders;
      // Only log the first capture per tab to avoid console spam
      if (!headerLoggedTabs[details.tabId]) {
        headerLoggedTabs[details.tabId] = true;
        console.log('[UnicornDS] Captured eBay API headers for tab', details.tabId, ':', details.requestHeaders.length, 'headers');
      }
      // Forward to content script immediately
      try {
        chrome.tabs.sendMessage(details.tabId, {
          type: 'ebay_request_headers',
          headers: details.requestHeaders,
        });
      } catch(e) {}
    }
  },
  {
    urls: [
      'https://www.ebay.com/lstng/api/*',
      'https://www.ebay.co.uk/lstng/api/*',
      'https://www.ebay.de/lstng/api/*',
      'https://www.ebay.fr/lstng/api/*',
      'https://www.ebay.it/lstng/api/*',
      'https://www.ebay.es/lstng/api/*',
      'https://www.ebay.nl/lstng/api/*',
      'https://www.ebay.com.au/lstng/api/*',
      'https://www.ebay.ca/lstng/api/*',
      'https://www.ebay.at/lstng/api/*',
      'https://www.ebay.be/lstng/api/*',
      'https://www.ebay.ch/lstng/api/*',
      'https://www.ebay.ie/lstng/api/*',
      'https://www.ebay.in/lstng/api/*',
    ],
  },
  ['requestHeaders', 'extraHeaders']
);

// ── Install ────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    const data = await chrome.storage.local.get('unicornds_onboarded');
    if (!data.unicornds_onboarded) {
      chrome.tabs.create({ url: chrome.runtime.getURL('onboarding/onboarding.html') });
    }
  }
  setupContextMenus();
  // Set up version check alarm — runs every 24 hours
  chrome.alarms.create('unicornds_version_check', { periodInMinutes: 1440 });
  // Service worker keepalive alarm — fires every 25 seconds during bulk ops
  chrome.alarms.create('unicornds_keepalive', { periodInMinutes: 0.4 });
  // Also check now
  checkForUpdates();
});

// ── Service Worker Keepalive ─────────────────
// MV3 service workers die after 30s of inactivity.
// This alarm fires every 25s to keep it alive during bulk listing.
let bulkOperationActive = false;

// ── Version Check (runs every 24h via alarm) ─────────────
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'unicornds_version_check') checkForUpdates();
  if (alarm.name === 'unicornds_keepalive' && bulkOperationActive) {
    // Touch storage to keep service worker alive
    chrome.storage.local.set({ _keepalive: Date.now() });
  }
});

async function checkForUpdates() {
  try {
    const res = await fetch('https://www.unicornds.io/api/version', { cache: 'no-cache' });
    if (!res.ok) return;
    const data = await res.json();
    const currentVersion = chrome.runtime.getManifest().version;
    const current = currentVersion.split('.').map(Number);
    const latest = data.version.split('.').map(Number);
    let needsUpdate = false;
    for (let i = 0; i < Math.max(current.length, latest.length); i++) {
      if ((latest[i] || 0) > (current[i] || 0)) { needsUpdate = true; break; }
      if ((current[i] || 0) > (latest[i] || 0)) break;
    }
    if (needsUpdate) {
      // Show badge on extension icon
      chrome.action.setBadgeText({ text: '1' });
      chrome.action.setBadgeBackgroundColor({ color: '#F59E0B' });
      chrome.storage.local.set({ unicornds_update_available: data.version });
      console.log('[UnicornDS] Update available: v' + data.version);
    } else {
      chrome.action.setBadgeText({ text: '' });
      chrome.storage.local.remove('unicornds_update_available');
    }
  } catch (e) { /* silent */ }
}

// ── Context Menus ──────────────────────────────────────
function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'unicornds_list_product',
      title: '🦄 List this product on eBay',
      contexts: ['page'],
      documentUrlPatterns: [
        'https://www.aliexpress.com/item/*',
        'https://www.aliexpress.co.uk/item/*',
        'https://de.aliexpress.com/item/*',
        'https://www.aliexpress.us/item/*',
        'https://*.amazon.com/*/dp/*',
        'https://*.amazon.co.uk/*/dp/*',
      ],
    });
    chrome.contextMenus.create({
      id: 'unicornds_open_supplier',
      title: '🦄 Open Supplier Page (UnicornDS)',
      contexts: ['selection', 'page'],
      documentUrlPatterns: [
        'https://www.ebay.com/*', 'https://www.ebay.co.uk/*', 'https://www.ebay.de/*',
        'https://www.ebay.fr/*', 'https://www.ebay.it/*', 'https://www.ebay.es/*',
        'https://www.ebay.ca/*', 'https://www.ebay.com.au/*', 'https://www.ebay.nl/*',
      ],
    });
    chrome.contextMenus.create({
      id: 'unicornds_open_settings',
      title: '⚙️ UnicornDS Settings',
      contexts: ['page'],
    });
  });
}

// Parse any UDS SKU format into a supplier URL
// Supports: UDS-AE-{id}, UDS-AZ-{asin}, UDS-UK-{id} (old), UDS-{id} (old)
// Also handles variant suffixes: UDS-AE-{id}_V3
function parseUdsSku(sku) {
  if (!sku || !sku.includes('UDS')) return null;
  // Strip variant suffix (_V1, _V2, etc)
  const cleanSku = sku.replace(/_V\d+$/, '');
  // New format: UDS-{2-letter-code}-{id}
  const match = cleanSku.match(/UDS-([A-Z]{2})-([A-Za-z0-9]+)/);
  if (match) {
    const source = match[1];
    const pid = match[2];
    if (source === 'AE') return { source: 'aliexpress', productId: pid, url: 'https://www.aliexpress.com/item/' + pid + '.html' };
    if (source === 'AZ') return { source: 'amazon', productId: pid, url: 'https://www.amazon.co.uk/dp/' + pid };
    // Old market codes (UK, DE, FR etc) - assume AliExpress
    return { source: 'aliexpress', productId: pid, url: 'https://www.aliexpress.com/item/' + pid + '.html' };
  }
  // Old format: UDS-{number}
  const oldMatch = cleanSku.match(/UDS-(\d+)/);
  if (oldMatch) return { source: 'aliexpress', productId: oldMatch[1], url: 'https://www.aliexpress.com/item/' + oldMatch[1] + '.html' };
  return null;
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'unicornds_list_product') {
    const url = tab.url || '';
    if (url.includes('amazon.')) {
      // Amazon page — click the floating panel's existing "List on eBay" button.
      // This triggers the Amazon content script's handler which sends
      // list_to_ebay back to background through the normal pipeline.
      console.log('[UnicornDS] Context menu: Amazon page detected, clicking List button');
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const btn = document.getElementById('unicornds-list-btn');
          if (btn) {
            btn.click();
          } else {
            console.warn('[UnicornDS] Context menu: List button not found — panel may not have loaded yet');
          }
        },
      });
    } else {
      // AliExpress or other page
      chrome.tabs.sendMessage(tab.id, { type: 'scrape_aliexpress_product' });
    }
  }
  if (info.menuItemId === 'unicornds_open_supplier') {
    // Try selected text first, then scan page for SKU
    const selectedText = (info.selectionText || '').trim();
    let parsed = null;

    if (selectedText) {
      // User selected text - try to parse as SKU
      parsed = parseUdsSku(selectedText);
      if (!parsed) {
        // Maybe they selected just the product ID - try with UDS-AE prefix
        if (/^\d{10,}$/.test(selectedText)) {
          parsed = { source: 'aliexpress', productId: selectedText, url: 'https://www.aliexpress.com/item/' + selectedText + '.html' };
        } else if (/^B0[A-Z0-9]{8}$/i.test(selectedText)) {
          parsed = { source: 'amazon', productId: selectedText, url: 'https://www.amazon.co.uk/dp/' + selectedText };
        }
      }
    }

    if (!parsed) {
      // No selection or couldn't parse - try to find SKU on the page via content script
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // Search visible text for UDS- pattern
          const bodyText = document.body.innerText;
          const match = bodyText.match(/UDS-[A-Z]{2}-[A-Za-z0-9]+|UDS-\d+/);
          return match ? match[0] : null;
        }
      }).then(results => {
        const foundSku = results?.[0]?.result;
        if (foundSku) {
          const p = parseUdsSku(foundSku);
          if (p) { chrome.tabs.create({ url: p.url }); return; }
        }
        // Last resort - check SKU dictionary
        chrome.storage.local.get('unicornds_sku_dictionary', s => {
          const dict = s.unicornds_sku_dictionary || {};
          // Can't determine which SKU without selection - show notification
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => { alert('🦄 UnicornDS: Select a SKU (like UDS-AE-1234567890) and right-click again.'); }
          });
        });
      }).catch(() => {});
      return;
    }

    console.log('[UnicornDS] Opening supplier:', parsed.source, parsed.productId, parsed.url);
    chrome.tabs.create({ url: parsed.url });
  }
  if (info.menuItemId === 'unicornds_open_settings') {
    chrome.runtime.openOptionsPage();
  }
});

// ── Tab Helpers ─────────────────────────────────────────

function waitForTabComplete(tabId) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(); // resolve anyway - don't block the flow
    }, 30000);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === 'complete') {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);

    // Check if already complete
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) { clearTimeout(timeout); resolve(); return; }
      if (tab && tab.status === 'complete') {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    });
  });
}

function waitForTabUrl(tabId, urlPattern, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('Tab URL timeout waiting for: ' + urlPattern));
    }, timeoutMs);

    // Check immediately
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) return;
      if (tab && tab.url && tab.url.includes(urlPattern)) {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve(tab.url), 500);
        return;
      }
    });

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.url && changeInfo.url.includes(urlPattern)) {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve(changeInfo.url), 500);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function sendMessageToTab(tabId, message, maxRetries = 10, delayMs = 1000) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, message);
      return response;
    } catch (err) {
      if (i < maxRetries - 1) {
        await new Promise((r) => setTimeout(r, delayMs));
      } else {
        console.error('[UnicornDS] sendMessageToTab failed after retries:', err.message);
        throw err;
      }
    }
  }
}

// ═══════════════════════════════════════════════════════
// CORE LISTING FLOW - verified from 
// ═══════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════
// LISTING TAB — opens in same window, active:true
// Exact working code from Apr 14 build
// ═══════════════════════════════════════════════════════

async function openEbayListingTab(productData, senderInfo) {
  console.log('[UnicornDS] openEbayListingTab:', productData?.title?.substring(0, 50));

  const domainStorage = await chrome.storage.local.get(['domain', 'unicornds_primary_market', 'unicornds_ebay_domain']);
  const ebayDomain = udsGetEbayDomain(domainStorage);
  const ebayUrl = 'https://www.ebay.' + ebayDomain + '/sl/prelist/suggest';

  console.log('[UnicornDS] eBay URL:', ebayUrl);

  // Tab must be active: true within the extension window to prevent Chrome throttling.
  // active: true makes it the active tab IN ITS WINDOW — does NOT focus the window itself.
  // Without this, Chrome throttles background tab JavaScript and MSKU freezes.
  const createOpts = { url: ebayUrl, active: true };
  if (senderInfo?.tab?.windowId) {
    createOpts.windowId = senderInfo.tab.windowId;
  }

  let ebayTab;
  try {
    ebayTab = await chrome.tabs.create(createOpts);
    console.log('[UnicornDS] eBay tab created:', ebayTab.id, 'in window:', ebayTab.windowId);
  } catch (e) {
    console.warn('[UnicornDS] Tab create failed, retrying without windowId:', e.message);
    ebayTab = await chrome.tabs.create({ url: ebayUrl, active: true });
  }

  await waitForTabComplete(ebayTab.id);
  await new Promise(r => setTimeout(r, 1000));

  console.log('[UnicornDS] Sending insert_draft_details to tab', ebayTab.id);
  try {
    await sendMessageToTab(ebayTab.id, { type: 'insert_draft_details', productData });
    console.log('[UnicornDS] insert_draft_details sent OK');
  } catch (err) {
    console.error('[UnicornDS] Failed to send insert_draft_details:', err.message);
  }

  console.log('[UnicornDS] Monitoring tab URL for navigation...');
  await monitorTabNavigation(ebayTab.id, productData);

  // ── HEARTBEAT-BASED SUCCESS WATCHER ─────────────────────────
  // NO artificial timeouts. The content script sends a heartbeat every 30s.
  // We just watch for 3 things:
  //   1. Tab URL changed to /sl/success → listing succeeded
  //   2. Tab closed → content script finished and closed it
  //   3. Heartbeat stopped for 2+ min → content script died, something went wrong
  // This means a product with 10 variants can take a few minutes and it's fine,
  // because the heartbeat keeps coming.
  const listingId = productData._listing_id || '';
  const listingTitle = productData.custom_title || productData.title || '';
  console.log('[UnicornDS] 👁️ Heartbeat watcher started for tab', ebayTab.id);

  // Fire and forget — don't await, let it run in background
  (async () => {
    const HEARTBEAT_KEY = 'unicornds_listing_heartbeat';
    const HEARTBEAT_DEAD_THRESHOLD = 120000; // 2 minutes without heartbeat = dead
    const MAX_ABSOLUTE_TIME = 8 * 60 * 1000; // 8 min absolute safety net (MSKU=5min + 3min buffer)
    const startTime = Date.now();

    while (true) {
      await new Promise(r => setTimeout(r, 3000)); // check every 3 seconds

      // Safety net: 8 min absolute max — skip and continue to next item
      if (Date.now() - startTime > MAX_ABSOLUTE_TIME) {
        console.log('[UnicornDS] 👁️ Absolute safety net (8 min) — skipping to next item');
        chrome.storage.local.set({
          unicornds_bulk_done: {
            success: false, error: 'Timeout (8 min) — skipped, check eBay manually',
            title: listingTitle, listing_id: listingId,
            timestamp: Date.now(), source: 'absolute_timeout'
          }
        });
        try { chrome.tabs.remove(ebayTab.id); } catch(e) {}
        return;
      }

      // Check 1: Is the tab still alive?
      let tab;
      try { tab = await chrome.tabs.get(ebayTab.id); }
      catch (e) {
        console.log('[UnicornDS] 👁️ Tab closed — listing completed or failed');
        // Check if bulk_done was already set (by listing-form.js) — if not, signal failure
        const existing = await chrome.storage.local.get('unicornds_bulk_done');
        if (!existing.unicornds_bulk_done || (Date.now() - (existing.unicornds_bulk_done.timestamp || 0)) > 5000) {
          // No recent done signal — tab closed unexpectedly
          chrome.storage.local.set({
            unicornds_bulk_done: {
              success: false, error: 'Tab closed unexpectedly',
              title: listingTitle, listing_id: listingId,
              timestamp: Date.now(), source: 'tab_closed'
            }
          });
        }
        chrome.storage.local.remove(HEARTBEAT_KEY);
        return;
      }

      // Check 2: Did eBay navigate to success page?
      const url = tab.url || '';
      if (url.includes('/sl/success')) {
        console.log('[UnicornDS] 👁️ ✅ SUCCESS detected!');
        chrome.storage.local.set({
          unicornds_bulk_done: {
            success: true, error: '', title: listingTitle,
            listing_id: listingId, timestamp: Date.now(),
            source: 'heartbeat_watcher'
          }
        });
        await new Promise(r => setTimeout(r, 2000));
        try { chrome.tabs.remove(ebayTab.id); } catch(e) {}
        chrome.storage.local.remove(HEARTBEAT_KEY);
        return;
      }

      // Check 3: Is the heartbeat still fresh?
      try {
        const hb = await chrome.storage.local.get(HEARTBEAT_KEY);
        const lastBeat = hb[HEARTBEAT_KEY] || 0;
        const beatAge = Date.now() - lastBeat;

        if (lastBeat > 0 && beatAge > HEARTBEAT_DEAD_THRESHOLD) {
          // Heartbeat stopped for 2+ minutes — content script is dead
          // But only fail if URL is still on /lstng (not navigating)
          if (url.includes('/lstng')) {
            console.warn('[UnicornDS] 👁️ Heartbeat dead for ' + Math.round(beatAge/1000) + 's — content script died on /lstng');
            chrome.storage.local.set({
              unicornds_bulk_done: {
                success: false, error: 'Content script stopped responding — listing may have failed',
                title: listingTitle, listing_id: listingId,
                timestamp: Date.now(), source: 'heartbeat_dead'
              }
            });
            try { chrome.tabs.remove(ebayTab.id); } catch(e) {}
            chrome.storage.local.remove(HEARTBEAT_KEY);
            return;
          }
          // URL is somewhere else (navigating, loading) — give it more time
        }
      } catch(e) {}
    }
  })();

  return ebayTab;
}

// Monitor tab URL changes - handles the full suggest → identify → lstng flow
async function monitorTabNavigation(tabId, productData) {
  let lastUrl = '';
  let identifySent = false;
  let lstngHandled = false;

  for (let i = 0; i < 120; i++) { // 2 minutes max
    await new Promise(r => setTimeout(r, 1000));

    let tab;
    try { tab = await chrome.tabs.get(tabId); }
    catch (e) { console.warn('[UnicornDS] Tab gone'); return; }

    const url = tab.url || '';
    if (url === lastUrl) continue;
    lastUrl = url;

    console.log('[UnicornDS] Tab URL changed:', url.substring(0, 100));

    // Reached /lstng - final destination, fill the form
    if (url.includes('/lstng') && !lstngHandled) {
      lstngHandled = true;
      console.log('[UnicornDS] ✅ Reached /lstng - sending form data');
      await new Promise(r => setTimeout(r, 800)); // let page render
      await sendDataToListingForm(tabId, productData);
      return;
    }

    // Reached /identify - send identify_product to help it along
    if (url.includes('identify') && !identifySent) {
      identifySent = true;
      console.log('[UnicornDS] Reached /identify - sending identify_product');
      await waitForTabComplete(tabId);
      await new Promise(r => setTimeout(r, 800));
      try {
        await sendMessageToTab(tabId, { type: 'identify_product', productData });
        console.log('[UnicornDS] identify_product sent');
      } catch (e) {
        console.warn('[UnicornDS] identify_product send error:', e.message);
      }
    }

    // Condition selection page - some categories (clothing, phones) show this extra step
    if (url.includes('view=cgtype') || url.includes('condition')) {
      console.log('[UnicornDS] Condition selection page detected - clicking "New with tags"');
      await waitForTabComplete(tabId);
      await new Promise(r => setTimeout(r, 1500));
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            // Click "New with tags" or first "New" condition button
            var buttons = document.querySelectorAll('.condition-button, button[class*="condition"]');
            for (var i = 0; i < buttons.length; i++) {
              var txt = buttons[i].textContent.trim();
              if (txt.indexOf('New with tags') > -1 || txt.indexOf('New') === 0) {
                buttons[i].click();
                console.log('[UnicornDS] Clicked condition:', txt.substring(0, 30));
                break;
              }
            }
            // Wait then click Continue
            setTimeout(function() {
              var cont = document.querySelector('button.btn--primary, button[class*="continue"]');
              if (!cont) {
                var allBtns = document.querySelectorAll('button');
                for (var j = 0; j < allBtns.length; j++) {
                  if (allBtns[j].textContent.trim() === 'Continue') { cont = allBtns[j]; break; }
                }
              }
              if (cont) { cont.click(); console.log('[UnicornDS] Clicked Continue'); }
            }, 1000);
          }
        });
        console.log('[UnicornDS] Condition page handled');
      } catch (e) {
        console.warn('[UnicornDS] Condition page error:', e.message);
      }
    }
  }
  console.warn('[UnicornDS] Monitor timeout - tab never reached /lstng');
}

// [S6 cleanup] identifyProductPageEbay removed — replaced by monitorTabNavigation

async function sendDataToListingForm(tabId, productData) {
  console.log('[UnicornDS] sendDataToListingForm, SKU:', productData?.sku || productData?.productId);

  // Wait for tab to finish loading
  await waitForTabComplete(tabId);

  // Inject listing-form.js via scripting API - SPA navigation doesn't trigger manifest
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content/ebay/listing-form.js'],
    });
    console.log('[UnicornDS] listing-form.js injected');
  } catch (err) {
    console.warn('[UnicornDS] inject failed (may already be loaded):', err.message);
  }

  // HANDSHAKE: Wait for content script to signal ready
  console.log('[UnicornDS] Waiting for page-loaded-and-stable from tab', tabId);
  try {
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        chrome.runtime.onMessage.removeListener(handler);
        console.warn('[UnicornDS] Handshake timeout (45s) - trying anyway');
        resolve();
      }, 45000);

      function handler(message, sender) {
        if (sender.tab && sender.tab.id === tabId && message.type === 'page-loaded-and-stable') {
          console.log('[UnicornDS] ✅ page-loaded-and-stable received');
          clearTimeout(timeout);
          chrome.runtime.onMessage.removeListener(handler);
          resolve();
        }
      }
      chrome.runtime.onMessage.addListener(handler);
    });
  } catch (e) {
    console.warn('[UnicornDS] Handshake error:', e.message);
  }

  // Send the data
  console.log('[UnicornDS] Sending insert_ebay_data');
  try {
    await sendMessageToTab(tabId, {
      type: 'insert_ebay_data',
      productData: productData,
    });
    console.log('[UnicornDS] insert_ebay_data sent OK');
  } catch (err) {
    console.error('[UnicornDS] insert_ebay_data failed:', err.message);
  }
}

// ═══════════════════════════════════════════════════════
// AI INTEGRATION - OpenAI (following 's exact flow)
//  uses: gpt-4.1-nano via their cloud function
// We use: gpt-4o-mini directly - same quality, no middleman
// ═══════════════════════════════════════════════════════

// Pick the best product image for AI vision — delegates to shared module
function pickBestImage(productData) {
  return udsPickBestImage(productData);
}

// ── IMAGE → BASE64 DATA URL ─────────────────────────────
// Fetches an AliExpress / Amazon CDN image and returns a base64 data URL
// suitable for OpenAI vision API. Handles AVIF, format negotiation, and
// AliExpress URL fallbacks. Returns null on failure.
//
// Critical context: AliExpress CDN ignores file extensions and serves AVIF
// by default unless the Accept header explicitly requests JPEG/PNG/WebP.
// OpenAI rejects AVIF → we must force a supported format.
async function fetchImageAsDataUrl(imageUrl) {
  if (!imageUrl) return null;

  // Normalise URL
  let imgSrc = imageUrl;
  if (imgSrc.startsWith('//')) imgSrc = 'https:' + imgSrc;
  if (imgSrc.includes('alicdn.com') || imgSrc.includes('aliexpress-media.com')) {
    imgSrc = imgSrc.replace(/\d+x\d+q\d+/g, '960x960q75');
  }
  if (imgSrc.includes('amazon') || imgSrc.includes('media-amazon')) {
    imgSrc = imgSrc.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.');
  }

  // Detect actual image format from magic bytes
  function detectFormat(bytes) {
    if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47) return 'image/png';
    if (bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) return 'image/jpeg';
    if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x38) return 'image/gif';
    if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 &&
        bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) return 'image/webp';
    if (bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70) return 'image/avif';
    return 'unknown';
  }

  function toBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    const CHUNK = 0x8000;
    let binary = '';
    for (let i = 0; i < bytes.length; i += CHUNK) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
    }
    return btoa(binary);
  }

  const validTypes = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];

  console.log('[UnicornDS] Vision: converting image to base64...', imgSrc.substring(0, 80));

  // Attempt 1: original URL with Accept header forcing supported formats
  try {
    const imgResp = await fetch(imgSrc, {
      headers: { 'Accept': 'image/jpeg, image/png, image/webp, image/gif' }
    });
    if (imgResp.ok) {
      const buffer = await imgResp.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const realFormat = detectFormat(bytes);
      console.log('[UnicornDS] Vision: fetched ' + (buffer.byteLength / 1024).toFixed(0) + 'KB, actual format: ' + realFormat);
      if (validTypes.includes(realFormat)) {
        const dataUrl = 'data:' + realFormat + ';base64,' + toBase64(buffer);
        console.log('[UnicornDS] Vision: base64 ready (' + realFormat + ')');
        return dataUrl;
      }
      console.warn('[UnicornDS] Vision: CDN returned ' + realFormat + ' despite Accept header');
    }
  } catch (e) {
    console.warn('[UnicornDS] Vision: attempt 1 fetch failed:', e.message);
  }

  // Attempt 2: AliExpress URL trick — change extension to .jpg
  if (imgSrc.includes('alicdn.com') || imgSrc.includes('aliexpress-media.com')) {
    const jpgUrl = imgSrc.replace(/\.\w+$/, '.jpg');
    console.log('[UnicornDS] Vision: retrying with .jpg URL:', jpgUrl.substring(0, 80));
    try {
      const retryResp = await fetch(jpgUrl, {
        headers: { 'Accept': 'image/jpeg, image/png, image/webp' }
      });
      if (retryResp.ok) {
        const buffer2 = await retryResp.arrayBuffer();
        const bytes2 = new Uint8Array(buffer2);
        const fmt2 = detectFormat(bytes2);
        console.log('[UnicornDS] Vision: retry got ' + (buffer2.byteLength / 1024).toFixed(0) + 'KB, format: ' + fmt2);
        if (validTypes.includes(fmt2)) {
          return 'data:' + fmt2 + ';base64,' + toBase64(buffer2);
        }
      }
    } catch (e2) { console.warn('[UnicornDS] Vision: .jpg retry failed:', e2.message); }
  }

  // Attempt 3: AliExpress thumbnail variant (always JPEG)
  if (imgSrc.includes('alicdn.com') || imgSrc.includes('aliexpress-media.com')) {
    const thumbUrl = imgSrc.replace(/\.\w+$/, '.jpg_120x120.jpg');
    console.log('[UnicornDS] Vision: last resort thumbnail:', thumbUrl.substring(0, 80));
    try {
      const thumbResp = await fetch(thumbUrl, {
        headers: { 'Accept': 'image/jpeg' }
      });
      if (thumbResp.ok) {
        const buffer3 = await thumbResp.arrayBuffer();
        const bytes3 = new Uint8Array(buffer3);
        const fmt3 = detectFormat(bytes3);
        if (validTypes.includes(fmt3)) {
          console.log('[UnicornDS] Vision: thumbnail worked (' + fmt3 + ', ' + (buffer3.byteLength / 1024).toFixed(0) + 'KB)');
          return 'data:' + fmt3 + ';base64,' + toBase64(buffer3);
        }
      }
    } catch (e3) { console.warn('[UnicornDS] Vision: thumbnail failed:', e3.message); }
  }

  console.warn('[UnicornDS] Vision: all image attempts failed');
  return null;
}

async function callOpenAI(systemMessage, userMessage, jsonMode = false, imageUrl = null) {
  // Step 1: If we have an image, convert it to a base64 data URL FIRST.
  // We do this once, then pass the same data URL to whichever path runs
  // (proxy or user-key fallback). Returns null if all CDN attempts fail.
  let imageDataUrl = null;
  if (imageUrl) {
    imageDataUrl = await fetchImageAsDataUrl(imageUrl);
    if (!imageDataUrl) {
      console.warn('[UnicornDS] Vision: image conversion failed — proceeding text-only');
    }
  }

  // Step 2: Try Firebase AI proxy first (no user API key needed).
  // Proxy now accepts optional imageDataUrl — works for both text and vision.
  try {
    const token = await getAuthToken();
    if (token) {
      const proxyBody = { systemPrompt: systemMessage, userMessage, jsonMode };
      if (imageDataUrl) proxyBody.imageDataUrl = imageDataUrl;

      const res = await fetch(`${CF_BASE}/aiProxy`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: proxyBody }),
      });
      if (res.ok) {
        const json = await res.json();
        const result = json.result?.result || json.result;
        const visionTag = imageDataUrl ? ' [vision]' : '';
        console.log('[UnicornDS] AI via proxy' + visionTag + ':', (result || '').substring(0, 60));
        return result;
      }
      console.warn('[UnicornDS] AI proxy failed, status:', res.status);
    }
  } catch (err) {
    console.warn('[UnicornDS] AI proxy error:', err.message);
  }

  // Step 3: Fallback — user's own API key (only used if proxy is down/auth missing)
  const storage = await chrome.storage.local.get(['unicornds_openai_key']);
  const apiKey = storage.unicornds_openai_key;
  if (!apiKey) { console.warn('[UnicornDS] No AI available — proxy failed and no user API key'); return null; }

  try {
    // Build user content using the data URL we already prepared
    const userContent = imageDataUrl
      ? [
          { type: 'image_url', image_url: { url: imageDataUrl, detail: 'low' } },
          { type: 'text', text: userMessage },
        ]
      : userMessage;

    if (imageDataUrl) console.log('[UnicornDS] Vision mode (user key) - sending image to OpenAI');

    const body = {
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: userContent },
      ],
      temperature: 0.7,
      max_tokens: 2000,
    };
    if (jsonMode) body.response_format = { type: 'json_object' };

    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + apiKey,
      },
      body: JSON.stringify(body),
    });

    if (!resp.ok) {
      const err = await resp.text();
      console.error('[UnicornDS] OpenAI error:', resp.status, err.substring(0, 200));
      return null;
    }

    const data = await resp.json();
    return data.choices?.[0]?.message?.content?.trim() || null;
  } catch (err) {
    console.error('[UnicornDS] OpenAI error:', err.message);
    return null;
  }
}

// ── TITLE OPTIMIZATION - eBay Cassini SEO Framework ──────
// Two-step process:
//   1. Research short-tail + long-tail keywords buyers search on eBay
//   2. Build 3 titles mixing those keywords, separated by " - "
//   3. Score each title and auto-pick the best
// Cassini ranks: keyword relevance > click-through > conversion
// ── MARKET LANGUAGE MAPPING ─────────────────────────────
const MARKET_LANGUAGES = {
  co_uk: { lang: 'English', locale: 'UK English' },
  com:   { lang: 'English', locale: 'US English' },
  com_au:{ lang: 'English', locale: 'Australian English' },
  ca:    { lang: 'English', locale: 'Canadian English' },
  de:    { lang: 'German',  locale: 'German (Deutsch)' },
  fr:    { lang: 'French',  locale: 'French (Français)' },
  it:    { lang: 'Italian', locale: 'Italian (Italiano)' },
  es:    { lang: 'Spanish', locale: 'Spanish (Español)' },
  nl:    { lang: 'Dutch',   locale: 'Dutch (Nederlands)' },
  at:    { lang: 'German',  locale: 'German (Deutsch, Austrian)' },
  be:    { lang: 'French',  locale: 'French (Français, Belgian)' },
  ch:    { lang: 'German',  locale: 'German (Deutsch, Swiss)' },
};

function getMarketLanguage(market) {
  return MARKET_LANGUAGES[market] || MARKET_LANGUAGES.co_uk;
}

async function optimizeTitle(productData) {
  const storage = await chrome.storage.local.get(['unicornds_custom_title_prompt', 'unicornds_primary_market']);
  const market = productData.marketplace || storage.unicornds_primary_market || 'co_uk';
  const { lang, locale } = getMarketLanguage(market);
  const langInstruction = lang !== 'English' 
    ? `\n\n═══ LANGUAGE ═══\nWRITE THE ENTIRE TITLE IN ${lang.toUpperCase()}. The listing is for eBay ${market.replace('_', '.').toUpperCase()}. Use ${locale} keywords that local buyers actually search for. Do NOT use English words unless they are commonly used in ${lang} (like "LED", "USB", "Bluetooth").`
    : '';

  const systemPrompt = storage.unicornds_custom_title_prompt ||
    `You are an elite eBay Cassini SEO specialist for 2026. Your job is to build titles that RANK #1 on eBay search by thinking like an eBay BUYER, not a Chinese seller.

═══ CRITICAL MINDSET ═══
FORGET the AliExpress/Amazon title. It's written for Chinese SEO, not eBay buyers.
Think: "What would a UK/US buyer type into eBay search to find this product?"
A buyer searching for a phone car mount types: "car phone holder" NOT "suction cup cell phone windshield dashboard mount"
A buyer searching for a camera strap types: "GoPro chest strap" NOT "adjustable action camera body harness mount"

═══ STEP 1: eBay BUYER KEYWORD RESEARCH ═══
Think about what REAL eBay buyers type:
• 2-3 SHORT-TAIL keywords (what buyers type first, 1-2 words)
  Think buyer language: "Phone Holder", "Car Mount", "LED Strip", "Chest Strap"
  NOT supplier language: "Cell Phone Bracket", "Automobile Cradle", "Luminous Diode Band"
• 3-5 LONG-TAIL keywords (buyer-intent phrases, 3-4 words)
  Include: compatibility ("for iPhone 15"), use case ("for Car Windscreen"), material ("Silicone Case")
• 2-3 ATTRIBUTE keywords (what buyers filter by)
  Colour, size, material, quantity - ONLY if confirmed from product data/image

═══ STEP 2: CASSINI 2026 TITLE RULES ═══
• EXACTLY 80 characters max - use ALL 80 characters
• First 3 words = most important for Cassini ranking AND buyer click-through
• Separate keyword groups with " - " (hyphen with spaces)
• Title Case every word
• Include the product's PRIMARY USE CASE (buyers search by what they need, not what the product is)
  Good: "Car Phone Holder - Windscreen Mount for iPhone Samsung - 360 Rotation"
  Bad: "Universal Suction Cup Mobile Phone Bracket Dashboard Cell Phone Stand"
• Add compatibility keywords: "for iPhone", "for GoPro", "for Samsung" — buyers filter by these
• Include quantity/pack size ONLY if explicitly stated in product data
• NEVER use: Chinese brand names (Xiaomi, Deli, UGREEN unless globally known), marketing fluff (Hot Sale, Free Shipping, New Arrival, Best Quality, 1pc/2pcs), special characters, emojis, ALL CAPS
• NEVER repeat keywords
• NEVER invent specs not in the product data

═══ STEP 3: GENERATE 3 TITLES ═══
Title 1: Lead with what the buyer searches → "Car Phone Holder - ..."
Title 2: Lead with the product type → "Phone Mount - ..."  
Title 3: Lead with compatibility → "iPhone Samsung Car Mount - ..."

═══ STEP 4: SCORE & PICK ═══
Score 1-10 on:
• eBay buyer search match (would a buyer find this with common search terms?)
• Click appeal (would a buyer click THIS listing over 50 others?)
• Character usage (closer to 80 = better)
• Cassini ranking (keywords in first 3 words, no repetition, attribute coverage)

If a product image is provided, USE IT as ground truth - the image shows what the product actually IS.

Return JSON:
{
  "keywords": {
    "short_tail": ["keyword1", "keyword2"],
    "long_tail": ["keyword phrase 1", "keyword phrase 2"],
    "attributes": ["attr1", "attr2"]
  },
  "titles": ["Title 1 here", "Title 2 here", "Title 3 here"],
  "scores": [8, 7, 9],
  "best": 2,
  "reasoning": "One sentence why this title wins"
}` + langInstruction;

  const specs = (productData.filteredItemSpecifics || [])
    .map(s => s.label + ': ' + s.value).join(', ');

  const userMessage = 'Product: ' + (productData.title || '') +
    (specs ? '\nSpecs: ' + specs : '') +
    (productData.category ? '\nCategory: ' + productData.category : '');

  // Pick best product image for vision - skips placeholders/store icons
  const firstImage = pickBestImage(productData);

  console.log('[UnicornDS] 🔍 Cassini SEO title optimization...', firstImage ? '(with vision)' : '(text only)');
  const result = await callOpenAI(systemPrompt, userMessage, true, firstImage);

  if (result) {
    try {
      const parsed = JSON.parse(result);
      const titles = parsed.titles || [];
      const scores = parsed.scores || [];
      const keywords = parsed.keywords || {};
      const bestIdx = parsed.best ?? 0;
      const best = titles[bestIdx] || titles[0] || '';

      console.log('[UnicornDS] 🔑 Keywords found:');
      console.log('[UnicornDS]   Short-tail:', (keywords.short_tail || []).join(', '));
      console.log('[UnicornDS]   Long-tail:', (keywords.long_tail || []).join(', '));
      console.log('[UnicornDS]   Attributes:', (keywords.attributes || []).join(', '));
      console.log('[UnicornDS] 📊 Titles generated:');
      titles.forEach((t, i) => console.log(`[UnicornDS]   ${i === bestIdx ? '★' : ' '} ${i+1}. [${scores[i] || '?'}/10] ${t}`));
      if (parsed.reasoning) console.log('[UnicornDS] 💡 Reason:', parsed.reasoning);

      // Store all data for popup / review screen
      productData.ai_titles = titles;
      productData.ai_title_scores = scores;
      productData.ai_keywords = keywords;
      productData.ai_best_title_idx = bestIdx;

      let title = best.replace(/^["']|["']$/g, '').trim();
      if (title.length > 80) title = smartTruncateTitle(title, 80);
      console.log('[UnicornDS] ✅ Best title:', title, `(${title.length}/80 chars)`);
      return title;
    } catch (e) {
      // Not JSON - use as plain text
      let title = result.replace(/^["']|["']$/g, '').trim();
      if (title.length > 80) title = smartTruncateTitle(title, 80);
      console.log('[UnicornDS] ✅ AI Title (plain):', title);
      return title;
    }
  }
  return null;
}

// Smart truncate that cuts on word boundary, never mid-letter.
// Also removes dangling words that make no sense at the end (prepositions, articles, fragments)
function smartTruncateTitle(title, maxLen) {
  if (!title || title.length <= maxLen) return title;
  // Cut to maxLen, then back off to nearest space
  let cut = title.substring(0, maxLen);
  const lastSpace = cut.lastIndexOf(' ');
  if (lastSpace > maxLen - 20) {
    cut = cut.substring(0, lastSpace);
  }
  // Strip trailing punctuation
  cut = cut.replace(/[\s,;:\-—–]+$/, '').trim();
  // Remove dangling words that make no sense at the end of a title
  // e.g. "Phone Case - Easy to" → "Phone Case"
  // e.g. "Car Mount for iPhone - with" → "Car Mount for iPhone"
  const danglingWords = /\s+(to|for|in|on|at|with|the|a|an|and|or|of|by|is|are|has|can|from|into|up|out|off|easy|your|our|my|its|this|that|very|most|more|also|new|all|no|not|so|as|be|it|if|do|we|he|she|but|use)$/i;
  // Remove up to 3 dangling words
  for (let i = 0; i < 3; i++) {
    if (danglingWords.test(cut)) {
      cut = cut.replace(danglingWords, '').trim();
    } else {
      break;
    }
  }
  // Strip trailing punctuation again after removing dangling words
  cut = cut.replace(/[\s,;:\-—–]+$/, '').trim();
  return cut;
}

// ── DESCRIPTION GENERATION - Cassini SEO Synergy ─────────
// Cassini checks keyword consistency between title + description + item specifics.
// Description must naturally contain the same keywords from the title.
// Structure: SEO-rich intro → features → benefits → trust signals → CTA
async function generateDescription(productData) {
  const storage = await chrome.storage.local.get(['unicornds_custom_desc_prompt', 'unicornds_primary_market']);
  const market = productData.marketplace || storage.unicornds_primary_market || 'co_uk';
  const { lang, locale } = getMarketLanguage(market);

  // Build keyword context from the title optimization step
  const keywordCtx = productData.ai_keywords || {};
  const allKeywords = [
    ...(keywordCtx.short_tail || []),
    ...(keywordCtx.long_tail || []),
    ...(keywordCtx.attributes || []),
  ];
  const keywordHint = allKeywords.length
    ? '\n\nKEYWORDS FROM TITLE (you MUST use these naturally in the description for Cassini SEO synergy):\n' + allKeywords.join(', ')
    : '';

  const systemPrompt = storage.unicornds_custom_desc_prompt ||
    `You are a professional eBay listing copywriter optimizing for Cassini 2026 AND buyer conversion. Your descriptions must work perfectly on MOBILE (70%+ of eBay traffic is mobile).

═══ CASSINI DESCRIPTION RULES ═══
• Cassini measures keyword consistency between TITLE → DESCRIPTION → ITEM SPECIFICS
• You MUST use the same keywords from the title naturally (2-3 times each, NOT stuffed)
• Front-load the primary keyword in the first sentence — Cassini weights early content
• Cassini rewards comprehensive descriptions (300-500 words) over short ones
• Description affects CONVERSION RATE which is a top Cassini ranking signal

═══ MOBILE-FIRST HTML STRUCTURE ═══
Use this exact format — clean, fast-loading, mobile-friendly:

1. <div style="max-width:800px;font-family:Arial,sans-serif;color:#333;line-height:1.6;padding:12px;">

2. <h2 style="font-size:20px;color:#1a1a1a;border-bottom:2px solid #7C3AED;padding-bottom:8px;">[Product Name with Primary Keyword]</h2>

3. <p style="font-size:15px;">[2-3 sentence intro — describe what it is, who it's for, why they need it. Use short-tail keywords. Write for a BUYER, not search engine.]</p>

4. <h3 style="font-size:17px;color:#1a1a1a;">Key Features</h3>
   <ul style="font-size:14px;padding-left:20px;"><li style="margin-bottom:6px;"> 6-8 specific features — dimensions, materials, specs. Weave in long-tail keywords. </li></ul>

5. <h3 style="font-size:17px;color:#1a1a1a;">Perfect For</h3>
   <p style="font-size:14px;">[3-4 specific use cases. "Ideal for car dashboards, kitchen counters, and office desks" — helps buyers imagine owning it]</p>

6. <h3 style="font-size:17px;color:#1a1a1a;">What's Included</h3>
   <p style="font-size:14px;">[Exact package contents — buyers want to know precisely what arrives]</p>

7. <div style="background:#f0f0f0;border-radius:8px;padding:12px;margin:16px 0;font-size:13px;">
   <strong>🚚 Fast Dispatch</strong> — shipped within 1 business day<br>
   <strong>✅ 30-Day Returns</strong> — hassle-free returns accepted<br>
   <strong>💬 UK Customer Support</strong> — we respond within 24 hours
   </div>

8. <p style="font-size:14px;"><strong>Order with confidence.</strong> Add to basket now — limited stock available.</p>

</div>

═══ CONVERSION RULES (what makes buyers CLICK BUY) ═══
• Answer the buyer's #1 question: "Will this work for MY situation?"
• Include compatibility: "fits iPhone 15/14/13", "works with GoPro Hero 13/12/11"
• Include measurements in BOTH metric and imperial
• Mention what problem it solves, not just what it is
• The trust signals section (dispatch, returns, support) is MANDATORY — it increases conversion 15-25%

═══ CRITICAL RULES ═══
• NEVER mention: China, AliExpress, Amazon, dropshipping, wholesale, manufacturer, factory, OEM, cheap
• NEVER use: "best quality", "top quality", "premium quality", "high quality" — empty words
• Write as a confident UK retailer, not a marketplace seller
• If you see the product image, describe specific visual details
• Return ONLY valid JSON: {"optimized_description": "<div style=...>...full HTML here...</div>"}` +
    (lang !== 'English' 
      ? `\n\n═══ LANGUAGE ═══\nWRITE THE ENTIRE DESCRIPTION IN ${lang.toUpperCase()}. The listing is for eBay ${market.replace('_', '.').toUpperCase()}. Use natural ${locale} that local buyers expect. All headings, features, benefits, and calls to action must be in ${lang}. Do NOT use English except for universal terms (LED, USB, Bluetooth, etc).`
      : '');
  const specs = (productData.filteredItemSpecifics || [])
    .map(s => s.label + ': ' + s.value).join('\n');

  const bullets = (productData.bullet_points || []).join('\n');

  const userMessage =
    'Product: ' + (productData.custom_title || productData.title || '') + '\n\n' +
    (bullets ? 'About this item:\n' + bullets + '\n\n' : '') +
    (specs ? 'Specifications:\n' + specs + '\n\n' : '') +
    (productData.descriptionText ? 'Original description:\n' + productData.descriptionText.substring(0, 800) + '\n\n' : '') +
    keywordHint +
    '\n\nCreate the Cassini-optimized eBay description following the structure above. Return as JSON: {"optimized_description": "<h2>...HTML...</h2>"}';

  // Pick best product image for vision
  const firstImage = pickBestImage(productData);

  console.log('[UnicornDS] 📝 Generating Cassini SEO description...', firstImage ? '(with vision)' : '(text only)');
  if (allKeywords.length) console.log('[UnicornDS]   Keywords to embed:', allKeywords.join(', '));
  const result = await callOpenAI(systemPrompt, userMessage, true, firstImage);

  if (result) {
    try {
      const parsed = JSON.parse(result);
      const html = (parsed.optimized_description || '').trim();
      if (html) {
        // Log keyword coverage check
        const lowerHtml = html.toLowerCase();
        const found = allKeywords.filter(k => lowerHtml.includes(k.toLowerCase()));
        console.log('[UnicornDS] ✅ AI Description:', html.length, 'chars');
        console.log('[UnicornDS]   Keyword coverage:', found.length + '/' + allKeywords.length,
          allKeywords.length ? '(' + Math.round(found.length / allKeywords.length * 100) + '%)' : '');
        return html;
      }
    } catch (e) {
      // Fallback: treat result as raw HTML
      let html = result.replace(/^```html?\n?/i, '').replace(/\n?```$/i, '').trim();
      if (html.includes('<h2>') || html.includes('<h3>')) {
        console.log('[UnicornDS] ✅ AI Description (raw):', html.length, 'chars');
        return html;
      }
    }
  }
  return null;
}

// ── PRICE ROUNDING — delegates to shared module ─────────
function applyPriceRounding(price, style) {
  return udsApplyPriceRounding(price, style);
}

// ── PROFIT CALCULATOR — delegates to shared module ─────────
function calculateProfit(sellPrice, costPrice, promoRate = 0, market = 'co_uk') {
  return udsCalculateProfit(sellPrice, costPrice, promoRate, market);
}

// ── MAIN AI ENHANCEMENT ─────────────────────────────────
async function enhanceWithAI(productData) {
  const storage = await chrome.storage.local.get([
    'unicornds_openai_key', 'unicornds_ai_enabled', 'unicornds_primary_market',
    'unicornds_stock_qty', 'unicornds_promo_rate', 'unicornds_ad_rate',
    'unicornds_markup', 'unicornds_round_prices', 'unicornds_rounding_style', 'unicornds_auto_approve',
    'unicornds_vat',
    'unicornds_markup_ali', 'unicornds_markup_amz',
    'unicornds_stock_qty_ali', 'unicornds_stock_qty_amz',
    'unicornds_promo_rate_ali', 'unicornds_promo_rate_amz',
    'unicornds_shipping_ali', 'unicornds_shipping_amz',
  ]);

  const market = productData.marketplace || storage.unicornds_primary_market || 'co_uk';

  // Step 0: Generate SKU with SOURCE PREFIX - enables right-click → supplier page
  // Format: UDS-AE-{aliexpress_product_id} or UDS-AZ-{amazon_asin}
  if (!productData.sku || !productData.sku.startsWith('UDS')) {
    const pid = productData.productId || productData.itemID || productData.sku || '';
    if (pid) {
      if (productData.source === 'amazon') {
        productData.sku = 'UDS-AZ-' + pid;
      } else {
        productData.sku = 'UDS-AE-' + pid;
      }
      console.log('[UnicornDS] SKU generated:', productData.sku);
    }
  }

  // ── EARLY DUPLICATE CHECK — before AI to save GPT credits ──
  try {
    const dupStore = await chrome.storage.local.get(['unicornds_listed_skus', 'unicornds_safety_settings']);
    const dupSafety = dupStore.unicornds_safety_settings || { duplicateCheck: true };
    if (dupSafety.duplicateCheck !== false && productData.sku) {
      const listedSkus = dupStore.unicornds_listed_skus || [];
      if (listedSkus.includes(productData.sku)) {
        console.error('[UnicornDS] 📋 EARLY DUPLICATE BLOCKED: SKU "' + productData.sku + '" already listed — skipping AI to save credits');
        productData._duplicate_blocked = true;
        return productData;
      }
    }
  } catch(e) {}

  // Step 0b-0d: Use shared pricing module (single source of truth)
  const isAmazonSource = productData.source === 'amazon';
  const pricingSettings = udsResolvePricingSettings(storage, isAmazonSource ? 'amazon' : 'aliexpress');
  
  productData.stock_quantity = pricingSettings.stockQty;
  console.log('[UnicornDS] Stock qty:', pricingSettings.stockQty, '(source:', productData.source || 'unknown', ')');

  productData.promoted_listing_ad_rate = String(pricingSettings.promoRate);
  console.log('[UnicornDS] Promo rate:', pricingSettings.promoRate + '%', '(source:', productData.source || 'unknown', ')');

  // Calculate sell price via shared module
  const rawPrice = parseFloat(productData.price?.minAmount || productData.price) || 0;
  
  // Validate price (Fixes C3: price=0 → £0.99 listing)
  const priceCheck = udsValidatePrice(rawPrice);
  if (!priceCheck.valid && !parseFloat(productData.custom_price)) {
    console.error('[UnicornDS] ⛔ PRICE VALIDATION FAILED:', priceCheck.error);
    // Don't block — let it through with a warning, user may have set custom_price
  }

  let sellPrice = parseFloat(productData.custom_price) || 0;
  if (!sellPrice || sellPrice <= 0) {
    const priceResult = udsCalculateSellPrice(rawPrice, {
      desiredProfit: pricingSettings.desiredProfit,
      promoRate: pricingSettings.promoRate,
      shippingCost: pricingSettings.shippingCost,
      vatRate: pricingSettings.vatRate,
      market: market,
      roundPrices: pricingSettings.roundPrices,
      roundingStyle: pricingSettings.roundingStyle,
    });
    if (priceResult.valid) {
      sellPrice = priceResult.sellPrice;
      if (pricingSettings.shippingCost > 0) console.log('[UnicornDS] Shipping: £' + pricingSettings.shippingCost.toFixed(2) + ' → total cost: £' + priceResult.totalCost.toFixed(2));
    } else {
      console.error('[UnicornDS] ❌ BLOCKED: Price is £0 or invalid — refusing to list. Error:', priceResult.error);
      productData.error = 'Price is £0 or invalid — cannot list. Please set a custom price.';
      productData.blocked = true;
      sendResponse({ error: 'Price scraping failed — cost is £0. Please check the product page and set a price manually.', blocked: true });
      return false;
    }
  }
  sellPrice = Math.max(sellPrice, 0.99);
  productData.custom_price = sellPrice.toFixed(2);
  console.log('[UnicornDS] Pricing: cost=' + rawPrice + ' profit=' + pricingSettings.desiredProfit + '% → sell=' + sellPrice.toFixed(2));

  // Step 0e: Calculate profit
  const totalCost = rawPrice + (pricingSettings.shippingCost || 0);
  const profitCalc = calculateProfit(sellPrice, totalCost, pricingSettings.promoRate, market);
  productData.profit_data = profitCalc;
  console.log('[UnicornDS] 💰 Profit:', profitCalc.currency + profitCalc.profit, '(' + profitCalc.profitPct + '% of cost)');
  console.log('[UnicornDS]    ', profitCalc.breakdown);

  // Step 0e2: Calculate per-variant eBay prices (with .99 rounding!)
  // So listing-form.js gets pre-calculated ebayPrice on every variant
  if (productData.variations && productData.variations.length > 0) {
    productData.variations.forEach(v => {
      if (v.price && parseFloat(v.price) > 0) {
        const varResult = udsCalculateSellPrice(parseFloat(v.price), {
          desiredProfit: pricingSettings.desiredProfit,
          promoRate: pricingSettings.promoRate,
          shippingCost: pricingSettings.shippingCost,
          vatRate: pricingSettings.vatRate,
          market: market,
          roundPrices: pricingSettings.roundPrices,
          roundingStyle: pricingSettings.roundingStyle,
        });
        v.ebayPrice = varResult.valid ? varResult.sellPrice : sellPrice;
      } else {
        v.ebayPrice = sellPrice;
      }
    });
    console.log('[UnicornDS] Variant prices (.99):', productData.variations.slice(0, 3).map(v => v.name + '=£' + v.ebayPrice).join(', '), '...');
  }

  // Step 0f: Auto-approve setting
  productData.auto_approve = storage.unicornds_auto_approve !== false; // default true
  console.log('[UnicornDS] Auto-approve:', productData.auto_approve);

  // Skip AI if already enhanced (bulk lister runs AI during scrape, then list_to_ebay calls this again)
  if (productData.ai_enhanced) {
    console.log('[UnicornDS] ⏭ AI already enhanced - skipping (title: "' + (productData.custom_title || '').substring(0, 50) + '...")');
    return productData;
  }

  if (storage.unicornds_ai_enabled === false) {
    console.log('[UnicornDS] AI disabled or no API key - using raw data');
    return productData;
  }

  console.log('[UnicornDS] ══════ AI Enhancement START ══════');

  // Step 0g: Strip banned words from title before AI (user's "Remove Words" setting)
  try {
    const removeWordsRaw = (await chrome.storage.local.get('unicornds_remove_words')).unicornds_remove_words || '';
    if (removeWordsRaw.trim()) {
      const wordsToRemove = removeWordsRaw.split(',').map(w => w.trim()).filter(Boolean);
      let title = productData.custom_title || productData.title || '';
      for (const word of wordsToRemove) {
        title = title.replace(new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '').trim();
      }
      title = title.replace(/\s{2,}/g, ' ').trim();
      productData.title = title;
      productData.custom_title = title;
      console.log('[UnicornDS] Removed', wordsToRemove.length, 'banned words from title');
    }
  } catch(e) {}

  // Step 1: Optimize title (generates 3, picks best)
  const aiTitle = await optimizeTitle(productData);
  if (aiTitle) {
    productData.custom_title = aiTitle;
    productData.cleanedTitle = aiTitle;
  }

  // Step 2: Generate description (using AI title if available)
  const aiDesc = await generateDescription(productData);
  if (aiDesc) {
    productData.ai_description = aiDesc;
  }

  // Mark as enhanced so list_to_ebay doesn't re-run AI
  productData.ai_enhanced = true;

  console.log('[UnicornDS] ══════ AI Enhancement DONE ══════');
  return productData;
}

// ═══════════════════════════════════════════════════════
// MESSAGE ROUTER
// ═══════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const type = message.type;
  // Short marker so we can see every message the main listener handles in the SW console:
  if (type && !['url-to-b64', 'list_to_ebay'].includes(type)) {
    console.log('[UnicornDS bg] msg:', type);
  }

  // ── POPUP DELEGATE: open eBay tab and dispatch a message ──
  // Popup windows die the instant they lose focus (e.g. when a new tab opens).
  // So the popup asks us (background) to do the whole open-and-send flow.
  // We keep retrying sendMessage every 500ms until the content script
  // responds OR ~10s passes. This reliably gets past eBay's slow init.
  if (type === 'uds_open_ebay_and_dispatch') {
    const urlPath = message.urlPath;
    const messageType = message.messageType;
    if (!urlPath || !messageType) {
      sendResponse({ ok: false, error: 'Missing urlPath or messageType' });
      return false;
    }
    (async () => {
      const stored = await new Promise(r => chrome.storage.local.get('unicornds_primary_market', r));
      const market = stored.unicornds_primary_market || 'co_uk';
      const domains = {
        com: 'www.ebay.com', co_uk: 'www.ebay.co.uk', de: 'www.ebay.de',
        com_au: 'www.ebay.com.au', ca: 'www.ebay.ca', fr: 'www.ebay.fr',
        it: 'www.ebay.it', es: 'www.ebay.es', nl: 'www.ebay.nl',
      };
      const domain = domains[market] || 'www.ebay.co.uk';
      const fullUrl = 'https://' + domain + urlPath;
      console.log('[UnicornDS bg] opening tab + dispatching', messageType, '→', fullUrl);

      const tab = await new Promise(r => chrome.tabs.create({ url: fullUrl }, r));

      // Retry sendMessage until the content script acknowledges, or give up.
      const MAX_ATTEMPTS = 30;          // 30 × 400ms = 12 seconds total
      const RETRY_INTERVAL_MS = 400;
      let lastError = null;
      for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
        await new Promise(r => setTimeout(r, RETRY_INTERVAL_MS));
        const response = await new Promise(r => {
          try {
            chrome.tabs.sendMessage(tab.id, { type: messageType }, (resp) => {
              lastError = chrome.runtime.lastError?.message || null;
              r(resp);
            });
          } catch (e) {
            lastError = e.message;
            r(undefined);
          }
        });
        if (response && !lastError) {
          console.log(`[UnicornDS bg] ${messageType} delivered on attempt ${attempt}`);
          return;
        }
      }
      console.warn(`[UnicornDS bg] ${messageType} never acknowledged after ${MAX_ATTEMPTS} attempts:`, lastError);
    })();
    sendResponse({ ok: true, dispatched: true });
    return false;
  }

  // ── GET TIER LIMITS (used by pages like Bulk Lister to read concurrency) ──
  if (type === 'get_tier_limits') {
    const limits = userProfile?.limits || TIER_LIMITS_FALLBACK.trial;
    const tier = userProfile?.tier || 'trial';
    sendResponse({ tier, limits });
    return false;
  }

  // ── TIER CHECK (used by content scripts before running gated features) ──
  // Returns { allowed: true, remaining } if user's tier permits the action.
  // Returns { allowed: false, error, blocked: true, upgrade: true } otherwise.
  // Currently used by: active-listings.js (Send Offers).
  if (type === 'check_tier') {
    const action = message.action;
    // Respond asynchronously so Chrome keeps the port open — a synchronous
    // sendResponse + return false path was sometimes racing with content-script
    // initialization and the caller saw `undefined`.
    setTimeout(() => {
      if (!action) { sendResponse({ allowed: false, error: 'Missing action' }); return; }
      const check = isActionAllowed(action);
      if (!check.allowed) {
        console.log(`[UnicornDS] check_tier ⛔ ${action}: ${check.reason}`);
        sendResponse({ allowed: false, error: check.reason, blocked: true, upgrade: true });
      } else {
        console.log(`[UnicornDS] check_tier ✅ ${action} (remaining: ${check.remaining ?? '∞'})`);
        sendResponse({ allowed: true, remaining: check.remaining ?? null });
      }
    }, 0);
    return true;  // keep message port open for async sendResponse
  }

  // ── LISTING FLOW ──────────────────────────────────────

  // Step 1: Content script says "list this on eBay"
  if (type === 'list_to_ebay') {
    console.log('[UnicornDS] list_to_ebay received');
    (async () => {
      try {
        // ── INPUT VALIDATION (Fixes C3: price=0, H5: empty title) ──
        const titleCheck = udsValidateTitle(message.product_data?.custom_title || message.product_data?.title);
        if (!titleCheck.valid) {
          console.error('[UnicornDS] ⛔ TITLE VALIDATION FAILED:', titleCheck.error);
          sendResponse({ success: false, error: titleCheck.error });
          return;
        }
        const priceRaw = parseFloat(message.product_data?.price?.minAmount || message.product_data?.price) || 0;
        const customPrice = parseFloat(message.product_data?.custom_price) || 0;
        if (priceRaw <= 0 && customPrice <= 0) {
          console.error('[UnicornDS] ⛔ PRICE VALIDATION FAILED: both raw price and custom price are 0 or missing');
          sendResponse({ success: false, error: 'Product price is missing or zero — cannot calculate sell price safely' });
          return;
        }

        // ── VERO SAFETY CHECK — block VERO brands from listing ──
        // BUT skip accessories (e.g. "Mount for GoPro" is NOT a VERO violation)
        const productTitle = message.product_data?.custom_title || message.product_data?.title || '';
        const productBrand = message.product_data?.brand || '';
        try {
          let vBrands = await new Promise(r => chrome.storage.local.get('unicornds_vero_brands', s => r(s.unicornds_vero_brands)));
          if (!vBrands || !vBrands.length) {
            const resp = await fetch(chrome.runtime.getURL('data/VeroList.txt'));
            const text = await resp.text();
            vBrands = text.split('\n').map(b => b.trim().toLowerCase()).filter(Boolean);
            chrome.storage.local.set({ unicornds_vero_brands: vBrands });
          }
          if (vBrands.length) {
            const titleLower = (productTitle + ' ' + productBrand).toLowerCase().replace(/[-–—]/g, ' ');
            // Accessory signals — specific phrases that indicate it's an accessory, NOT the brand itself
            // IMPORTANT: never use single common words like "for" — "Cream for Itchy Skin" is NOT an accessory
            const accPhrases = ['compatible with', 'works with', 'fits for', 'designed for', 'mount for',
              'case for', 'cover for', 'strap for', 'band for', 'holder for', 'stand for', 'bracket for',
              'bag for', 'pouch for', 'sleeve for', 'protector for', 'guard for', 'cable for', 'charger for',
              'adapter for', 'replacement for', 'aftermarket', 'generic', 'third party', 'third-party',
              'screen protector', 'tempered glass', 'tripod for', 'selfie stick', 'filter for', 'lens for',
              'cap for', 'remote for', 'not oem', 'non-oem', 'non oem', 'unbranded'];
            const isAccessory = accPhrases.some(w => titleLower.includes(w));
            
            const isVero = vBrands.some(v => {
              const vLower = v.replace(/[-–—]/g, ' ');
              let matched = false;
              if (vLower.includes(' ')) { matched = titleLower.includes(vLower); }
              else {
                const re = new RegExp('\\b' + vLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
                matched = re.test(titleLower);
              }
              if (matched && isAccessory) return false; // accessory, not counterfeit
              return matched;
            });
            if (isVero) {
              console.warn('[UnicornDS] ⛔ VERO BLOCKED — skipping listing for:', productTitle);
              chrome.storage.local.set({
                bulk_item_result: { status: 'skipped', reason: 'VERO brand detected', title: productTitle, at: Date.now() }
              });
              sendResponse({ error: 'VERO brand detected — listing blocked' });
              return;
            }
          }
        } catch(e) { console.warn('[UnicornDS] VERO pre-check error:', e.message); }

        // ── TIER GATE: listing ──
        if (!gateAction('listing', sendResponse)) return;
        // Extract variations from DOM - only if sender is an AliExpress tab (not bulk lister page)
        const senderUrl = sender.tab?.url || '';
        const isAliExpressTab = senderUrl.includes('aliexpress.com') || senderUrl.includes('aliexpress.us');
        if (sender.tab && isAliExpressTab) {
          const existingVars = message.product_data.variations || [];
          const hasNoPrices = existingVars.length === 0 || existingVars.every(v => !v.price);
          try {
            const varResults = await chrome.scripting.executeScript({
              target: { tabId: sender.tab.id },
              func: () => {
                return new Promise((resolve) => {
                  var variations = [];
                  var wraps = document.querySelectorAll('[class*="sku-item--wrap"]');
                  
                  // Collect all variant elements first
                  var allItems = [];
                  for (var w = 0; w < wraps.length; w++) {
                    var titleEl = wraps[w].querySelector('[class*="sku-item--title"]');
                    var propName = titleEl ? titleEl.textContent.trim().replace(/:\s*$/, '') : '';
                    var imgs = wraps[w].querySelectorAll('img');
                    var texts = wraps[w].querySelectorAll('[class*="sku-item--text"]');
                    if (imgs.length > 0) {
                      for (var i = 0; i < imgs.length; i++) {
                        var vName = imgs[i].alt || '';
                        var vImg = imgs[i].src || '';
                        if (vName && vName.length > 0) {
                          // Convert thumbnail to full-size alicdn URL
                          var hashMatch = vImg.match(/\/kf\/([A-Za-z0-9]+\.(?:jpg|jpeg|png))/i);
                          var fullImg = hashMatch ? 'https://ae01.alicdn.com/kf/' + hashMatch[1] : vImg;
                          allItems.push({ propName: propName, name: vName, image: fullImg, element: imgs[i] });
                        }
                      }
                    }
                    if (texts.length > 0) {
                      for (var t = 0; t < texts.length; t++) {
                        var tName = texts[t].textContent.trim();
                        if (tName && tName.length > 0) {
                          var already = false;
                          for (var c = 0; c < allItems.length; c++) { if (allItems[c].name === tName) { already = true; break; } }
                          if (!already) allItems.push({ propName: propName, name: tName, image: '', element: texts[t] });
                        }
                      }
                    }
                  }

                  // Helper to read current displayed price
                  function readPrice() {
                    // Try multiple selectors for the displayed price
                    var selectors = [
                      '[class*="price-default--current--"]',
                      '[class*="price--currentPriceText"]',
                      '[class*="price--current--"]',
                      '[class*="product-price-current"] span',
                      '[class*="uniform-banner-box-price"]',
                      '[class*="snow-price--original"]',
                    ];
                    for (var s = 0; s < selectors.length; s++) {
                      var priceEl = document.querySelector(selectors[s]);
                      if (priceEl) {
                        var txt = priceEl.textContent.trim().replace(/[^0-9.,]/g, '').replace(',', '.');
                        var val = parseFloat(txt);
                        if (val > 0) return val;
                      }
                    }
                    return 0;
                  }

                  // Click each variant to read its price (signal-based: polls for price change)
                  var idx = 0;
                  function clickNext() {
                    if (idx >= allItems.length) {
                      // Done - build result without DOM elements
                      var result = allItems.map(function(item) {
                        return { propName: item.propName, name: item.name, image: item.image, price: item.price || 0 };
                      });
                      resolve(result);
                      return;
                    }
                    var item = allItems[idx];
                    var clickTarget = item.element.closest('[class*="sku-item--item"]') || item.element.closest('button') || item.element;
                    var priceBefore = readPrice();
                    clickTarget.click();
                    
                    // Poll for price change instead of fixed 400ms (Fixes C4)
                    var pollCount = 0;
                    var pollMax = 20; // 20 × 150ms = 3s max
                    function pollPrice() {
                      var current = readPrice();
                      pollCount++;
                      if ((current !== priceBefore && current > 0) || pollCount >= pollMax) {
                        item.price = current > 0 ? current : priceBefore;
                        idx++;
                        clickNext();
                      } else {
                        setTimeout(pollPrice, 150);
                      }
                    }
                    setTimeout(pollPrice, 200); // initial delay for click to register
                  }
                  
                  if (allItems.length > 0) {
                    clickNext();
                  } else {
                    resolve([]);
                  }
                });
              }
            });
            const extractedVars = varResults?.[0]?.result || [];
            if (extractedVars.length > 0) {
              // DOM extraction has prices and full-size images - always prefer it
              message.product_data.variations = extractedVars;
              console.log('[UnicornDS] Extracted', extractedVars.length, 'variations from DOM:');
              extractedVars.forEach((v, i) => console.log('[UnicornDS]   Variant ' + i + ':', v.propName, '=', v.name, 'price:', v.price, v.image ? '[HAS IMG]' : ''));
            } else if (existingVars.length > 0) {
              console.log('[UnicornDS] DOM extraction empty - keeping', existingVars.length, 'existing variations (no prices)');
            }
          } catch (varErr) {
            console.warn('[UnicornDS] Variation extraction error:', varErr.message);
          }
        }

        // ── FLATTEN AMAZON VARIATIONS ──
        // Amazon sends: [{type: "size", options: [{name, asin, image, selected}]}]
        // eBay listing-form expects: [{name, price, image}]
        const rawVars = message.product_data.variations || [];
        if (rawVars.length > 0 && rawVars[0]?.options && Array.isArray(rawVars[0].options)) {
          const basePrice = parseFloat(message.product_data.price) || 0;
          const flatVars = [];
          for (const varType of rawVars) {
            for (const opt of varType.options) {
              // Use per-variant price if available, otherwise base price
              let optPrice = parseFloat(opt.price) || basePrice;
              let optImage = opt.image || '';
              const optAsin = opt.asin || '';

              flatVars.push({
                name: opt.name || '',
                price: optPrice,
                image: optImage,
                asin: optAsin,
                propName: varType.type || 'Option',
              });
            }
          }
          if (flatVars.length > 1) {
            message.product_data.variations = flatVars;
            console.log('[UnicornDS] Flattened Amazon variations:', flatVars.length, 'variants');
            flatVars.forEach((v, i) => console.log('[UnicornDS]   ' + i + ':', v.name, '£' + v.price, v.image ? '[IMG]' : ''));
          } else {
            console.log('[UnicornDS] Amazon variations: only 1 option, keeping as single listing');
          }
        }

        // Enhance with AI before listing
        const enhanced = await enhanceWithAI(message.product_data);

        // ── EARLY DUPLICATE — caught before AI ran ──
        if (enhanced._duplicate_blocked) {
          sendResponse({ success: false, error: 'DUPLICATE: SKU "' + enhanced.sku + '" is already listed on eBay' });
          return;
        }

        // ── COMPLIANCE CHECK ──
        if (typeof ComplianceChecker !== 'undefined') {
          const compliance = ComplianceChecker.check(enhanced);
          ComplianceChecker.formatForConsole(compliance);
          enhanced._compliance = compliance;

          if (!compliance.safe && compliance.blocks.length > 0) {
            const blockMsg = compliance.blocks.map(b => b.message).join('\n');
            console.error('[UnicornDS] 🚨 LISTING BLOCKED BY COMPLIANCE CHECK');
            sendResponse({ success: false, error: 'COMPLIANCE BLOCK: ' + compliance.blocks[0].message });
            return;
          }
        }

        // ── SAFETY CHECKS (read user toggles) ──
        const safetyStorage = await chrome.storage.local.get(['unicornds_safety_settings', 'unicornds_listed_skus']);
        const safety = safetyStorage.unicornds_safety_settings || { 
          veroCheck: true, rateLimiting: true, clothingBlock: true, 
          duplicateCheck: true, profitFloor: true 
        };

        // 1. CLOTHING & FOOTWEAR BLOCK
        if (safety.clothingBlock !== false) {
          const title = (enhanced.custom_title || enhanced.title || '').toLowerCase();
          const clothingKeywords = [
            'dress', 'blouse', 'skirt', 'trousers', 'jeans', 'leggings', 'shorts',
            'jacket', 'coat', 'hoodie', 'sweater', 'jumper', 'cardigan', 'blazer',
            't-shirt', 'tshirt', 'polo shirt', 'tank top', 'vest', 'camisole',
            'underwear', 'bra', 'boxer', 'panties', 'lingerie', 'swimsuit', 'bikini',
            'trainers', 'sneakers', 'boots', 'sandals', 'heels', 'loafers', 'slippers',
            'shoes', 'footwear', 'stiletto', 'pumps', 'espadrilles', 'moccasins',
            'pyjamas', 'pajamas', 'nightgown', 'robe', 'kimono robe',
            'suit', 'waistcoat', 'tie', 'bow tie', 'scarf', 'gloves',
          ];
          const blocked = clothingKeywords.find(kw => {
            // Word boundary match - "bra" must NOT match "brake" or "vibrant"
            const regex = new RegExp('\\b' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
            return regex.test(title);
          });
          if (blocked) {
            console.error('[UnicornDS] 🚫 CLOTHING BLOCKED: "' + blocked + '" detected in title');
            sendResponse({ success: false, error: 'CLOTHING BLOCKED: "' + blocked + '" - clothing/footwear not allowed (high return rate)' });
            return;
          }
        }

        // 2. DUPLICATE SKU CHECK
        if (safety.duplicateCheck !== false) {
          const sku = enhanced.sku || '';
          const listedSkus = safetyStorage.unicornds_listed_skus || [];
          if (sku && listedSkus.includes(sku)) {
            console.error('[UnicornDS] 📋 DUPLICATE BLOCKED: SKU "' + sku + '" already listed');
            sendResponse({ success: false, error: 'DUPLICATE: SKU "' + sku + '" is already listed on eBay' });
            return;
          }
        }

        // 3. PROFIT FLOOR GUARD - auto-adjust price UP to meet minimum profit instead of failing
        if (safety.profitFloor !== false && enhanced.profit_data) {
          const minProfit = safety.minProfitMargin || 15;
          const actualProfitPct = enhanced.profit_data.profitPct || 0;
          if (actualProfitPct < minProfit) {
            // AUTO-ADJUST: Calculate the correct sell price for minimum profit
            const costPrice = enhanced.profit_data.costPrice || enhanced.price || 0;
            const promoRate = enhanced.profit_data.promoRate ?? 0;
            const fvfRate = 0.128; // eBay final value fee 12.8%
            const promoFeeRate = promoRate / 100;
            const fixedFee = 0.30; // eBay per-item fixed fee
            // Formula: sellPrice = (costPrice * (1 + minProfit/100) + fixedFee) / (1 - fvfRate - promoFeeRate)
            let adjustedPrice = (costPrice * (1 + minProfit / 100) + fixedFee) / (1 - fvfRate - promoFeeRate);
            // Round UP to nearest .99 (never down — that would drop below minimum again)
            adjustedPrice = Math.ceil(adjustedPrice) - 0.01; // e.g. 10.43 → 10.99
            if (adjustedPrice < adjustedPrice) adjustedPrice = Math.ceil(adjustedPrice + 1) - 0.01;

            console.log('[UnicornDS] 💰 PROFIT AUTO-ADJUST: ' + actualProfitPct.toFixed(1) + '% → adjusting price from ' + enhanced.profit_data.currency + enhanced.profit_data.sellPrice + ' to ' + enhanced.profit_data.currency + adjustedPrice.toFixed(2) + ' to meet ' + minProfit + '% minimum');

            // Recalculate profit with new price
            enhanced.custom_price = adjustedPrice.toFixed(2);
            const newProfitCalc = calculateProfit(adjustedPrice, costPrice, promoRate, enhanced.ebayMarket || 'co_uk');
            enhanced.profit_data = newProfitCalc;
            console.log('[UnicornDS] 💰 New profit:', newProfitCalc.currency + newProfitCalc.profit, '(' + newProfitCalc.profitPct + '% of cost)');
          }
        }

        // Save enhanced product back so generate_item_specifics has AI data
        await chrome.storage.local.set({ unicornds_last_product: enhanced });

        // Log variations status
        if (enhanced.variations && enhanced.variations.length > 0) {
          console.log('[UnicornDS] Variations to list:', enhanced.variations.length);
          enhanced.variations.forEach((v, i) => console.log('[UnicornDS]   ' + i + ':', v.name));
        } else {
          console.log('[UnicornDS] No variations - listing as single item');
        }

        const tab = await openEbayListingTab(enhanced, sender);

        // Save SKU to listed list (for duplicate detection)
        const sku = enhanced.sku || enhanced.customLabel || '';
        if (sku) {
          const s = await chrome.storage.local.get('unicornds_listed_skus');
          const list = s.unicornds_listed_skus || [];
          if (!list.includes(sku)) {
            list.push(sku);
            await chrome.storage.local.set({ unicornds_listed_skus: list });
            console.log('[UnicornDS] SKU saved for duplicate check:', sku, '(' + list.length + ' total)');
          }
        }

        sendResponse({ success: true, tabId: tab?.id });
      } catch (err) {
        console.error('[UnicornDS] list_to_ebay error:', err);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (type === 'list_to_ebay_in_same_tab') {
    console.log('[UnicornDS] list_to_ebay_in_same_tab received');
    openEbayListingTab(message.product_data, sender).then((tab) => {
      sendResponse({ tabID: tab?.id });
    });
    return true;
  }

  // Step 3: prelist/suggest clicked Continue
  if (type === 'clicked_go_list_an_item') {
    console.log('[UnicornDS] clicked_go_list_an_item received (handled by monitor)');
    sendResponse({ response: 'ok' });
    return false;
  }

  // Step 5: prelist/identify clicked "Continue without match"
  if (type === 'clicked_continued_without_matching' || type === 'inserted_draft') {
    console.log('[UnicornDS] ' + type + ' received (handled by monitor)');
    sendResponse({ received: true });
    return false;
  }

  // ── PRODUCT DATA ──────────────────────────────────────

  if (type === 'product_scraped' || type === 'aliexpress_product_scraped') {
    chrome.storage.local.set({
      unicornds_last_product: message.data || message.product,
      unicornds_last_scrape_at: Date.now(),
    }, () => sendResponse({ success: true }));
    return true;
  }

  if (type === 'get_active_aliexpress_product') {
    chrome.storage.local.get('unicornds_last_product', (data) => {
      sendResponse({ product: data.unicornds_last_product || null });
    });
    return true;
  }

  // ── PROFIT CALCULATOR — uses shared module ─────────────
  if (type === 'calculate_profit') {
    (async () => {
      const storage = await chrome.storage.local.get(null); // get ALL settings
      const source = message.source || 'aliexpress';
      const ps = udsResolvePricingSettings(storage, source);
      const market = message.market || ps.market;
      const rawPrice = parseFloat(message.costPrice) || 0;

      let sellPrice = parseFloat(message.sellPrice) || 0;
      if (!sellPrice || sellPrice <= 0) {
        const priceResult = udsCalculateSellPrice(rawPrice, {
          desiredProfit: ps.desiredProfit,
          promoRate: ps.promoRate,
          shippingCost: ps.shippingCost,
          market,
          vatRate: ps.vatRate,
          roundPrices: ps.roundPrices,
          roundingStyle: ps.roundingStyle,
        });
        sellPrice = priceResult.valid ? priceResult.sellPrice : Math.max(rawPrice * 2, 0.99);
      }
      sellPrice = Math.max(sellPrice, 0.99);

      const result = calculateProfit(sellPrice, rawPrice, ps.promoRate, market);
      result.sellPrice = sellPrice;
      sendResponse({ profit: result });
    })();
    return true;
  }

  // ── STORE SKU WITH SOURCE URL ──────────────────────────
  if (type === 'store_sku_with_url') {
    (async () => {
      try {
        const dict = await chrome.storage.local.get('unicornds_sku_dictionary');
        const dictionary = dict.unicornds_sku_dictionary || {};
        const sku = message.sku;
        const existing = dictionary[sku] || {};

        dictionary[sku] = {
          ...existing,
          sku,
          source: message.sourceUrl?.includes('amazon') ? 'amazon' : 'aliexpress',
          productId: message.productId || existing.productId || '',
          aliexpressUrl: message.sourceUrl || existing.aliexpressUrl || '',
          sourceUrl: message.sourceUrl || existing.sourceUrl || '',
          title: message.title || existing.title || '',
          marketplace: message.marketplace || existing.marketplace || 'com',
          lastSeen: new Date().toISOString(),
          dateAdded: existing.dateAdded || new Date().toISOString(),
        };

        await chrome.storage.local.set({ unicornds_sku_dictionary: dictionary });
        console.log('[UnicornDS] SKU stored with URL:', sku, '→', message.sourceUrl?.substring(0, 60));
        sendResponse({ success: true });
      } catch (e) {
        console.warn('[UnicornDS] store_sku_with_url error:', e.message);
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  // ── GENERIC OPENAI CALL (for Title Builder etc) ────────
  if (type === 'call_openai') {
    // ── TIER GATE: ai_title ──
    if (!gateAction('ai_title', sendResponse)) return false;
    (async () => {
      const result = await callOpenAI(message.systemPrompt, message.userMessage, message.jsonMode || false);
      sendResponse({ result });
    })();
    return true;
  }

  // ── AI ITEM SPECIFICS ──────────────────────────────────

  if (type === 'generate_item_specifics') {
    // ── TIER GATE: ai_title (same gate as AI Title — both use GPT-4o vision) ──
    if (!gateAction('ai_title', sendResponse)) return false;
    const ebayFields = message.ebayFields || [];
    const scrapedSpecs = message.scrapedSpecs || [];

    console.log('[UnicornDS] generate_item_specifics:', ebayFields.length, 'fields,', scrapedSpecs.length, 'scraped specs');

    (async () => {
      const storage = await chrome.storage.local.get(['unicornds_openai_key', 'unicornds_ai_enabled']);

      // Use product data from the message (per-tab), NOT from shared storage
      const product = message.productData || {};
      const productTitle = product.custom_title || product.title || '';
      const productSpecs = scrapedSpecs.map(s => s.label + ': ' + s.value).join('\n');
      const bullets = (product.bullet_points || []).join('\n');
      const description = product.descriptionText || product.descriptionAndFeatures || '';

      // Build keyword context from Cassini title optimization
      const keywords = product.ai_keywords || {};
      const allKeywords = [
        ...(keywords.short_tail || []),
        ...(keywords.long_tail || []),
        ...(keywords.attributes || []),
      ];

      console.log('[UnicornDS] Product for specs:', productTitle.substring(0, 60) || '(no title)');
      console.log('[UnicornDS] Scraped specs:', productSpecs.substring(0, 100) || '(none)');
      if (allKeywords.length) console.log('[UnicornDS] AI keywords available:', allKeywords.join(', '));

      // ── SMART DEFAULTS - always filled even if AI fails ──
      const smartDefaults = {};
      // Detect source from SKU or product data
      const sku = product.sku || product.customLabel || '';
      const isAliExpress = sku.startsWith('AE') || (product.source || '').includes('aliexpress');
      const isAmazon = sku.startsWith('AZ') || (product.source || '').includes('amazon');
      // Country based on source
      const countryOfOrigin = isAliExpress ? 'China' : 'United Kingdom';
      
      for (const fieldInfo of ebayFields) {
        const label = fieldInfo.replace(/\s*\[OPTIONS:.*$/, '').replace(/\s*\[FREE TEXT\].*$/, '').trim();
        const labelLower = label.toLowerCase();

        if (labelLower === 'brand') smartDefaults[label] = 'Unbranded';
        if (labelLower === 'mpn') smartDefaults[label] = 'Does Not Apply';
        if (labelLower === 'manufacturer part number') smartDefaults[label] = 'Does Not Apply';
        if (labelLower === 'personalised') smartDefaults[label] = 'No';
        if (labelLower === 'country of origin' || labelLower === 'country/region of manufacture') smartDefaults[label] = countryOfOrigin;
        if (labelLower === 'seller warranty' || labelLower === 'manufacturer warranty') smartDefaults[label] = 'Does Not Apply';
        if (labelLower === 'number in pack') smartDefaults[label] = '1';
        if (labelLower === 'classic part') smartDefaults[label] = 'No';
        if (labelLower === 'performance part') smartDefaults[label] = 'No';
        if (labelLower === 'model') smartDefaults[label] = 'Does Not Apply';
        if (labelLower === 'product line') smartDefaults[label] = 'Does Not Apply';
      }

      // Try to extract obvious values from scraped specs
      for (const spec of scrapedSpecs) {
        const specLabel = (spec.label || '').toLowerCase().trim();
        const specValue = (spec.value || '').trim();
        if (!specValue) continue;

        for (const fieldInfo of ebayFields) {
          const label = fieldInfo.replace(/\s*\[OPTIONS:.*$/, '').replace(/\s*\[FREE TEXT\].*$/, '').trim();
          if (label.toLowerCase() === specLabel || label.toLowerCase().includes(specLabel)) {
            smartDefaults[label] = specValue;
          }
        }
      }

      console.log('[UnicornDS] Smart defaults:', Object.keys(smartDefaults).length, 'fields pre-filled');

      if (storage.unicornds_ai_enabled === false) {
        console.log('[UnicornDS] AI disabled - using smart defaults only');
        sendResponse({ values: Object.keys(smartDefaults).length ? smartDefaults : null });
        return;
      }

      const systemPrompt =
        'You are filling eBay item specifics for Cassini SEO. Each field is listed with its valid options.\n\n' +
        'CRITICAL RULES:\n' +
        '- Fields marked [OPTIONS: ...] have predefined values. You MUST pick one of the listed options.\n' +
        '- Fields marked "(MUST pick from options)" - ONLY use a listed option, never invent values.\n' +
        '- Fields marked "(custom allowed)" - prefer listed options but custom values are OK.\n' +
        '- Fields marked [FREE TEXT] - enter any appropriate value.\n' +
        '- Return a JSON object. Keys = field names (without the [OPTIONS] part). Values = your picks.\n' +
        '- For Brand: ALWAYS use "Unbranded" unless the brand is a well-known international brand (Apple, Samsung, Nike, Adidas, Bosch, etc). NEVER use Chinese brand names or obscure brands from AliExpress.\n' +
        '- For MPN: ALWAYS use "Does Not Apply".\n' +
        '- For Country/Region of Manufacture or Country of Origin: use "' + countryOfOrigin + '".\n' +
        '- For Warranty fields (Seller Warranty, Manufacturer Warranty): ALWAYS use "Does Not Apply" unless warranty info is explicitly stated in the source data.\n' +
        '- For Number in Pack: use "1" unless the product listing explicitly states a pack quantity.\n' +
        '- FILL EVERY FIELD. Use "Does Not Apply" for any field where you are not certain of the correct value based on the product data.\n' +
        '- NEVER guess or invent values. Only use information from the product title, specs, description, or image.\n' +
        '- For weight/size fields (Item Height, Item Width, Item Length, Item Depth, Item Weight, Item Diameter): ONLY use values found in the Source Specifications or Description. If no measurement data is available, use "Does Not Apply". NEVER guess or estimate dimensions.\n' +
        '- For Department: default to "Unisex Adults" unless product is clearly for kids/specific gender.\n' +
        '- IMPORTANT: All values MUST be 65 characters or less. eBay rejects longer values. If a value would be longer, shorten it.\n' +
        (allKeywords.length ? '\n- CASSINI SEO: Where possible, use values that match these title keywords: ' + allKeywords.join(', ') + '\n' : '') +
        '- Return ONLY valid JSON, no explanation';

      const userMessage =
        'Product Title: ' + productTitle + '\n\n' +
        (bullets ? 'Product Features:\n' + bullets + '\n\n' : '') +
        (productSpecs ? 'Source Specifications:\n' + productSpecs + '\n\n' : '') +
        (description ? 'Description:\n' + description.substring(0, 1000) + '\n\n' : '') +
        'eBay fields to fill (FILL ALL):\n' + ebayFields.join('\n');

      // Pick best product image for vision
      const firstImage = pickBestImage(product);

      try {
        console.log('[UnicornDS] Calling AI for specs...', firstImage ? '(with vision)' : '(text only)');
        const result = await callOpenAI(systemPrompt, userMessage, true, firstImage);
        if (result) {
          try {
            const values = JSON.parse(result);
            console.log('[UnicornDS] ✅ AI specs generated:', Object.keys(values).length);
            for (const [k, v] of Object.entries(values)) {
              console.log('[UnicornDS]   ', k, '=', v);
            }
            sendResponse({ values });
          } catch (parseErr) {
            console.warn('[UnicornDS] AI specs JSON parse failed:', parseErr.message);
            console.warn('[UnicornDS] Raw result:', result.substring(0, 200));
            console.log('[UnicornDS] Falling back to smart defaults');
            sendResponse({ values: smartDefaults });
          }
        } else {
          console.warn('[UnicornDS] AI specs returned null - using smart defaults');
          sendResponse({ values: Object.keys(smartDefaults).length ? smartDefaults : null });
        }
      } catch (e) {
        console.warn('[UnicornDS] AI specs error:', e.message, '- using smart defaults');
        sendResponse({ values: Object.keys(smartDefaults).length ? smartDefaults : null });
      }
    })();
    return true;
  }

  // ── BULK LISTER ────────────────────────────────────────

  if (type === 'bulk_scrape_product') {
    bulkOperationActive = true; // Keep service worker alive
    // ── TIER GATE: listing (bulk) ──
    if (!gateAction('listing', sendResponse)) return false;
    const { url, source, sku } = message;
    (async () => {
      try {
        console.log('[UnicornDS] Bulk scrape:', source, url);
        const tab = await chrome.tabs.create({ url, active: false });

        // Fixed 5 second page load wait — matches old working version
        // executeScript works on inactive tabs, no need for active:true
        await new Promise(r => setTimeout(r, 5000));

        let product = null;

        if (source === 'amazon') {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              // Reuse the Amazon scraper logic inline
              const title = document.querySelector('#productTitle')?.textContent?.trim() || '';
              if (!title) return null;

              let price = 0;
              const priceEl = document.getElementById('price_inside_buybox') ||
                             document.getElementById('newBuyBoxPrice') ||
                             document.getElementById('priceblock_ourprice') ||
                             document.getElementById('corePrice_desktop') ||
                             document.getElementById('apex_offerDisplay_desktop');
              if (priceEl) price = parseFloat(priceEl.innerText.replace(/[^0-9.]/g, '')) || 0;

              let brand = '';
              const brandEl = document.querySelector('#bylineInfo') || document.querySelector('#brand');
              if (brandEl) brand = brandEl.textContent.trim().replace(/Visit the |Brand: | Store/gi, '').trim();

              // Images
              const images = [];
              const scripts = document.querySelectorAll('script');
              for (const s of scripts) {
                if (s.innerHTML.includes('colorImages')) {
                  const m = s.innerHTML.match(/"hiRes"\s*:\s*"(https?:\/\/[^"]+)"/g);
                  if (m) m.forEach(match => {
                    const u = match.match(/"(https?:\/\/[^"]+)"/);
                    if (u) images.push(u[1]);
                  });
                  if (images.length) break;
                }
              }
              if (!images.length) {
                const landing = document.querySelector('#landingImage');
                if (landing?.src) images.push(landing.src);
              }

              // Bullets
              const bullets = [];
              document.querySelectorAll('#feature-bullets li span.a-list-item').forEach(el => {
                const t = el.textContent.trim();
                if (t && !t.toLowerCase().includes('this fits')) bullets.push(t);
              });

              // Description
              const descEl = document.querySelector('#productDescription') || document.querySelector('#aplus');
              const descHTML = descEl ? descEl.innerHTML : '';
              const descText = descEl ? descEl.innerText.trim() : '';

              // ASIN
              const asinEl = document.getElementById('ASIN');
              const asin = asinEl ? asinEl.value : (window.location.href.match(/\/dp\/([A-Z0-9]{10})/i) || [])[1] || '';

              // Specs
              const specs = [];
              document.querySelectorAll('#poExpander div[class*="po-"]').forEach(el => {
                const spans = el.querySelectorAll('span');
                if (spans.length >= 2) specs.push({ label: spans[0].innerText.trim(), value: spans[1].innerText.trim() });
              });
              document.querySelectorAll('table.a-keyvalue.prodDetTable tr').forEach(tr => {
                const th = tr.querySelector('th'), td = tr.querySelector('td');
                if (th && td) specs.push({ label: th.innerText.trim(), value: td.innerText.trim() });
              });

              return {
                title, price, brand, sku: asin,
                images: images.map(u => u.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.')),
                main_hd_images: images.map(u => u.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.')),
                bullet_points: bullets,
                descriptionHTML: descHTML,
                descriptionText: descText,
                descriptionAndFeatures: title + '\n' + bullets.join('\n') + '\n' + descText,
                itemSpecifics: specs,
                filteredItemSpecifics: specs,
                source: 'amazon',
                url: window.location.href,
              };
            }
          });
          product = results?.[0]?.result;
        } else if (source === 'aliexpress') {
          // IMPROVED: Wait for content script to scrape (more reliable than executeScript)
          product = null; // use OUTER product variable (was `let product` which shadowed it!)
          
          // Clear previous scrape data
          await chrome.storage.local.remove('unicornds_last_product');
          
          // ── CAPTCHA DETECTION ──────────────────────────────
          // Check if AliExpress is showing a CAPTCHA/verification page
          try {
            const captchaCheck = await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                const body = document.body?.innerHTML || '';
                const title = document.title || '';
                // Common AliExpress CAPTCHA indicators
                if (document.querySelector('#captcha') ||
                    document.querySelector('.captcha') ||
                    document.querySelector('[class*="captcha"]') ||
                    document.querySelector('[class*="baxia"]') ||
                    document.querySelector('#nc_1_wrapper') ||
                    document.querySelector('.nc-container') ||
                    document.querySelector('[id*="slider"]') ||
                    document.querySelector('.J_MIDDLEWARE_FRAME_WIDGET') ||
                    body.includes('punish') ||
                    body.includes('verify') && body.includes('slide') ||
                    title.includes('Verify') ||
                    title.includes('Security') ||
                    title.includes('captcha')) {
                  return 'captcha';
                }
                // Check if page is blank/error (no product content loaded)
                if (!document.querySelector('h1') && !document.querySelector('[data-pl="product-title"]')) {
                  return 'no_content';
                }
                return 'ok';
              }
            });
            
            const pageStatus = captchaCheck?.[0]?.result;
            
            if (pageStatus === 'captcha') {
              console.warn('[UnicornDS] ⚠️ CAPTCHA detected on AliExpress!');
              // Bring tab to front so user can solve it
              await chrome.tabs.update(tab.id, { active: true });
              await chrome.windows.update(tab.windowId, { focused: true });
              
              // Notify bulk lister via storage
              chrome.storage.local.set({ 
                unicornds_captcha_detected: true,
                unicornds_captcha_tab: tab.id,
                unicornds_captcha_url: url,
              });
              
              // Wait up to 120 seconds for user to solve CAPTCHA
              console.log('[UnicornDS] Waiting for user to solve CAPTCHA (120s max)...');
              let captchaSolved = false;
              for (let i = 0; i < 60; i++) { // Check every 2 seconds for 120s
                await new Promise(r => setTimeout(r, 2000));
                try {
                  const recheck = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: () => {
                      return !!(document.querySelector('h1') || 
                               document.querySelector('[data-pl="product-title"]') ||
                               document.querySelector('.product-title-text'));
                    }
                  });
                  if (recheck?.[0]?.result) {
                    captchaSolved = true;
                    console.log('[UnicornDS] ✅ CAPTCHA solved! Continuing scrape...');
                    chrome.storage.local.remove(['unicornds_captcha_detected', 'unicornds_captcha_tab', 'unicornds_captcha_url']);
                    // Wait for content script to re-run after CAPTCHA solve
                    await new Promise(r => setTimeout(r, 5000));
                    break;
                  }
                } catch (e) { /* tab might have navigated */ }
              }
              
              if (!captchaSolved) {
                console.warn('[UnicornDS] CAPTCHA not solved within 120s, skipping item');
                chrome.storage.local.remove(['unicornds_captcha_detected', 'unicornds_captcha_tab', 'unicornds_captcha_url']);
                try { await chrome.tabs.remove(tab.id); } catch(e) {}
                sendResponse({ product: null, error: 'CAPTCHA not solved — skipped' });
                return;
              }
            }
          } catch (e) {
            console.warn('[UnicornDS] CAPTCHA check failed:', e.message);
          }
          
          // ── SCRAPE via executeScript (direct, fast, reliable) ──────
          // Content script poll was removed — it failed every time and wasted 5 seconds.
          // executeScript works instantly and is more reliable for bulk scraping.
          console.log('[UnicornDS] Bulk: Scraping AliExpress via executeScript...');
          // Extra 3s for AliExpress dynamic content (matches old working version)
          await new Promise(r => setTimeout(r, 3000));
            try {
              const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              // Title - same selectors as content script
              const title = (
                document.querySelector('h1[data-pl="product-title"]')?.textContent?.trim() ||
                document.querySelectorAll('h1')[1]?.textContent?.trim() ||
                document.querySelector('.product-title-text')?.textContent?.trim() ||
                document.querySelector('h1')?.textContent?.trim() ||
                ''
              );
              if (!title || title.toLowerCase() === 'aliexpress') return null;

              // Price
              const priceEl = document.querySelector('[class*="price"][class*="current"]');
              let price = 0;
              if (priceEl) price = parseFloat(priceEl.textContent.replace(/[^\d.]/g, '')) || 0;

              // Images - extract from page JSON data (HEADER_IMAGE_PC.imagePathList)
              // This is the CLEAN source - only main product gallery photos, no description junk
              //  uses the exact same approach
              var images = [];
              var seenHashes = {};
              function addImg(src) {
                if (!src) return;
                var hm = src.match(/\/kf\/([A-Za-z0-9]+\.(?:jpg|jpeg|png))/i);
                var hash = hm ? hm[1] : src;
                if (seenHashes[hash]) return;
                seenHashes[hash] = true;
                images.push(hm ? 'https://ae01.alicdn.com/kf/' + hm[1] : src);
              }
              // Step 1: Product slider (scoped)
              ['.pdp-info-left [class*="slider--img"] img', '.main-image--wrap [class*="slider--img"] img'].forEach(function(sel) {
                document.querySelectorAll(sel).forEach(function(img) {
                  if (img.className && img.className.indexOf('videoIcon') > -1) return;
                  addImg(img.src || img.dataset?.src);
                });
              });
              // Step 2: SKU variant images
              document.querySelectorAll('[class*="sku-item--image"] img').forEach(function(img) {
                addImg(img.src || img.dataset?.src);
              });
              // Step 3: JSON fallback if DOM found nothing
              if (images.length === 0) {
                var scripts = document.querySelectorAll('script');
                for (var s = 0; s < scripts.length; s++) {
                  var text = scripts[s].textContent;
                  if (text.indexOf('imagePathList') > -1) {
                    var match = text.match(/"imagePathList"\s*:\s*\[([^\]]+)\]/);
                    if (match) {
                      var urls = match[1].match(/"(https?:\/\/[^"]+)"/g);
                      if (urls) urls.forEach(function(u) { addImg(u.replace(/"/g, '')); });
                      break;
                    }
                  }
                }
              }

              // Specs table - AliExpress puts specs in various places
              const specs = [];
              // Method 1: Product specs section (key-value pairs)
              document.querySelectorAll('[class*="specification"] [class*="property"], [class*="spec"] [class*="property"]').forEach(el => {
                const parts = el.textContent.split(':');
                if (parts.length >= 2) {
                  specs.push({ label: parts[0].trim(), value: parts.slice(1).join(':').trim() });
                }
              });
              // Method 2: Table rows
              document.querySelectorAll('[class*="specification"] tr, [class*="spec"] tr, [class*="attr"] tr').forEach(tr => {
                const cells = tr.querySelectorAll('td, th');
                if (cells.length >= 2) {
                  specs.push({ label: cells[0].textContent.trim(), value: cells[1].textContent.trim() });
                }
              });
              // Method 3: Key-value divs (newer AliExpress layout)
              document.querySelectorAll('[class*="ItemDetail"] [class*="skuKey"], [class*="property-item"]').forEach(el => {
                const label = el.querySelector('[class*="name"], [class*="key"]')?.textContent?.trim();
                const value = el.querySelector('[class*="val"], [class*="desc"]')?.textContent?.trim();
                if (label && value) specs.push({ label, value });
              });
              // Method 4: Search entire page HTML for spec patterns
              if (specs.length === 0) {
                const html = document.documentElement.innerHTML;
                const specMatches = html.match(/"attrName"\s*:\s*"([^"]+)"\s*,\s*"attrValue"\s*:\s*"([^"]+)"/g);
                if (specMatches) {
                  specMatches.forEach(m => {
                    const name = m.match(/"attrName"\s*:\s*"([^"]+)"/)?.[1];
                    const val = m.match(/"attrValue"\s*:\s*"([^"]+)"/)?.[1];
                    if (name && val) specs.push({ label: name, value: val });
                  });
                }
              }

              // Description text - extract from page data or description section
              let descText = '';
              // Try description iframe/section
              const descEl = document.querySelector('[class*="description"], [class*="detail-desc"]');
              if (descEl) descText = descEl.innerText?.trim()?.substring(0, 2000) || '';
              // Try page HTML for description in JSON
              if (!descText) {
                const html = document.documentElement.innerHTML;
                const descMatch = html.match(/"description"\s*:\s*"([^"]{50,500})"/);
                if (descMatch) descText = descMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
              }

              // Bullet points from features section
              const bullets = [];
              document.querySelectorAll('[class*="feature"] li, [class*="highlight"] li, [class*="keyFeature"]').forEach(el => {
                const txt = el.textContent?.trim();
                if (txt && txt.length > 5 && txt.length < 200) bullets.push(txt);
              });

              // Variations - extract from DOM buttons
              var variations = [];
              var varWraps = document.querySelectorAll('[class*="sku-item--wrap"]');
              for (var w = 0; w < varWraps.length; w++) {
                var titleEl = varWraps[w].querySelector('[class*="sku-item--title"]');
                var propName = titleEl ? titleEl.textContent.trim().replace(/:\s*$/, '') : '';
                // Get variant options - images with alt text or text buttons
                var imgs = varWraps[w].querySelectorAll('img');
                var texts = varWraps[w].querySelectorAll('[class*="sku-item--text"]');
                if (imgs.length > 0) {
                  for (var vi = 0; vi < imgs.length; vi++) {
                    var vName = imgs[vi].alt || '';
                    var vImg = imgs[vi].src || '';
                    if (vName && vName.length > 0) {
                      // Convert thumbnail to full-size alicdn URL
                      var hashMatch = vImg.match(/\/kf\/([A-Za-z0-9]+\.(?:jpg|jpeg|png))/i);
                      var fullImg = hashMatch ? 'https://ae01.alicdn.com/kf/' + hashMatch[1] : vImg;
                      variations.push({ propName: propName, name: vName, image: fullImg });
                    }
                  }
                }
                if (texts.length > 0) {
                  for (var ti = 0; ti < texts.length; ti++) {
                    var tName = texts[ti].textContent.trim();
                    if (tName && tName.length > 0) {
                      // Check if this name is already captured from images
                      var alreadyHave = false;
                      for (var ch = 0; ch < variations.length; ch++) {
                        if (variations[ch].name === tName) { alreadyHave = true; break; }
                      }
                      if (!alreadyHave) variations.push({ propName: propName, name: tName, image: '' });
                    }
                  }
                }
              }

              return {
                title, price,
                sku: (window.location.href.match(/item\/(\d+)/) || [])[1] || '',
                images, main_hd_images: images,
                bullet_points: bullets,
                descriptionHTML: '',
                descriptionText: descText,
                descriptionAndFeatures: title + '\n' + bullets.join('\n') + '\n' + descText,
                itemSpecifics: specs,
                filteredItemSpecifics: specs,
                source: 'aliexpress',
                url: window.location.href,
                brand: 'Unbranded',
                variations: variations,
              };
            }
          });
          product = results?.[0]?.result;
            } catch (e) {
              console.warn('[UnicornDS] Bulk executeScript failed:', e.message);
            }
        } // end aliexpress

        // Close the scrape tab - but first extract per-variant prices if we have variations
        if (product && product.variations && product.variations.length > 0) {
          try {
            const varPriceResults = await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                return new Promise((resolve) => {
                  var allItems = [];
                  document.querySelectorAll('[class*="sku-item--wrap"]').forEach(function(wrap) {
                    var titleEl = wrap.querySelector('[class*="sku-item--title"]');
                    var propName = titleEl ? titleEl.textContent.trim().replace(/:\s*$/, '') : '';
                    wrap.querySelectorAll('img[alt], [class*="sku-item--text"]').forEach(function(el) {
                      var name = el.alt || el.textContent?.trim() || '';
                      if (name) allItems.push({ propName, name, element: el });
                    });
                  });
                  function readPrice() {
                    var sels = ['[class*="price-default--current--"]', '[class*="product-price-current"]', '.product-price-value'];
                    for (var s = 0; s < sels.length; s++) {
                      var el = document.querySelector(sels[s]);
                      if (el) {
                        var txt = el.textContent.trim().replace(/[^0-9.,]/g, '').replace(',', '.');
                        var val = parseFloat(txt);
                        if (val > 0) return val;
                      }
                    }
                    return 0;
                  }
                  var idx = 0;
                  function clickNext() {
                    if (idx >= allItems.length) {
                      resolve(allItems.map(function(item) {
                        return { propName: item.propName, name: item.name, price: item.price || 0 };
                      }));
                      return;
                    }
                    var item = allItems[idx];
                    var target = item.element.closest('[class*="sku-item--item"]') || item.element.closest('button') || item.element;
                    var priceBefore = readPrice();
                    target.click();
                    // Poll for price change instead of fixed 400ms (Fixes C4)
                    var pollCount = 0;
                    function pollPrice() {
                      var current = readPrice();
                      pollCount++;
                      if ((current !== priceBefore && current > 0) || pollCount >= 20) {
                        item.price = current > 0 ? current : priceBefore;
                        idx++;
                        clickNext();
                      } else {
                        setTimeout(pollPrice, 150);
                      }
                    }
                    setTimeout(pollPrice, 200);
                  }
                  if (allItems.length > 0) clickNext(); else resolve([]);
                });
              }
            });
            const varPrices = varPriceResults?.[0]?.result || [];
            if (varPrices.length > 0) {
              for (const vp of varPrices) {
                const match = product.variations.find(v => v.name === vp.name);
                if (match) match.price = vp.price;
              }
              console.log('[UnicornDS] Bulk: Got per-variant prices for', varPrices.length, 'variants');
            }
          } catch (e) { console.warn('[UnicornDS] Bulk variant price error:', e.message); }
        }

        try { chrome.tabs.remove(tab.id); } catch (e) {}

        if (product) {
          // Apply markup + price rounding from settings — uses shared pricing module
          const storage = await chrome.storage.local.get([
            'unicornds_markup', 'unicornds_markup_ali', 'unicornds_markup_amz',
            'unicornds_openai_key', 'unicornds_ai_enabled',
            'unicornds_promo_rate', 'unicornds_promo_rate_ali', 'unicornds_promo_rate_amz',
            'unicornds_ad_rate', 'unicornds_stock_qty', 'unicornds_stock_qty_ali', 'unicornds_stock_qty_amz',
            'unicornds_round_prices', 'unicornds_rounding_style', 'unicornds_primary_market',
            'unicornds_shipping_ali', 'unicornds_shipping_amz', 'unicornds_vat',
          ]);
          // Fixes H8: use per-source settings (ali vs amz) via shared resolver
          const bulkSource = product.source || 'aliexpress';
          const ps = udsResolvePricingSettings(storage, bulkSource);
          const market = ps.market;

          // Use shared sell price calculator
          const priceResult = udsCalculateSellPrice(product.price, {
            desiredProfit: ps.desiredProfit,
            promoRate: ps.promoRate,
            shippingCost: ps.shippingCost,
            vatRate: ps.vatRate,
            market: market,
            roundPrices: ps.roundPrices,
            roundingStyle: ps.roundingStyle,
          });
          let sellPrice = 0;
          let priceBlocked = false;
          if (priceResult.valid) {
            sellPrice = priceResult.sellPrice;
          } else {
            // BLOCK: Skip product with invalid price instead of listing at £0.99
            console.error('[UnicornDS] ❌ BULK BLOCKED: Price is £0 for "' + product.title + '" — skipping');
            product.status = 'error';
            product.error = 'Price is £0 — cannot list. Check source page.';
            updateQueueStatus(product, 'failed', 'Price is £0 — skipped');
            priceBlocked = true;
          }
          
          if (!priceBlocked) {
          
          product.custom_price = sellPrice.toFixed(2);
          product.custom_title = product.title;
          product.filteredTitle = product.title;
          product.upc = 'Does Not Apply';

          // Apply profit-based pricing to per-variant prices too (via shared module)
          if (product.variations && product.variations.length > 0) {
            product.variations.forEach(v => {
              let varPrice = sellPrice;
              if (v.price && v.price > 0) {
                const varResult = udsCalculateSellPrice(v.price, {
                  desiredProfit: ps.desiredProfit,
                  promoRate: ps.promoRate,
                  shippingCost: ps.shippingCost,
                  vatRate: ps.vatRate,
                  market: market,
                  roundPrices: ps.roundPrices,
                  roundingStyle: ps.roundingStyle,
                });
                if (varResult.valid) varPrice = varResult.sellPrice;
              }
              v.ebayPrice = parseFloat(Math.max(varPrice, 0.99).toFixed(2));
            });
            console.log('[UnicornDS] Variant prices:',
              product.variations.slice(0, 3).map(v => v.name + '=' + v.ebayPrice).join(', '));
          }

          product.promoted_listing_ad_rate = String(ps.promoRate);
          product.stock_quantity = ps.stockQty;

          const profitCalc = calculateProfit(sellPrice, product.price, ps.promoRate, market);
          product.profit_data = profitCalc;
          console.log('[UnicornDS] Bulk profit:', profitCalc.currency + profitCalc.profit, '(' + profitCalc.profitPct + '% of cost)');
          // AI Enhancement - generate best title + description
          if (storage.unicornds_openai_key && storage.unicornds_ai_enabled !== false) {
            console.log('[UnicornDS] Bulk: Running AI enhancement...');
            try {
              const aiTitle = await optimizeTitle(product);
              if (aiTitle) {
                product.custom_title = aiTitle;
                product.cleanedTitle = aiTitle;
                console.log('[UnicornDS] Bulk AI Title:', aiTitle);
              }
            } catch (e) { console.warn('[UnicornDS] Bulk AI title error:', e.message); }

            try {
              const aiDesc = await generateDescription(product);
              if (aiDesc) {
                product.ai_description = aiDesc;
                console.log('[UnicornDS] Bulk AI Description:', aiDesc.length, 'chars');
              }
            } catch (e) { console.warn('[UnicornDS] Bulk AI desc error:', e.message); }

            // Mark as enhanced so list_to_ebay won't re-run AI (saves 2 API calls per item)
            product.ai_enhanced = true;
          }

          // Save for eBay form
          await chrome.storage.local.set({ unicornds_last_product: product });

          // Compliance check
          if (typeof ComplianceChecker !== 'undefined') {
            const compliance = ComplianceChecker.check(product);
            ComplianceChecker.formatForConsole(compliance);
            product._compliance = compliance;
          }

          // Log variations if found
          if (product.variations && product.variations.length > 0) {
            console.log('[UnicornDS] Bulk variations:', product.variations.length, 'found');
            product.variations.forEach((v, i) => console.log('[UnicornDS]   Variant ' + i + ':', v.propName, '=', v.name, v.image ? '[HAS IMG]' : ''));
          }

          console.log('[UnicornDS] Bulk scraped:', (product.custom_title || product.title)?.substring(0, 50), '£' + product.custom_price);
          sendResponse({ product });
          } // end if (!priceBlocked)
          else {
            sendResponse({ product: null, error: 'Price is £0 — blocked to prevent loss' });
          }
        } else {
          sendResponse({ product: null, error: 'Scrape failed' });
        }
      } catch (e) {
        console.error('[UnicornDS] Bulk scrape error:', e);
        sendResponse({ product: null, error: e.message });
      }
    })();
    return true;
  }

  // ── FAST TRACKER ────────────────────────────────────

  if (type === 'download_active_listings') {
    // Fetch active listings from eBay by opening the page and scraping.
    // Uses the SAME selectors as content/ebay/active-listings.js (which works).
    (async () => {
      try {
        const storage = await chrome.storage.local.get('unicornds_primary_market');
        const market = (storage.unicornds_primary_market || 'co_uk').replace('_', '.');
        const domain = 'www.ebay.' + market;
        const url = `https://${domain}/sh/lst/active?sort=START_TIME_NEWEST&limit=200&offset=0`;
        console.log('[UnicornDS] Fetching active listings from:', url);

        const tab = await chrome.tabs.create({ url, active: false });

        // Wait for page load + render (retry up to 15s if not ready)
        let listings = [];
        for (let attempt = 0; attempt < 5; attempt++) {
          await new Promise(r => setTimeout(r, 3000));
          try {
            const results = await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                // Use same selectors as active-listings.js
                const rows = [
                  ...document.querySelectorAll('tr.grid-row'),
                  ...document.querySelectorAll('[class*="listing-row"]'),
                  ...document.querySelectorAll('tr[data-id]'),
                ];
                const items = [];
                for (const row of rows) {
                  const titleEl = row.querySelector('div[class*="title__text"]') || row.querySelector('[class*="item-title"]');
                  const title = titleEl ? titleEl.textContent.trim() : '';
                  const skuEl = row.querySelector('td[class*="listingSKU"]') || row.querySelector('[class*="custom-label"]');
                  const customLabel = skuEl ? skuEl.textContent.trim() : '';
                  const priceEl = row.querySelector('td[class*="price"] [class*="price__current"]') ||
                                  row.querySelector('td[class*="price"] [class*="sh-strikethrough"]') ||
                                  row.querySelector('[class*="item-price"]');
                  const price = priceEl ? parseFloat(priceEl.textContent.trim().replace(/[^0-9.]/g, '')) || 0 : 0;
                  const qtyEl = row.querySelector('td[class*="availableQuantity"] [class*="cell-wrapper"]') ||
                                row.querySelector('[class*="available-qty"]');
                  const quantity = qtyEl ? parseInt(qtyEl.textContent.trim().replace(/[^0-9]/g, '')) || 0 : 0;
                  const idEl = row.querySelector('td[class*="listingId"]');
                  let itemId = '';
                  if (idEl) {
                    itemId = idEl.textContent.trim();
                  } else {
                    const gridRow = row.querySelector('.grid-row[data-id]') || row.closest('[data-id]');
                    if (gridRow) itemId = gridRow.getAttribute('data-id');
                  }
                  if (itemId && title) items.push({ itemId, customLabel, title, price, quantity });
                }
                return items;
              }
            });
            listings = results?.[0]?.result || [];
            console.log('[UnicornDS] Scrape attempt', attempt + 1, '→', listings.length, 'items');
            if (listings.length > 0) break;
          } catch (e) {
            console.warn('[UnicornDS] Scrape attempt', attempt + 1, 'error:', e.message);
          }
        }

        try { chrome.tabs.remove(tab.id); } catch (e) {}

        if (listings.length === 0) {
          sendResponse({
            success: false,
            listings: [],
            error: 'No listings found. Make sure you are logged into eBay and have active listings. If you do have listings, eBay may have changed their page layout — please report to support.',
          });
        } else {
          sendResponse({ success: true, listings });
        }
      } catch (e) {
        console.error('[UnicornDS] Download listings error:', e);
        sendResponse({ success: false, error: e.message, listings: [] });
      }
    })();
    return true;
  }

  if (type === 'tracker_check_product') {
    // ── TIER GATE: tracker ──
    if (!gateAction('tracker', sendResponse)) return false;
    const { supplier, sku, productUrl, site } = message;

    (async () => {
      try {
        console.log('[UnicornDS] Tracker checking:', sku, productUrl);

        // Open product page in background tab
        const tab = await chrome.tabs.create({ url: productUrl, active: false });

        // Wait for page to load
        await new Promise(r => setTimeout(r, 4000));

        let productData = null;

        if (supplier === 'amazon') {
          // Inject scraper into Amazon page
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              // Check for IP block / captcha
              if (document.title.includes('503') || document.querySelector('#captchacharacters')) {
                return { blocked: true };
              }

              // Check availability
              const avail = document.querySelector('#availability');
              const availText = avail?.innerText?.toLowerCase()?.trim() || '';
              const inStock = availText.includes('in stock') || availText.includes('in den warenkorb') ||
                              availText.includes('ajouter au panier') || availText === '' ||
                              !!document.querySelector('#add-to-cart-button');

              // Get price
              let price = 0;
              const priceEl = document.getElementById('price_inside_buybox') ||
                             document.getElementById('newBuyBoxPrice') ||
                             document.getElementById('priceblock_ourprice') ||
                             document.getElementById('corePrice_desktop') ||
                             document.getElementById('apex_offerDisplay_desktop');
              if (priceEl) {
                const priceText = priceEl.innerText.replace(/[^0-9.]/g, '');
                price = parseFloat(priceText) || 0;
              }

              // Get brand
              const brandEl = document.querySelector('#bylineInfo') || document.querySelector('#brand');
              const brand = brandEl?.textContent?.trim()?.replace(/Visit the |Brand: | Store/gi, '')?.trim() || '';

              // Get title
              const title = document.querySelector('#productTitle')?.textContent?.trim() || '';

              return {
                available: inStock,
                price,
                brand,
                title,
                blocked: false,
              };
            }
          });

          productData = results?.[0]?.result || { available: false };
        } else {
          // AliExpress check
          await new Promise(r => setTimeout(r, 3000)); // Extra time for AliExpress

          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const title = document.querySelector('h1')?.textContent?.trim() || '';
              const priceEl = document.querySelector('[class*="price"][class*="current"]');
              let price = 0;
              if (priceEl) {
                const t = priceEl.textContent.replace(/[^\d.]/g, '');
                price = parseFloat(t) || 0;
              }
              return { available: !!title, price, title, brand: '' };
            }
          });

          productData = results?.[0]?.result || { available: false };
        }

        // Close tab
        try { chrome.tabs.remove(tab.id); } catch (e) {}

        console.log('[UnicornDS] Tracker result:', sku, productData);
        sendResponse(productData);
      } catch (e) {
        console.error('[UnicornDS] Tracker check error:', e);
        try { /* cleanup */ } catch (e2) {}
        sendResponse({ available: false, error: e.message });
      }
    })();
    return true;
  }

  if (type === 'tracker_update_listings') {
    // ── TIER GATE: tracker (Growth+) — matches sibling tracker_check_product ──
    if (!gateAction('tracker', sendResponse)) return false;
    const { updates } = message;
    (async () => {
      try {
        // For each update, call eBay API
        let updated = 0;
        for (const upd of updates) {
          try {
            // This would call eBay's ReviseItem or EndItem API
            // For now, we log it - real API integration requires eBay OAuth tokens
            console.log('[UnicornDS] Would update:', upd);
            updated++;
          } catch (e) {
            console.error('[UnicornDS] Update error for', upd.itemId, e);
          }
        }
        sendResponse({ success: true, updated });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  // ── CREDITS & MEMBERSHIP ────────────────────────────────
  // Always return 'ultimate' membership - this is our own extension, no license gates
  if (type === 'checkMembership') {
    chrome.storage.local.get('unicornds_tier', s => {
      // All users pass  membership check - credits enforce limits
      sendResponse({ membership: 'ultimate' });
    });
    return true;
  }

  if (type === 'checkCredits') {
    chrome.storage.local.get(['unicornds_credits', 'unicornds_tier'], s => {
      const credits = s.unicornds_credits ?? 0;
      const tier = s.unicornds_tier || 'free';
      sendResponse({
        creditsAvailable: tier === 'ultimate' ? 99999 : credits,
        membership: tier === 'free' ? 'free' : 'ultimate',
      });
    });
    return true;
  }

  if (type === 'deductCredits') {
    // Deduct in Firebase (source of truth) + locally (instant feedback)
    (async () => {
      const amount = message.amount || 1;

      // 1. LOCAL DEDUCTION (instant, so UI updates immediately)
      const s = await new Promise(r => chrome.storage.local.get(['unicornds_credits', 'unicornds_tokens_used', 'unicornds_tier'], d => r(d)));
      const tier = s.unicornds_tier || 'free';
      if (tier === 'ultimate' || tier === 'empire') {
        // Still call Firebase to track usage, but don't block
      }
      const used = (s.unicornds_tokens_used || 0) + amount;
      const remaining = Math.max(0, (s.unicornds_credits || 0) - amount);
      chrome.storage.local.set({ unicornds_credits: remaining, unicornds_tokens_used: used });
      console.log('[UnicornDS] Credit deducted locally. Remaining:', remaining, 'Used:', used);

      // 2. FIREBASE DEDUCTION (source of truth — syncs to Firestore)
      try {
        const token = await getAuthToken();
        if (token) {
          const res = await fetch(`${CF_BASE}/deductCredit`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: { amount } })
          });
          if (res.ok) {
            const json = await res.json();
            const result = json.result || json;
            console.log('[UnicornDS] ✅ Firebase credit deducted. Server remaining:', result.remaining);
            // Sync local with server value
            if (result.remaining !== undefined) {
              chrome.storage.local.set({ unicornds_credits: result.remaining });
              // Update cached profile too
              if (userProfile) {
                userProfile.tokensUsed = (userProfile.tokensTotal || 100) - result.remaining;
                userProfile.usage = userProfile.usage || {};
                userProfile.usage.listings_this_month = userProfile.tokensUsed;
              }
            }
          } else {
            const errText = await res.text();
            console.warn('[UnicornDS] Firebase deductCredit failed:', res.status, errText);
            // If resource-exhausted (no credits), block locally too
            if (res.status === 429 || errText.includes('resource-exhausted') || errText.includes('No credits') || errText.includes('Trial ended')) {
              chrome.storage.local.set({ unicornds_credits: 0 });
              console.warn('[UnicornDS] ⛔ No credits remaining — local credits set to 0');
            }
          }
        } else {
          console.warn('[UnicornDS] No auth token — credit deducted locally only');
        }
      } catch (e) {
        console.warn('[UnicornDS] Firebase deductCredit error:', e.message, '— local deduction still applied');
      }

      sendResponse({ remaining });
    })();
    return true;
  }

  // ── CHECK SEND OFFERS TIER (P0-1) ────────────────────
  // [P1-19 cleanup] check_send_offers removed — superseded by generic check_tier handler

  // ── REVIEW PENDING OFFER ─────────────────────────────
  if (type === 'review_pending_offer') {
    const { url, options } = message;
    (async () => {
      try {
        const markupPct = options?.markupPercent || 60;
        console.log('[UnicornDS] Reviewing offer:', url, 'min markup:', markupPct + '%');

        const tab = await chrome.tabs.create({ url, active: false });
        await new Promise(r => setTimeout(r, 5000));

        // Scrape offer details from the offer page
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            // Extract offer price
            const offerEl = document.querySelector('[data-testid="offer-price"], .offer-price, [class*="offerPrice"]');
            const offerText = offerEl?.textContent?.replace(/[^0-9.]/g, '') || '0';
            const offerPrice = parseFloat(offerText) || 0;

            // Extract listing price
            const listEl = document.querySelector('[data-testid="listing-price"], .listing-price, [class*="listingPrice"], [class*="item-price"]');
            const listText = listEl?.textContent?.replace(/[^0-9.]/g, '') || '0';
            const listingPrice = parseFloat(listText) || 0;

            // Extract SKU
            const skuEl = document.querySelector('[data-testid="custom-label"], [class*="sku"], [class*="customLabel"]');
            const sku = skuEl?.textContent?.trim() || '';

            // Extract buyer name
            const buyerEl = document.querySelector('[data-testid="buyer-name"], [class*="buyer"], [class*="userName"]');
            const buyer = buyerEl?.textContent?.trim() || '';

            // Find accept/decline buttons
            const acceptBtn = Array.from(document.querySelectorAll('button')).find(b =>
              /accept/i.test(b.textContent) && !b.disabled);
            const declineBtn = Array.from(document.querySelectorAll('button')).find(b =>
              /decline|reject/i.test(b.textContent) && !b.disabled);

            return {
              offerPrice, listingPrice, sku, buyer,
              hasAccept: !!acceptBtn, hasDecline: !!declineBtn,
            };
          }
        });

        const data = results?.[0]?.result;
        if (!data || !data.offerPrice) {
          try { chrome.tabs.remove(tab.id); } catch(e) {}
          sendResponse({ success: false, error: 'Could not read offer details', action: 'error' });
          return;
        }

        console.log('[UnicornDS] Offer:', data.offerPrice, 'Listing:', data.listingPrice, 'SKU:', data.sku);

        // Look up cost price from SKU dictionary
        let costPrice = 0;
        if (data.sku) {
          const dict = await chrome.storage.local.get('unicornds_sku_dictionary');
          const dictionary = dict.unicornds_sku_dictionary || {};
          const entry = dictionary[data.sku] || dictionary[data.sku.replace(/_V\d+$/, '')];
          if (entry?.costPrice) costPrice = entry.costPrice;
        }

        // Calculate markup
        let action = 'accept';
        let reason = '';
        if (costPrice > 0) {
          const profitPct = ((data.offerPrice - costPrice) / costPrice) * 100;
          if (profitPct < markupPct) {
            action = 'decline';
            reason = 'Offer £' + data.offerPrice.toFixed(2) + ' = ' + profitPct.toFixed(0) + '% markup (min ' + markupPct + '%)';
          } else {
            reason = 'Offer £' + data.offerPrice.toFixed(2) + ' = ' + profitPct.toFixed(0) + '% markup ✓';
          }
        } else {
          // No cost data - accept if offer >= 70% of listing price
          const pctOfListing = (data.offerPrice / data.listingPrice) * 100;
          if (pctOfListing < 70) {
            action = 'decline';
            reason = 'Offer is ' + pctOfListing.toFixed(0) + '% of listing (min 70%)';
          } else {
            reason = 'Offer is ' + pctOfListing.toFixed(0) + '% of listing ✓';
          }
        }

        console.log('[UnicornDS] Decision:', action, reason);

        // Click accept or decline
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (decision) => {
            const btn = Array.from(document.querySelectorAll('button')).find(b =>
              decision === 'accept' ? /accept/i.test(b.textContent) : /decline|reject/i.test(b.textContent)
            );
            if (btn) btn.click();
          },
          args: [action]
        });

        await new Promise(r => setTimeout(r, 3000));

        // Confirm if needed
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const confirmBtn = Array.from(document.querySelectorAll('button')).find(b =>
              /confirm|yes|submit/i.test(b.textContent) && !b.disabled);
            if (confirmBtn) confirmBtn.click();
          }
        });

        await new Promise(r => setTimeout(r, 2000));
        if (!options?.keepTabOpen) { try { chrome.tabs.remove(tab.id); } catch(e) {} }

        sendResponse({ success: true, action, amount: data.offerPrice, reason });

      } catch(e) {
        console.error('[UnicornDS] Review offer error:', e);
        sendResponse({ success: false, error: e.message, action: 'error' });
      }
    })();
    return true;
  }

  // ── PAGE NAVIGATION ───────────────────────────────────

  // [P1-19 cleanup] open_review_screen removed — zero senders

  if (type === 'open_options') {
    chrome.runtime.openOptionsPage();
    sendResponse({ success: true });
    return false;
  }

  // ── REVIEW SCREEN ─────────────────────────────────────

  if (type === 'listing_review_decision') {
    chrome.storage.local.set({
      unicornds_review_decision: {
        approved: message.approved,
        listing: message.listing,
        timestamp: Date.now(),
      }
    }, () => sendResponse({ success: true }));
    return true;
  }

  // ── EBAY CONNECTION CHECK ─────────────────────────────

  if (type === 'check_ebay_connection') {
    chrome.tabs.query({ url: '*://*.ebay.*/*' }, (tabs) => {
      sendResponse({ connected: tabs.length > 0, sessionBased: true });
    });
    return true;
  }

  // ── IMAGE URL TO BASE64 ────────────────────────────────
  if (type === 'url-to-b64') {
    const imageUrl = message.url;
    console.log('[UnicornDS] url-to-b64:', imageUrl?.substring(0, 80));

    (async () => {
      try {
        const response = await fetch(imageUrl);
        if (!response.ok) {
          sendResponse({ error: 'HTTP ' + response.status });
          return;
        }
        const contentType = response.headers.get('content-type') || 'image/jpeg';
        const buffer = await response.arrayBuffer();
        const bytes = new Uint8Array(buffer);

        // Chunked base64 encoding - handles large images without stack overflow
        const CHUNK = 0x8000;
        let binary = '';
        for (let i = 0; i < bytes.length; i += CHUNK) {
          binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
        }
        const b64 = btoa(binary);
        const dataUrl = 'data:' + contentType + ';base64,' + b64;

        console.log('[UnicornDS] url-to-b64 OK:', (buffer.byteLength / 1024).toFixed(0) + 'KB');
        sendResponse({ b64Image: dataUrl });
      } catch (err) {
        console.error('[UnicornDS] url-to-b64 error:', err.message);
        sendResponse({ error: err.message });
      }
    })();
    return true;
  }

  // ── MISC ──────────────────────────────────────────────

  // Stock check — fetches source URL (Amazon/AliExpress) and parses availability + price
  // Called by active-listings Stock Check button. Must return true for async sendResponse.
  if (type === 'uds_check_source_stock') {
    (async () => {
      try {
        const url = message.url;
        if (!url) { sendResponse({ error: 'No URL provided' }); return; }
        const isAmazon = url.includes('amazon.');
        const isAli = url.includes('aliexpress.');
        if (!isAmazon && !isAli) { sendResponse({ error: 'Unsupported source' }); return; }

        const res = await fetch(url, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Accept': 'text/html,application/xhtml+xml',
            'User-Agent': navigator.userAgent,
          },
        });
        if (!res.ok) { sendResponse({ error: 'HTTP ' + res.status }); return; }
        const html = await res.text();

        let inStock = false;
        let price = '';
        let source = isAmazon ? 'amazon' : 'aliexpress';

        if (isAmazon) {
          // Amazon markers: if "currently unavailable" / "out of stock" appears, treat as out.
          // Otherwise look for buybox availability.
          const outMarkers = [
            /currently unavailable/i,
            /out of stock/i,
            /we don't know when or if this item will be back/i,
          ];
          const isOut = outMarkers.some(re => re.test(html));
          if (isOut) {
            inStock = false;
          } else {
            // "In Stock" or buybox present + price = in stock
            const inMarker = /<span[^>]*class="[^"]*a-size-medium[^"]*a-color-success[^"]*"[^>]*>\s*In Stock/i.test(html)
              || /id="add-to-cart-button"/i.test(html)
              || /id="buy-now-button"/i.test(html);
            inStock = inMarker;
          }
          // Price
          const priceMatch = html.match(/"priceAmount"\s*:\s*([\d.]+)/) ||
                             html.match(/<span class="a-offscreen">\s*([£$€][\d.,]+)\s*<\/span>/) ||
                             html.match(/id="priceblock_ourprice"[^>]*>\s*([£$€][\d.,]+)/);
          if (priceMatch) {
            price = priceMatch[1].startsWith('£') || priceMatch[1].startsWith('$') || priceMatch[1].startsWith('€')
              ? priceMatch[1]
              : '£' + priceMatch[1];
          }
        } else {
          // AliExpress — page is JS-heavy, so we check the embedded JSON
          // If we see "sku" data and no "sold out" marker, assume in stock.
          const outMarkers = [/"status"\s*:\s*"OUT_OF_STOCK"/i, /sold out/i];
          const isOut = outMarkers.some(re => re.test(html));
          inStock = !isOut && /"skuInfo"|"skuModule"/.test(html);
          const priceMatch = html.match(/"formatedPrice"\s*:\s*"([^"]+)"/);
          if (priceMatch) price = priceMatch[1];
        }

        sendResponse({ inStock, price, source });
      } catch (e) {
        console.warn('[UnicornDS] Stock check error:', e.message);
        sendResponse({ error: e.message });
      }
    })();
    return true; // async
  }

  if (type === 'openNewTab') {
    const opts = message.options || {};
    chrome.tabs.create({ url: message.url, active: opts.active !== false });
    return false;
  }

  if (type === 'activate_this_tab') {
    // Activate tab in its own window (extension window, not user's main window)
    if (sender.tab) {
      (async () => {
        try {
          await chrome.tabs.update(sender.tab.id, { active: true });
          console.log('[UnicornDS] Activated tab', sender.tab.id, 'in window', sender.tab.windowId);
        } catch(e) { console.warn('[UnicornDS] Tab activate error:', e.message); }
      })();
    }
    return false;
  }

  if (type === 'deactivate_ebay_tab') {
    // No-op — eBay tab is in extension window, user's main window not affected
    console.log('[UnicornDS] Deactivate requested (user in separate window — no action)');
    return false;
  }

  if (type === 'open_msku') {
    // ── TIER GATE: bulk_lister (MSKU) ──
    if (!gateAction('bulk_lister', sendResponse)) return false;
    (async () => {
      try {
        const { draftId, variations, price, quantity, sku } = message;
        console.log('[UnicornDS] Opening MSKU for draftId:', draftId, 'with', variations.length, 'variations');

        // Store variation data for msku-form.js to pick up
        await chrome.storage.local.set({
          unicornds_msku_data: { variations, price, quantity, sku }
        });

        // Construct MSKU URL — uses shared domain resolver (Fixes C5)
        const domainData = await chrome.storage.local.get(['domain', 'unicornds_primary_market', 'unicornds_ebay_domain']);
        const ebayDomain = udsGetEbayDomain(domainData);
        const mskuUrl = 'https://bulkedit.ebay.' + ebayDomain + '/msku?draftId=' + draftId + '&listingMode=ReviseItem&isSingleListFlow=true';
        console.log('[UnicornDS] MSKU URL:', mskuUrl);

        const mskuTab = await chrome.tabs.create({ url: mskuUrl, active: true, windowId: sender.tab?.windowId });
        console.log('[UnicornDS] MSKU tab created:', mskuTab.id);

        sendResponse({ success: true });
      } catch (e) {
        console.error('[UnicornDS] open_msku error:', e);
        sendResponse({ error: e.message });
      }
    })();
    return true;
  }

  if (type === 'msku_complete') {
    console.log('[UnicornDS] MSKU variations saved successfully');
    // Don't close tab - MSKU now runs inside iframe on the listing form page
    return false;
  }

  if (type === 'call_anthropic') {
    // ── TIER GATE: ai_title (Claude API is an AI feature, same tier as AI Titles) ──
    if (!gateAction('ai_title', sendResponse)) return false;
    (async () => {
      try {
        const storage = await chrome.storage.local.get(['unicornds_openai_key']);
        const apiKey = storage.unicornds_openai_key;
        if (!apiKey) { sendResponse({ error: 'No API key set. Add your Anthropic/OpenAI key in Settings.' }); return; }
        const res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify({
            model: message.model || 'claude-sonnet-4-20250514',
            max_tokens: message.max_tokens || 1000,
            system: message.system || '',
            messages: message.messages || [],
          }),
        });
        const data = await res.json();
        if (!res.ok) { sendResponse({ error: data.error?.message || `API error ${res.status}` }); return; }
        sendResponse({ content: data.content });
      } catch (e) { sendResponse({ error: e.message }); }
    })();
    return true;
  }

  if (type === 'close_current_tab') {
    if (sender.tab) {
      try { chrome.tabs.remove(sender.tab.id); } catch(e) {}
    }
    return false;
  }

  if (type === 'makeTabActive') {
    // Tab runs in its own window - no need to steal focus
    sendResponse({ success: true });
    return false;
  }

  if (type === 'aliexpress_scrape_failed') {
    console.warn('[UnicornDS] Scrape failed:', message.url, message.reason);
    return false;
  }

  // Content script requests captured eBay API headers
  if (type === 'get_ebay_headers') {
    if (sender.tab && ebayApiHeaders[sender.tab.id]) {
      chrome.tabs.sendMessage(sender.tab.id, {
        type: 'ebay_request_headers',
        headers: ebayApiHeaders[sender.tab.id],
      });
      console.log('[UnicornDS] Sent cached headers to tab', sender.tab.id);
    }
    return false;
  }

  if (type === 'page-loaded-and-stable') {
    return false;
  }

  // ═══════════════════════════════════════════════
  // PRODUCT HUNTER - Amazon search orchestrator
  // ═══════════════════════════════════════════════
  if (type === 'hunter_search') {
    // ── TIER GATE: hunter_search ──
    if (!gateAction('hunter_search', sendResponse)) return false;
    const { keyword, settings } = message;
    console.log('[UnicornDS] Hunter: searching Amazon for:', keyword);

    const url = buildAmazonSearchUrl(keyword, settings);
    console.log('[UnicornDS] Hunter: opening', url);

    chrome.tabs.create({ url, active: false }, (tab) => {
      let tabClosed = false;
      const closeTab = () => {
        if (tabClosed) return;
        tabClosed = true;
        chrome.tabs.remove(tab.id).catch(() => {});
      };

      const onUpdated = (tabId, info) => {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);

          setTimeout(() => {
            chrome.tabs.sendMessage(tab.id, {
              type: 'hunter_scrape_search',
              keyword: keyword,
              settings: settings,
            }, (response) => {
              const products = response?.products || [];
              console.log('[UnicornDS] Hunter: received', products.length, 'products for:', keyword);

              // Use unique key per batch to avoid race conditions with concurrent tabs
              const batchKey = 'hunter_batch_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
              const saveData = {};
              saveData[batchKey] = { products, keyword, timestamp: Date.now() };
              saveData['hunter_term_complete'] = Date.now();

              chrome.storage.local.set(saveData, () => {
                console.log('[UnicornDS] Hunter: saved batch', batchKey, 'with', products.length, 'products');
                closeTab();
              });
            });
          }, 2500 + Math.random() * 1500);
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdated);

      // Timeout - close + signal complete after 30s
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.storage.local.set({ hunter_term_complete: Date.now() });
        closeTab();
      }, 30000);
    });

    sendResponse({ started: true });
    return false;
  }

  // [P1-19 cleanup] hunter_search_scraped removed — zero senders (legacy)

  if (type === 'openProductHunter') {
    chrome.tabs.create({ url: chrome.runtime.getURL('pages/product-hunter/hunter.html') });
    return false;
  }

  // Open Bulk Lister with pre-filled Amazon links (from Product Hunter transfer)
  if (type === 'openBulkUploadPage') {
    // ── TIER GATE: bulk_lister ──
    if (!gateAction('bulk_lister', sendResponse)) return false;
    const newLinks = message.amazonLinks || [];
    console.log('[UnicornDS] Transfer to Bulk Lister:', newLinks.length, 'links');

    // APPEND to existing links (don't overwrite)
    chrome.storage.local.get('bulk_links', (s) => {
      const existing = (s.bulk_links || '').trim();
      const combined = existing ? existing + '\n' + newLinks.join('\n') : newLinks.join('\n');
      // Deduplicate
      const unique = [...new Set(combined.split('\n').map(l => l.trim()).filter(Boolean))];
      console.log('[UnicornDS] Bulk Lister total links:', unique.length, '(added', newLinks.length, 'new)');

      chrome.storage.local.set({ bulk_links: unique.join('\n') }, () => {
        // Try to find existing Bulk Lister tab and reload it
        const bulkUrl = chrome.runtime.getURL('pages/bulk-lister/bulk-lister.html');
        chrome.tabs.query({}, (tabs) => {
          const existing = tabs.find(t => t.url && t.url.includes('bulk-lister/bulk-lister.html'));
          if (existing) {
            chrome.tabs.reload(existing.id);
            chrome.tabs.update(existing.id, { active: true });
          } else {
            chrome.tabs.create({ url: bulkUrl });
          }
        });
      });
    });
    return false;
  }

  // Open Bulk Lister from Competitor Scanner (with eBay item URLs to search on Amazon)
  if (type === 'openBulkLister') {
    chrome.tabs.create({ url: chrome.runtime.getURL('pages/bulk-lister/bulk-lister.html') });
    return false;
  }

  // ═══════════════════════════════════════════════
  // EBAY SEARCH BUTTONS - Action handlers
  // ═══════════════════════════════════════════════

  // Search Amazon for an eBay item's title
  if (type === 'search-on-amazon') {
    const { searchQuery, options, itemData } = message;
    const domain = options?.domain || 'co.uk';
    const sort = options?.sort || 'reviews';
    const url = buildAmazonSearchUrl(searchQuery, {
      domain: domain,
      sortBy: sort,
      primeOnly: true,
    });
    chrome.tabs.create({ url, active: options?.isTabActive !== false });
    sendResponse({ ok: true });
    return false;
  }

  // List an eBay item (opens the item page, scrapes it, then lists)
  if (type === 'listFromEbayItem') {
    const { itemData } = message;
    console.log('[UnicornDS] List from eBay item:', itemData?.title);

    if (itemData?.url) {
      // Open the eBay item page - content script will handle scraping
      chrome.tabs.create({ url: itemData.url, active: true });
    } else if (itemData?.itemNumber) {
      chrome.storage.local.get('unicornds_ebay_domain', (result) => {
        const domain = result.unicornds_ebay_domain || 'co.uk';
        chrome.tabs.create({
          url: `https://www.ebay.${domain}/itm/${itemData.itemNumber}`,
          active: true,
        });
      });
    }
    sendResponse({ ok: true });
    return false;
  }

  // Google Image search
  if (type === 'search_image_on_google') {
    const url = `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(message.imageUrl)}`;
    chrome.tabs.create({ url, active: true });
    return false;
  }

  // ═══════════════════════════════════════════════
  // COMPETITOR SCANNER - Seller scanning
  // ═══════════════════════════════════════════════
  if (type === 'scanner_scan_seller') {
    // ── TIER GATE: competitor_scan ──
    if (!gateAction('competitor_scan', sendResponse)) return false;
    const { url, seller, autoClose } = message;
    const MAX_PAGES = 10;
    console.log('[UnicornDS] Scanner: opening seller page for', seller, '(max', MAX_PAGES, 'pages)');

    // ── Inline scraper function — injected into each page ──
    const inlineScraperFn = () => {
      // ── DIAGNOSTICS ──
      console.log('[UnicornDS] Scanner: URL:', window.location.href);
      console.log('[UnicornDS] Scanner: Title:', document.title);
      console.log('[UnicornDS] Scanner: Body length:', document.body?.innerHTML?.length || 0);
      console.log('[UnicornDS] Scanner: All li:', document.querySelectorAll('li').length);
      console.log('[UnicornDS] Scanner: /itm/ links:', document.querySelectorAll('a[href*="/itm/"]').length);
      console.log('[UnicornDS] Scanner: .s-item:', document.querySelectorAll('.s-item').length);
      console.log('[UnicornDS] Scanner: .srp-results:', document.querySelectorAll('.srp-results').length);
      console.log('[UnicornDS] Scanner: #srp-river-results:', document.querySelectorAll('#srp-river-results').length);
      // Log all unique class names on direct children of body or main containers
      const mainEl = document.querySelector('main, #mainContent, #srp-river-results, .srp-results, [role="main"]');
      if (mainEl) {
        console.log('[UnicornDS] Scanner: main container tag:', mainEl.tagName, 'class:', mainEl.className?.substring(0, 200));
        const kids = mainEl.querySelectorAll(':scope > *');
        console.log('[UnicornDS] Scanner: main children:', kids.length);
        kids.forEach((k, i) => { if (i < 5) console.log('[UnicornDS] Scanner: child', i, k.tagName, k.className?.substring(0, 100)); });
      } else {
        console.log('[UnicornDS] Scanner: NO main container found');
        // Dump first few top-level elements
        const bodyKids = document.body?.children || [];
        for (let i = 0; i < Math.min(bodyKids.length, 5); i++) {
          console.log('[UnicornDS] Scanner: body child', i, bodyKids[i].tagName, bodyKids[i].id, bodyKids[i].className?.substring(0, 100));
        }
      }
      // Check for CAPTCHA or empty states
      if (document.body?.innerText?.includes('verify') || document.body?.innerText?.includes('robot')) {
        console.log('[UnicornDS] Scanner: POSSIBLE CAPTCHA DETECTED');
      }
      // ── END DIAGNOSTICS ──

      const selectors = [
        '#srp-river-results .s-item',
        '.srp-results .s-item',
        'ul.srp-results li.s-item',
        '.srp-river-results li.s-item',
        'li.s-item[data-viewport]',
        'li.s-item',
        '.b-list__items_nofooter > li',
        '.srp-river-results [data-gr4]',
        '[data-view="mi:1953"]',
        '.srp-lista--results .srp-lista--item',
      ];
      let itemEls = [];
      for (const sel of selectors) {
        itemEls = document.querySelectorAll(sel);
        console.log('[UnicornDS] Scanner: selector', sel, '→', itemEls.length, 'matches');
        if (itemEls.length > 1) break;
      }
      if (itemEls.length <= 1) {
        const allLi = document.querySelectorAll('li');
        const itmLis = Array.from(allLi).filter(li => li.querySelector('a[href*="/itm/"]'));
        console.log('[UnicornDS] Scanner: li fallback → total li:', allLi.length, 'with /itm/:', itmLis.length);
        if (itmLis.length > 0) itemEls = itmLis;
      }
      if (itemEls.length <= 1) {
        const allLinks = document.querySelectorAll('a[href*="/itm/"]');
        console.log('[UnicornDS] Scanner: /itm/ link fallback →', allLinks.length, 'links');
        // Log the parent chain of first link to understand DOM structure
        if (allLinks.length > 0) {
          let el = allLinks[0];
          const chain = [];
          for (let depth = 0; depth < 8 && el; depth++) {
            chain.push(el.tagName + (el.id ? '#' + el.id : '') + (el.className ? '.' + el.className.split(' ').slice(0, 3).join('.') : ''));
            el = el.parentElement;
          }
          console.log('[UnicornDS] Scanner: first /itm/ parent chain:', chain.join(' → '));
        }
        const parents = new Set();
        allLinks.forEach(a => { if (a.closest('li, [class*="item"], [class*="card"], article, [class*="result"]')) parents.add(a.closest('li, [class*="item"], [class*="card"], article, [class*="result"]')); });
        if (parents.size > 0) itemEls = Array.from(parents);
        console.log('[UnicornDS] Scanner: parent container fallback →', itemEls.length, 'items');
      }
      console.log('[UnicornDS] Scanner inline: found', itemEls.length, 'raw items, URL:', window.location.href);
      const scraped = [];

      // ── UNIVERSAL FALLBACK: if selectors found nothing, build items from /itm/ links ──
      if (itemEls.length <= 1) {
        console.log('[UnicornDS] Scanner: using universal /itm/ link scraper');
        const allItmLinks = document.querySelectorAll('a[href*="/itm/"]');
        const seen = new Set();
        allItmLinks.forEach(a => {
          const href = a.href?.split('?')[0];
          if (!href || seen.has(href)) return;
          seen.add(href);
          const itemNumber = href.split('/').pop();
          // Walk up to find a container
          const container = a.closest('li, article, div[class*="item"], div[class*="card"], div[class*="result"], tr') || a.parentElement?.parentElement;
          if (!container) return;
          // Extract title - prefer the link text or nearby heading
          let title = '';
          const heading = container.querySelector('h3, h4, [role="heading"], .s-item__title');
          if (heading) title = heading.textContent.trim();
          if (!title) title = a.textContent.trim();
          if (!title || title === 'Shop on eBay') return;
          // Extract price
          let price = 0;
          const allText = container.innerText || '';
          const priceMatch = allText.match(/[£€$]\s*([\d,.]+)/);
          if (priceMatch) {
            let pt = priceMatch[1];
            const lc = pt.lastIndexOf(','), ld = pt.lastIndexOf('.');
            if (lc > ld) pt = pt.replace(/\./g, '').replace(',', '.');
            else pt = pt.replace(/,/g, '');
            price = parseFloat(pt) || 0;
          }
          // Extract image
          const img = container.querySelector('img[src*="ebayimg"], img[src*="i.ebayimg"], img');
          const image = img ? (img.src || img.dataset.src || '') : '';
          // Sold
          const soldMatch2 = allText.match(/(\d[\d,]*)\s*sold/i);
          const sold = soldMatch2 ? parseInt(soldMatch2[1].replace(/,/g, '')) : 0;
          const soldText = soldMatch2 ? soldMatch2[0] : '';
          scraped.push({ title, price, image, itemNumber, url: a.href, sold, soldText, qty: 0, watchers: 0, shipping: '' });
        });
        console.log('[UnicornDS] Scanner universal: scraped', scraped.length, 'items from /itm/ links');
      } else {
        Array.from(itemEls).forEach(el => {
          const titleEl = el.querySelector('.s-item__title, .s-card__title, h3, [role="heading"]');
          if (!titleEl) return;
          const title = titleEl.textContent.trim();
          if (!title || title === 'Shop on eBay' || title === 'Results matching fewer words') return;
          const priceEl = el.querySelector('.s-item__price, .s-card__price, [class*="price"] span');
          let price = 0;
          if (priceEl) {
            const pt = priceEl.textContent.replace(/[^0-9.,]/g, '');
            const lc = pt.lastIndexOf(','), ld = pt.lastIndexOf('.');
            let c = pt;
            if (lc > ld) c = pt.replace(/\./g, '').replace(',', '.');
            else c = pt.replace(/,/g, '');
            price = parseFloat(c) || 0;
          }
          const imgEl = el.querySelector('.s-item__image-wrapper img, .image-treatment img, img[src*="ebayimg"]');
          const image = imgEl ? (imgEl.src || imgEl.dataset.src || '') : '';
          const linkEl = el.querySelector('a[href*="/itm/"]');
          let itemNumber = '', url = '';
          if (linkEl) { url = linkEl.href; itemNumber = linkEl.href.split('?')[0].split('/').pop(); }
          const soldEl = el.querySelector('.s-item__quantity-sold, .s-item__quantitySold, [class*="sold"]');
          const soldText = soldEl ? soldEl.textContent.trim() : '';
          const soldMatch = soldText.match(/(\d[\d,]*)\s*sold/i);
          const sold = soldMatch ? parseInt(soldMatch[1].replace(/,/g, '')) : 0;
          const qtyEl = el.querySelector('.s-item__quantity, [class*="quantity"]');
          const qtyText = qtyEl ? qtyEl.textContent.trim() : '';
          const qtyMatch = qtyText.match(/(\d[\d,]*)\s*(available|left|in stock)/i);
          const qty = qtyMatch ? parseInt(qtyMatch[1].replace(/,/g, '')) : 0;
          const watchEl = el.querySelector('.s-item__watchhint, .s-item__watch-count, [class*="watch"]');
          const watchText = watchEl ? watchEl.textContent.trim() : '';
          const watchMatch = watchText.match(/(\d[\d,]*)\s*watch/i);
          const watchers = watchMatch ? parseInt(watchMatch[1].replace(/,/g, '')) : 0;
          const shipEl = el.querySelector('.s-item__shipping, .s-item__freeXDays, [class*="shipping"], [class*="delivery"]');
          const shipping = shipEl ? shipEl.textContent.trim() : '';
          scraped.push({ title, price, image, itemNumber, url, sold, soldText, qty, watchers, shipping });
        });
      }

      // Find next page URL (runs for both branches)
      let nextPageUrl = null;
      const nextLink = document.querySelector('a.pagination__next, a[aria-label="Go to next search page"], nav.pagination a[rel="next"], .srp-pagination a[aria-label="Go to next search page"]');
      if (nextLink && nextLink.href) {
        nextPageUrl = nextLink.href;
      }
      // Fallback: look for pagination links and find current + 1
      if (!nextPageUrl) {
        const pagLinks = document.querySelectorAll('.pagination__items a, nav.pagination a, .srp-pagination a');
        const currentPage = document.querySelector('.pagination__items .pagination__item--current, .pagination__item--active, a[aria-current="page"]');
        const currentNum = currentPage ? parseInt(currentPage.textContent.trim()) : 1;
        pagLinks.forEach(a => {
          const num = parseInt(a.textContent.trim());
          if (num === currentNum + 1 && a.href) nextPageUrl = a.href;
        });
      }
      console.log('[UnicornDS] Scanner inline: scraped', scraped.length, 'items, nextPage:', nextPageUrl ? 'YES' : 'NO');
      return { items: scraped, nextPageUrl };
    };

    chrome.tabs.create({ url, active: false }, (tab) => {
      let tabClosed = false;
      const allItems = [];
      let pageNum = 0;
      let retryCount = 0;
      const MAX_RETRIES = 2;

      const closeTab = () => {
        if (tabClosed) return;
        tabClosed = true;
        chrome.tabs.remove(tab.id).catch(() => {});
      };

      const saveBatch = () => {
        const batchKey = 'scanner_batch_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
        const saveData = {};
        saveData[batchKey] = { items: allItems, seller };
        saveData['scanner_seller_done'] = Date.now();
        chrome.storage.local.set(saveData, () => {
          console.log('[UnicornDS] Scanner: saved batch', batchKey, '—', allItems.length, 'total items from', pageNum, 'pages');
          if (autoClose) closeTab();
        });
      };

      // ── Scrape one page, then navigate to next or finish ──
      const scrapePage = () => {
        pageNum++;
        console.log('[UnicornDS] Scanner: scraping page', pageNum, 'for', seller, '(retry:', retryCount + ')');

        // Brief focus to force eBay to render
        chrome.tabs.update(tab.id, { active: true }, () => {
          setTimeout(() => {
            chrome.tabs.update(tab.id, { active: false }).catch(() => {});
          }, 800);
        });

        setTimeout(() => {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: inlineScraperFn,
          }).then((results) => {
            const data = results?.[0]?.result || { items: [], nextPageUrl: null };
            const items = data.items || [];
            const nextPageUrl = data.nextPageUrl;

            // RETRY: if 0 items and we haven't retried enough, wait and try again
            if (items.length === 0 && retryCount < MAX_RETRIES) {
              retryCount++;
              pageNum--; // don't count this as a new page
              console.log('[UnicornDS] Scanner: 0 items — retrying in 5s (attempt', retryCount, 'of', MAX_RETRIES + ')');
              // Focus tab again to force render
              chrome.tabs.update(tab.id, { active: true }, () => {
                setTimeout(() => {
                  chrome.tabs.update(tab.id, { active: false }).catch(() => {});
                }, 1000);
              });
              setTimeout(() => scrapePage(), 5000);
              return;
            }
            retryCount = 0; // reset for next page

            console.log('[UnicornDS] Scanner: page', pageNum, '→', items.length, 'items (running total:', allItems.length + items.length + ')');
            allItems.push(...items);

            // Send progress update to scanner UI
            chrome.storage.local.set({
              scanner_page_progress: { seller, page: pageNum, itemsSoFar: allItems.length, hasMore: !!nextPageUrl }
            });

            if (nextPageUrl && pageNum < MAX_PAGES && items.length > 0) {
              // Navigate same tab to next page
              console.log('[UnicornDS] Scanner: navigating to page', pageNum + 1);
              chrome.tabs.update(tab.id, { url: nextPageUrl }, () => {
                // Wait for page to load
                const onNav = (tabId, info) => {
                  if (tabId === tab.id && info.status === 'complete') {
                    chrome.tabs.onUpdated.removeListener(onNav);
                    scrapePage();
                  }
                };
                chrome.tabs.onUpdated.addListener(onNav);
              });
            } else {
              // Done — save all items
              console.log('[UnicornDS] Scanner: finished —', allItems.length, 'total items across', pageNum, 'pages');
              saveBatch();
            }
          }).catch((err) => {
            console.error('[UnicornDS] Scanner: page', pageNum, 'executeScript failed:', err.message);
            if (allItems.length > 0) {
              saveBatch();
            } else {
              chrome.storage.local.set({ scanner_seller_done: Date.now() });
              if (autoClose) closeTab();
            }
          });
        }, 6000 + Math.random() * 2000);
      };

      // Start: wait for first page to load
      const onFirstLoad = (tabId, info) => {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onFirstLoad);
          scrapePage();
        }
      };
      chrome.tabs.onUpdated.addListener(onFirstLoad);

      // Timeout safety — save whatever we have after 3 minutes
      setTimeout(() => {
        if (!tabClosed) {
          console.log('[UnicornDS] Scanner: timeout — saving', allItems.length, 'items collected so far');
          saveBatch();
        }
      }, 180000);
    });

    sendResponse({ started: true });
    return false;
  }

  // ═══════════════════════════════════════════════
  // C3: PURCHASE HISTORY — Total Sold Lookup
  // ═══════════════════════════════════════════════
  // Opens /bin/purchaseHistory?item=X, scrapes rows within date range.
  // C5: Uses DNR to block all non-HTML resources for 30-50x faster page load.
  if (type === 'scanner_get_purchase_history') {
    const { itemId, domain, days } = message;
    if (!itemId) { sendResponse({ totalSold: 0, error: 'Missing itemId' }); return false; }

    const url = `https://www.ebay.${domain || 'co.uk'}/bin/purchaseHistory?item=${itemId}`;

    (async () => {
      let tab;
      try {
        tab = await new Promise(r => chrome.tabs.create({ url: 'about:blank', active: false }, r));

        // C5: Block all non-HTML resources on this tab for maximum speed
        const ruleId = 90000 + (tab.id % 10000);
        try {
          await chrome.declarativeNetRequest.updateSessionRules({
            addRules: [{
              id: ruleId,
              priority: 1,
              action: { type: 'block' },
              condition: {
                tabIds: [tab.id],
                resourceTypes: ['sub_frame', 'stylesheet', 'script', 'image', 'font', 'object', 'xmlhttprequest', 'ping', 'media', 'websocket'],
              },
            }],
          });
        } catch (e) { console.warn('[UnicornDS] C5: DNR rule failed:', e.message); }

        // Navigate to the purchase history page (HTML only now — loads ~100ms)
        await new Promise(r => {
          chrome.tabs.update(tab.id, { url }, () => {
            const onUp = (tid, info) => {
              if (tid === tab.id && info.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(onUp);
                r();
              }
            };
            chrome.tabs.onUpdated.addListener(onUp);
          });
        });
        await new Promise(r => setTimeout(r, 800));

        // Scrape the purchase history table
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (maxDays) => {
            const rows = document.querySelectorAll('table tr, .history-row, [class*="purchase"] tr');
            let count = 0;
            const cutoff = Date.now() - (maxDays * 24 * 60 * 60 * 1000);
            for (const row of rows) {
              // Skip header rows
              if (row.querySelector('th')) continue;
              // Try to find date cell
              const cells = row.querySelectorAll('td');
              if (cells.length < 2) continue;
              // eBay purchase history has date in first or second cell
              const dateText = (cells[0]?.textContent || '') + ' ' + (cells[1]?.textContent || '');
              const dateMatch = dateText.match(/(\w{3}[-\s]\d{1,2}[-,\s]+\d{4})/);
              if (dateMatch) {
                const d = new Date(dateMatch[1]);
                if (!isNaN(d.getTime()) && d.getTime() >= cutoff) {
                  // Count quantity from the row (look for qty cell)
                  const qtyCell = Array.from(cells).find(c => /^\d+$/.test(c.textContent.trim()));
                  count += qtyCell ? parseInt(qtyCell.textContent.trim()) || 1 : 1;
                }
              } else {
                // No date found — count row if table has any data at all
                count++;
              }
            }
            return { totalSold: count, rowsFound: rows.length };
          },
          args: [days || 30],
        });

        const data = results?.[0]?.result;
        console.log(`[UnicornDS] C3: item ${itemId} → ${data?.totalSold || 0} sold (${data?.rowsFound || 0} rows)`);

        // Cleanup: remove DNR rule + close tab
        try { await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId] }); } catch(e) {}
        try { chrome.tabs.remove(tab.id); } catch(e) {}

        sendResponse({ totalSold: data?.totalSold || 0 });

      } catch (e) {
        console.error('[UnicornDS] C3: purchase history error:', e.message);
        if (tab) { try { chrome.tabs.remove(tab.id); } catch(e2) {} }
        sendResponse({ totalSold: 0, error: e.message });
      }
    })();
    return true;
  }

  // [P1-19 cleanup] openCompetitorScanner removed — zero senders

  // ═══════════════════════════════════════════════
  // STOCK CHECKER - Verify product availability
  // ═══════════════════════════════════════════════
  if (type === 'verify_stock') {
    // ── TIER GATE: stock_check ──
    if (!gateAction('stock_check', sendResponse)) return false;
    const { asin, domain } = message;
    const productUrl = `https://www.amazon.${domain || 'co.uk'}/dp/${asin}?th=1&psc=1`;
    console.log('[UnicornDS] Stock check: opening', productUrl);

    chrome.tabs.create({ url: productUrl, active: false }, (tab) => {
      let tabClosed = false;
      const closeTab = () => {
        if (tabClosed) return;
        tabClosed = true;
        chrome.tabs.remove(tab.id).catch(() => {});
      };

      const onUpdated = (tabId, info) => {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);

          setTimeout(() => {
            chrome.tabs.sendMessage(tab.id, { type: 'check_stock' }, (response) => {
              const stockInfo = response || { inStock: false, quantity: 0, quantityText: 'Check failed' };
              console.log('[UnicornDS] Stock check result:', stockInfo);

              // Save result with ASIN key
              const saveData = {};
              saveData['stock_check_' + asin] = { ...stockInfo, checkedAt: Date.now() };
              chrome.storage.local.set(saveData, () => {
                closeTab();
              });
            });
          }, 3000);
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdated);

      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        const saveData = {};
        saveData['stock_check_' + asin] = { inStock: false, quantity: 0, quantityText: 'Timeout', checkedAt: Date.now() };
        chrome.storage.local.set(saveData, () => closeTab());
      }, 20000);
    });

    sendResponse({ started: true });
    return false;
  }

  // ═══════════════════════════════════════════════
  // eBay SOLD CHECK — Check if product sells on eBay
  // ═══════════════════════════════════════════════
  if (type === 'check_ebay_sold') {
    const { asin, searchQuery } = message;
    const query = encodeURIComponent(searchQuery);
    // Search eBay sold listings (completed + sold filter)
    const soldUrl = `https://www.ebay.co.uk/sch/i.html?_nkw=${query}&LH_Sold=1&LH_Complete=1&_sop=12&rt=nc`;
    console.log('[UnicornDS] eBay sold check:', searchQuery);

    chrome.tabs.create({ url: soldUrl, active: false }, (tab) => {
      let tabClosed = false;
      const closeTab = () => {
        if (tabClosed) return;
        tabClosed = true;
        chrome.tabs.remove(tab.id).catch(() => {});
      };

      const onUpdated = (tabId, info) => {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);

          setTimeout(() => {
            // Scrape sold listing data from the search results page
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                try {
                  // Count sold items
                  const countEl = document.querySelector('.srp-controls__count-heading .BOLD');
                  const countText = countEl ? countEl.textContent.replace(/[^\d]/g, '') : '0';
                  const soldCount = parseInt(countText) || 0;

                  // Get prices from sold items
                  const priceEls = document.querySelectorAll('.s-item__price');
                  const prices = [];
                  priceEls.forEach(el => {
                    // Handle range prices like "£3.99 to £5.99" — take the first price
                    const txt = el.textContent.trim();
                    const matches = txt.match(/[\d]+[.,]\d{2}/g);
                    if (matches && matches.length > 0) {
                      const p = parseFloat(matches[0].replace(',', '.'));
                      if (p > 0 && p < 10000) prices.push(p);
                    }
                  });

                  const avgPrice = prices.length > 0
                    ? (prices.reduce((a, b) => a + b, 0) / prices.length).toFixed(2)
                    : '0';

                  return { soldCount, avgPrice, priceCount: prices.length };
                } catch (e) {
                  return { soldCount: 0, avgPrice: '0', priceCount: 0 };
                }
              }
            }, (results) => {
              const soldData = results?.[0]?.result || { soldCount: 0, avgPrice: '0' };

              // Now check active listings count
              const activeUrl = `https://www.ebay.co.uk/sch/i.html?_nkw=${query}&rt=nc`;
              chrome.tabs.update(tab.id, { url: activeUrl }, () => {
                const onUpdated2 = (tabId2, info2) => {
                  if (tabId2 === tab.id && info2.status === 'complete') {
                    chrome.tabs.onUpdated.removeListener(onUpdated2);

                    setTimeout(() => {
                      chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                          try {
                            const countEl = document.querySelector('.srp-controls__count-heading .BOLD');
                            const countText = countEl ? countEl.textContent.replace(/[^\d]/g, '') : '0';
                            return parseInt(countText) || 0;
                          } catch (e) { return 0; }
                        }
                      }, (activeResults) => {
                        const activeCount = activeResults?.[0]?.result || 0;

                        const saveData = {};
                        saveData['ebay_sold_' + asin] = {
                          soldCount: soldData.soldCount,
                          avgPrice: soldData.avgPrice,
                          activeCount: activeCount,
                          checkedAt: Date.now()
                        };
                        console.log('[UnicornDS] eBay sold result:', saveData['ebay_sold_' + asin]);
                        chrome.storage.local.set(saveData, () => closeTab());
                      });
                    }, 2000);
                  }
                };
                chrome.tabs.onUpdated.addListener(onUpdated2);
              });
            });
          }, 5000); // 5s wait for eBay search results to render
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdated);

      // Timeout after 25s
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        const saveData = {};
        saveData['ebay_sold_' + asin] = { soldCount: 0, avgPrice: '0', activeCount: 0, checkedAt: Date.now() };
        chrome.storage.local.set(saveData, () => closeTab());
      }, 25000);
    });

    sendResponse({ started: true });
    return false;
  }

  // ═══════════════════════════════════════════════
  // ORDER MANAGER - Sync eBay orders
  // ═══════════════════════════════════════════════
  if (type === 'sync_ebay_orders') {
    // ── TIER GATE: orders_sync (Growth+) ──
    if (!gateAction('orders_sync', sendResponse)) return false;
    const domain = message.domain || 'co.uk';
    // Open eBay Seller Hub orders page (ALL orders, not just awaiting)
    const url = `https://www.ebay.${domain}/sh/ord/?filter=status:ALL_ORDERS&limit=50`;
    console.log('[UnicornDS] Orders: opening', url);

    chrome.tabs.create({ url, active: false }, (tab) => {
      let tabClosed = false;
      const closeTab = () => {
        if (tabClosed) return;
        tabClosed = true;
        chrome.tabs.remove(tab.id).catch(() => {});
      };

      const onUpdated = (tabId, info) => {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);

          setTimeout(async () => {
            // First scroll down to load more orders (eBay lazy-loads)
            try {
              await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                  return new Promise(resolve => {
                    let scrollCount = 0;
                    const scrollInterval = setInterval(() => {
                      window.scrollBy(0, 800);
                      scrollCount++;
                      if (scrollCount >= 10) { // scroll 10 times
                        clearInterval(scrollInterval);
                        window.scrollTo(0, 0); // back to top
                        resolve(true);
                      }
                    }, 300);
                  });
                }
              });
            } catch(e) {}
            
            // Wait for lazy-loaded content to render
            await new Promise(r => setTimeout(r, 2000));
            
            // Now scrape the orders
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                try {
                  const orders = [];
                  // eBay Seller Hub orders page — multiple possible layouts
                  const rows = document.querySelectorAll(
                    '.order-info, [data-test-id="order-line-item"], .sold-order-info, ' +
                    '.sh-tbl__row, [class*="order-line"], [class*="OrderLineItem"], ' +
                    'tr.order-row, [class*="order-card"], [class*="orderCard"]'
                  );
                  
                  // Also try to get orders from the newer eBay Seller Hub layout
                  const orderCards = rows.length > 0 ? rows : document.querySelectorAll('[class*="order"]');
                  
                  orderCards.forEach(row => {
                    try {
                      const order = {};
                      
                      // Order ID — from link or data attribute
                      const orderLink = row.querySelector('a[href*="orderId"], a[href*="/sh/ord/"], a[href*="orderid"]');
                      if (orderLink) {
                        order.ebayOrderId = orderLink.textContent.trim();
                        const oidMatch = orderLink.href.match(/orderId[=:]([^&]+)/i);
                        if (oidMatch) order.ebayOrderIdFull = oidMatch[1];
                        order.orderUrl = orderLink.href;
                      }
                      
                      // Buyer — look for username links
                      const buyerEl = row.querySelector(
                        'a[href*="usr/"], a[href*="/usr/"], [class*="buyer"] a, ' +
                        '[data-test-id="buyer-id"], [class*="Buyer"] a, [class*="buyer-name"]'
                      );
                      if (buyerEl) {
                        let bName = buyerEl.textContent.trim();
                        // Extract username from URL if text is empty
                        if (!bName && buyerEl.href) {
                          const usrMatch = buyerEl.href.match(/usr\/([^?&/]+)/);
                          if (usrMatch) bName = usrMatch[1];
                        }
                        // Check if this looks like an order number (XX-XXXXX-XXXXX) — NOT a buyer name
                        if (/^\d{2}-\d{4,5}-\d{4,5}$/.test(bName)) {
                          order.ebayOrderId = bName;
                          order.buyerName = '';
                        } else {
                          order.buyerName = bName;
                        }
                      }
                      
                      // Item title
                      const titleEl = row.querySelector(
                        '[class*="item-title"] a, [data-test-id="item-title"], a[href*="/itm/"], ' +
                        '[class*="itemTitle"], [class*="line-item-title"]'
                      );
                      order.itemTitle = titleEl ? titleEl.textContent.trim() : '';
                      
                      // Item number from link
                      if (titleEl && titleEl.href) {
                        const match = titleEl.href.match(/\/itm\/(\d+)/);
                        if (match) order.itemNumber = match[1];
                      }
                      
                      // SKU / Custom label
                      const skuEl = row.querySelector(
                        '[class*="sku"], [class*="custom-label"], [data-test-id="sku"], ' +
                        '[class*="customLabel"], [class*="SKU"]'
                      );
                      if (skuEl) {
                        const skuText = skuEl.textContent.trim();
                        // Clean SKU — remove "SKU:" prefix
                        order.sku = skuText.replace(/^(SKU|Custom label|Custom Label)[:\s]*/i, '').trim();
                      }
                      
                      // Price — order total (try multiple selectors)
                      let foundPrice = 0;
                      const priceSelectors = [
                        '[class*="total"] .sh-bold', '[data-test-id="order-total"]',
                        '[class*="item-price"]', '[class*="order-price"]', '[class*="amount"]',
                        '[class*="price"]', '[class*="Price"]', '[class*="cost"]',
                        'span[class*="total"]', 'div[class*="total"]',
                        '.sh-col__price', '.order-total', '.line-item-price',
                      ];
                      for (const sel of priceSelectors) {
                        const el = row.querySelector(sel);
                        if (el) {
                          const m = el.textContent.match(/[\d]+[.,]\d{2}/);
                          if (m) { foundPrice = parseFloat(m[0].replace(',', '.')); break; }
                        }
                      }
                      // Fallback: find any currency amount in the entire row
                      if (!foundPrice) {
                        const rowText = row.textContent;
                        // Look for £X.XX pattern
                        const currMatch = rowText.match(/[£$€]\s*([\d]+[.,]\d{2})/);
                        if (currMatch) foundPrice = parseFloat(currMatch[1].replace(',', '.'));
                      }
                      order.soldPrice = foundPrice;
                      
                      // Date — try datetime attribute first (most reliable)
                      const timeEl = row.querySelector('time[datetime], [class*="date"] time');
                      if (timeEl && timeEl.getAttribute('datetime')) {
                        order.soldDate = timeEl.getAttribute('datetime');
                        order.soldDateTs = new Date(timeEl.getAttribute('datetime')).getTime();
                      } else {
                        // Fallback to text content
                        const dateEl = row.querySelector('[class*="date"], [data-test-id="order-date"], time, [class*="Date"]');
                        if (dateEl) {
                          const dateText = dateEl.textContent.trim();
                          order.soldDate = dateText;
                          // Try to parse common date formats
                          const dmyMatch = dateText.match(/(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s*,?\s*(\d{4})?/i);
                          if (dmyMatch) {
                            const months = {jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11};
                            const y = dmyMatch[3] ? parseInt(dmyMatch[3]) : new Date().getFullYear();
                            order.soldDateTs = new Date(y, months[dmyMatch[2].toLowerCase()], parseInt(dmyMatch[1])).getTime();
                          }
                        }
                      }
                      
                      // Image
                      const imgEl = row.querySelector('img[src*="ebayimg"], img[src*="i.ebayimg"]');
                      order.image = imgEl ? imgEl.src : '';
                      
                      // Status
                      const statusEl = row.querySelector('[class*="status"], [data-test-id="order-status"], [class*="Status"]');
                      const statusText = statusEl ? statusEl.textContent.trim().toLowerCase() : '';
                      if (statusText.includes('dispatch') || statusText.includes('ship') || statusText.includes('awaiting')) order.ebayStatus = 'awaiting_dispatch';
                      else if (statusText.includes('delivered') || statusText.includes('complete')) order.ebayStatus = 'delivered';
                      else if (statusText.includes('paid')) order.ebayStatus = 'paid';
                      else if (statusText.includes('cancelled') || statusText.includes('cancel')) order.ebayStatus = 'cancelled';
                      else order.ebayStatus = statusText || 'unknown';
                      
                      // Quantity
                      const qtyEl = row.querySelector('[class*="quantity"], [class*="qty"], [data-test-id="quantity"]');
                      if (qtyEl) {
                        const qtyMatch = qtyEl.textContent.match(/\d+/);
                        order.quantity = qtyMatch ? parseInt(qtyMatch[0]) : 1;
                      }
                      
                      if (order.itemTitle) orders.push(order);
                    } catch (e) { /* skip row */ }
                  });
                  
                  // If no orders found from structured selectors, try getting all visible text data
                  if (orders.length === 0) {
                    // Try the table-based layout
                    const tableRows = document.querySelectorAll('table tbody tr');
                    tableRows.forEach(tr => {
                      try {
                        const cells = tr.querySelectorAll('td');
                        if (cells.length < 3) return;
                        const titleLink = tr.querySelector('a[href*="/itm/"]');
                        if (!titleLink) return;
                        const priceMatch = tr.textContent.match(/[\d]+[.,]\d{2}/);
                        orders.push({
                          itemTitle: titleLink.textContent.trim(),
                          itemNumber: (titleLink.href.match(/\/itm\/(\d+)/) || [])[1] || '',
                          soldPrice: priceMatch ? parseFloat(priceMatch[0]) : 0,
                          buyerName: '',
                          soldDate: new Date().toLocaleDateString('en-GB'),
                          soldDateTs: Date.now(),
                          ebayStatus: 'unknown',
                        });
                      } catch (e) {}
                    });
                  }
                  
                  return { orders, count: orders.length, pageTitle: document.title, url: location.href };
                } catch (e) {
                  return { orders: [], error: e.message };
                }
              }
            }, (results) => {
              const scraped = results?.[0]?.result || { orders: [] };
              const orders = scraped.orders || [];
              console.log('[UnicornDS] Orders: received', orders.length, 'from', scraped.url);

              // Match with listed products for cost
              chrome.storage.local.get('unicornds_listed_products', (data) => {
                const listedProducts = data.unicornds_listed_products || {};
                orders.forEach(order => {
                  const listed = listedProducts[order.itemNumber];
                  if (listed) {
                    order.sourceUrl = listed.sourceUrl || '';
                    order.sourceCost = listed.sourceCost || 0;
                  }
                });

                chrome.storage.local.set({
                  ebay_orders_sync_result: { orders, syncedAt: Date.now() }
                }, () => closeTab());
              });
            });
          }, 5000); // Wait for page to fully render
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdated);

      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.storage.local.set({
          ebay_orders_sync_result: { orders: [], syncedAt: Date.now() }
        }, () => closeTab());
      }, 30000);
    });

    sendResponse({ started: true });
    return false;
  }

  // [P1-19 cleanup] openOrderManager removed — zero senders

  // Upload tracking to eBay (opens order page for manual tracking entry)
  if (type === 'upload_tracking_to_ebay') {
    const { orderId, itemNumber, trackingNumber, carrier } = message;
    console.log('[UnicornDS] Uploading tracking:', trackingNumber, 'for', orderId || itemNumber);

    // Open eBay order details page where user can enter tracking
    chrome.storage.local.get('unicornds_ebay_domain', (data) => {
      const domain = data.unicornds_ebay_domain || 'co.uk';
      let url;
      if (orderId) {
        url = `https://www.ebay.${domain}/sh/ord/details?orderid=${encodeURIComponent(orderId)}`;
      } else if (itemNumber) {
        url = `https://www.ebay.${domain}/sh/ord/?filter=status:AWAITING_SHIPMENT&search=${itemNumber}`;
      }
      if (url) {
        chrome.tabs.create({ url, active: true });
        // Copy tracking number to clipboard so user can paste it
        // Note: can't use clipboard API from background, so save to storage
        chrome.storage.local.set({
          unicornds_pending_tracking: { trackingNumber, carrier, copiedAt: Date.now() }
        });
      }
    });
    sendResponse({ ok: true });
    return false;
  }

  // ── ADDRESS HELPER ─────────────────────────────
  if (message.action === 'copyAddress') {
    // ── TIER GATE: address_helper (Growth+ per Bible) ──
    if (!gateAction('address_helper', sendResponse)) return false;
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) { sendResponse({ success: false, error: 'No active tab' }); return; }
      await addrEnsureContentScript(tabs[0].id, tabs[0].url);
      setTimeout(() => {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'captureAddress' }, async (res) => {
          if (chrome.runtime.lastError) {
            sendResponse({ success: false, error: 'Not on a supported page (eBay/Amazon/TikTok order)' });
            return;
          }
          if (res && res.orderInfo) {
            await new Promise(r => chrome.storage.local.set({ orderInfo: res.orderInfo }, r));
            await addrAddToHistory(res.orderInfo);
            sendResponse({ success: true, orderInfo: res.orderInfo, source: res.source });
          } else {
            sendResponse({ success: false, error: res?.error || 'Could not find address on this page' });
          }
        });
      }, 300);
    });
    return true;
  }

  if (message.action === 'pasteAddress') {
    // ── TIER GATE: address_helper (Growth+) ──
    if (!gateAction('address_helper', sendResponse)) return false;
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) { sendResponse({ success: false, error: 'No active tab' }); return; }
      if (!tabs[0].url.includes('aliexpress')) {
        sendResponse({ success: false, error: 'Navigate to AliExpress checkout first' }); return;
      }
      chrome.storage.local.get('orderInfo', async (data) => {
        if (!data.orderInfo) { sendResponse({ success: false, error: 'No address copied yet' }); return; }
        await addrEnsureContentScript(tabs[0].id, tabs[0].url);
        setTimeout(() => {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'fillForm', orderInfo: data.orderInfo }, (res) => {
            if (chrome.runtime.lastError) {
              sendResponse({ success: false, error: 'Could not connect to AliExpress. Refresh the page.' });
              return;
            }
            sendResponse(res || { success: false, error: 'No response' });
          });
        }, 300);
      });
    });
    return true;
  }

  if (message.action === 'checkDuplicate') {
    addrCheckDuplicate(message.orderInfo).then(m => sendResponse({ duplicate: m }));
    return true;
  }

  if (message.action === 'saveOrderInfo') {
    chrome.storage.local.set({ orderInfo: message.orderInfo }, async () => {
      await addrAddToHistory(message.orderInfo);
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.action === 'getOrderInfo') {
    chrome.storage.local.get('orderInfo', (d) => sendResponse({ orderInfo: d.orderInfo || null }));
    return true;
  }

  if (message.action === 'clearOrderInfo') {
    chrome.storage.local.remove('orderInfo', () => sendResponse({ success: true }));
    return true;
  }

  if (message.action === 'getHistory') {
    chrome.storage.local.get('addressHistory', (d) => sendResponse({ history: d.addressHistory || [] }));
    return true;
  }

  if (message.action === 'loadFromHistory') {
    chrome.storage.local.set({ orderInfo: message.orderInfo }, () => sendResponse({ success: true }));
    return true;
  }

  if (message.action === 'clearHistory') {
    chrome.storage.local.remove('addressHistory', () => sendResponse({ success: true }));
    return true;
  }
});

console.log('[UnicornDS] Background ready v' + chrome.runtime.getManifest().version);

// Refresh VERO list from file on startup (clears stale cache)
(async () => {
  try {
    const resp = await fetch(chrome.runtime.getURL('data/VeroList.txt'));
    const text = await resp.text();
    const brands = text.split('\n').map(b => b.trim().toLowerCase()).filter(Boolean);
    chrome.storage.local.set({ unicornds_vero_brands: brands });
    console.log('[UnicornDS] VERO list loaded:', brands.length, 'brands');
  } catch (e) { console.warn('[UnicornDS] VERO list load error:', e.message); }
})();

// ============================================================
// ADDRESS HELPER - Message Handlers
// ============================================================
const ADDR_MAX_HISTORY = 50;

async function addrEnsureContentScript(tabId, url) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, { action: 'ping' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        let file = null;
        if (url.includes('aliexpress.com') || url.includes('aliexpress.us')) file = 'content/address-helper/aliexpress-fill.js';
        else if (url.includes('seller') && url.includes('tiktok.com')) file = 'content/address-helper/tiktok-capture.js';
        else if (url.includes('sellercentral.amazon') || url.includes('amazon.com') || url.includes('amazon.co')) file = 'content/address-helper/amazon-capture.js';
        else if (/ebay\.(com|co\.uk|de|fr|it|es|com\.au|ca|nl|be|at|ch|ie|in|com\.hk|com\.my|com\.sg)/.test(url)) file = 'content/address-helper/ebay-capture.js';
        if (file) {
          chrome.scripting.executeScript({ target: { tabId }, files: [file] }, () => {
            if (chrome.runtime.lastError) console.log('[UnicornDS] Addr inject error:', chrome.runtime.lastError.message);
            if (file.includes('aliexpress')) {
              chrome.scripting.insertCSS({ target: { tabId }, files: ['content/address-helper/fill-overlay.css'] }).catch(() => {});
            }
            resolve(true);
          });
        } else resolve(false);
      } else resolve(true);
    });
  });
}

async function addrAddToHistory(orderInfo) {
  return new Promise((resolve) => {
    chrome.storage.local.get('addressHistory', (data) => {
      let history = data.addressHistory || [];
      const entry = { ...orderInfo, savedAt: new Date().toISOString(), id: Date.now() };
      history.unshift(entry);
      if (history.length > ADDR_MAX_HISTORY) history = history.slice(0, ADDR_MAX_HISTORY);
      chrome.storage.local.set({ addressHistory: history }, () => resolve(entry));
    });
  });
}

async function addrCheckDuplicate(orderInfo) {
  return new Promise((resolve) => {
    chrome.storage.local.get('addressHistory', (data) => {
      const history = data.addressHistory || [];
      const name = ((orderInfo.firstName || '') + ' ' + (orderInfo.lastName || '')).toLowerCase().trim();
      const zip = (orderInfo.zip || '').toLowerCase().trim();
      if (!name || !zip) { resolve(null); return; }
      let skippedFirst = false;
      const match = history.find(h => {
        const hName = ((h.firstName || '') + ' ' + (h.lastName || '')).toLowerCase().trim();
        const hZip = (h.zip || '').toLowerCase().trim();
        if (hName === name && hZip === zip) {
          if (!skippedFirst) { skippedFirst = true; return false; }
          return true;
        }
        return false;
      });
      resolve(match || null);
    });
  });
}

// Address Helper handlers integrated into main listener

// ═══════════════════════════════════════════════════════
// C4: TAB ACTIVATION QUEUE — Prevent Chrome Throttling
// ═══════════════════════════════════════════════════════
// Chrome throttles inactive tabs (timers slow to 1/min, fetch delays).
// This queue briefly activates each scraper tab every 300ms to keep them fast.
// Toggle-controlled: default OFF (set to true via scanner/bulk lister when running).
let tabActivationQueue = [];
let tabActivationEnabled = false;
let tabActivationTimer = null;

function startTabActivation() {
  if (tabActivationTimer) return;
  tabActivationEnabled = true;
  let queueIdx = 0;
  tabActivationTimer = setInterval(() => {
    if (!tabActivationEnabled || tabActivationQueue.length === 0) return;
    queueIdx = queueIdx % tabActivationQueue.length;
    const tabId = tabActivationQueue[queueIdx];
    try {
      chrome.tabs.update(tabId, { active: true }, () => {
        if (chrome.runtime.lastError) {
          // Tab closed — remove from queue
          tabActivationQueue = tabActivationQueue.filter(id => id !== tabId);
        }
      });
    } catch (e) {}
    queueIdx++;
  }, 300);
  console.log('[UnicornDS] C4: Tab activation started');
}

function stopTabActivation() {
  tabActivationEnabled = false;
  if (tabActivationTimer) { clearInterval(tabActivationTimer); tabActivationTimer = null; }
  tabActivationQueue = [];
  console.log('[UnicornDS] C4: Tab activation stopped');
}

// Expose to message system so scanner/bulk lister can control it
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'tab_activation_add') {
    if (!tabActivationQueue.includes(msg.tabId)) tabActivationQueue.push(msg.tabId);
    if (!tabActivationTimer) startTabActivation();
    sendResponse({ ok: true, queued: tabActivationQueue.length });
    return false;
  }
  if (msg.type === 'tab_activation_remove') {
    tabActivationQueue = tabActivationQueue.filter(id => id !== msg.tabId);
    if (tabActivationQueue.length === 0) stopTabActivation();
    sendResponse({ ok: true, queued: tabActivationQueue.length });
    return false;
  }
  if (msg.type === 'tab_activation_stop') {
    stopTabActivation();
    sendResponse({ ok: true });
    return false;
  }
});

// ═══════════════════════════════════════════════════════
// P2-26: VERSION CHECK ON STARTUP
// ═══════════════════════════════════════════════════════
(async () => {
  try {
    const localVersion = chrome.runtime.getManifest().version;
    const res = await fetch(`${CF_BASE}/versionCheck`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: {} }),
    });
    if (res.ok) {
      const json = await res.json();
      const latest = json.result?.latestVersion;
      if (latest && latest !== localVersion) {
        console.log(`[UnicornDS] ⬆️ Update available: ${localVersion} → ${latest}`);
        chrome.storage.local.set({ unicornds_update_available: { current: localVersion, latest, url: json.result?.updateUrl || 'https://unicornds.io' } });
        chrome.notifications.create('update_' + Date.now(), {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: 'UnicornDS Update Available',
          message: `v${latest} is available (you have v${localVersion}). Click to update.`,
        });
      } else {
        chrome.storage.local.remove('unicornds_update_available');
      }
    }
  } catch (e) { /* version check is non-critical */ }
})();

// ═══════════════════════════════════════════════════════
// P2-30: STALE BATCH CLEANUP ON STARTUP
// ═══════════════════════════════════════════════════════
(async () => {
  try {
    const allData = await chrome.storage.local.get(null);
    const staleKeys = [];
    const ONE_HOUR = 60 * 60 * 1000;
    for (const key of Object.keys(allData)) {
      if (key.startsWith('hunter_batch_') || key.startsWith('scanner_batch_')) {
        // These are temporary batch keys — remove if older than 1 hour
        const data = allData[key];
        if (data?.timestamp && Date.now() - data.timestamp > ONE_HOUR) {
          staleKeys.push(key);
        } else if (!data?.timestamp) {
          // No timestamp — assume stale
          staleKeys.push(key);
        }
      }
    }
    if (staleKeys.length) {
      chrome.storage.local.remove(staleKeys);
      console.log('[UnicornDS] P2-30: Cleaned', staleKeys.length, 'stale batch keys');
    }
  } catch (e) {}
})();
