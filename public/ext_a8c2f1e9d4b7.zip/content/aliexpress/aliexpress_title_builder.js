/**
 * UnicornDS - AliExpress Title Builder
 *
 * Takes scraped AliExpress product data, builds an AI prompt,
 * calls the Claude API, and returns clean eBay-ready title suggestions.
 *
 * Mirrors the existing buildTheSeoTitles() pattern from index_copy_bundle.js
 * but adapted specifically for AliExpress source data.
 */

// ─────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────

const EBAY_TITLE_MAX_CHARS = 80;
const EBAY_TITLE_MIN_CHARS = 40;

// Words that must never appear in an eBay title
// (sourced from restricted_words.txt + eBay policy)
const SPAM_WORDS = [
  'hot sale', 'best seller', 'top quality', 'free shipping',
  'wholesale', 'dropshipping', 'new 2024', 'new 2025', 'new 2023',
  'fashion new', 'high quality', 'luxury brand', 'amazing', 'incredible',
  'stunning', 'gorgeous', 'must have', 'super', 'great',
];

// Words that flag a VERO / clothing restriction risk
// (subset of restricted_words.txt most relevant to AliExpress)
const VERO_RISK_WORDS = [
  'nike', 'adidas', 'gucci', 'louis vuitton', 'chanel', 'prada',
  'supreme', 'off-white', 'balenciaga', 'yeezy', 'jordan',
  'playstation', 'xbox', 'nintendo',
];

// ─────────────────────────────────────────────────────────
// 1. PROMPT BUILDER
// ─────────────────────────────────────────────────────────

/**
 * Builds the full AI prompt by injecting product data into the template.
 * @param {Object} productData - scraped AliExpress product (from content_aliexpress.js)
 * @param {string} promptTemplate - contents of samplePrompt_aliexpress.txt
 * @returns {string} - ready-to-send prompt string
 */
function buildPrompt(productData, promptTemplate) {
  const {
    title         = '',
    cleanedTitle  = '',
    description   = {},
    specs         = {},
    marketplace   = 'com',
  } = productData;

  // Format specs as readable key: value list
  const specsText = Object.entries(specs)
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n') || 'No specifications available';

  // Description text - prefer the text field, fall back to empty
  const descText = description?.text || 'No description available';

  return promptTemplate
    .replace('{{AliExpress_Raw_Title}}',     title)
    .replace('{{AliExpress_Cleaned_Title}}', cleanedTitle || cleanTitle(title))
    .replace('{{Product_Description}}',      descText)
    .replace('{{Product_Specs}}',            specsText)
    .replace('{{Product_Category}}',         inferCategory(title, specs))
    .replace('{{Marketplace}}',              marketplaceLabel(marketplace));
}

// ─────────────────────────────────────────────────────────
// 2. CATEGORY INFERENCE
// ─────────────────────────────────────────────────────────

/**
 * Makes a best-guess at the product category from title + specs.
 * Used to help the AI understand context better.
 */
function inferCategory(title, specs) {
  const t = (title || '').toLowerCase();
  const categories = [
    { keywords: ['lamp', 'light', 'led', 'bulb', 'lantern'],           label: 'Lighting' },
    { keywords: ['mug', 'tumbler', 'bottle', 'flask', 'cup'],           label: 'Drinkware' },
    { keywords: ['phone', 'case', 'charger', 'cable', 'earphone'],      label: 'Phone Accessories' },
    { keywords: ['watch', 'bracelet', 'ring', 'necklace', 'jewel'],     label: 'Jewellery & Watches' },
    { keywords: ['bag', 'backpack', 'wallet', 'purse', 'handbag'],      label: 'Bags & Wallets' },
    { keywords: ['chair', 'desk', 'shelf', 'cabinet', 'drawer'],        label: 'Furniture' },
    { keywords: ['kitchen', 'cooking', 'pan', 'pot', 'knife'],          label: 'Kitchen' },
    { keywords: ['garden', 'plant', 'soil', 'sprinkler', 'outdoor'],    label: 'Garden' },
    { keywords: ['car', 'auto', 'vehicle', 'seat', 'steering'],         label: 'Car Accessories' },
    { keywords: ['toy', 'game', 'puzzle', 'lego', 'doll'],              label: 'Toys & Games' },
    { keywords: ['health', 'massage', 'fitness', 'yoga', 'gym'],        label: 'Health & Fitness' },
    { keywords: ['tool', 'drill', 'wrench', 'screwdriver', 'hammer'],   label: 'Tools' },
    { keywords: ['baby', 'infant', 'toddler', 'stroller', 'nappy'],     label: 'Baby' },
    { keywords: ['pet', 'dog', 'cat', 'collar', 'leash'],               label: 'Pet Supplies' },
    { keywords: ['camera', 'tripod', 'lens', 'gimbal', 'photo'],        label: 'Camera & Photo' },
    { keywords: ['laptop', 'keyboard', 'mouse', 'monitor', 'usb hub'],  label: 'Computer Accessories' },
  ];

  for (const cat of categories) {
    if (cat.keywords.some((kw) => t.includes(kw))) {
      return cat.label;
    }
  }

  // Try specs as fallback
  const specValues = Object.values(specs).join(' ').toLowerCase();
  for (const cat of categories) {
    if (cat.keywords.some((kw) => specValues.includes(kw))) {
      return cat.label;
    }
  }

  return 'General / Other';
}

// ─────────────────────────────────────────────────────────
// 3. TITLE CLEANING (pre-AI)
// ─────────────────────────────────────────────────────────

/**
 * Strips spam from an AliExpress title before sending to AI.
 * More thorough version of the function in content_aliexpress.js.
 */
function cleanTitle(rawTitle) {
  if (!rawTitle) return '';

  let t = rawTitle;

  // Remove year markers
  t = t.replace(/\b(new\s+)?20(2[3-9]|[3-9]\d)\b/gi, '');

  // Remove spam phrases
  SPAM_WORDS.forEach((phrase) => {
    const escaped = phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    t = t.replace(new RegExp(`\\b${escaped}\\b`, 'gi'), '');
  });

  // Remove standalone "New" at start
  t = t.replace(/^\s*new\s+/i, '');

  // Remove excessive punctuation
  t = t.replace(/[!?]{2,}/g, '').replace(/,{2,}/g, ',');

  // Remove leading/trailing dashes, pipes, commas
  t = t.replace(/^[\s\-–|,]+|[\s\-–|,]+$/g, '');

  // Normalise whitespace
  t = t.replace(/\s+/g, ' ').trim();

  return t;
}

// ─────────────────────────────────────────────────────────
// 4. TITLE VALIDATION
// ─────────────────────────────────────────────────────────

/**
 * Validates a single eBay title candidate.
 * @param {string} title
 * @returns {{ valid: boolean, issues: string[] }}
 */
function validateTitle(title) {
  const issues = [];

  if (!title || typeof title !== 'string') {
    return { valid: false, issues: ['Title is empty or not a string'] };
  }

  const len = title.trim().length;

  if (len > EBAY_TITLE_MAX_CHARS) {
    issues.push(`Too long: ${len} chars (max ${EBAY_TITLE_MAX_CHARS})`);
  }

  if (len < EBAY_TITLE_MIN_CHARS) {
    issues.push(`Too short: ${len} chars (min ${EBAY_TITLE_MIN_CHARS})`);
  }

  // Check for spam words
  const lower = title.toLowerCase();
  SPAM_WORDS.forEach((word) => {
    if (lower.includes(word)) {
      issues.push(`Contains spam word: "${word}"`);
    }
  });

  // Check for VERO risk words
  const veroHits = VERO_RISK_WORDS.filter((w) => lower.includes(w));
  if (veroHits.length > 0) {
    issues.push(`VERO risk - possible trademark: ${veroHits.join(', ')}`);
  }

  // Check for ALL CAPS words (3+ chars)
  const allCapsWords = title.match(/\b[A-Z]{3,}\b/g) || [];
  // Allow known abbreviations: USB, LED, PVC, LCD, AC, DC, UV, etc.
  const allowedCaps = ['USB', 'LED', 'LCD', 'PVC', 'PU', 'AC', 'DC', 'UV',
                       'UK', 'USA', 'EU', 'CE', 'XL', 'XXL', 'XXXL', 'HD',
                       'PC', 'ABS', 'TPU', 'RGB', 'IP67', 'IP68'];
  const badCaps = allCapsWords.filter((w) => !allowedCaps.includes(w));
  if (badCaps.length > 0) {
    issues.push(`Contains ALL CAPS (not allowed): ${badCaps.join(', ')}`);
  }

  // Check starts with bad word
  const badStarts = ['new ', 'for ', 'the ', ' a ', ' an '];
  if (badStarts.some((s) => lower.startsWith(s.trim()))) {
    issues.push('Title starts with a low-value word (New/For/The/A/An)');
  }

  return {
    valid:  issues.length === 0,
    issues,
  };
}

// ─────────────────────────────────────────────────────────
// 5. AI API CALL
// ─────────────────────────────────────────────────────────

/**
 * Calls the Claude API with the built prompt.
 * Returns parsed JSON with title suggestions.
 * @param {string} prompt
 * @returns {Promise<Object>} - parsed AI response
 */
async function callAI(prompt) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: 'call_anthropic',
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: 'You are an expert eBay SEO copywriter specialising in AliExpress to eBay dropshipping. Always respond with valid JSON only. No markdown. No extra text.',
      messages: [{ role: 'user', content: prompt }],
    }, (response) => {
      if (!response || response.error) {
        reject(new Error(response?.error || 'AI API call failed. Check your API key in Settings.'));
        return;
      }
      const rawText = response.content
        ?.filter((block) => block.type === 'text')
        ?.map((block) => block.text)
        ?.join('') || '';
      const cleaned = rawText.replace(/```json|```/g, '').trim();
      try {
        resolve(JSON.parse(cleaned));
      } catch {
        reject(new Error('Failed to parse AI response: ' + cleaned.slice(0, 200)));
      }
    });
  });
}

// ─────────────────────────────────────────────────────────
// 6. MAIN ENTRY POINT
// ─────────────────────────────────────────────────────────

/**
 * Full pipeline: AliExpress product data → eBay title suggestions.
 *
 * @param {Object} productData     - from content_aliexpress.js scrapeProduct()
 * @param {string} promptTemplate  - contents of samplePrompt_aliexpress.txt
 * @param {Function} [onStatus]    - optional callback for status updates (for UI)
 * @returns {Promise<Object>}      - { titles, recommended, validation, raw }
 */
async function buildAliexpressTitles(productData, promptTemplate, onStatus) {
  const status = (msg) => {
    console.log('[UnicornDS TitleBuilder]', msg);
    if (typeof onStatus === 'function') onStatus(msg);
  };

  status('Building prompt...');
  const prompt = buildPrompt(productData, promptTemplate);

  status('Calling AI...');
  let aiResult;
  try {
    aiResult = await callAI(prompt);
  } catch (err) {
    console.error('[UnicornDS TitleBuilder] AI call failed:', err);
    throw err;
  }

  status('Processing AI results...');

  // Validate each title the AI returned
  const titlesWithValidation = (aiResult.titles || []).map((t) => {
    const titleText   = (t.title || '').trim();
    const charCount   = titleText.length;
    const validation  = validateTitle(titleText);
    return {
      ...t,
      title:    titleText,
      charCount,
      valid:    validation.valid,
      issues:   validation.issues,
    };
  });

  // Sort: valid titles first, then by character count (longer = more keywords = better)
  titlesWithValidation.sort((a, b) => {
    if (a.valid && !b.valid) return -1;
    if (!a.valid && b.valid) return 1;
    return b.charCount - a.charCount;
  });

  // Best recommended title
  const recommended = titlesWithValidation.find((t) => t.valid)
    || titlesWithValidation[0]
    || null;

  status('Done.');

  return {
    productId:       productData.productId,
    marketplace:     productData.marketplace,
    rawTitle:        productData.title,
    cleanedTitle:    productData.cleanedTitle,
    realProduct:     aiResult.realProduct     || null,
    keyAttributes:   aiResult.keyAttributes   || null,
    topKeywords:     aiResult.topKeywords     || [],
    titles:          titlesWithValidation,
    recommended:     recommended?.title       || null,
    recommendedReason: aiResult.recommendedReason || null,
    allValid:        titlesWithValidation.filter((t) => t.valid).length,
    totalGenerated:  titlesWithValidation.length,
  };
}

// ─────────────────────────────────────────────────────────
// 7. DISPLAY HELPER
// ─────────────────────────────────────────────────────────

/**
 * Renders title results into the #output_titles div.
 * Mirrors the existing UnicornDS UI pattern from index.html.
 * @param {Object} result - from buildAliexpressTitles()
 * @param {HTMLElement} container - the #output_titles element
 */
function displayTitleResults(result, container) {
  if (!container) return;

  container.innerHTML = '';

  // Header
  const header = document.createElement('div');
  header.className = 'title_type';
  header.textContent = `eBay Title Suggestions for: ${result.realProduct || result.cleanedTitle}`;
  container.appendChild(header);

  // Keywords found
  if (result.topKeywords?.length) {
    const kwDiv = document.createElement('div');
    kwDiv.style.cssText = 'margin-bottom:12px; font-size:13px; color:#555;';
    kwDiv.innerHTML = `<strong>Top Keywords:</strong> ${result.topKeywords.join(', ')}`;
    container.appendChild(kwDiv);
  }

  // Each title
  result.titles.forEach((t, i) => {
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'margin-bottom: 16px; padding: 10px; border: 1px solid #ddd; border-radius: 6px; background: #fff;';

    // Recommended badge
    if (t.title === result.recommended) {
      wrapper.style.borderColor = '#28a745';
      wrapper.style.backgroundColor = '#f0fff4';
    }

    const titleEl = document.createElement('div');
    titleEl.className = 'perfect_title';
    titleEl.style.cursor = 'pointer';
    titleEl.title = 'Click to copy';
    titleEl.textContent = t.title;

    // Click to copy
    titleEl.addEventListener('click', () => {
      navigator.clipboard.writeText(t.title);
      titleEl.style.backgroundColor = '#d4edda';
      setTimeout(() => { titleEl.style.backgroundColor = ''; }, 1500);
    });

    const meta = document.createElement('div');
    meta.style.cssText = 'font-size:12px; color:#888; margin-top:4px;';
    meta.innerHTML = `
      <span style="margin-right:8px;">📏 ${t.charCount} chars</span>
      <span style="margin-right:8px;">🎯 ${t.strategy || ''}</span>
      ${t.valid
        ? '<span style="color:#28a745;">✅ Valid</span>'
        : `<span style="color:#dc3545;">⚠️ ${t.issues.join('; ')}</span>`}
      ${t.title === result.recommended ? ' <strong style="color:#28a745;">⭐ Recommended</strong>' : ''}
    `;

    wrapper.appendChild(titleEl);
    wrapper.appendChild(meta);
    container.appendChild(wrapper);
  });

  // Summary
  const summary = document.createElement('div');
  summary.style.cssText = 'font-size:13px; color:#666; margin-top:8px;';
  summary.textContent = `${result.allValid} of ${result.totalGenerated} titles passed validation.`;
  container.appendChild(summary);
}

// ─────────────────────────────────────────────────────────
// 8. CHROME EXTENSION MESSAGE BRIDGE
// ─────────────────────────────────────────────────────────

/**
 * Listens for the background script triggering a title build
 * (same pattern as the existing build_the_seo_titles message).
 */
if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.type === 'build_aliexpress_titles') {
      const { productData, promptTemplate } = message.options;

      buildAliexpressTitles(productData, promptTemplate)
        .then((result) => {
          console.log('[UnicornDS] Titles built:', result);
          sendResponse({ success: true, result });
        })
        .catch((err) => {
          console.error('[UnicornDS] Title build failed:', err);
          sendResponse({ success: false, error: err.message });
        });

      return true; // keep message channel open
    }
  });
}

// ─────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────

function marketplaceLabel(code) {
  const labels = {
    com:   'aliexpress.com (Global)',
    us:    'aliexpress.us (United States)',
    co_uk: 'aliexpress.co.uk (United Kingdom)',
    de:    'de.aliexpress.com (Germany)',
    fr:    'fr.aliexpress.com (France)',
    es:    'es.aliexpress.com (Spain)',
    it:    'it.aliexpress.com (Italy)',
    nl:    'nl.aliexpress.com (Netherlands)',
  };
  return labels[code] || code;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    buildAliexpressTitles,
    buildPrompt,
    validateTitle,
    cleanTitle,
    inferCategory,
    displayTitleResults,
  };
} else {
  window.UDSTitleBuilder = {
    buildAliexpressTitles,
    buildPrompt,
    validateTitle,
    cleanTitle,
    inferCategory,
    displayTitleResults,
  };
}
