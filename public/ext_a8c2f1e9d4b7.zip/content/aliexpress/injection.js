/**
 * UnicornDS - AliExpress Injection Script
 * 
 * THIS RUNS IN THE PAGE'S MAIN CONTEXT - not in the extension's isolated world.
 * It can access window variables, AliExpress's data stores, and intercept API calls.
 *
 * Flow:
 *   1. Content script injects this via <script src="chrome.getURL('...')">
 *   2. Content script sends window.postMessage({from: 'aliexpress-scraper'})
 *   3. This script reads page data and responds with window.postMessage({for: 'aliexpress-scraper', data: ...})
 *
 * Data structure returned matches 's expected format:
 *   - GLOBAL_DATA.globalData.subject (title)
 *   - GLOBAL_DATA.globalData.productId
 *   - HEADER_IMAGE_PC.imagePathList (full-size images)
 *   - HEADER_IMAGE_PC.skuImagesMap (variation images)
 *   - PRICE.targetSkuPriceInfo.salePriceString
 *   - PRICE.skuPriceInfoMap
 *   - SKU.skuProperties (variations)
 *   - SKU.skuPaths
 *   - PRODUCT_PROP_PC.showedProps (item specifics)
 *   - DESC.pcDescUrl (description iframe URL)
 *   - QUANTITY_PC.allSkuQuantityView
 *   - SHIPPING.deliveryLayoutInfo
 */

(function() {
  'use strict';

  // ── Listen for requests from content script ────────────
  window.addEventListener('message', function(event) {
    if (event.source !== window) return;
    if (!event.data || event.data.from !== 'aliexpress-scraper') return;

    console.log('[UnicornDS injection.js] Received request from content script');

    try {
      const data = extractPageData();
      if (data) {
        console.log('[UnicornDS injection.js] Sending data back:', Object.keys(data));
        window.postMessage({ for: 'aliexpress-scraper', data: JSON.stringify(data) }, '*');
      } else {
        console.warn('[UnicornDS injection.js] No data found');
        window.postMessage({ for: 'aliexpress-scraper', data: null }, '*');
      }
    } catch (err) {
      console.error('[UnicornDS injection.js] Error:', err);
      window.postMessage({ for: 'aliexpress-scraper', data: null }, '*');
    }
  });

  // ── Extract product data from page ─────────────────────
  function extractPageData() {
    // Method 1: __NEXT_DATA__ (modern AliExpress uses Next.js)
    var data = tryNextData();
    if (data) { console.log('[UnicornDS injection.js] Got data from __NEXT_DATA__'); return data; }

    // Method 2: runParams (older AliExpress pages)
    data = tryRunParams();
    if (data) { console.log('[UnicornDS injection.js] Got data from runParams'); return data; }

    // Method 3: Script tag JSON (some pages embed data in script tags)
    data = tryScriptTags();
    if (data) { console.log('[UnicornDS injection.js] Got data from script tags'); return data; }

    // Method 4: window._dida_config_ or window.PAGE_DATA
    data = tryWindowVars();
    if (data) { console.log('[UnicornDS injection.js] Got data from window vars'); return data; }

    // Method 5: Deep search - scan ALL window properties for product data
    data = tryDeepSearch();
    if (data) { console.log('[UnicornDS injection.js] Got data from deep search'); return data; }

    console.warn('[UnicornDS injection.js] All extraction methods failed');
    return null;
  }

  // ── Method 1: __NEXT_DATA__ ────────────────────────────
  function tryNextData() {
    try {
      var nextData = window.__NEXT_DATA__;
      if (!nextData) return null;

      var pageProps = nextData.props && nextData.props.pageProps;
      if (!pageProps) return null;

      // AliExpress stores component data in pageProps
      var initialData = pageProps.initialData || pageProps.data || pageProps;

      // Check if it has the expected structure
      if (initialData.HEADER_IMAGE_PC || initialData.productInfoComponent || initialData.imageComponent) {
        return normalizeData(initialData);
      }

      // Sometimes nested deeper
      if (initialData.data) {
        var nested = initialData.data;
        if (nested.HEADER_IMAGE_PC || nested.productInfoComponent) {
          return normalizeData(nested);
        }
      }

      // Try result key
      if (initialData.result) {
        return normalizeData(initialData.result);
      }

      return null;
    } catch (e) {
      console.warn('[UnicornDS injection.js] __NEXT_DATA__ failed:', e.message);
      return null;
    }
  }

  // ── Method 2: runParams ────────────────────────────────
  function tryRunParams() {
    try {
      var rp = window.runParams;
      if (!rp) return null;

      var data = rp.data || rp;
      if (data.titleModule || data.imageModule || data.priceModule) {
        // Old-style AliExpress data - convert to new format
        return convertOldFormat(data);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ── Method 3: Script tags ──────────────────────────────
  function tryScriptTags() {
    try {
      var scripts = document.querySelectorAll('script');
      for (var i = 0; i < scripts.length; i++) {
        var text = scripts[i].textContent || '';

        // Look for window.runParams assignment
        if (text.includes('window.runParams')) {
          var match = text.match(/window\.runParams\s*=\s*(\{[\s\S]*?\});/);
          if (match) {
            var parsed = JSON.parse(match[1]);
            var data = parsed.data || parsed;
            if (data.titleModule || data.imageModule) {
              return convertOldFormat(data);
            }
          }
        }

        // Look for __NEXT_DATA__ in script
        if (text.includes('"HEADER_IMAGE_PC"') || text.includes('"productInfoComponent"')) {
          try {
            var jsonMatch = text.match(/\{[\s\S]*"HEADER_IMAGE_PC"[\s\S]*\}/);
            if (jsonMatch) {
              var parsed = JSON.parse(jsonMatch[0]);
              return normalizeData(parsed);
            }
          } catch (e) { /* continue */ }
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ── Method 4: Window variables ─────────────────────────
  function tryWindowVars() {
    try {
      // Various global vars AliExpress might use
      var candidates = [
        window._dida_config_,
        window.PAGE_DATA,
        window.__page_data__,
        window.pageData,
      ];

      for (var i = 0; i < candidates.length; i++) {
        if (candidates[i]) {
          var data = candidates[i].data || candidates[i];
          if (data.HEADER_IMAGE_PC || data.titleModule || data.productInfoComponent) {
            return normalizeData(data);
          }
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ── Normalize modern AliExpress data ───────────────────
  // Makes sure all expected keys exist in the format  uses
  function normalizeData(raw) {
    return {
      GLOBAL_DATA: raw.GLOBAL_DATA || {
        globalData: {
          subject: raw.productInfoComponent && raw.productInfoComponent.subject || '',
          productId: raw.productInfoComponent && raw.productInfoComponent.idStr || '',
        }
      },
      HEADER_IMAGE_PC: raw.HEADER_IMAGE_PC || {
        imagePathList: (raw.imageComponent && raw.imageComponent.imagePathList) || [],
        skuImagesMap: (raw.imageComponent && raw.imageComponent.skuImagesMap) || {},
        productVideo: null,
      },
      PRICE: raw.PRICE || raw.priceComponent || {
        targetSkuPriceInfo: { salePriceString: '' },
        skuPriceInfoMap: {},
      },
      SKU: raw.SKU || {
        skuProperties: (raw.skuComponent && raw.skuComponent.productSKUPropertyList) || [],
        skuPaths: [],
      },
      PRODUCT_PROP_PC: raw.PRODUCT_PROP_PC || {
        showedProps: (raw.productPropComponent && raw.productPropComponent.props) || [],
      },
      DESC: raw.DESC || {
        pcDescUrl: (raw.productDescComponent && raw.productDescComponent.descriptionUrl) || '',
      },
      QUANTITY_PC: raw.QUANTITY_PC || {
        allSkuQuantityView: {},
      },
      SHIPPING: raw.SHIPPING || raw.webGeneralFreightCalculateComponent || null,
      // Pass through any extra keys
      productInfoComponent: raw.productInfoComponent || null,
      priceComponent: raw.priceComponent || null,
      skuComponent: raw.skuComponent || null,
    };
  }

  // ── Convert old runParams format to new format ─────────
  function convertOldFormat(data) {
    var images = [];
    if (data.imageModule && data.imageModule.imagePathList) {
      images = data.imageModule.imagePathList;
    }

    var price = '';
    if (data.priceModule) {
      price = data.priceModule.formatedActivityPrice || data.priceModule.formatedPrice || '';
    }

    var specs = [];
    if (data.specsModule && data.specsModule.props) {
      specs = data.specsModule.props;
    }

    return {
      GLOBAL_DATA: {
        globalData: {
          subject: data.titleModule && data.titleModule.subject || '',
          productId: (data.actionModule && data.actionModule.productId) ||
                     (data.commonModule && data.commonModule.productId) || '',
        }
      },
      HEADER_IMAGE_PC: {
        imagePathList: images,
        skuImagesMap: {},
        productVideo: null,
      },
      PRICE: {
        targetSkuPriceInfo: { salePriceString: price },
        skuPriceInfoMap: {},
      },
      SKU: {
        skuProperties: (data.skuModule && data.skuModule.productSKUPropertyList) || [],
        skuPaths: [],
      },
      PRODUCT_PROP_PC: {
        showedProps: specs,
      },
      DESC: {
        pcDescUrl: (data.descriptionModule && data.descriptionModule.descUrl) || '',
      },
      QUANTITY_PC: {
        allSkuQuantityView: {},
      },
      SHIPPING: null,
    };
  }

  console.log('[UnicornDS injection.js] Ready - listening for postMessage from content script');

  // ── Method 5: Deep search window properties ────────────
  function tryDeepSearch() {
    try {
      console.log('[UnicornDS injection.js] Deep search starting...');
      
      // Check common AliExpress data storage patterns
      var keysToTry = Object.keys(window).filter(function(k) {
        try {
          return typeof window[k] === 'object' && window[k] !== null && !k.startsWith('__') && k !== 'chrome' && k !== 'document' && k !== 'location';
        } catch(e) { return false; }
      });

      for (var i = 0; i < keysToTry.length; i++) {
        try {
          var obj = window[keysToTry[i]];
          if (!obj) continue;
          
          // Check if this object has imagePathList directly
          if (obj.imagePathList && Array.isArray(obj.imagePathList)) {
            console.log('[UnicornDS injection.js] Found imagePathList on window.' + keysToTry[i]);
            return normalizeData(obj);
          }
          
          // Check one level deep
          if (typeof obj === 'object') {
            var subKeys = Object.keys(obj);
            for (var j = 0; j < subKeys.length; j++) {
              var sub = obj[subKeys[j]];
              if (sub && typeof sub === 'object') {
                if (sub.HEADER_IMAGE_PC || sub.imagePathList) {
                  console.log('[UnicornDS injection.js] Found data on window.' + keysToTry[i] + '.' + subKeys[j]);
                  return normalizeData(sub.HEADER_IMAGE_PC ? sub : { HEADER_IMAGE_PC: { imagePathList: sub.imagePathList } });
                }
                if (sub.data && sub.data.HEADER_IMAGE_PC) {
                  console.log('[UnicornDS injection.js] Found on window.' + keysToTry[i] + '.' + subKeys[j] + '.data');
                  return normalizeData(sub.data);
                }
              }
            }
          }
        } catch(e) { continue; }
      }

      // Also try to find data in script tags (from MAIN world we can eval)
      var scripts = document.querySelectorAll('script:not([src])');
      for (var s = 0; s < scripts.length; s++) {
        var text = scripts[s].textContent || '';
        if (text.includes('imagePathList') && text.includes('alicdn.com')) {
          console.log('[UnicornDS injection.js] Found imagePathList in script tag');
          var imgMatch = text.match(/"imagePathList"\s*:\s*(\[[^\]]+\])/);
          if (imgMatch) {
            try {
              var imgList = JSON.parse(imgMatch[1]);
              console.log('[UnicornDS injection.js] Extracted', imgList.length, 'images from script');
              
              // Try to get title too
              var titleMatch = text.match(/"subject"\s*:\s*"([^"]+)"/);
              var idMatch = text.match(/"productId"\s*:\s*"?(\d+)"?/);
              
              return {
                GLOBAL_DATA: { globalData: { 
                  subject: titleMatch ? titleMatch[1] : '',
                  productId: idMatch ? idMatch[1] : '',
                }},
                HEADER_IMAGE_PC: { imagePathList: imgList, skuImagesMap: {} },
                PRICE: { targetSkuPriceInfo: { salePriceString: '' } },
                SKU: { skuProperties: [] },
                PRODUCT_PROP_PC: { showedProps: [] },
                DESC: { pcDescUrl: '' },
                QUANTITY_PC: {},
                SHIPPING: null,
              };
            } catch(e) { console.warn('[UnicornDS injection.js] Parse error:', e.message); }
          }
        }
      }

      return null;
    } catch(e) {
      console.warn('[UnicornDS injection.js] Deep search error:', e.message);
      return null;
    }
  }

})();
