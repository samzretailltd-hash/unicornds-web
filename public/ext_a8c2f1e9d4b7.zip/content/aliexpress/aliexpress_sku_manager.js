/**
 * UnicornDS - AliExpress SKU Manager
 *
 * Manages the mapping between AliExpress Product IDs and eBay Custom Labels (SKUs).
 *
 * Why this matters:
 *   - Amazon uses ASINs as a natural unique ID. AliExpress doesn't have an
 *     equivalent on eBay - you set your own Custom Label (SKU).
 *   - A consistent SKU format lets you instantly trace any eBay listing
 *     back to its AliExpress source product and variant.
 *   - The duplicate checker uses SKUs to find listings of the same product.
 *
 * SKU Format:
 *   Single variant:   AE-{productId}
 *                     e.g. AE-1005006123456789
 *
 *   Specific variant: AE-{productId}-{variantHash}
 *                     e.g. AE-1005006123456789-WHT  (White colour)
 *                     e.g. AE-1005006123456789-BLK  (Black colour)
 *
 *   With marketplace: AE-{marketplace}-{productId}
 *                     e.g. AE-UK-1005006123456789
 *
 * Dictionary structure (stored in Chrome local storage + dictionary.json):
 * {
 *   "AE-1005006123456789": {
 *     source: "aliexpress",
 *     productId: "1005006123456789",
 *     marketplace: "co_uk",
 *     variantCode: null,
 *     aliexpressUrl: "https://...",
 *     ebayListingId: "123456789012",  // eBay item number once listed
 *     title: "LED Desk Lamp ...",
 *     dateAdded: "2025-01-01T00:00:00.000Z",
 *     lastSeen: "2025-01-15T00:00:00.000Z",
 *   }
 * }
 */

// ─────────────────────────────────────────────────────────
// 1. SKU GENERATION
// ─────────────────────────────────────────────────────────

/**
 * Generates a clean eBay SKU from an AliExpress product.
 *
 * @param {string} productId   - AliExpress product ID (e.g. "1005006123456789")
 * @param {string} marketplace - 'com' | 'co_uk' | 'de' | 'us' | 'com_au' | 'ca'
 * @param {string} [variantValue] - variant label e.g. "White", "XL", "Red"
 * @returns {string} eBay SKU
 */
function generateSKU(productId, marketplace = 'com', variantValue = null) {
  if (!productId) throw new Error('productId is required');

  // Marketplace prefix (only for non-US to keep US SKUs shorter)
  const mkPrefix = marketplace === 'com' ? '' : `-${marketplaceCode(marketplace)}`;

  // Base SKU
  let sku = `AE${mkPrefix}-${productId}`;

  // Variant suffix - normalise to 3-char uppercase code
  if (variantValue) {
    const variantCode = normaliseVariantCode(variantValue);
    sku += `-${variantCode}`;
  }

  return sku;
}

/**
 * Generates SKUs for all variants of a product.
 * @param {string}   productId
 * @param {string}   marketplace
 * @param {Array}    variants    - from stock.variants in scraped data
 * @returns {Array}  [{ variantValue, sku }, ...]
 */
function generateVariantSKUs(productId, marketplace, variants = []) {
  const skus = [];

  if (!variants || variants.length === 0) {
    // Single variant product
    skus.push({
      variantValue: null,
      sku:          generateSKU(productId, marketplace),
    });
    return skus;
  }

  // Flatten all variant combinations
  // For simplicity, use the primary variant group (e.g. colour)
  const primaryGroup = variants[0];
  if (primaryGroup?.options) {
    primaryGroup.options.forEach((option) => {
      skus.push({
        variantGroup: primaryGroup.name,
        variantValue: option.value,
        sku:          generateSKU(productId, marketplace, option.value),
        price:        option.price,
        stock:        option.stock,
      });
    });
  }

  return skus;
}

/**
 * Parses a SKU back into its components.
 * @param {string} sku
 * @returns {{ source, marketplace, productId, variantCode } | null}
 */
function parseSKU(sku) {
  if (!sku || typeof sku !== 'string') return null;

  // AliExpress SKU: AE[-MKT]-productId[-VARIANT]
  const aliMatch = sku.match(/^AE(?:-([A-Z]+))?-(\d{10,20})(?:-([A-Z0-9]{1,6}))?$/);
  if (aliMatch) {
    return {
      source:      'aliexpress',
      marketplace: aliMatch[1] ? reverseMarketplaceCode(aliMatch[1]) : 'com',
      productId:   aliMatch[2],
      variantCode: aliMatch[3] || null,
    };
  }

  // Amazon ASIN SKU (backward compat): typically B0XXXXXXXXX
  const asinMatch = sku.match(/^B0[A-Z0-9]{8}$/i);
  if (asinMatch) {
    return {
      source:      'amazon',
      marketplace: 'com',
      productId:   sku.toUpperCase(),
      variantCode: null,
    };
  }

  // Unknown format
  return { source: 'unknown', sku };
}

/**
 * Checks if a SKU belongs to an AliExpress product.
 */
function isAliexpressSKU(sku) {
  return sku?.startsWith('AE-') || sku?.startsWith('AE-');
}

/**
 * Checks if a SKU looks like an Amazon ASIN.
 */
function isAmazonSKU(sku) {
  return /^B0[A-Z0-9]{8}$/i.test(sku || '');
}

// ─────────────────────────────────────────────────────────
// 2. SKU NORMALISATION HELPERS
// ─────────────────────────────────────────────────────────

/**
 * Converts a variant value into a 3-6 char code suitable for a SKU.
 * e.g. "White" → "WHT", "Black" → "BLK", "Extra Large" → "XL"
 */
function normaliseVariantCode(variantValue) {
  if (!variantValue) return 'DEF';

  const v = variantValue.trim().toUpperCase();

  // Known colour mappings
  const colourMap = {
    'WHITE':      'WHT', 'BLACK':       'BLK', 'RED':         'RED',
    'BLUE':       'BLU', 'GREEN':       'GRN', 'YELLOW':      'YLW',
    'PINK':       'PNK', 'PURPLE':      'PRP', 'ORANGE':      'ORG',
    'GREY':       'GRY', 'GRAY':        'GRY', 'SILVER':      'SLV',
    'GOLD':       'GLD', 'BROWN':       'BRN', 'BEIGE':       'BGE',
    'NAVY':       'NVY', 'ROSE GOLD':   'RSG', 'ROSE':        'ROS',
    'TRANSPARENT':'TRP', 'CLEAR':       'CLR',
  };
  if (colourMap[v]) return colourMap[v];

  // Known size mappings
  const sizeMap = {
    'EXTRA SMALL': 'XS',  'SMALL':       'S',
    'MEDIUM':      'M',   'LARGE':       'L',
    'EXTRA LARGE': 'XL',  'EXTRA EXTRA LARGE': 'XXL',
    'ONE SIZE':    'OS',
  };
  if (sizeMap[v]) return sizeMap[v];

  // Default: take first 3 chars, strip non-alphanumeric
  return v.replace(/[^A-Z0-9]/g, '').substring(0, 6) || 'VAR';
}

function marketplaceCode(marketplace) {
  const codes = {
    co_uk:  'UK',
    de:     'DE',
    fr:     'FR',
    es:     'ES',
    it:     'IT',
    nl:     'NL',
    com_au: 'AU',
    ca:     'CA',
    us:     'US',
  };
  return codes[marketplace] || marketplace.toUpperCase().substring(0, 3);
}

function reverseMarketplaceCode(code) {
  const map = {
    'UK': 'co_uk', 'DE': 'de', 'FR': 'fr',
    'ES': 'es', 'IT': 'it', 'NL': 'nl',
    'AU': 'com_au', 'CA': 'ca', 'US': 'us',
  };
  return map[code] || 'com';
}

// ─────────────────────────────────────────────────────────
// 3. DICTIONARY MANAGER
// ─────────────────────────────────────────────────────────

const STORAGE_KEY = 'unicornds_sku_dictionary';

/**
 * Loads the full SKU dictionary from Chrome storage.
 * Merges with any entries from dictionary.json if present.
 * @returns {Promise<Object>} dictionary
 */
async function loadDictionary() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  return result[STORAGE_KEY] || {};
}

/**
 * Saves the full dictionary to Chrome storage.
 */
async function saveDictionary(dictionary) {
  await chrome.storage.local.set({ [STORAGE_KEY]: dictionary });
}

/**
 * Adds or updates a single entry in the dictionary.
 * @param {string} sku
 * @param {Object} entry
 */
async function upsertEntry(sku, entry) {
  const dict = await loadDictionary();
  dict[sku]  = {
    ...entry,
    sku,
    lastSeen: new Date().toISOString(),
    dateAdded: dict[sku]?.dateAdded || new Date().toISOString(),
  };
  await saveDictionary(dict);
  return dict[sku];
}

/**
 * Looks up a SKU in the dictionary.
 * @param {string} sku
 * @returns {Promise<Object|null>}
 */
async function lookupSKU(sku) {
  const dict = await loadDictionary();
  return dict[sku] || null;
}

/**
 * Looks up all SKUs for a given AliExpress product ID.
 * @param {string} productId
 * @returns {Promise<Array>}
 */
async function lookupByProductId(productId) {
  const dict    = await loadDictionary();
  const matches = [];
  for (const [sku, entry] of Object.entries(dict)) {
    if (entry.productId === productId && entry.source === 'aliexpress') {
      matches.push({ sku, ...entry });
    }
  }
  return matches;
}

/**
 * Registers a newly scraped AliExpress product into the dictionary.
 * Generates SKUs for all variants.
 *
 * @param {Object} productData - from content_aliexpress.js
 * @returns {Promise<Array>} generated SKU entries
 */
async function registerProduct(productData) {
  const { productId, marketplace, title, url, stock } = productData;

  if (!productId) throw new Error('Cannot register product without productId');

  const variants     = stock?.variants || [];
  const generatedSKUs = generateVariantSKUs(productId, marketplace, variants);
  const entries      = [];

  for (const { sku, variantValue, variantGroup, price, stock: varStock } of generatedSKUs) {
    const entry = {
      source:        'aliexpress',
      productId,
      marketplace,
      variantValue:  variantValue || null,
      variantGroup:  variantGroup || null,
      variantCode:   variantValue ? normaliseVariantCode(variantValue) : null,
      aliexpressUrl: url,
      title:         title,
      cleanedTitle:  productData.cleanedTitle || title,
      aliexpressPrice: price || productData.price?.minAmount || null,
      ebayListingId: null, // set when listed on eBay
      ebayTitle:     null, // set when listed on eBay
      ebayPrice:     null, // set when listed on eBay
      variantStock:  varStock ?? null,
    };

    await upsertEntry(sku, entry);
    entries.push({ sku, ...entry });
  }

  console.log(`[UnicornDS SKU] Registered ${entries.length} SKU(s) for product ${productId}`);
  return entries;
}

/**
 * Links a SKU to an eBay listing once it has been created.
 * @param {string} sku
 * @param {string} ebayListingId - eBay item number
 * @param {string} ebayTitle
 * @param {number} ebayPrice
 */
async function linkToEbayListing(sku, ebayListingId, ebayTitle, ebayPrice) {
  const dict  = await loadDictionary();
  if (!dict[sku]) throw new Error(`SKU not found: ${sku}`);

  dict[sku].ebayListingId = ebayListingId;
  dict[sku].ebayTitle     = ebayTitle;
  dict[sku].ebayPrice     = ebayPrice;
  dict[sku].listedAt      = new Date().toISOString();

  await saveDictionary(dict);
  return dict[sku];
}

// ─────────────────────────────────────────────────────────
// 4. DUPLICATE DETECTION
// ─────────────────────────────────────────────────────────

/**
 * Finds duplicate SKUs in a list of eBay listings.
 * Works for both AliExpress (AE-) and Amazon (B0...) SKUs.
 *
 * @param {string[]} skuList - array of SKU strings from eBay
 * @returns {{ duplicates: Object, uniqueCount: number, duplicateCount: number }}
 */
function findDuplicateSKUs(skuList) {
  const seen      = new Map(); // sku → first index
  const duplicates= {};        // sku → [indices]

  skuList.forEach((sku, index) => {
    const normalised = (sku || '').trim().toUpperCase();
    if (!normalised) return;

    if (seen.has(normalised)) {
      if (!duplicates[normalised]) {
        duplicates[normalised] = [seen.get(normalised)];
      }
      duplicates[normalised].push(index);
    } else {
      seen.set(normalised, index);
    }
  });

  return {
    duplicates,
    uniqueCount:    seen.size - Object.keys(duplicates).length,
    duplicateCount: Object.keys(duplicates).length,
    totalDupes:     Object.values(duplicates).reduce((sum, arr) => sum + arr.length - 1, 0),
  };
}

/**
 * Finds AliExpress products that are listed multiple times
 * (even with different SKUs, if they share a productId).
 *
 * @param {string[]} skuList
 * @returns {Object} productId → [skus]
 */
function findDuplicateProductIds(skuList) {
  const productIdMap = {};

  skuList.forEach((sku) => {
    const parsed = parseSKU(sku);
    if (parsed?.source === 'aliexpress' && parsed.productId) {
      if (!productIdMap[parsed.productId]) {
        productIdMap[parsed.productId] = [];
      }
      productIdMap[parsed.productId].push(sku);
    }
  });

  // Keep only productIds that appear more than once
  const duplicates = {};
  Object.entries(productIdMap).forEach(([productId, skus]) => {
    if (skus.length > 1) duplicates[productId] = skus;
  });

  return duplicates;
}

// ─────────────────────────────────────────────────────────
// 5. ASIN ↔ ALIEXPRESS ID CONVERSION TOOLS
// ─────────────────────────────────────────────────────────

/**
 * Converts a list of AliExpress product IDs to UnicornDS SKUs.
 * @param {string} input - newline-separated product IDs
 * @param {string} marketplace
 * @returns {string} newline-separated SKUs
 */
function convertProductIdsToSKUs(input, marketplace = 'com') {
  return input
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((id) => {
      const cleanId = id.replace(/[^0-9]/g, '');
      if (!cleanId) return `INVALID: ${id}`;
      return generateSKU(cleanId, marketplace);
    })
    .join('\n');
}

/**
 * Converts a list of UnicornDS SKUs back to AliExpress product IDs.
 * @param {string} input - newline-separated SKUs
 * @returns {string} newline-separated product IDs + marketplace info
 */
function convertSKUsToProductIds(input) {
  return input
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((sku) => {
      const parsed = parseSKU(sku);
      if (!parsed || parsed.source === 'unknown') return `UNKNOWN: ${sku}`;
      if (parsed.source === 'amazon')    return `AMAZON-ASIN: ${parsed.productId}`;
      return `${parsed.productId} (${parsed.marketplace}${parsed.variantCode ? ', variant: ' + parsed.variantCode : ''})`;
    })
    .join('\n');
}

/**
 * Converts an AliExpress product URL to a product ID.
 * @param {string} url
 * @returns {string|null}
 */
function urlToProductId(url) {
  const match = url.match(/\/item\/(\d+)\.html/);
  return match ? match[1] : null;
}

/**
 * Converts an AliExpress product URL to an UnicornDS SKU.
 * @param {string} url
 * @param {string} marketplace
 * @returns {string|null}
 */
function urlToSKU(url, marketplace = 'com') {
  const productId = urlToProductId(url);
  if (!productId) return null;
  return generateSKU(productId, marketplace);
}

/**
 * Reconstructs the source product URL from a SKU.
 * For AliExpress SKUs: returns aliexpress.com/item/{productId}.html
 * For Amazon SKUs: returns amazon.com/dp/{ASIN}
 * @param {string} sku
 * @returns {string|null} source URL
 */
function skuToSourceUrl(sku) {
  const parsed = parseSKU(sku);
  if (!parsed || !parsed.productId) return null;

  if (parsed.source === 'aliexpress') {
    return 'https://www.aliexpress.com/item/' + parsed.productId + '.html';
  }
  if (parsed.source === 'amazon') {
    return 'https://www.amazon.com/dp/' + parsed.productId;
  }
  return null;
}

/**
 * Gets the source URL for a SKU - checks dictionary first (may have actual URL),
 * then falls back to URL reconstruction.
 * @param {string} sku
 * @returns {Promise<string|null>}
 */
async function getSourceUrl(sku) {
  // Check dictionary for stored URL (most accurate)
  const entry = await lookupSKU(sku);
  if (entry?.aliexpressUrl) return entry.aliexpressUrl;
  if (entry?.sourceUrl) return entry.sourceUrl;
  // Reconstruct from SKU format
  return skuToSourceUrl(sku);
}

// ─────────────────────────────────────────────────────────
// 6. BATCH OPERATIONS
// ─────────────────────────────────────────────────────────

/**
 * Exports the full dictionary as a CSV string.
 * Useful for backup or importing into eBay.
 * @returns {Promise<string>} CSV data
 */
async function exportDictionaryAsCSV() {
  const dict    = await loadDictionary();
  const entries = Object.values(dict);

  if (entries.length === 0) return 'No entries found';

  const headers = [
    'SKU', 'Source', 'Product ID', 'Marketplace', 'Variant',
    'AliExpress Price', 'eBay Price', 'eBay Listing ID',
    'Title', 'AliExpress URL', 'Date Added',
  ];

  const rows = entries.map((e) => [
    e.sku,
    e.source,
    e.productId,
    e.marketplace,
    e.variantValue || '',
    e.aliexpressPrice || '',
    e.ebayPrice || '',
    e.ebayListingId || '',
    `"${(e.cleanedTitle || e.title || '').replace(/"/g, '""')}"`,
    e.aliexpressUrl || '',
    e.dateAdded || '',
  ].join(','));

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Imports a dictionary from a JSON file (for restore/migration).
 * @param {Object} importData - parsed JSON
 * @returns {Promise<{ imported: number, skipped: number }>}
 */
async function importDictionary(importData) {
  const dict    = await loadDictionary();
  let imported  = 0;
  let skipped   = 0;

  for (const [sku, entry] of Object.entries(importData)) {
    if (sku && entry.source && entry.productId) {
      // Don't overwrite existing entries with ebayListingId
      if (dict[sku]?.ebayListingId && !entry.ebayListingId) {
        skipped++;
        continue;
      }
      dict[sku] = { ...entry, sku };
      imported++;
    } else {
      skipped++;
    }
  }

  await saveDictionary(dict);
  return { imported, skipped };
}

/**
 * Returns summary stats about the current dictionary.
 * @returns {Promise<Object>}
 */
async function getDictionaryStats() {
  const dict    = await loadDictionary();
  const entries = Object.values(dict);

  const aliEntries   = entries.filter((e) => e.source === 'aliexpress');
  const amaEntries   = entries.filter((e) => e.source === 'amazon');
  const listedOnEbay = entries.filter((e) => e.ebayListingId);

  const byMarketplace = {};
  aliEntries.forEach((e) => {
    byMarketplace[e.marketplace] = (byMarketplace[e.marketplace] || 0) + 1;
  });

  return {
    total:             entries.length,
    aliexpress:        aliEntries.length,
    amazon:            amaEntries.length,
    listedOnEbay:      listedOnEbay.length,
    notYetListed:      entries.length - listedOnEbay.length,
    byMarketplace,
  };
}

// ─────────────────────────────────────────────────────────
// 7. CHROME EXTENSION MESSAGE BRIDGE
// ─────────────────────────────────────────────────────────

if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.type === 'generate_sku') {
      try {
        const sku = generateSKU(message.productId, message.marketplace, message.variantValue);
        sendResponse({ success: true, sku });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return false;
    }

    if (message.type === 'register_aliexpress_product') {
      registerProduct(message.productData)
        .then((entries) => sendResponse({ success: true, entries }))
        .catch((err)    => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (message.type === 'lookup_sku') {
      lookupSKU(message.sku)
        .then((entry) => sendResponse({ success: true, entry }))
        .catch((err)  => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (message.type === 'find_duplicate_skus') {
      const result = findDuplicateSKUs(message.skuList || []);
      sendResponse({ success: true, result });
      return false;
    }

    if (message.type === 'parse_sku') {
      sendResponse({ success: true, parsed: parseSKU(message.sku) });
      return false;
    }

    if (message.type === 'convert_product_ids_to_skus') {
      const result = convertProductIdsToSKUs(message.input, message.marketplace);
      sendResponse({ success: true, result });
      return false;
    }

    if (message.type === 'convert_skus_to_product_ids') {
      const result = convertSKUsToProductIds(message.input);
      sendResponse({ success: true, result });
      return false;
    }

    if (message.type === 'url_to_sku') {
      const sku = urlToSKU(message.url, message.marketplace);
      sendResponse({ success: true, sku });
      return false;
    }

    if (message.type === 'get_source_url') {
      getSourceUrl(message.sku)
        .then((url) => sendResponse({ success: true, url }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (message.type === 'sku_to_source_url') {
      const url = skuToSourceUrl(message.sku);
      sendResponse({ success: true, url });
      return false;
    }

    if (message.type === 'export_dictionary_csv') {
      exportDictionaryAsCSV()
        .then((csv) => sendResponse({ success: true, csv }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (message.type === 'get_dictionary_stats') {
      getDictionaryStats()
        .then((stats) => sendResponse({ success: true, stats }))
        .catch((err)  => sendResponse({ success: false, error: err.message }));
      return true;
    }
  });
}

// ─────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    generateSKU, generateVariantSKUs, parseSKU,
    isAliexpressSKU, isAmazonSKU,
    normaliseVariantCode,
    loadDictionary, saveDictionary, upsertEntry,
    lookupSKU, lookupByProductId,
    registerProduct, linkToEbayListing,
    findDuplicateSKUs, findDuplicateProductIds,
    convertProductIdsToSKUs, convertSKUsToProductIds,
    urlToProductId, urlToSKU, skuToSourceUrl, getSourceUrl,
    exportDictionaryAsCSV, importDictionary,
    getDictionaryStats,
  };
} else {
  window.UDSSKUManager = {
    generateSKU, generateVariantSKUs, parseSKU,
    isAliexpressSKU, isAmazonSKU,
    normaliseVariantCode,
    loadDictionary, saveDictionary, upsertEntry,
    lookupSKU, lookupByProductId,
    registerProduct, linkToEbayListing,
    findDuplicateSKUs, findDuplicateProductIds,
    convertProductIdsToSKUs, convertSKUsToProductIds,
    urlToProductId, urlToSKU, skuToSourceUrl, getSourceUrl,
    exportDictionaryAsCSV, importDictionary,
    getDictionaryStats,
  };
  window.AliexpressSKUManager = window.UDSSKUManager; // Alias for scanner
}
