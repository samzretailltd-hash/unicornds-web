/**
 * UnicornDS - AliExpress → eBay Price Calculator
 *
 * ⚠️ DEPRECATED — This file uses a MULTIPLIER-based formula (cost × 2.8)
 * which is DIFFERENT from the profit-based formula used everywhere else.
 * The canonical pricing source of truth is now: utils/pricing.js
 * 
 * This file is kept for backward compatibility with the pricing calculator
 * page UI. No critical listing flow should call these functions.
 * TODO: Migrate pricing page to use utils/pricing.js and remove this file.
 *
 * Handles the full pricing pipeline:
 *   AliExpress cost → markup → eBay fees → suggested listing price
 *
 * Supports all 4 marketplaces: .com (US), .co.uk (UK), .de (EU), .us (US)
 *
 * eBay Fee Reference (2025):
 *   ebay.com    - 13.25% FVF + $0.30 per order (most categories)
 *   ebay.co.uk  - 12.8%  FVF + £0.30 per order
 *   ebay.de     - 11.9%  FVF + €0.35 per order
 *   ebay.com.au - 13.5%  FVF + A$0.30 per order
 *   ebay.ca     - 12.9%  FVF + C$0.30 per order
 *
 * Note: eBay Managed Payments processing is already included in the FVF above.
 * Note: eBay Store subscribers get reduced FVF - configurable below.
 */

// ─────────────────────────────────────────────────────────
// 1. MARKETPLACE FEE TABLES
// ─────────────────────────────────────────────────────────

/**
 * eBay Final Value Fee (FVF) rates by marketplace and category.
 * Rates are percentages (e.g. 13.25 = 13.25%).
 * perOrderFee is the flat fee added per transaction.
 */
const EBAY_FEE_TABLE = {
  com: {
    currency:     'USD',
    symbol:       '$',
    default:      { fvf: 13.25, perOrder: 0.30 },
    categories: {
      'Motors Parts & Accessories': { fvf: 11.5,  perOrder: 0.30 },
      'Books & Magazines':          { fvf: 14.95, perOrder: 0.30 },
      'Music':                      { fvf: 14.95, perOrder: 0.30 },
      'DVDs & Movies':              { fvf: 14.95, perOrder: 0.30 },
      'Cameras & Photo':            { fvf: 8.70,  perOrder: 0.30 },
      'Cell Phones & Accessories':  { fvf: 13.25, perOrder: 0.30 },
      'Clothing Shoes & Accessories':{ fvf: 15.0,  perOrder: 0.30 },
      'Jewellery & Watches':        { fvf: 15.0,  perOrder: 0.30 },
      'Sporting Goods':             { fvf: 13.25, perOrder: 0.30 },
      'Toys & Hobbies':             { fvf: 13.25, perOrder: 0.30 },
    },
    storeFvfDiscount: 0.5, // Store subscribers pay ~0.5% less on average
  },
  co_uk: {
    currency:     'GBP',
    symbol:       '£',
    default:      { fvf: 12.8, perOrder: 0.30 },
    categories: {
      'Vehicle Parts & Accessories':{ fvf: 10.9,  perOrder: 0.30 },
      'Books':                      { fvf: 12.8,  perOrder: 0.30 },
      'Cameras & Photography':      { fvf: 8.70,  perOrder: 0.30 },
      'Clothes Shoes & Accessories':{ fvf: 13.5,  perOrder: 0.30 },
      'Jewellery & Watches':        { fvf: 13.5,  perOrder: 0.30 },
    },
    storeFvfDiscount: 0.5,
  },
  de: {
    currency:     'EUR',
    symbol:       '€',
    default:      { fvf: 11.9, perOrder: 0.35 },
    categories: {
      'Auto & Motorrad':            { fvf: 10.9,  perOrder: 0.35 },
      'Kameras & Foto':             { fvf: 7.70,  perOrder: 0.35 },
      'Kleidung & Accessoires':     { fvf: 12.5,  perOrder: 0.35 },
    },
    storeFvfDiscount: 0.5,
  },
  us: {
    // aliexpress.us → list on ebay.com
    currency:     'USD',
    symbol:       '$',
    default:      { fvf: 13.25, perOrder: 0.30 },
    categories: {},
    storeFvfDiscount: 0.5,
  },
  com_au: {
    currency:     'AUD',
    symbol:       'A$',
    default:      { fvf: 13.5, perOrder: 0.30 },
    categories: {},
    storeFvfDiscount: 0.5,
  },
  ca: {
    currency:     'CAD',
    symbol:       'C$',
    default:      { fvf: 12.9, perOrder: 0.30 },
    categories: {},
    storeFvfDiscount: 0.5,
  },
};

// ─────────────────────────────────────────────────────────
// 2. DEFAULT SETTINGS
// ─────────────────────────────────────────────────────────

const DEFAULT_SETTINGS = {
  markupMultiplier:    2.8,   // AliExpress price × this = base eBay price
  minProfitMargin:     30,    // Minimum profit margin % - warn if below this
  roundingStyle:      '0.99', // '0.99' | '0.95' | 'none'
  hasEbayStore:        false, // Store subscribers get lower FVF
  shippingCostToYou:   0,     // If you pay extra to ship from AliExpress (usually 0)
  returnCostBuffer:    0,     // Optional buffer for returns (% of sale price)
  vatRate:             0,     // VAT/GST rate if applicable (%)
};

// ─────────────────────────────────────────────────────────
// 3. CORE CALCULATION ENGINE
// ─────────────────────────────────────────────────────────

/**
 * Calculates the full pricing breakdown for a single AliExpress product.
 *
 * @param {number}  aliexpressPrice  - cost price from AliExpress (in source currency)
 * @param {string}  marketplace      - 'com' | 'co_uk' | 'de' | 'us' | 'com_au' | 'ca'
 * @param {Object}  settings         - override DEFAULT_SETTINGS
 * @param {string}  [category]       - eBay category name (for accurate FVF)
 * @returns {Object}  full pricing breakdown
 */
function calculatePrice(aliexpressPrice, marketplace = 'com', settings = {}, category = null) {
  const cfg = { ...DEFAULT_SETTINGS, ...settings };

  // Validate input
  const cost = parseFloat(aliexpressPrice);
  if (isNaN(cost) || cost <= 0) {
    throw new Error(`Invalid AliExpress price: ${aliexpressPrice}`);
  }

  // Get fee table for this marketplace
  const feeTable = EBAY_FEE_TABLE[marketplace] || EBAY_FEE_TABLE['com'];

  // Get FVF rate - use category-specific if available
  const feeEntry = (category && feeTable.categories[category])
    ? feeTable.categories[category]
    : feeTable.default;

  let fvfRate = feeEntry.fvf;
  if (cfg.hasEbayStore) {
    fvfRate = Math.max(0, fvfRate - feeTable.storeFvfDiscount);
  }

  const perOrderFee      = feeEntry.perOrder;
  const { currency, symbol } = feeTable;

  // ── Step 1: Apply markup ──────────────────────────────
  const totalCost        = cost + (cfg.shippingCostToYou || 0);
  const rawListingPrice  = totalCost * cfg.markupMultiplier;

  // ── Step 2: Round to psychological price ─────────────
  const roundedPrice     = applyRounding(rawListingPrice, cfg.roundingStyle);

  // ── Step 3: Calculate eBay fees on the rounded price ─
  const fvfAmount        = roundedPrice * (fvfRate / 100);
  const totalEbayFees    = fvfAmount + perOrderFee;

  // ── Step 4: Calculate VAT if applicable ──────────────
  const vatAmount        = cfg.vatRate > 0
    ? roundedPrice * (cfg.vatRate / 100)
    : 0;

  // ── Step 5: Return buffer ─────────────────────────────
  const returnBuffer     = cfg.returnCostBuffer > 0
    ? roundedPrice * (cfg.returnCostBuffer / 100)
    : 0;

  // ── Step 6: Net profit ────────────────────────────────
  const netProfit        = roundedPrice - totalCost - totalEbayFees - vatAmount - returnBuffer;
  const profitMargin     = (netProfit / roundedPrice) * 100;
  const profitMultiplier = roundedPrice / totalCost;

  // ── Step 7: Break-even check ──────────────────────────
  // Minimum price to cover costs + fees (0% profit)
  // listingPrice - listingPrice*(fvf/100) - perOrderFee - cost = 0
  // listingPrice * (1 - fvf/100) = cost + perOrderFee
  const breakEvenPrice   = (totalCost + perOrderFee) / (1 - fvfRate / 100);

  // ── Step 8: Recommended min price (target margin) ────
  // netProfit / listingPrice = minMargin/100
  // listingPrice * (1 - fvf/100) - perOrderFee - cost = listingPrice * minMargin/100
  // listingPrice * (1 - fvf/100 - minMargin/100) = cost + perOrderFee
  const minMarginFraction = cfg.minProfitMargin / 100;
  const minRecommendedRaw = (totalCost + perOrderFee) / (1 - fvfRate / 100 - minMarginFraction);
  const minRecommended    = applyRounding(minRecommendedRaw, cfg.roundingStyle);

  // ── Step 9: Health check ──────────────────────────────
  const warnings = [];
  if (profitMargin < cfg.minProfitMargin) {
    warnings.push(`Profit margin ${profitMargin.toFixed(1)}% is below your minimum of ${cfg.minProfitMargin}%`);
  }
  if (profitMargin < 0) {
    warnings.push(`⚠️ LOSS MAKING - you would LOSE ${symbol}${Math.abs(netProfit).toFixed(2)} per sale`);
  }
  if (roundedPrice < breakEvenPrice) {
    warnings.push(`Price ${symbol}${roundedPrice.toFixed(2)} is below break-even of ${symbol}${breakEvenPrice.toFixed(2)}`);
  }

  return {
    // Input
    aliexpressPrice:      round2(cost),
    marketplace,
    currency,
    symbol,
    category:             category || 'Default',

    // Costs
    totalCost:            round2(totalCost),
    shippingCostToYou:    round2(cfg.shippingCostToYou || 0),

    // eBay pricing
    markupMultiplier:     cfg.markupMultiplier,
    rawListingPrice:      round2(rawListingPrice),
    suggestedListingPrice: round2(roundedPrice),
    formattedPrice:       `${symbol}${roundedPrice.toFixed(2)}`,

    // eBay fees breakdown
    fvfRate:              round2(fvfRate),
    fvfAmount:            round2(fvfAmount),
    perOrderFee:          round2(perOrderFee),
    totalEbayFees:        round2(totalEbayFees),
    hasEbayStore:         cfg.hasEbayStore,

    // VAT / other
    vatRate:              cfg.vatRate,
    vatAmount:            round2(vatAmount),
    returnBuffer:         round2(returnBuffer),

    // Profit
    netProfit:            round2(netProfit),
    profitMargin:         round2(profitMargin),
    profitMultiplier:     round2(profitMultiplier),

    // Benchmarks
    breakEvenPrice:       round2(breakEvenPrice),
    minRecommendedPrice:  round2(minRecommended),

    // Health
    warnings,
    profitable:           netProfit > 0,
    meetsMinMargin:       profitMargin >= cfg.minProfitMargin,
  };
}

// ─────────────────────────────────────────────────────────
// 4. VARIANT PRICING
// ─────────────────────────────────────────────────────────

/**
 * Calculates pricing for all variants of a product (e.g. White/Black/Pink).
 * Uses the cheapest variant as the base price, most expensive for the ceiling.
 *
 * @param {Object} productData  - from content_aliexpress.js
 * @param {string} marketplace
 * @param {Object} settings
 * @returns {Object}
 */
function calculateVariantPricing(productData, marketplace, settings = {}) {
  const { price, stock } = productData;

  if (!price) {
    throw new Error('No price data in product');
  }

  const minCost = parseFloat(price.minAmount) || 0;
  const maxCost = parseFloat(price.maxAmount) || minCost;

  const cheapestVariant = calculatePrice(minCost, marketplace, settings);
  const mostExpensive   = minCost !== maxCost
    ? calculatePrice(maxCost, marketplace, settings)
    : null;

  // Per-variant pricing if variant data exists
  const variantPrices = [];
  if (stock?.variants?.length) {
    stock.variants.forEach((variantGroup) => {
      variantGroup.options?.forEach((option) => {
        if (option.price) {
          const varCalc = calculatePrice(parseFloat(option.price), marketplace, settings);
          variantPrices.push({
            variantName:    variantGroup.name,
            variantValue:   option.value,
            aliexpressPrice: option.price,
            ebayPrice:      varCalc.suggestedListingPrice,
            profit:         varCalc.netProfit,
            margin:         varCalc.profitMargin,
          });
        }
      });
    });
  }

  return {
    cheapestVariant,
    mostExpensiveVariant:  mostExpensive,
    priceRange: mostExpensive
      ? `${cheapestVariant.symbol}${cheapestVariant.suggestedListingPrice.toFixed(2)} – ${mostExpensive.symbol}${mostExpensive.suggestedListingPrice.toFixed(2)}`
      : `${cheapestVariant.symbol}${cheapestVariant.suggestedListingPrice.toFixed(2)}`,
    variantBreakdown: variantPrices,
    allProfitable: variantPrices.every((v) => v.profit > 0),
  };
}

// ─────────────────────────────────────────────────────────
// 5. MARKUP CALCULATOR (reverse: target price → required markup)
// ─────────────────────────────────────────────────────────

/**
 * Given a target eBay selling price, calculates what markup was applied
 * and what the profit breakdown looks like.
 *
 * Useful for: "I want to sell this for £19.99 - what's my profit?"
 *
 * @param {number} aliexpressPrice
 * @param {number} targetEbayPrice
 * @param {string} marketplace
 * @param {Object} settings
 */
function reverseCalculate(aliexpressPrice, targetEbayPrice, marketplace = 'com', settings = {}) {
  const cfg      = { ...DEFAULT_SETTINGS, ...settings };
  const cost     = parseFloat(aliexpressPrice);
  const listPrice= parseFloat(targetEbayPrice);

  const feeTable  = EBAY_FEE_TABLE[marketplace] || EBAY_FEE_TABLE['com'];
  const fvfRate   = feeTable.default.fvf - (cfg.hasEbayStore ? feeTable.storeFvfDiscount : 0);
  const perOrder  = feeTable.default.perOrder;
  const { symbol } = feeTable;

  const fvfAmount    = listPrice * (fvfRate / 100);
  const totalFees    = fvfAmount + perOrder;
  const netProfit    = listPrice - cost - totalFees;
  const margin       = (netProfit / listPrice) * 100;
  const impliedMarkup = listPrice / cost;

  return {
    aliexpressPrice:      round2(cost),
    targetEbayPrice:      round2(listPrice),
    impliedMarkupMultiplier: round2(impliedMarkup),
    fvfAmount:            round2(fvfAmount),
    totalFees:            round2(totalFees),
    netProfit:            round2(netProfit),
    profitMargin:         round2(margin),
    formattedSummary:     `Buy for ${symbol}${cost.toFixed(2)}, sell for ${symbol}${listPrice.toFixed(2)}, profit ${symbol}${netProfit.toFixed(2)} (${margin.toFixed(1)}%)`,
    profitable:           netProfit > 0,
    meetsMinMargin:       margin >= cfg.minProfitMargin,
  };
}

// ─────────────────────────────────────────────────────────
// 6. BATCH PRICING
// ─────────────────────────────────────────────────────────

/**
 * Calculates pricing for an array of products at once.
 * Used when processing a full AliExpress CSV or bulk import.
 *
 * @param {Array}  products    - array of { aliexpressPrice, title, productId }
 * @param {string} marketplace
 * @param {Object} settings
 * @returns {Array} pricing results with product info attached
 */
function calculateBatch(products, marketplace = 'com', settings = {}) {
  return products.map((product) => {
    try {
      const result = calculatePrice(product.aliexpressPrice, marketplace, settings);
      return {
        ...result,
        productId: product.productId || null,
        title:     product.title     || null,
        error:     null,
      };
    } catch (err) {
      return {
        productId: product.productId || null,
        title:     product.title     || null,
        error:     err.message,
        profitable: false,
      };
    }
  });
}

// ─────────────────────────────────────────────────────────
// 7. SETTINGS MANAGER
// ─────────────────────────────────────────────────────────

/**
 * Saves pricing settings to Chrome extension local storage.
 */
async function savePricingSettings(settings) {
  const validated = validateSettings(settings);
  if (typeof chrome !== 'undefined' && chrome.storage) {
    await chrome.storage.local.set({ unicornds_pricing_settings: validated });
  }
  return validated;
}

/**
 * Loads pricing settings from Chrome extension local storage.
 * Returns defaults if none saved.
 */
async function loadPricingSettings() {
  if (typeof chrome !== 'undefined' && chrome.storage) {
    const result = await chrome.storage.local.get('unicornds_pricing_settings');
    return result.unicornds_pricing_settings || { ...DEFAULT_SETTINGS };
  }
  return { ...DEFAULT_SETTINGS };
}

/**
 * Validates and clamps settings to safe ranges.
 */
function validateSettings(settings) {
  const s = { ...DEFAULT_SETTINGS, ...settings };

  s.markupMultiplier = clamp(parseFloat(s.markupMultiplier), 1.1, 20);
  s.minProfitMargin  = clamp(parseFloat(s.minProfitMargin),  0,   90);
  s.vatRate          = clamp(parseFloat(s.vatRate),          0,   30);
  s.shippingCostToYou = Math.max(0, parseFloat(s.shippingCostToYou) || 0);
  s.returnCostBuffer  = clamp(parseFloat(s.returnCostBuffer),  0,  20);
  s.roundingStyle     = ['0.99', '0.95', 'none'].includes(s.roundingStyle)
    ? s.roundingStyle : '0.99';

  return s;
}

// ─────────────────────────────────────────────────────────
// 8. DISPLAY HELPER
// ─────────────────────────────────────────────────────────

/**
 * Renders a pricing breakdown into a UI element.
 * @param {Object}      result    - from calculatePrice()
 * @param {HTMLElement} container - element to render into
 */
function displayPricingResult(result, container) {
  if (!container) return;

  const s = result.symbol;
  const rows = [
    ['AliExpress Cost',        `${s}${result.aliexpressPrice.toFixed(2)}`],
    ['Markup Multiplier',      `${result.markupMultiplier}x`],
    ['─────────────────',      '─────────'],
    ['Raw eBay Price',         `${s}${result.rawListingPrice.toFixed(2)}`],
    ['Suggested Listing Price',`<strong>${s}${result.suggestedListingPrice.toFixed(2)}</strong>`],
    ['─────────────────',      '─────────'],
    [`eBay FVF (${result.fvfRate}%)`, `- ${s}${result.fvfAmount.toFixed(2)}`],
    ['Per-Order Fee',          `- ${s}${result.perOrderFee.toFixed(2)}`],
    ['Total eBay Fees',        `- ${s}${result.totalEbayFees.toFixed(2)}`],
    result.vatAmount > 0 ? [`VAT (${result.vatRate}%)`, `- ${s}${result.vatAmount.toFixed(2)}`] : null,
    ['─────────────────',      '─────────'],
    ['Net Profit',             `<strong style="color:${result.netProfit >= 0 ? '#28a745' : '#dc3545'}">${s}${result.netProfit.toFixed(2)}</strong>`],
    ['Profit Margin',          `<strong style="color:${result.meetsMinMargin ? '#28a745' : '#ffc107'}">${result.profitMargin.toFixed(1)}%</strong>`],
    ['Profit Multiplier',      `${result.profitMultiplier.toFixed(2)}x your cost`],
    ['Break-Even Price',       `${s}${result.breakEvenPrice.toFixed(2)}`],
    ['Min Recommended Price',  `${s}${result.minRecommendedPrice.toFixed(2)}`],
  ].filter(Boolean);

  let html = '<table style="width:100%; font-size:13px; border-collapse:collapse;">';
  rows.forEach(([label, value]) => {
    if (label.startsWith('─')) {
      html += `<tr><td colspan="2" style="border-top:1px solid #eee; padding:2px 0;"></td></tr>`;
    } else {
      html += `<tr>
        <td style="padding:3px 8px; color:#555;">${label}</td>
        <td style="padding:3px 8px; text-align:right;">${value}</td>
      </tr>`;
    }
  });
  html += '</table>';

  if (result.warnings.length > 0) {
    html += `<div style="margin-top:8px; padding:8px; background:#fff3cd; border-radius:4px; font-size:12px;">
      ${result.warnings.map((w) => `⚠️ ${w}`).join('<br>')}
    </div>`;
  }

  container.innerHTML = html;
}

// ─────────────────────────────────────────────────────────
// 9. UTILITIES
// ─────────────────────────────────────────────────────────

function round2(n) {
  return Math.round(n * 100) / 100;
}

function clamp(val, min, max) {
  return Math.min(Math.max(isNaN(val) ? min : val, min), max);
}

/**
 * Applies psychological price rounding.
 *   '0.99' → £19.99, £24.99, £49.99
 *   '0.95' → £19.95, £24.95, £49.95
 *   'none' → exact value rounded to 2dp
 */
function applyRounding(price, style) {
  if (style === 'none') return round2(price);

  const ending = parseFloat('0.' + style.split('.')[1]); // 0.99 or 0.95
  const floored = Math.floor(price);

  // If price is very close to the next whole number already, step up
  const candidate = floored + ending;
  return candidate >= price ? candidate : floored + 1 + ending;
}

// ─────────────────────────────────────────────────────────
// 10. CHROME EXTENSION MESSAGE BRIDGE
// ─────────────────────────────────────────────────────────

if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.type === 'calculate_aliexpress_price') {
      const { aliexpressPrice, marketplace, settings, category } = message;
      try {
        const result = calculatePrice(aliexpressPrice, marketplace, settings, category);
        sendResponse({ success: true, result });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return false;
    }

    if (message.type === 'calculate_variant_pricing') {
      const { productData, marketplace, settings } = message;
      try {
        const result = calculateVariantPricing(productData, marketplace, settings);
        sendResponse({ success: true, result });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return false;
    }

    if (message.type === 'save_pricing_settings') {
      savePricingSettings(message.settings)
        .then((saved) => sendResponse({ success: true, settings: saved }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (message.type === 'load_pricing_settings') {
      loadPricingSettings()
        .then((settings) => sendResponse({ success: true, settings }))
        .catch((err)     => sendResponse({ success: false, error: err.message }));
      return true;
    }
  });
}

// ─────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    calculatePrice,
    calculateVariantPricing,
    reverseCalculate,
    calculateBatch,
    savePricingSettings,
    loadPricingSettings,
    validateSettings,
    displayPricingResult,
    applyRounding,
    EBAY_FEE_TABLE,
    DEFAULT_SETTINGS,
  };
} else {
  window.UDSPricing = {
    calculatePrice,
    calculateVariantPricing,
    reverseCalculate,
    calculateBatch,
    savePricingSettings,
    loadPricingSettings,
    validateSettings,
    displayPricingResult,
    EBAY_FEE_TABLE,
    DEFAULT_SETTINGS,
  };
}
