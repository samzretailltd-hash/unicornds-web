/**
 * UnicornDS - AliExpress Image Handler
 *
 * Downloads all product images from AliExpress CDN and
 * prepares them for upload to eBay Picture Services.
 *
 * Flow:
 *   AliExpress image URLs (from scraper)
 *       ↓
 *   Fetch each image in background script
 *       ↓
 *   Convert to Blob + base64
 *       ↓
 *   Pass to ebay_image_uploader.js
 *       ↓
 *   Get back eBay-hosted URLs
 *       ↓
 *   Build carousel HTML for listing template
 *
 * Why we download instead of linking directly:
 *   1. AliExpress CDN URLs expire and break listings
 *   2. eBay requires images on their own servers for
 *      search thumbnails and Gallery Plus
 *   3. AliExpress watermarks can be cropped/removed
 */

// ─────────────────────────────────────────────────────────
// 1. CONSTANTS
// ─────────────────────────────────────────────────────────

const IMAGE_CONFIG = {
  // eBay allows max 24 images per listing but 12 is the practical limit
  maxImages:       12,

  // Minimum image dimensions to bother uploading (skip tiny thumbnails)
  minWidth:        400,
  minHeight:       400,

  // AliExpress image URL size suffixes
  // _640x640.jpg  → medium quality (fast)
  // _AC_SL1500_.jpg → high quality (best for eBay)
  preferredSuffix: '800x800',

  // Request timeout per image (ms)
  fetchTimeoutMs:  15000,

  // Delay between downloads to avoid rate-limiting (ms)
  delayBetween:    300,

  // Allowed image MIME types
  allowedTypes: ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'],
};

// ─────────────────────────────────────────────────────────
// 2. URL NORMALISATION
// ─────────────────────────────────────────────────────────

/**
 * Upgrades an AliExpress image URL to the highest available quality.
 *
 * AliExpress URLs follow this pattern:
 *   https://ae01.alicdn.com/kf/{hash}/{filename}_{size}.jpg
 *
 * We strip size suffixes and request the full-size version.
 *
 * @param {string} url
 * @returns {string} upgraded URL
 */
function upgradeImageUrl(url) {
  if (!url) return url;

  let upgraded = url;

  // Ensure HTTPS
  if (upgraded.startsWith('//')) upgraded = 'https:' + upgraded;

  // Remove existing size suffix (e.g. _640x640, _200x200, _50x50)
  upgraded = upgraded.replace(/_\d+x\d+(\.[a-z]+)$/i, '$1');

  // Remove AliExpress thumbnail parameters
  upgraded = upgraded.replace(/\?.*$/, '');

  // Remove _Q90.jpg_ type quality markers
  upgraded = upgraded.replace(/_Q\d+\.jpg_/i, '.jpg');

  // Remove .webp force and prefer jpg
  upgraded = upgraded.replace(/\.webp$/i, '.jpg');

  return upgraded;
}

/**
 * Generates multiple size variants of an AliExpress image URL.
 * We'll try the largest first and fall back.
 * @param {string} url
 * @returns {string[]} ordered list of URLs to try
 */
function generateUrlVariants(url) {
  const base = upgradeImageUrl(url);
  const ext  = base.match(/\.[a-z]+$/i)?.[0] || '.jpg';
  const stem = base.replace(/\.[a-z]+$/i, '');

  return [
    base,                           // full size (no suffix)
    `${stem}_1200x1200${ext}`,      // 1200px
    `${stem}_800x800${ext}`,        // 800px fallback
    `${stem}_640x640${ext}`,        // 640px last resort
  ];
}

// ─────────────────────────────────────────────────────────
// 3. SINGLE IMAGE DOWNLOADER
// ─────────────────────────────────────────────────────────

/**
 * Downloads a single image from AliExpress CDN.
 * Tries URL variants from largest to smallest.
 *
 * @param {string} imageUrl  - original URL from scraper
 * @param {number} index     - image index (for naming)
 * @param {string} productId - AliExpress product ID
 * @returns {Promise<ImageResult|null>}
 */
async function downloadImage(imageUrl, index, productId) {
  const variants = generateUrlVariants(imageUrl);

  for (const url of variants) {
    try {
      const controller = new AbortController();
      const timeoutId  = setTimeout(
        () => controller.abort(),
        IMAGE_CONFIG.fetchTimeoutMs
      );

      const response = await fetch(url, {
        signal:      controller.signal,
        credentials: 'omit',  // no cookies needed for CDN
        headers: {
          'Accept':          'image/webp,image/jpeg,image/*',
          'Accept-Encoding': 'gzip, deflate, br',
          // Spoof a browser referer so AliExpress CDN doesn't block
          'Referer':         'https://www.aliexpress.com/',
        },
      });

      clearTimeout(timeoutId);

      if (!response.ok) continue;

      const contentType = response.headers.get('content-type') || '';
      const mimeType    = contentType.split(';')[0].trim().toLowerCase();

      if (!IMAGE_CONFIG.allowedTypes.some((t) => mimeType.includes(t.replace('image/', '')))) {
        console.warn(`[UnicornDS Images] Unexpected content-type for ${url}: ${mimeType}`);
        continue;
      }

      const arrayBuffer = await response.arrayBuffer();
      const blob        = new Blob([arrayBuffer], { type: 'image/jpeg' });
      const base64      = await blobToBase64(blob);

      // Get image dimensions to filter out tiny thumbnails
      const dimensions  = await getImageDimensions(base64);

      if (
        dimensions.width  < IMAGE_CONFIG.minWidth ||
        dimensions.height < IMAGE_CONFIG.minHeight
      ) {
        console.log(`[UnicornDS Images] Skipping small image ${index}: ${dimensions.width}x${dimensions.height}`);
        continue;
      }

      const filename = `unicornds-${productId}-img${String(index + 1).padStart(2, '0')}.jpg`;

      console.log(`[UnicornDS Images] ✓ Downloaded image ${index + 1}: ${dimensions.width}x${dimensions.height} (${formatBytes(blob.size)})`);

      return {
        index,
        originalUrl: imageUrl,
        downloadedUrl: url,
        blob,
        base64,
        mimeType:   'image/jpeg',
        filename,
        dimensions,
        sizeBytes:  blob.size,
      };

    } catch (err) {
      if (err.name === 'AbortError') {
        console.warn(`[UnicornDS Images] Timeout fetching image ${index + 1}`);
      } else {
        console.warn(`[UnicornDS Images] Failed to fetch ${url}:`, err.message);
      }
      // Try next variant
    }
  }

  console.error(`[UnicornDS Images] All variants failed for image ${index + 1}: ${imageUrl}`);
  return null;
}

// ─────────────────────────────────────────────────────────
// 4. BATCH DOWNLOADER
// ─────────────────────────────────────────────────────────

/**
 * Downloads all images for a product.
 * Processes in sequence with a small delay to avoid CDN rate-limiting.
 *
 * @param {string[]}  imageUrls  - from content_aliexpress.js scraper
 * @param {string}    productId
 * @param {Function}  [onProgress] - callback(downloaded, total, result)
 * @returns {Promise<ImageResult[]>} successfully downloaded images
 */
async function downloadAllImages(imageUrls, productId, onProgress) {
  if (!imageUrls || imageUrls.length === 0) {
    console.warn('[UnicornDS Images] No image URLs provided');
    return [];
  }

  // Deduplicate URLs
  const uniqueUrls = [...new Set(imageUrls.map(upgradeImageUrl))];

  // Cap at max allowed
  const urlsToProcess = uniqueUrls.slice(0, IMAGE_CONFIG.maxImages);

  console.log(`[UnicornDS Images] Starting download of ${urlsToProcess.length} images for product ${productId}`);

  const results = [];

  for (let i = 0; i < urlsToProcess.length; i++) {
    const result = await downloadImage(urlsToProcess[i], i, productId);

    if (result) {
      results.push(result);
    }

    // Progress callback
    if (typeof onProgress === 'function') {
      onProgress(i + 1, urlsToProcess.length, result);
    }

    // Polite delay between requests
    if (i < urlsToProcess.length - 1) {
      await delay(IMAGE_CONFIG.delayBetween);
    }
  }

  console.log(`[UnicornDS Images] Downloaded ${results.length}/${urlsToProcess.length} images successfully`);
  return results;
}

// ─────────────────────────────────────────────────────────
// 5. DEDUPLICATION
// ─────────────────────────────────────────────────────────

/**
 * Removes near-duplicate images by comparing their sizes.
 * AliExpress sometimes includes the same image in multiple resolutions.
 *
 * @param {ImageResult[]} images
 * @returns {ImageResult[]} deduplicated list
 */
function deduplicateImages(images) {
  const seen    = new Set();
  const unique  = [];

  for (const img of images) {
    // Use file size as a rough fingerprint
    const key = `${img.dimensions.width}x${img.dimensions.height}-${img.sizeBytes}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(img);
    }
  }

  if (unique.length < images.length) {
    console.log(`[UnicornDS Images] Removed ${images.length - unique.length} duplicate image(s)`);
  }

  return unique;
}

// ─────────────────────────────────────────────────────────
// 6. UTILITIES
// ─────────────────────────────────────────────────────────

/**
 * Converts a Blob to a base64 data URL string.
 */
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror   = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Gets the pixel dimensions of an image from its base64 data URL.
 */
function getImageDimensions(base64DataUrl) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload  = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
    img.onerror = () => resolve({ width: 0, height: 0 });
    img.src     = base64DataUrl;
  });
}

function formatBytes(bytes) {
  if (bytes < 1024)        return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

// ─────────────────────────────────────────────────────────
// 7. CHROME EXTENSION MESSAGE BRIDGE
// ─────────────────────────────────────────────────────────

if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.type === 'download_aliexpress_images') {
      const { imageUrls, productId } = message;

      downloadAllImages(
        imageUrls,
        productId,
        (downloaded, total) => {
          // Push progress to popup
          chrome.runtime.sendMessage({
            type:       'image_download_progress',
            downloaded,
            total,
            productId,
          }).catch(() => {});
        }
      )
      .then((images) => {
        const deduped = deduplicateImages(images);
        sendResponse({
          success: true,
          images:  deduped,
          count:   deduped.length,
        });
      })
      .catch((err) => {
        console.error('[UnicornDS Images] Download batch error:', err);
        sendResponse({ success: false, error: err.message });
      });

      return true; // async
    }
  });
}

// ─────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    downloadImage,
    downloadAllImages,
    deduplicateImages,
    upgradeImageUrl,
    generateUrlVariants,
    blobToBase64,
    IMAGE_CONFIG,
  };
} else {
  window.UDSImageHandler = {
    downloadImage,
    downloadAllImages,
    deduplicateImages,
    upgradeImageUrl,
    blobToBase64,
    IMAGE_CONFIG,
  };
}
