/**
 * UnicornDS - eBay Image Uploader
 *
 * Uploads images to eBay Picture Services (EPS) so they are
 * hosted on eBay's servers - required for eBay search thumbnails,
 * Gallery Plus, and stable listing images that never break.
 *
 * Two upload methods (tried in order):
 *   1. External URL method - pass the AliExpress URL directly,
 *      eBay fetches it themselves. Fast but can fail if eBay
 *      blocks the source domain.
 *   2. Binary upload - download the image ourselves, send the
 *      raw binary data to eBay. More reliable, slightly slower.
 *
 * eBay API used:
 *   Trading API - UploadSiteHostedPictures
 *   Endpoint: https://api.ebay.com/ws/api.dll
 *
 * Auth:
 *   Uses the eBay OAuth token stored in Chrome extension storage.
 *   The token is set during the extension onboarding/login flow.
 */

// ─────────────────────────────────────────────────────────
// 1. CONSTANTS
// ─────────────────────────────────────────────────────────

// eBay Trading API endpoint (same for all marketplaces)
const EBAY_TRADING_API_URL = 'https://api.ebay.com/ws/api.dll';

// Site IDs for each marketplace
const EBAY_SITE_IDS = {
  com:    '0',   // eBay US
  co_uk:  '3',   // eBay UK
  de:     '77',  // eBay Germany
  com_au: '15',  // eBay Australia
  ca:     '2',   // eBay Canada
  fr:     '71',  // eBay France
  es:     '186', // eBay Spain
  it:     '101', // eBay Italy
  nl:     '146', // eBay Netherlands
};

// eBay picture set options
// 'Standard'   → up to 400x400px (free)
// 'Supersize'  → up to 800x800px (free with subscription)
// 'SupportLargeImages' → up to 1600x1600px
const PICTURE_SET = 'Supersize';

// Max upload attempts per image before giving up
const MAX_RETRIES = 3;

// Delay between retry attempts (ms)
const RETRY_DELAY_MS = 2000;

// ─────────────────────────────────────────────────────────
// 2. AUTH TOKEN MANAGEMENT
// ─────────────────────────────────────────────────────────

/**
 * Loads the eBay OAuth token from Chrome extension storage.
 * @returns {Promise<string|null>}
 */
async function getEbayToken() {
  const result = await chrome.storage.local.get('ebayAuthToken');
  return result.ebayAuthToken || null;
}

/**
 * Saves the eBay OAuth token to Chrome extension storage.
 * Called during the extension login/onboarding flow.
 * @param {string} token
 */
async function saveEbayToken(token) {
  await chrome.storage.local.set({ ebayAuthToken: token });
}

/**
 * Checks if we have a valid eBay token.
 * @returns {Promise<boolean>}
 */
async function hasValidToken() {
  const token = await getEbayToken();
  return Boolean(token && token.length > 10);
}

// ─────────────────────────────────────────────────────────
// 3. XML BUILDERS
// ─────────────────────────────────────────────────────────

/**
 * Builds the XML body for UploadSiteHostedPictures (external URL method).
 * eBay fetches the image from the provided URL.
 */
function buildExternalUrlXml(token, pictureName, externalUrl, siteId) {
  return `<?xml version="1.0" encoding="utf-8"?>
<UploadSiteHostedPicturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <RequesterCredentials>
    <eBayAuthToken>${escapeXml(token)}</eBayAuthToken>
  </RequesterCredentials>
  <ErrorLanguage>en_US</ErrorLanguage>
  <WarningLevel>High</WarningLevel>
  <PictureName>${escapeXml(pictureName)}</PictureName>
  <PictureSet>${PICTURE_SET}</PictureSet>
  <ExternalPictureURL>${escapeXml(externalUrl)}</ExternalPictureURL>
</UploadSiteHostedPicturesRequest>`;
}

/**
 * Builds the multipart form body for binary upload.
 * Used as fallback when external URL method fails.
 */
function buildBinaryUploadXml(token, pictureName, siteId) {
  return `<?xml version="1.0" encoding="utf-8"?>
<UploadSiteHostedPicturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <RequesterCredentials>
    <eBayAuthToken>${escapeXml(token)}</eBayAuthToken>
  </RequesterCredentials>
  <ErrorLanguage>en_US</ErrorLanguage>
  <WarningLevel>High</WarningLevel>
  <PictureName>${escapeXml(pictureName)}</PictureName>
  <PictureSet>${PICTURE_SET}</PictureSet>
</UploadSiteHostedPicturesRequest>`;
}

/**
 * Builds standard request headers for eBay Trading API.
 */
function buildEbayHeaders(callName, siteId, contentType = 'text/xml') {
  return {
    'X-EBAY-API-CALL-NAME':        callName,
    'X-EBAY-API-SITEID':           siteId,
    'X-EBAY-API-APP-NAME':         'UnicornDS',
    'X-EBAY-API-DEV-NAME':         'UnicornDS',
    'X-EBAY-API-CERT-NAME':        'UnicornDS',
    'X-EBAY-API-COMPATIBILITY-LEVEL': '967',
    'Content-Type':                contentType,
  };
}

// ─────────────────────────────────────────────────────────
// 4. RESPONSE PARSER
// ─────────────────────────────────────────────────────────

/**
 * Parses the XML response from eBay Trading API.
 * Extracts the hosted image URL or error message.
 *
 * @param {string} xmlText - raw XML response from eBay
 * @returns {{ success: boolean, imageUrl?: string, error?: string }}
 */
function parseEbayUploadResponse(xmlText) {
  try {
    const parser   = new DOMParser();
    const doc      = parser.parseFromString(xmlText, 'text/xml');

    // Check for API-level errors
    const ack      = doc.querySelector('Ack')?.textContent;
    if (ack === 'Failure') {
      const errorMsg = doc.querySelector('Errors ShortMessage')?.textContent
        || doc.querySelector('Errors LongMessage')?.textContent
        || 'Unknown eBay API error';
      return { success: false, error: errorMsg };
    }

    // Extract the hosted image URL
    // eBay returns multiple size variants - we want the fullURL (largest)
    const fullUrl     = doc.querySelector('SiteHostedPictureDetails FullURL')?.textContent;
    const baseUrl     = doc.querySelector('SiteHostedPictureDetails BaseURL')?.textContent;

    const imageUrl = fullUrl || baseUrl;

    if (!imageUrl) {
      return { success: false, error: 'eBay response missing picture URL' };
    }

    return { success: true, imageUrl };

  } catch (err) {
    return { success: false, error: 'Failed to parse eBay response: ' + err.message };
  }
}

// ─────────────────────────────────────────────────────────
// 5. UPLOAD METHODS
// ─────────────────────────────────────────────────────────

/**
 * Method 1: External URL upload.
 * Passes the AliExpress CDN URL to eBay - eBay fetches it.
 * Fastest, but eBay might block AliExpress domains.
 */
async function uploadViaExternalUrl(token, pictureName, externalUrl, siteId) {
  const xml      = buildExternalUrlXml(token, pictureName, externalUrl, siteId);
  const headers  = buildEbayHeaders('UploadSiteHostedPictures', siteId);

  const response = await fetch(EBAY_TRADING_API_URL, {
    method:  'POST',
    headers,
    body:    xml,
  });

  if (!response.ok) {
    throw new Error(`eBay API HTTP error: ${response.status}`);
  }

  const xmlText = await response.text();
  return parseEbayUploadResponse(xmlText);
}

/**
 * Method 2: Binary upload (multipart form data).
 * We download the image and send the raw bytes to eBay.
 * More reliable when external URL method fails.
 */
async function uploadViaBinary(token, pictureName, imageBlob, siteId) {
  const xmlPart   = buildBinaryUploadXml(token, pictureName, siteId);
  const boundary  = `----UnicornDSBoundary${Date.now()}`;

  // Build multipart body manually
  // eBay requires: XML part first, then image part
  const xmlBytes  = new TextEncoder().encode(
    `--${boundary}\r\n` +
    `Content-Disposition: form-data; name="XML Payload"\r\n` +
    `Content-Type: text/xml;charset=utf-8\r\n\r\n` +
    xmlPart +
    `\r\n--${boundary}\r\n` +
    `Content-Disposition: form-data; name="Image"; filename="${pictureName}.jpg"\r\n` +
    `Content-Type: image/jpeg\r\n\r\n`
  );

  const endBytes  = new TextEncoder().encode(`\r\n--${boundary}--\r\n`);
  const imgBytes  = new Uint8Array(await imageBlob.arrayBuffer());

  // Combine all parts
  const body = new Uint8Array(xmlBytes.length + imgBytes.length + endBytes.length);
  body.set(xmlBytes, 0);
  body.set(imgBytes, xmlBytes.length);
  body.set(endBytes, xmlBytes.length + imgBytes.length);

  const headers = {
    ...buildEbayHeaders('UploadSiteHostedPictures', siteId, `multipart/form-data; boundary=${boundary}`),
  };

  const response = await fetch(EBAY_TRADING_API_URL, {
    method:  'POST',
    headers,
    body:    body.buffer,
  });

  if (!response.ok) {
    throw new Error(`eBay API HTTP error: ${response.status}`);
  }

  const xmlText = await response.text();
  return parseEbayUploadResponse(xmlText);
}

// ─────────────────────────────────────────────────────────
// 6. SINGLE IMAGE UPLOAD (with retry + fallback)
// ─────────────────────────────────────────────────────────

/**
 * Uploads a single image to eBay Picture Services.
 * Tries external URL first, falls back to binary upload,
 * retries up to MAX_RETRIES times.
 *
 * @param {Object} imageResult  - from aliexpress_image_handler.js
 * @param {string} marketplace  - determines eBay site ID
 * @param {string} token        - eBay auth token
 * @returns {Promise<UploadResult>}
 */
async function uploadSingleImage(imageResult, marketplace, token) {
  const siteId      = EBAY_SITE_IDS[marketplace] || EBAY_SITE_IDS['com'];
  const pictureName = imageResult.filename.replace(/\.jpg$/i, '');
  let   lastError   = null;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    console.log(`[UnicornDS Upload] Image ${imageResult.index + 1}, attempt ${attempt}/${MAX_RETRIES}`);

    // ── Try method 1: external URL ─────────────────────
    try {
      const result = await uploadViaExternalUrl(
        token,
        pictureName,
        imageResult.downloadedUrl,
        siteId
      );

      if (result.success) {
        console.log(`[UnicornDS Upload] ✓ Image ${imageResult.index + 1} uploaded via URL: ${result.imageUrl}`);
        return {
          success:      true,
          index:        imageResult.index,
          ebayImageUrl: result.imageUrl,
          method:       'external_url',
          originalUrl:  imageResult.originalUrl,
        };
      }

      console.warn(`[UnicornDS Upload] External URL method failed: ${result.error}. Trying binary upload…`);

    } catch (err) {
      console.warn(`[UnicornDS Upload] External URL error: ${err.message}`);
    }

    // ── Try method 2: binary upload ────────────────────
    try {
      if (!imageResult.blob) {
        throw new Error('No blob available for binary upload');
      }

      const result = await uploadViaBinary(
        token,
        pictureName,
        imageResult.blob,
        siteId
      );

      if (result.success) {
        console.log(`[UnicornDS Upload] ✓ Image ${imageResult.index + 1} uploaded via binary: ${result.imageUrl}`);
        return {
          success:      true,
          index:        imageResult.index,
          ebayImageUrl: result.imageUrl,
          method:       'binary',
          originalUrl:  imageResult.originalUrl,
        };
      }

      lastError = result.error;
      console.warn(`[UnicornDS Upload] Binary upload failed: ${result.error}`);

    } catch (err) {
      lastError = err.message;
      console.warn(`[UnicornDS Upload] Binary upload error: ${err.message}`);
    }

    // Wait before retry
    if (attempt < MAX_RETRIES) {
      console.log(`[UnicornDS Upload] Retrying in ${RETRY_DELAY_MS}ms…`);
      await new Promise((res) => setTimeout(res, RETRY_DELAY_MS));
    }
  }

  console.error(`[UnicornDS Upload] ✗ Image ${imageResult.index + 1} failed after ${MAX_RETRIES} attempts`);
  return {
    success:     false,
    index:       imageResult.index,
    error:       lastError || 'All upload methods failed',
    originalUrl: imageResult.originalUrl,
  };
}

// ─────────────────────────────────────────────────────────
// 7. BATCH UPLOAD
// ─────────────────────────────────────────────────────────

/**
 * Uploads all downloaded images to eBay in sequence.
 *
 * @param {ImageResult[]} downloadedImages - from aliexpress_image_handler.js
 * @param {string}        marketplace
 * @param {Function}      [onProgress] - callback(uploaded, total, result)
 * @returns {Promise<{ ebayUrls: string[], results: UploadResult[] }>}
 */
async function uploadAllImages(downloadedImages, marketplace, onProgress) {
  const token = await getEbayToken();

  if (!token) {
    throw new Error(
      'No eBay auth token found. Please reconnect your eBay account in UnicornDS settings.'
    );
  }

  if (!downloadedImages || downloadedImages.length === 0) {
    return { ebayUrls: [], results: [] };
  }

  console.log(`[UnicornDS Upload] Starting upload of ${downloadedImages.length} images`);

  const results  = [];
  const ebayUrls = [];

  for (let i = 0; i < downloadedImages.length; i++) {
    const uploadResult = await uploadSingleImage(
      downloadedImages[i],
      marketplace,
      token
    );

    results.push(uploadResult);

    if (uploadResult.success) {
      ebayUrls.push(uploadResult.ebayImageUrl);
    }

    if (typeof onProgress === 'function') {
      onProgress(i + 1, downloadedImages.length, uploadResult);
    }

    // Small delay between uploads to avoid eBay rate limiting
    if (i < downloadedImages.length - 1) {
      await new Promise((res) => setTimeout(res, 500));
    }
  }

  const successCount = results.filter((r) => r.success).length;
  console.log(`[UnicornDS Upload] Completed: ${successCount}/${downloadedImages.length} images uploaded to eBay`);

  return { ebayUrls, results };
}

// ─────────────────────────────────────────────────────────
// 8. FULL PIPELINE (download + upload in one call)
// ─────────────────────────────────────────────────────────

/**
 * Complete pipeline: AliExpress image URLs → eBay hosted URLs.
 * Combines aliexpress_image_handler.js + this uploader.
 *
 * @param {string[]}  aliexpressImageUrls  - from scraper
 * @param {string}    productId
 * @param {string}    marketplace
 * @param {Function}  [onStatus]           - status update callback for UI
 * @returns {Promise<string[]>}  eBay-hosted image URLs
 */
async function processAllImages(aliexpressImageUrls, productId, marketplace, onStatus) {

  const status = (msg) => {
    console.log('[UnicornDS Images]', msg);
    if (typeof onStatus === 'function') onStatus(msg);
  };

  // ── Step 1: Download from AliExpress ──────────────────
  status(`Downloading ${aliexpressImageUrls.length} images from AliExpress…`);

  const handler = window.UDSImageHandler;
  if (!handler) throw new Error('AliexpressImageHandler not loaded');

  const downloaded = await handler.downloadAllImages(
    aliexpressImageUrls,
    productId,
    (done, total) => status(`Downloading images: ${done}/${total}`)
  );

  if (downloaded.length === 0) {
    throw new Error('No images could be downloaded from AliExpress');
  }

  const deduped = handler.deduplicateImages(downloaded);
  status(`Downloaded ${deduped.length} unique images`);

  // ── Step 2: Upload to eBay ────────────────────────────
  status(`Uploading ${deduped.length} images to eBay…`);

  const { ebayUrls, results } = await uploadAllImages(
    deduped,
    marketplace,
    (done, total, result) => {
      status(`Uploading to eBay: ${done}/${total}${result.success ? ' ✓' : ' ✗'}`);
    }
  );

  const failedCount = results.filter((r) => !r.success).length;
  if (failedCount > 0) {
    status(`⚠️ ${failedCount} image(s) failed to upload - listing will use remaining ${ebayUrls.length} images`);
  } else {
    status(`✅ All ${ebayUrls.length} images uploaded to eBay successfully`);
  }

  return ebayUrls;
}

// ─────────────────────────────────────────────────────────
// 9. UTILITIES
// ─────────────────────────────────────────────────────────

function escapeXml(str) {
  return String(str || '')
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;')
    .replace(/'/g,  '&apos;');
}

// ─────────────────────────────────────────────────────────
// 10. CHROME EXTENSION MESSAGE BRIDGE
// ─────────────────────────────────────────────────────────

if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.type === 'process_aliexpress_images') {
      const { imageUrls, productId, marketplace } = message;

      processAllImages(
        imageUrls,
        productId,
        marketplace,
        (statusMsg) => {
          chrome.runtime.sendMessage({
            type:    'image_pipeline_status',
            message: statusMsg,
            productId,
          }).catch(() => {});
        }
      )
      .then((ebayUrls) => sendResponse({ success: true, ebayUrls }))
      .catch((err) => {
        console.error('[UnicornDS Upload] Pipeline error:', err);
        sendResponse({ success: false, error: err.message });
      });

      return true;
    }

    if (message.type === 'save_ebay_token') {
      saveEbayToken(message.token)
        .then(() => sendResponse({ success: true }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (message.type === 'check_ebay_token') {
      hasValidToken()
        .then((valid) => sendResponse({ valid }))
        .catch(() => sendResponse({ valid: false }));
      return true;
    }
  });
}

// ─────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    uploadSingleImage,
    uploadAllImages,
    processAllImages,
    getEbayToken,
    saveEbayToken,
    hasValidToken,
    parseEbayUploadResponse,
    EBAY_SITE_IDS,
  };
} else {
  window.UDSImageUploader = {
    uploadSingleImage,
    uploadAllImages,
    processAllImages,
    getEbayToken,
    saveEbayToken,
    hasValidToken,
    EBAY_SITE_IDS,
  };
}
