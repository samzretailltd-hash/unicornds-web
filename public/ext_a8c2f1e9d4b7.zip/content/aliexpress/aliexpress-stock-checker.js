/**
 * UnicornDS - AliExpress Stock Status Checker
 *
 * Equivalent of the Amazon in-stock-messages.txt lookup system,
 * but built for AliExpress stock patterns across all 6 supported languages.
 *
 * Usage:
 *   const checker = new AliExpressStockChecker();
 *   const result  = checker.check('only 3 pieces available');
 *   // → { inStock: true, quantity: 3, confidence: 'high', language: 'en' }
 */

class AliExpressStockChecker {

  constructor() {
    // ── In-stock patterns ────────────────────────────────
    // Each entry: [regex, language, extractsQuantity]
    this.IN_STOCK_PATTERNS = [

      // ── English ──────────────────────────────────────
      { re: /\bin\s*stock\b/i,                                    lang: 'en', qty: false },
      { re: /\bavailable\b/i,                                     lang: 'en', qty: false },
      { re: /\bready\s+to\s+ship\b/i,                             lang: 'en', qty: false },
      { re: /ships?\s+in\s+\d+/i,                                 lang: 'en', qty: false },
      { re: /only\s+(\d+)\s+(piece|item|left|unit)s?\s+available/i, lang: 'en', qty: true },
      { re: /only\s+(\d+)\s+left/i,                               lang: 'en', qty: true },
      { re: /(\d+)\s+(piece|item|unit)s?\s+available/i,           lang: 'en', qty: true },
      { re: /more\s+than\s+(\d+)\s+available/i,                   lang: 'en', qty: false },
      { re: /\bhurry[!.]?\s+only\s+(\d+)/i,                       lang: 'en', qty: true },
      { re: /\balmost\s+gone\b/i,                                  lang: 'en', qty: false },
      { re: /\bin\s+high\s+demand\b/i,                             lang: 'en', qty: false },
      { re: /\blast\s+(one|item|unit|\d+)\b/i,                    lang: 'en', qty: false },
      { re: /\blimited\s+(stock|quantity)\b/i,                    lang: 'en', qty: false },
      { re: /\bselling\s+fast\b/i,                                lang: 'en', qty: false },
      { re: /\bfree\s+shipping\b/i,                               lang: 'en', qty: false },

      // ── German ───────────────────────────────────────
      { re: /\bauf\s+lager\b/i,                                   lang: 'de', qty: false },
      { re: /\bverfügbar\b/i,                                     lang: 'de', qty: false },
      { re: /\bversandbereit\b/i,                                  lang: 'de', qty: false },
      { re: /versand\s+in\s+\d+/i,                                lang: 'de', qty: false },
      { re: /nur\s+noch\s+(\d+)\s+(stück|verfügbar)/i,           lang: 'de', qty: true },
      { re: /nur\s+noch\s+(\d+)\s+verfügbar/i,                   lang: 'de', qty: true },
      { re: /(\d+)\s+stück\s+verfügbar/i,                         lang: 'de', qty: true },
      { re: /mehr\s+als\s+(\d+)\s+verfügbar/i,                   lang: 'de', qty: false },
      { re: /\bbegrenzte\s+(stückzahl|menge)\b/i,                 lang: 'de', qty: false },
      { re: /\bfast\s+weg\b/i,                                    lang: 'de', qty: false },
      { re: /\bhohe\s+nachfrage\b/i,                              lang: 'de', qty: false },
      { re: /\bletztes\s+stück\b/i,                               lang: 'de', qty: false },
      { re: /\bniedrig(er)?\s+lagerbestand\b/i,                   lang: 'de', qty: false },

      // ── French ───────────────────────────────────────
      { re: /\ben\s+stock\b/i,                                    lang: 'fr', qty: false },
      { re: /\bdisponible\b/i,                                    lang: 'fr', qty: false },
      { re: /\bprêt\s+à\s+expédier\b/i,                          lang: 'fr', qty: false },
      { re: /expédié\s+en\s+\d+/i,                               lang: 'fr', qty: false },
      { re: /seulement\s+(\d+)\s+disponibles?/i,                 lang: 'fr', qty: true },
      { re: /il\s+ne\s+reste\s+que\s+(\d+)/i,                    lang: 'fr', qty: true },
      { re: /(\d+)\s+pièces?\s+disponibles?/i,                   lang: 'fr', qty: true },
      { re: /plus\s+de\s+(\d+)\s+disponibles?/i,                 lang: 'fr', qty: false },
      { re: /\bquantité\s+limitée\b/i,                           lang: 'fr', qty: false },
      { re: /\bpresque\s+épuisé\b/i,                             lang: 'fr', qty: false },
      { re: /\bforte\s+demande\b/i,                              lang: 'fr', qty: false },
      { re: /\bdernière\s+(pièce|unité)\b/i,                     lang: 'fr', qty: false },

      // ── Spanish ──────────────────────────────────────
      { re: /\ben\s+stock\b/i,                                    lang: 'es', qty: false },
      { re: /\bdisponible\b/i,                                    lang: 'es', qty: false },
      { re: /\blisto\s+para\s+enviar\b/i,                        lang: 'es', qty: false },
      { re: /se\s+envía\s+en\s+\d+/i,                           lang: 'es', qty: false },
      { re: /solo\s+queda[n]?\s+(\d+)\s+disponibles?/i,         lang: 'es', qty: true },
      { re: /solo\s+queda\s+(\d+)/i,                             lang: 'es', qty: true },
      { re: /(\d+)\s+unidades?\s+disponibles?/i,                 lang: 'es', qty: true },
      { re: /más\s+de\s+(\d+)\s+disponibles?/i,                 lang: 'es', qty: false },
      { re: /\bcantidad\s+limitada\b/i,                          lang: 'es', qty: false },
      { re: /\bcasi\s+agotado\b/i,                               lang: 'es', qty: false },
      { re: /\balta\s+demanda\b/i,                               lang: 'es', qty: false },
      { re: /\búltimo\s+(artículo|disponible)\b/i,               lang: 'es', qty: false },

      // ── Italian ──────────────────────────────────────
      { re: /\bdisponibile\b/i,                                   lang: 'it', qty: false },
      { re: /\bin\s+stock\b/i,                                    lang: 'it', qty: false },
      { re: /\bpronto\s+per\s+la\s+spedizione\b/i,               lang: 'it', qty: false },
      { re: /spedito\s+in\s+\d+/i,                               lang: 'it', qty: false },
      { re: /solo\s+(\d+)\s+disponibili/i,                       lang: 'it', qty: true },
      { re: /rimane\s+solo\s+(\d+)/i,                            lang: 'it', qty: true },
      { re: /(\d+)\s+pezzi?\s+disponibili/i,                     lang: 'it', qty: true },
      { re: /più\s+di\s+(\d+)\s+disponibili/i,                   lang: 'it', qty: false },
      { re: /\bquantità\s+limitata\b/i,                          lang: 'it', qty: false },
      { re: /\bquasi\s+esaurito\b/i,                             lang: 'it', qty: false },
      { re: /\balta\s+domanda\b/i,                               lang: 'it', qty: false },
      { re: /\bultima?\s+(unità|articolo)\b/i,                   lang: 'it', qty: false },

      // ── Dutch ────────────────────────────────────────
      { re: /\bop\s+voorraad\b/i,                                lang: 'nl', qty: false },
      { re: /\bbeschikbaar\b/i,                                  lang: 'nl', qty: false },
      { re: /\bklaar\s+voor\s+verzending\b/i,                    lang: 'nl', qty: false },
      { re: /verzending\s+in\s+\d+/i,                           lang: 'nl', qty: false },
      { re: /nog\s+maar\s+(\d+)\s+beschikbaar/i,                lang: 'nl', qty: true },
      { re: /(\d+)\s+stuks?\s+beschikbaar/i,                    lang: 'nl', qty: true },
      { re: /meer\s+dan\s+(\d+)\s+beschikbaar/i,                lang: 'nl', qty: false },
      { re: /\bbeperkte\s+voorraad\b/i,                         lang: 'nl', qty: false },
      { re: /\bbijna\s+uitverkocht\b/i,                         lang: 'nl', qty: false },
      { re: /\bgrote\s+vraag\b/i,                               lang: 'nl', qty: false },
      { re: /\blaatste\s+(artikel|exemplaar)\b/i,               lang: 'nl', qty: false },
    ];

    // ── Out-of-stock patterns ────────────────────────────
    this.OUT_OF_STOCK_PATTERNS = [
      // English
      { re: /\bsold\s+out\b/i,                         lang: 'en' },
      { re: /\bout\s+of\s+stock\b/i,                   lang: 'en' },
      { re: /\bcurrently\s+unavailable\b/i,            lang: 'en' },
      { re: /\bitem\s+unavailable\b/i,                 lang: 'en' },
      { re: /\bnot\s+available\b/i,                    lang: 'en' },
      { re: /\btemporarily\s+out\s+of\s+stock\b/i,     lang: 'en' },
      { re: /\bno\s+longer\s+available\b/i,            lang: 'en' },
      { re: /\b0\s+(piece|item|unit)s?\s+available\b/i, lang: 'en' },

      // German
      { re: /\bausverkauft\b/i,                        lang: 'de' },
      { re: /\bnicht\s+vorrätig\b/i,                   lang: 'de' },
      { re: /\bderzeit\s+nicht\s+verfügbar\b/i,        lang: 'de' },
      { re: /\bartikel\s+nicht\s+verfügbar\b/i,        lang: 'de' },
      { re: /\bnicht\s+lieferbar\b/i,                  lang: 'de' },
      { re: /\b0\s+stück\s+verfügbar\b/i,              lang: 'de' },

      // French
      { re: /\brupture\s+de\s+stock\b/i,              lang: 'fr' },
      { re: /\barticle\s+indisponible\b/i,             lang: 'fr' },
      { re: /\bnon\s+disponible\b/i,                   lang: 'fr' },
      { re: /\bépuisé\b/i,                             lang: 'fr' },
      { re: /\b0\s+pièce\s+disponible\b/i,             lang: 'fr' },

      // Spanish
      { re: /\bagotado\b/i,                            lang: 'es' },
      { re: /\bsin\s+existencias\b/i,                  lang: 'es' },
      { re: /\bno\s+disponible\b/i,                    lang: 'es' },
      { re: /\b0\s+unidades\s+disponibles\b/i,         lang: 'es' },

      // Italian
      { re: /\besaurito\b/i,                           lang: 'it' },
      { re: /\bnon\s+disponibile\b/i,                  lang: 'it' },
      { re: /\b0\s+pezzi\s+disponibili\b/i,            lang: 'it' },

      // Dutch
      { re: /\buitverkocht\b/i,                        lang: 'nl' },
      { re: /\bniet\s+op\s+voorraad\b/i,               lang: 'nl' },
      { re: /\bartikel\s+niet\s+beschikbaar\b/i,       lang: 'nl' },
      { re: /\b0\s+stuks\s+beschikbaar\b/i,            lang: 'nl' },
    ];
  }

  /**
   * Main check function.
   * @param {string} text - raw stock text from AliExpress page
   * @returns {{ inStock: boolean, quantity: number|null, confidence: 'high'|'medium'|'low', language: string, rawText: string }}
   */
  check(text) {
    if (!text || typeof text !== 'string') {
      return { inStock: false, quantity: null, confidence: 'low', language: 'unknown', rawText: text };
    }

    const normalised = text.trim().toLowerCase();

    // Check out-of-stock first - takes priority
    for (const pattern of this.OUT_OF_STOCK_PATTERNS) {
      if (pattern.re.test(normalised)) {
        return {
          inStock:    false,
          quantity:   0,
          confidence: 'high',
          language:   pattern.lang,
          rawText:    text,
        };
      }
    }

    // Check in-stock patterns
    for (const pattern of this.IN_STOCK_PATTERNS) {
      const match = normalised.match(pattern.re);
      if (match) {
        const quantity = pattern.qty && match[1] ? parseInt(match[1], 10) : null;
        return {
          inStock:    true,
          quantity,
          confidence: 'high',
          language:   pattern.lang,
          rawText:    text,
        };
      }
    }

    // Nothing matched - unknown
    return {
      inStock:    null,
      quantity:   null,
      confidence: 'low',
      language:   'unknown',
      rawText:    text,
    };
  }

  /**
   * Checks a numeric quantity directly (from runParams.totalAvailQuantity).
   * @param {number} quantity
   * @returns {{ inStock: boolean, quantity: number, status: string }}
   */
  checkQuantity(quantity) {
    if (quantity === null || quantity === undefined) {
      return { inStock: null, quantity: null, status: 'unknown' };
    }
    if (quantity === 0) {
      return { inStock: false, quantity: 0, status: 'Out of stock' };
    }
    if (quantity <= 5) {
      return { inStock: true, quantity, status: `Only ${quantity} left - order soon` };
    }
    if (quantity <= 20) {
      return { inStock: true, quantity, status: `Only ${quantity} left in stock` };
    }
    return { inStock: true, quantity, status: `In stock (${quantity} available)` };
  }
}

// Export for use in both browser extension context and Node.js tests
if (typeof module !== 'undefined' && module.exports) {
  module.exports = AliExpressStockChecker;
} else {
  window.AliExpressStockChecker = AliExpressStockChecker;
}
