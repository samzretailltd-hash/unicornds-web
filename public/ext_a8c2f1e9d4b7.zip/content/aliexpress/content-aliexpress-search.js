/**
 * UnicornDS — AliExpress Search Page Multi-Select
 * Injects checkboxes on product cards + floating bar to send selected items to Bulk Lister.
 * Runs on: AliExpress search, category, wholesale, and store pages.
 */

console.log('[UnicornDS] AliExpress search script loaded');

const UDS_SEARCH = {
  selected: new Map(), // url → { title, price, image }
  injected: new WeakSet(),
  bar: null,
};

// ═══════════════════════════════════════════════════════
// STYLES
// ═══════════════════════════════════════════════════════
function injectStyles() {
  if (document.getElementById('uds-ali-search-styles')) return;
  const style = document.createElement('style');
  style.id = 'uds-ali-search-styles';
  style.textContent = `
    .uds-card-check {
      position: absolute; top: 8px; left: 8px; z-index: 999;
      width: 22px; height: 22px; cursor: pointer;
      accent-color: #7C3AED; border-radius: 4px;
      opacity: 0.7; transition: opacity 0.15s, transform 0.15s;
    }
    .uds-card-check:hover { opacity: 1; transform: scale(1.2); }
    .uds-card-check:checked { opacity: 1; }
    .uds-card-selected { outline: 2px solid #7C3AED !important; outline-offset: -2px; }

    .uds-float-bar {
      position: fixed; bottom: 0; left: 0; right: 0; z-index: 999999;
      background: rgba(30, 27, 75, 0.97); border-top: 2px solid #7C3AED;
      padding: 12px 24px; display: flex; align-items: center; gap: 16px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      color: #fff; box-shadow: 0 -4px 20px rgba(0,0,0,0.5);
      animation: udsSlideUp 0.3s ease;
    }
    @keyframes udsSlideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
    .uds-float-bar .uds-logo { font-size: 18px; font-weight: 700; color: #F59E0B; }
    .uds-float-bar .uds-count {
      background: #7C3AED; padding: 4px 14px; border-radius: 16px;
      font-size: 14px; font-weight: 700; min-width: 30px; text-align: center;
    }
    .uds-float-bar .uds-btn {
      padding: 8px 20px; border-radius: 8px; border: none; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s;
    }
    .uds-float-bar .uds-btn-bulk {
      background: #7C3AED; color: #fff;
    }
    .uds-float-bar .uds-btn-bulk:hover { background: #6D28D9; }
    .uds-float-bar .uds-btn-clear {
      background: transparent; color: #aaa; border: 1px solid #555;
    }
    .uds-float-bar .uds-btn-clear:hover { color: #fff; border-color: #888; }
    .uds-float-bar .uds-btn-all {
      background: transparent; color: #F59E0B; border: 1px solid #F59E0B;
    }
    .uds-float-bar .uds-btn-all:hover { background: rgba(245,158,11,0.1); }
  `;
  document.head.appendChild(style);
}

// ═══════════════════════════════════════════════════════
// FIND PRODUCT CARDS
// ═══════════════════════════════════════════════════════
function isBundle(card) {
  const text = (card.textContent || '').toLowerCase();
  return text.includes('bundle for less') || text.includes('bundle deal') ||
         text.includes('buy together') || text.includes('combo deal');
}

function findProductCards() {
  // AliExpress search results use various card selectors depending on page version
  const selectors = [
    '.search-item-card-wrapper-gallery',    // Gallery view
    '.list--gallery--C2f2ivm',              // 2024+ gallery
    '[class*="SearchResult"] [class*="card"]',
    '[class*="product-card"]',
    '.JIIxO',                                // Legacy cards
    'a[href*="/item/"]',                     // Fallback: any link to product pages
  ];

  for (const sel of selectors) {
    const cards = document.querySelectorAll(sel);
    if (cards.length > 2) return Array.from(cards);
  }

  // Ultimate fallback: find containers that have product links inside
  const allLinks = document.querySelectorAll('a[href*="/item/"]');
  const containers = new Set();
  allLinks.forEach(a => {
    // Walk up to find a card-like container
    const card = a.closest('[class*="card"], [class*="Card"], [class*="product"], [class*="gallery"], [class*="item"]')
      || a.parentElement?.parentElement;
    if (card && card !== document.body) containers.add(card);
  });
  return Array.from(containers);
}

// ═══════════════════════════════════════════════════════
// EXTRACT DATA FROM CARD
// ═══════════════════════════════════════════════════════
function extractCardData(card) {
  // URL
  const link = card.querySelector('a[href*="/item/"]') || (card.tagName === 'A' && card.href?.includes('/item/') ? card : null);
  if (!link) return null;
  let url = link.href || link.getAttribute('href') || '';
  if (url.startsWith('//')) url = 'https:' + url;
  if (!url.includes('/item/')) return null;

  // Title
  const titleEl = card.querySelector('h1, h3, [class*="title"], [class*="Title"], [class*="name"]');
  const title = titleEl?.textContent?.trim() || '';

  // Price
  const priceEl = card.querySelector('[class*="price"], [class*="Price"]');
  const priceText = priceEl?.textContent?.replace(/[^0-9.]/g, '') || '0';
  const price = parseFloat(priceText) || 0;

  // Image
  const img = card.querySelector('img[src*="alicdn"], img[src*="aliexpress"], img');
  const image = img?.src || img?.getAttribute('src') || '';

  return { url: url.split('?')[0], title, price, image };
}

// ═══════════════════════════════════════════════════════
// INJECT CHECKBOXES
// ═══════════════════════════════════════════════════════
function injectCheckboxes() {
  const cards = findProductCards();
  let injected = 0;

  for (const card of cards) {
    if (UDS_SEARCH.injected.has(card)) continue;
    UDS_SEARCH.injected.add(card);

    const data = extractCardData(card);
    if (!data || !data.url) continue;

    // Skip bundle/combo deals — these can't be listed individually
    if (isBundle(card)) continue;

    // Make card position relative for absolute checkbox positioning
    const style = getComputedStyle(card);
    if (style.position === 'static') card.style.position = 'relative';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'uds-card-check';
    cb.title = 'Select for Bulk Lister';
    cb.dataset.url = data.url;

    // Restore checked state if previously selected
    if (UDS_SEARCH.selected.has(data.url)) cb.checked = true;

    cb.addEventListener('change', (e) => {
      e.stopPropagation();
      if (cb.checked) {
        UDS_SEARCH.selected.set(data.url, data);
        card.classList.add('uds-card-selected');
      } else {
        UDS_SEARCH.selected.delete(data.url);
        card.classList.remove('uds-card-selected');
      }
      updateFloatingBar();
    });

    cb.addEventListener('click', (e) => e.stopPropagation());

    card.appendChild(cb);
    if (UDS_SEARCH.selected.has(data.url)) card.classList.add('uds-card-selected');
    injected++;
  }

  if (injected > 0) console.log('[UnicornDS] Injected checkboxes into', injected, 'product cards');
}

// ═══════════════════════════════════════════════════════
// FLOATING BAR
// ═══════════════════════════════════════════════════════
function createFloatingBar() {
  if (UDS_SEARCH.bar) return;

  const bar = document.createElement('div');
  bar.className = 'uds-float-bar';
  bar.id = 'uds-ali-float-bar';
  bar.style.display = 'none';
  bar.innerHTML = `
    <span class="uds-logo">🦄 UnicornDS</span>
    <span class="uds-count" id="uds-select-count">0</span>
    <span style="font-size:13px;opacity:0.8;">products selected</span>
    <button class="uds-btn uds-btn-all" id="uds-select-all">Select All on Page</button>
    <div style="flex:1;"></div>
    <button class="uds-btn uds-btn-clear" id="uds-clear-sel">Clear</button>
    <button class="uds-btn uds-btn-bulk" id="uds-send-bulk">🚀 Add to Bulk Lister</button>
  `;
  document.body.appendChild(bar);
  UDS_SEARCH.bar = bar;

  document.getElementById('uds-send-bulk').addEventListener('click', sendToBulkLister);
  document.getElementById('uds-clear-sel').addEventListener('click', clearSelection);
  document.getElementById('uds-select-all').addEventListener('click', selectAllOnPage);
}

function updateFloatingBar() {
  if (!UDS_SEARCH.bar) createFloatingBar();
  const count = UDS_SEARCH.selected.size;
  document.getElementById('uds-select-count').textContent = count;
  UDS_SEARCH.bar.style.display = count > 0 ? 'flex' : 'none';
}

function selectAllOnPage() {
  const checkboxes = document.querySelectorAll('.uds-card-check');
  checkboxes.forEach(cb => {
    if (!cb.checked) {
      cb.checked = true;
      cb.dispatchEvent(new Event('change', { bubbles: false }));
    }
  });
}

function clearSelection() {
  UDS_SEARCH.selected.clear();
  document.querySelectorAll('.uds-card-check').forEach(cb => {
    cb.checked = false;
    cb.closest('[class]')?.classList.remove('uds-card-selected');
  });
  updateFloatingBar();
}

// ═══════════════════════════════════════════════════════
// SEND TO BULK LISTER
// ═══════════════════════════════════════════════════════
async function sendToBulkLister() {
  const urls = Array.from(UDS_SEARCH.selected.keys());
  if (!urls.length) return;

  const btn = document.getElementById('uds-send-bulk');
  btn.textContent = '⏳ Sending...';
  btn.disabled = true;

  try {
    // Append URLs to existing bulk lister links
    const stored = await new Promise(r => chrome.storage.local.get('bulk_lister_urls', r));
    const existing = stored.bulk_lister_urls || [];
    const combined = [...new Set([...existing, ...urls])];

    await new Promise(r => chrome.storage.local.set({ bulk_lister_urls: combined }, r));

    console.log('[UnicornDS] Sent', urls.length, 'products to Bulk Lister (' + combined.length + ' total)');

    // Show success toast
    showToast(`✅ ${urls.length} products added to Bulk Lister!`);

    // Open Bulk Lister
    chrome.runtime.sendMessage({
      type: 'openBulkUploadPage',
      amazonLinks: urls,
    });

    // Clear selection
    clearSelection();

  } catch (e) {
    console.error('[UnicornDS] Bulk send error:', e);
    showToast('❌ Failed to send — try again');
  } finally {
    btn.textContent = '🚀 Add to Bulk Lister';
    btn.disabled = false;
  }
}

function showToast(text) {
  const toast = document.createElement('div');
  toast.style.cssText = `
    position: fixed; bottom: 70px; right: 20px; z-index: 9999999;
    background: rgba(30,27,75,0.95); color: #fff; padding: 12px 20px;
    border-radius: 10px; border: 1px solid #7C3AED;
    font-family: -apple-system, sans-serif; font-size: 14px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    animation: udsSlideUp 0.3s ease;
  `;
  toast.textContent = text;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// ═══════════════════════════════════════════════════════
// OBSERVE NEW CARDS (infinite scroll / pagination)
// ═══════════════════════════════════════════════════════
function observeNewCards() {
  const observer = new MutationObserver(() => {
    injectCheckboxes();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// ═══════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════
function init() {
  // Don't run on product pages (they have their own content script)
  // or checkout/cart/order/account pages
  const skip = ['/item/', '/checkout/', '/cart/', '/order/', '/account/', '/wishlist/', '/shoppingcart/'];
  if (skip.some(s => location.href.includes(s))) {
    console.log('[UnicornDS] AliExpress search: skipping non-browsing page');
    return;
  }

  // Auth check — don't inject checkboxes if not logged in
  chrome.storage.local.get('unicornds_session', (s) => {
    if (!s?.unicornds_session?.idToken) {
      console.log('[UnicornDS] Not logged in — AliExpress multi-select not injected');
      return;
    }
    injectStyles();
    createFloatingBar();

    // Wait for products to render (AliExpress is SPA, slow load)
    let attempts = 0;
    const waitForCards = setInterval(() => {
      const cards = findProductCards();
      if (cards.length > 0 || attempts > 30) {
        clearInterval(waitForCards);
        injectCheckboxes();
        observeNewCards();
        console.log('[UnicornDS] AliExpress search: found', cards.length, 'product cards');
      }
      attempts++;
    }, 1000);
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
