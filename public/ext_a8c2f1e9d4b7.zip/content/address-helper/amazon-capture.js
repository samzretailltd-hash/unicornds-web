// ============================================================
// Unicorn DS - Amazon Seller Central Address Capture
// Reads "Ship to" section from order detail page
// ============================================================

(() => {
  console.log('Unicorn DS: Amazon capture loaded');

  const COUNTRIES = [
    'United Kingdom','United States','Germany','France','Spain','Italy','Netherlands',
    'Belgium','Austria','Switzerland','Sweden','Norway','Denmark','Finland','Ireland',
    'Portugal','Poland','Czech Republic','Australia','New Zealand','Canada','Japan',
    'India','Brazil','Mexico','South Africa','United Arab Emirates','Saudi Arabia',
    'Turkey','China','Singapore','Malaysia','Thailand','Philippines','Indonesia',
    'Pakistan','Bangladesh','Nigeria','South Korea','Vietnam','Hong Kong','Taiwan'
  ];

  const PHONE_CODES = {
    'United Kingdom':'44','United States':'1','Germany':'49','France':'33',
    'Spain':'34','Italy':'39','Netherlands':'31','Belgium':'32','Austria':'43',
    'Switzerland':'41','Ireland':'353','Australia':'61','Canada':'1','India':'91',
    'Pakistan':'92','Bangladesh':'880','New Zealand':'64','Japan':'81',
    'South Korea':'82','Brazil':'55','Mexico':'52','South Africa':'27',
    'United Arab Emirates':'971','Saudi Arabia':'966','Turkey':'90','China':'86',
    'Singapore':'65','Malaysia':'60','Philippines':'63','Indonesia':'62'
  };

  function captureAddress() {
    const info = { name:'', firstName:'', lastName:'', phone:'', phoneCode:'', phoneNumber:'', email:'', street1:'', street2:'', zip:'', country:'', state:'', city:'' };

    // Find phone from anywhere on page: "Phone: +447975587378"
    const bodyText = document.body.innerText;
    const phoneMatch = bodyText.match(/Phone:\s*(\+?[\d\s\-\(\)]+)/i);
    let rawPhone = '';
    if (phoneMatch) {
      rawPhone = phoneMatch[1].replace(/[\s\-\(\)]/g, '').trim();
      if (!rawPhone.startsWith('+')) rawPhone = '+' + rawPhone;
    }

    // Find "Ship to" section
    let shipToBlock = null;
    const allElements = document.querySelectorAll('h2, h3, h4, strong, b, span, div, p');
    for (const el of allElements) {
      const t = el.textContent.trim();
      if (/^Ship\s*to$/i.test(t)) {
        // Get the parent container
        shipToBlock = el.closest('div[class]') || el.closest('td') || el.parentElement;
        break;
      }
    }

    if (!shipToBlock) return null;

    // Get text from the ship-to block
    let text = shipToBlock.innerText;
    let lines = text.split('\n').map(l => l.trim()).filter(l => l);

    // Clean out labels and junk
    lines = lines.filter(l => {
      if (/^Ship\s*to$/i.test(l)) return false;
      if (/^Address\s*Type/i.test(l)) return false;
      if (/^Residential$/i.test(l)) return false;
      if (/^Commercial$/i.test(l)) return false;
      if (/^Contact\s*Buyer/i.test(l)) return false;
      if (/^Phone:/i.test(l)) return false;
      if (/^Upload\s*invoice/i.test(l)) return false;
      if (/^Print\s*packing/i.test(l)) return false;
      if (/^Refund\s*Order/i.test(l)) return false;
      if (/^Request\s*a\s*Review/i.test(l)) return false;
      return true;
    });

    // Remove phone number line if it appears in the address block
    if (rawPhone) {
      const phoneDigits = rawPhone.replace(/\D/g, '');
      lines = lines.filter(l => {
        const lineDigits = l.replace(/\D/g, '');
        return lineDigits !== phoneDigits;
      });
    }

    // Remove single short names that might be contact buyer name
    // (Amazon shows "Jemima" on the right side as contact buyer link)
    // Keep only lines that are clearly address parts
    const used = new Set();

    // Country (last line matching known country)
    for (let i = lines.length - 1; i >= 0; i--) {
      if (used.has(i)) continue;
      const found = COUNTRIES.find(c => lines[i].toLowerCase() === c.toLowerCase());
      if (found) { info.country = found; used.add(i); break; }
    }

    // Postcode
    for (let i = lines.length - 1; i >= 0; i--) {
      if (used.has(i)) continue;
      const l = lines[i].trim();
      if (/^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/i.test(l) || /^\d{5}(-\d{4})?$/.test(l) ||
          (l.length <= 10 && /\d/.test(l) && /^[A-Z0-9\s\-]{3,10}$/i.test(l))) {
        info.zip = l; used.add(i); break;
      }
    }

    // Name = first unused line
    for (let i = 0; i < lines.length; i++) {
      if (used.has(i)) continue;
      if (/[A-Za-z]/.test(lines[i]) && lines[i].length > 2) {
        info.name = lines[i]; used.add(i); break;
      }
    }

    // Remaining = street (last remaining = city, rest = street parts)
    const remaining = [];
    for (let i = 0; i < lines.length; i++) {
      if (!used.has(i)) remaining.push(lines[i]);
    }
    // Join all remaining as street address
    info.street1 = remaining.join(', ');

    // Phone parsing
    if (rawPhone) {
      info.phone = rawPhone;
      splitPhoneCode(info);
    }

    // Split name
    if (info.name) {
      const p = info.name.trim().split(/\s+/);
      info.firstName = p[0] || '';
      info.lastName = p.slice(1).join(' ') || info.firstName;
    }

    // If no phone code found but have country, use country code
    if (!info.phoneCode && info.country && PHONE_CODES[info.country]) {
      info.phoneCode = '+' + PHONE_CODES[info.country];
    }

    console.log('Unicorn DS Amazon parsed:', info);
    return info;
  }

  function splitPhoneCode(info) {
    if (!info.phone) return;
    const cleaned = info.phone.replace(/[\s\-\(\)]/g, '');
    if (!cleaned.startsWith('+')) return;

    const digits = cleaned.substring(1); // remove +

    // Try known codes (longest first)
    const codes = Object.values(PHONE_CODES).sort((a, b) => b.length - a.length);
    for (const code of codes) {
      if (digits.startsWith(code)) {
        info.phoneCode = '+' + code;
        info.phoneNumber = digits.substring(code.length);
        return;
      }
    }
    // Fallback: first 2 digits as code
    info.phoneCode = '+' + digits.substring(0, 2);
    info.phoneNumber = digits.substring(2);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'ping') { sendResponse({ loaded: true }); return; }
    if (msg.action === 'captureAddress') {
      try {
        sendResponse({ orderInfo: captureAddress(), source: 'amazon' });
      } catch (e) {
        console.error('Unicorn DS Amazon error:', e);
        sendResponse({ orderInfo: null, error: e.message });
      }
    }
    return true;
  });
})();
