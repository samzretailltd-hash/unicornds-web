// ============================================================
// Unicorn DS - TikTok Seller Center Address Capture
// HTML structure: div.text-gray-3 "Shipping address" → sibling container
// ============================================================

(() => {
  console.log('Unicorn DS: TikTok capture loaded');

  const COUNTRIES = [
    'United Kingdom','United States','Germany','France','Spain','Italy','Netherlands',
    'Belgium','Austria','Switzerland','Sweden','Norway','Denmark','Finland','Ireland',
    'Portugal','Poland','Czech Republic','Australia','New Zealand','Canada','Japan',
    'India','Brazil','Mexico','South Africa','United Arab Emirates','Saudi Arabia',
    'Turkey','China','Singapore','Malaysia','Thailand','Philippines','Indonesia',
    'Pakistan','Bangladesh','Nigeria','Kenya','South Korea','Vietnam','Hong Kong','Taiwan'
  ];

  function captureAddress() {
    // Find "Shipping address" label
    let dataContainer = null;
    const labels = document.querySelectorAll('.text-gray-3, [class*="text-gray"]');
    for (const label of labels) {
      if (label.textContent.trim() === 'Shipping address') {
        dataContainer = label.nextElementSibling;
        break;
      }
    }
    if (!dataContainer) return null;

    // Get direct children — each is a line of data
    // Name, phone, email are individual flex divs
    // Address block is a div with class containing "sc-esbhDv" with inner divs
    const children = dataContainer.children;
    const lines = [];

    for (const child of children) {
      if (child.querySelector('[class*="sc-esbhDv"], [class*="hJztVL"]')) {
        // Address block — get each inner div separately
        const innerDivs = child.querySelectorAll(':scope > div[class*="break-words"]');
        for (const d of innerDivs) {
          const t = d.textContent.trim();
          if (t) lines.push(t);
        }
      } else {
        // Single line (name/phone/email) — get deepest text
        const inner = child.querySelector('div[class*="break-words"]');
        const t = (inner || child).textContent.trim();
        if (t) lines.push(t);
      }
    }

    if (!lines.length) return null;
    console.log('Unicorn DS lines:', lines);

    const info = { name:'', firstName:'', lastName:'', phone:'', phoneCode:'', phoneNumber:'', email:'', street1:'', street2:'', zip:'', country:'', state:'', city:'' };
    const used = new Set();

    // Phone: (+44)7729382996
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(/^\(\+(\d{1,4})\)(.+)$/);
      if (m) {
        info.phoneCode = '+' + m[1];
        info.phoneNumber = m[2].replace(/[\s\-]/g, '');
        info.phone = info.phoneCode + info.phoneNumber;
        used.add(i);
        break;
      }
    }

    // Email
    for (let i = 0; i < lines.length; i++) {
      if (used.has(i)) continue;
      if (lines[i].includes('@') && lines[i].includes('.') && !lines[i].includes(' ')) {
        info.email = lines[i];
        used.add(i);
        break;
      }
    }

    // Postcode (short line with digits, from end)
    for (let i = lines.length - 1; i >= 0; i--) {
      if (used.has(i)) continue;
      const l = lines[i].trim();
      if (/^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/i.test(l) || /^\d{5}(-\d{4})?$/.test(l) ||
          (l.length <= 10 && /\d/.test(l) && /^[A-Z0-9\s\-]{3,10}$/i.test(l))) {
        info.zip = l;
        used.add(i);
        break;
      }
    }

    // Country line: "East Sussex,England,United Kingdom"
    for (let i = lines.length - 1; i >= 0; i--) {
      if (used.has(i)) continue;
      const found = COUNTRIES.find(c => lines[i].toLowerCase().includes(c.toLowerCase()));
      if (found) {
        const parts = lines[i].split(',').map(p => p.trim());
        if (parts.length >= 3) {
          const UK_REGIONS = ['England','Scotland','Wales','Northern Ireland'];
          if (UK_REGIONS.includes(parts[1])) {
            info.state = parts[1];
            info.city = parts[0];
          } else {
            info.state = parts[0];
          }
          info.country = parts[parts.length - 1];
        } else if (parts.length === 2) {
          info.state = parts[0];
          info.country = parts[1];
        } else {
          info.country = found;
        }
        used.add(i);
        break;
      }
    }

    // Name = first unused line with uppercase letters
    for (let i = 0; i < lines.length; i++) {
      if (used.has(i)) continue;
      if (/[A-Za-z]/.test(lines[i]) && lines[i].length > 1 && !/^[a-z0-9_]+$/.test(lines[i])) {
        info.name = lines[i];
        used.add(i);
        break;
      }
    }

    // Street = all remaining unused lines joined
    const streetParts = [];
    for (let i = 0; i < lines.length; i++) {
      if (!used.has(i)) streetParts.push(lines[i]);
    }
    info.street1 = streetParts.join(', ');

    // Split name
    if (info.name) {
      const p = info.name.trim().split(/\s+/);
      info.firstName = p[0] || '';
      info.lastName = p.slice(1).join(' ') || info.firstName;
    }

    console.log('Unicorn DS parsed:', info);
    return info;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'ping') { sendResponse({ loaded: true }); return; }
    if (msg.action === 'captureAddress') {
      try {
        sendResponse({ orderInfo: captureAddress(), source: 'tiktok' });
      } catch (e) {
        console.error('Unicorn DS TikTok error:', e);
        sendResponse({ orderInfo: null, error: e.message });
      }
    }
    return true;
  });
})();
