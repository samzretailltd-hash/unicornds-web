// ============================================================
// Unicorn DS - AliExpress Address Form Filler
// Flow: 
//   1. Fill name (first + last)
//   2. Fill phone number (no code, no spaces)
//   3. Search postcode → AliExpress auto-fills county/state
//   4. Wait for auto-fill
//   5. Paste street address exactly as-is from eBay
// Does NOT touch: country, phone code (already set by country)
// ============================================================

(() => {
  console.log('Unicorn DS: AliExpress filler loaded');

  const nativeSet = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype, 'value'
  ).set;

  function setVal(input, value) {
    if (!input || value === undefined || value === null) return false;
    input.focus();
    const tracker = input._valueTracker;
    if (tracker) tracker.setValue('');
    nativeSet.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }

  function findInput(placeholder) {
    for (const input of document.querySelectorAll('input')) {
      if (input.placeholder && input.placeholder.toLowerCase().includes(placeholder.toLowerCase())) {
        return input;
      }
    }
    return null;
  }

  function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

  function findSearchField() {
    for (const input of document.querySelectorAll('input')) {
      const p = (input.placeholder || '').toLowerCase();
      if (p.includes('search by postcode') || p.includes('search by street') || p.includes('search by')) return input;
      if (input.getAttribute('role') === 'combobox' && input.closest('.search-input-wrap, .next-select-auto-complete')) return input;
    }
    return null;
  }

  function findStreetField() {
    for (const input of document.querySelectorAll('input')) {
      if (input.getAttribute('role') === 'combobox') continue;
      if (input.getAttribute('aria-autocomplete')) continue;
      if (input.closest('.search-input-wrap')) continue;
      if (input.closest('.next-select-auto-complete')) continue;
      const p = (input.placeholder || '').toLowerCase();
      if (p.includes('search')) continue;
      if (p.includes('house number') || p.includes('building, street') || p.includes('building,')) return input;
    }
    return null;
  }

  function clickDropdownItem() {
    const items = document.querySelectorAll('.next-menu-item, [role="option"], [role="listbox"] li, .next-select-menu-item, .address-suggest-item, .suggest-item');
    for (const item of items) {
      try {
        const s = window.getComputedStyle(item);
        if (s.display !== 'none' && s.visibility !== 'hidden' && item.offsetHeight > 0) {
          item.click();
          return true;
        }
      } catch (e) {}
    }
    return false;
  }

  async function trySearch(searchField, query) {
    console.log('Unicorn DS: searching postcode:', query);
    searchField.focus();
    const t = searchField._valueTracker;
    if (t) t.setValue('');
    nativeSet.call(searchField, '');
    searchField.dispatchEvent(new Event('input', { bubbles: true }));
    await wait(200);
    if (t) t.setValue('');
    nativeSet.call(searchField, query);
    searchField.dispatchEvent(new Event('input', { bubbles: true }));
    searchField.dispatchEvent(new Event('change', { bubbles: true }));
    await wait(2000);
    const clicked = clickDropdownItem();
    if (!clicked) {
      document.body.click();
      await wait(200);
    }
    return clicked;
  }

  function showNotification(msg, type = 'success') {
    const existing = document.getElementById('uds-notification');
    if (existing) existing.remove();
    const div = document.createElement('div');
    div.id = 'uds-notification';
    div.className = 'dropship-notif dropship-notif-' + type;
    div.innerHTML = '<div class="dropship-notif-icon">' + (type === 'success' ? '\u2713' : '\u2715') + '</div>' +
                    '<div class="dropship-notif-text">' + msg + '</div>';
    document.body.appendChild(div);
    setTimeout(() => { div.classList.add('dropship-notif-hide'); setTimeout(() => div.remove(), 500); }, 3000);
  }

  async function fillForm(orderInfo) {
    try {
      console.log('Unicorn DS: filling form with:', orderInfo);
      let filled = 0;

      // === STEP 1: Fill name (first + last) ===
      const fn = findInput('First name');
      if (fn && orderInfo.firstName) { setVal(fn, orderInfo.firstName); filled++; await wait(150); }

      const ln = findInput('Last name');
      if (ln && orderInfo.lastName) { setVal(ln, orderInfo.lastName); filled++; await wait(150); }

      // === STEP 2: Fill phone number ONLY (no code — already set by country) ===
      // Remove spaces, dashes, brackets from phone number
      if (orderInfo.phoneNumber || orderInfo.phone) {
        let phoneNum = (orderInfo.phoneNumber || orderInfo.phone || '').replace(/[\s\-\(\)\+]/g, '');
        // If phone starts with country code, try to strip it
        // e.g. 447948101362 → 7948101362 (strip 44)
        // But only if we know the code
        if (orderInfo.phoneCode) {
          const code = orderInfo.phoneCode.replace(/[^\d]/g, '');
          if (phoneNum.startsWith(code)) {
            phoneNum = phoneNum.substring(code.length);
          }
        }
        const ph = findInput('Mobile number') || findInput('Phone number') || document.querySelector('.main-part input');
        if (ph && phoneNum) { setVal(ph, phoneNum); filled++; await wait(150); }
      }

      // === STEP 3: Search postcode → AliExpress auto-fills county/state ===
      const searchField = findSearchField();
      let searchWorked = false;

      if (searchField && orderInfo.zip) {
        const zip = orderInfo.zip.trim();

        // Attempt 1: full postcode as-is
        searchWorked = await trySearch(searchField, zip);

        // Attempt 2: without spaces
        if (!searchWorked && zip.includes(' ')) {
          searchWorked = await trySearch(searchField, zip.replace(/\s+/g, ''));
        }

        if (searchWorked) {
          filled++;
          // Wait for AliExpress to auto-fill state, county, postcode
          await wait(2500);
          console.log('Unicorn DS: postcode search worked, AliExpress auto-filled fields');
        } else {
          // Clear search field
          const t = searchField._valueTracker;
          if (t) t.setValue('');
          nativeSet.call(searchField, '');
          searchField.dispatchEvent(new Event('input', { bubbles: true }));
          document.body.click();
          await wait(300);

          // Fallback: fill postcode directly
          const zipInput = findInput('Postcode') || findInput('ZIP') || findInput('Postal');
          if (zipInput && orderInfo.zip) {
            setVal(zipInput, orderInfo.zip);
            filled++;
            await wait(200);
          }
        }
      }

      // === STEP 4: Paste street address exactly as-is from eBay ===
      const streetInput = findStreetField();
      if (streetInput && orderInfo.street1) {
        // First attempt
        setVal(streetInput, orderInfo.street1);
        await wait(500);

        // Second attempt if React overwrote
        if (streetInput.value !== orderInfo.street1) {
          setVal(streetInput, orderInfo.street1);
          await wait(300);
        }

        // Third attempt with execCommand
        if (streetInput.value !== orderInfo.street1) {
          streetInput.focus();
          streetInput.select();
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, orderInfo.street1);
          await wait(200);
        }

        filled++;
      }

      // Close any dropdowns
      document.body.click();

      if (filled > 0) {
        showNotification('Unicorn DS: Filled ' + filled + ' fields');
      } else {
        showNotification('Unicorn DS: No fields found. Open the address form first.', 'error');
      }

      return { success: true, fieldsFilled: filled };
    } catch (err) {
      console.error('Unicorn DS fill error:', err);
      showNotification('Error: ' + err.message, 'error');
      return { success: false, error: err.message };
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'ping') { sendResponse({ loaded: true }); return; }
    if (msg.action === 'fillForm' && msg.orderInfo) {
      fillForm(msg.orderInfo).then(res => sendResponse(res));
      return true;
    }
  });
})();
