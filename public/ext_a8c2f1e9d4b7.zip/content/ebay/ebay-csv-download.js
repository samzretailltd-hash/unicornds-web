/**
 * UnicornDS - eBay Active Listings CSV Download
 * Runs on: ebay.[domain]/sh/reports/downloads
 * Downloads active listings report as CSV from eBay Seller Hub
 */
'use strict';
console.log('[UnicornDS] Listings CSV download script loaded');

const DOWNLOAD_SELECTORS = {
  downloadButton: '#listings-content-target .app-mod-banner button',
  generateButton: '#reports-bam .lightbox-dialog__footer .btn.btn--primary',
  fieldCards: '.se-field-card__content-description',
  welcomeButton: '.welcome-dialog .btn.btn--primary',
  gridTable: 'table[id$="grid-component-table"]',
};

const REPORT_SOURCE = { SOURCE: 'LISTINGS' };
const REPORT_TYPE = { SOURCE: 'LISTINGS', TYPE: 'ALL_LISTINGS' };

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function waitForStableDom(timeout = 1000) {
  return new Promise(resolve => {
    let observer, lastChange = Date.now(), active = false;
    function check() {
      if (Date.now() - lastChange > timeout) { if (active) observer.disconnect(); resolve(); }
      else setTimeout(check, timeout);
    }
    const onMutate = () => { lastChange = Date.now(); };
    const opts = { attributes: true, childList: true, subtree: true };
    if (document.readyState === 'complete') {
      observer = new MutationObserver(onMutate); observer.observe(document.body, opts); active = true; setTimeout(check, timeout);
    } else {
      window.onload = () => { observer = new MutationObserver(onMutate); observer.observe(document.body, opts); active = true; setTimeout(check, timeout); };
    }
  });
}

async function pollForElement(checkFn, label, interval = 500, timeout = 15000) {
  const start = Date.now();
  let el;
  while (!(el = checkFn())) {
    if (Date.now() - start > timeout) throw new Error('Timed out waiting for ' + label);
    await sleep(interval);
  }
  console.log(label + ' found');
  return el;
}

function findRadioByValue(val) {
  const json = JSON.stringify(val);
  return Array.from(document.querySelectorAll('input[type=radio]')).find(r => r.value === json);
}

function getReportRows() {
  const table = document.querySelector(DOWNLOAD_SELECTORS.gridTable);
  return table ? Array.from(table.querySelectorAll('tbody')) : [];
}

function getRowRequestId(row) {
  const cell = row.querySelector('.shui-dt-column__requestId .shui-dt--text-column div');
  return cell ? cell.textContent.trim() : null;
}

async function fetchReportCsv(requestId) {
  const d = new Date();
  const fname = 'eBay-all-active-listings-report-' + d.getFullYear() + '-' +
    String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') + '-' + requestId + '.csv';
  const url = window.location.origin + '/sh/fpp/getfiledetails?client=sh-listings&requestId=' + requestId +
    '&filetype=output&fileName=' + encodeURIComponent(fname);
  console.log('Fetching CSV from ' + url);
  const res = await fetch(url, { credentials: 'include' });
  if (!res.ok) throw new Error('Fetch failed: ' + res.status);
  return await res.text();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'download_active_listings_csv') {
    console.log('Request received: download_active_listings_csv');
    runDownloadFlow().then(csv => sendResponse({ success: true, csv }))
      .catch(err => { console.error('Download flow error:', err); sendResponse({ success: false, error: err.message }); });
    return true;
  }
});

async function runDownloadFlow() {
  // Dismiss welcome modal if present
  const welcomeBtn = document.querySelector(DOWNLOAD_SELECTORS.welcomeButton);
  if (welcomeBtn) { welcomeBtn.click(); console.log('Welcome modal closed'); await sleep(1000); }

  (await pollForElement(() => document.querySelector(DOWNLOAD_SELECTORS.downloadButton), 'Download banner button')).click();
  console.log('Download UI opened');

  (await pollForElement(() => document.querySelectorAll(DOWNLOAD_SELECTORS.fieldCards)[0], 'Source dropdown')).click();
  (await pollForElement(() => findRadioByValue(REPORT_SOURCE), 'Report source radio')).click();
  (await pollForElement(() => document.querySelectorAll(DOWNLOAD_SELECTORS.fieldCards)[1], 'Type dropdown')).click();
  (await pollForElement(() => findRadioByValue(REPORT_TYPE), 'All-listings radio')).click();

  await pollForElement(() => document.querySelector(DOWNLOAD_SELECTORS.gridTable), 'Reports table');
  const existingIds = getReportRows().map(getRowRequestId).filter(Boolean);
  console.log('Existing requestIds:', existingIds);

  document.title = 'Report in progress…';
  const genBtn = await pollForElement(() => document.querySelector(DOWNLOAD_SELECTORS.generateButton), 'Generate report button');
  genBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await sleep(2000);
  genBtn.click();
  console.log('Report generation triggered');

  await pollForElement(() => getReportRows().some(r => { const id = getRowRequestId(r); return id && !existingIds.includes(id); }),
    'New report row', 1000, 600000);

  const newRow = getReportRows().find(r => { const id = getRowRequestId(r); return id && !existingIds.includes(id); });
  const newId = getRowRequestId(newRow);
  console.log('Extracted new requestId: ' + newId);

  const csv = await fetchReportCsv(newId);
  document.title = 'Report completed';
  return csv;
}
