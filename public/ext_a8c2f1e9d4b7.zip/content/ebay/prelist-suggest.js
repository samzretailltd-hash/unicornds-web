/**
 * UnicornDS - eBay Prelist Suggest Page
 * 
 * FIXED FLOW:
 *   1. Type title into search
 *   2. Click search button
 *   3. Wait for category dialog → click first suggested → click Done
 *   4. ONLY AFTER category is handled, send clicked_go_list_an_item to background
 */

console.log('[UnicornDS] prelist-suggest.js loaded');

const sleep = ms => new Promise(r => setTimeout(r, ms));

// ── Selectors ───────────────────────────────────────────
function findSearchInput() {
  return document.querySelector('[id$="@box-@input-textbox"]') ||
         document.querySelector('[id*="@simplified-keyword-@search-textbox-@se-textbox"]') ||
         document.querySelector('input[type="text"][aria-label]') ||
         document.querySelector('.se-textbox--input') ||
         document.querySelector('input[placeholder]');
}

function findSearchButton() {
  return document.querySelector('[aria-label="Continue" i]') ||
         document.querySelector('[aria-label="Go to list an item page" i]') ||
         document.querySelector('[aria-label="Search" i]') ||
         document.querySelector('.keyword-suggestion__button') ||
         document.querySelector('.sell-search-simplified__next-action');
}

// ── Message Listener ────────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[UnicornDS] suggest message:', request.type);
  if (request.type === 'insert_draft_details') {
    handleSuggest(request.productData);
    sendResponse({ received: true });
  }
  // Ignore insert_ebay_data on this page - it's not the listing form
  if (request.type === 'insert_ebay_data') {
    console.log('[UnicornDS] Ignoring insert_ebay_data on suggest page');
    sendResponse({ ignored: true });
  }
});

// ── Main Flow ───────────────────────────────────────────
async function handleSuggest(productData) {
  console.log('[UnicornDS] === SUGGEST FLOW START ===');

  // Step 1: Wait for search input
  let input = null;
  for (let i = 0; i < 30; i++) {
    input = findSearchInput();
    if (input) break;
    await sleep(500);
  }
  if (!input) { console.error('[UnicornDS] Search input not found'); return; }

  // Step 2: Type title
  const searchText = productData.custom_title || productData.cleanedTitle || productData.title || '';
  input.value = searchText;
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new Event('input', { bubbles: true }));
  console.log('[UnicornDS] Typed:', searchText.substring(0, 60));

  await sleep(2000);

  // Verify
  if (!input.value || input.value.length < 3) {
    input.value = productData.title || searchText;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(1000);
  }

  // Step 3: Click search button
  const btn = findSearchButton();
  if (btn) {
    console.log('[UnicornDS] Clicking search button');
    btn.click();
  } else {
    console.warn('[UnicornDS] Search button not found');
  }

  // Step 4: Handle category dialog if it appears
  await handleCategoryDialog();

  // Step 5: NOW signal background - page should be navigating to identify
  console.log('[UnicornDS] Sending clicked_go_list_an_item');
  chrome.runtime.sendMessage({
    type: 'clicked_go_list_an_item',
    productData: productData,
  });

  console.log('[UnicornDS] === SUGGEST FLOW DONE ===');
}

// ── Category Dialog Handler ─────────────────────────────
async function handleCategoryDialog() {
  console.log('[UnicornDS] Watching for category dialog...');

  for (let attempt = 0; attempt < 25; attempt++) {
    await sleep(1000);

    // Check if page already navigated (no category dialog needed)
    if (window.location.href.includes('identify') || window.location.href.includes('/lstng')) {
      console.log('[UnicornDS] Page navigated - no category dialog');
      return;
    }

    // ── Strategy 1: se-field-card (eBay's category card component) ──
    const card = document.querySelector('.se-field-card__container') ||
                 document.querySelector('[class*="field-card"]') ||
                 document.querySelector('[data-testid*="category"] [role="radio"]');
    if (card) {
      console.log('[UnicornDS] Clicking category card');
      card.click();
      await sleep(1500);
      if (await clickDoneButton()) return;
      continue;
    }

    // ── Strategy 2: Radio buttons for category selection ──
    const radios = document.querySelectorAll('[role="radio"], input[type="radio"]');
    if (radios.length > 0) {
      // Click the first one (most relevant suggestion)
      const first = radios[0];
      const label = first.closest('label, div')?.textContent?.trim() || '';
      console.log('[UnicornDS] Clicking category radio:', label.substring(0, 60));
      first.click();
      await sleep(1500);
      if (await clickDoneButton()) return;
      continue;
    }

    // ── Strategy 3: Links/items with ">" (category path like "Home > Garden > Tools") ──
    const allLinks = document.querySelectorAll('a, [role="option"], [role="listitem"], [role="menuitem"], li');
    for (const link of allLinks) {
      const text = link.textContent.trim();
      if (text.includes('>') && text.length > 15 && text.length < 200 && !text.includes('http')) {
        console.log('[UnicornDS] Clicking category path:', text.substring(0, 60));
        link.click();
        await sleep(1500);
        if (await clickDoneButton()) return;
        break;
      }
    }

    // ── Strategy 4: Category list items (clickable rows in category picker) ──
    const listItems = document.querySelectorAll('[class*="category"] li, [class*="category"] button, [data-testid*="category"]');
    if (listItems.length > 0) {
      console.log('[UnicornDS] Clicking category list item:', (listItems[0].textContent || '').substring(0, 60));
      listItems[0].click();
      await sleep(1500);
      if (await clickDoneButton()) return;
    }
  }
  console.log('[UnicornDS] Category dialog timed out');
}

// Click the Done/Continue button after category selection
async function clickDoneButton() {
  for (let d = 0; d < 10; d++) {
    // Check if page navigated
    if (window.location.href.includes('identify') || window.location.href.includes('/lstng')) {
      console.log('[UnicornDS] Page navigated after category');
      return true;
    }

    const doneBtn = Array.from(document.querySelectorAll('button, [role="button"]'))
      .find(b => {
        const txt = b.textContent.trim().toLowerCase();
        return txt === 'done' || txt === 'continue' || txt === 'select' || 
               txt === 'confirm' || txt === 'next' ||
               b.getAttribute('aria-label')?.toLowerCase() === 'done' ||
               b.getAttribute('aria-label')?.toLowerCase() === 'continue';
      });
    if (doneBtn && !doneBtn.disabled) {
      console.log('[UnicornDS] Clicking Done/Continue:', doneBtn.textContent.trim());
      doneBtn.click();
      await sleep(2000);
      return true;
    }
    await sleep(500);
  }
  return false;
}
