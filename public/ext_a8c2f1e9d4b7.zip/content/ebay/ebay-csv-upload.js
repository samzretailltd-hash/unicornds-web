/**
 * UnicornDS - eBay CSV Upload
 * Runs on: ebay.[domain]/sh/reports/uploads
 * Uploads CSV file to eBay Seller Hub for bulk updates
 */
'use strict';
console.log('[UnicornDS] CSV upload script loaded');

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function pollForElement(checkFn, label, interval = 500, timeout = 15000) {
  const start = Date.now();
  let el;
  while (!(el = checkFn())) {
    if (Date.now() - start > timeout) throw new Error('Timed out waiting for ' + label);
    await sleep(interval);
  }
  console.log(label + ' found');
  return el;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'upload_csv') {
    console.log('Request received: upload_csv');
    runUploadFlow(msg.csvData, msg.filename)
      .then(() => sendResponse({ success: true }))
      .catch(err => { console.error('Upload flow error:', err); document.title = '❌ Upload failed'; sendResponse({ success: false, error: err.message }); });
    return true;
  }
});

async function runUploadFlow(csvData, filename = 'upload.csv') {
  document.title = '⏳ Starting upload';

  // Find and click Upload button
  const uploadBtn = await pollForElement(
    () => [...document.querySelectorAll('button')].find(b =>
      ['Upload template', 'Vorlage hochladen', 'Carica modello'].includes(b.textContent.trim())),
    'Upload template button');
  uploadBtn.click();
  console.log('Upload dialog opened');

  document.title = '📂 Opening dialog…';

  // Find the hidden file input
  const fileInput = await pollForElement(
    () => document.querySelector('input[type="file"][accept=".xlsm,.xlsx,.txt,.csv"]'),
    'Hidden file input');

  // Wait for Choose file button to appear
  await pollForElement(
    () => [...document.querySelectorAll('button')].find(b =>
      ['Choose file', 'Datei auswählen', 'Scegli il file'].includes(b.textContent.trim())),
    'Choose file button');

  document.title = '⚙️ Preparing CSV…';

  // Convert base64 data to blob
  const blob = dataUriToBlob(csvData);
  const file = new File([blob], filename, { type: 'text/csv' });

  document.title = '📤 Injecting CSV…';

  // Inject file into file input
  const dt = new DataTransfer();
  dt.items.add(file);
  fileInput.files = dt.files;
  fileInput.dispatchEvent(new Event('change', { bubbles: true }));
  console.log('CSV injected and file input triggered');

  document.title = '📤 Uploading file…';

  // Record existing upload row IDs
  const existingIds = Array.from(document.querySelectorAll('tbody tr.grid-row'))
    .map(row => row.getAttribute('data-request-id') ||
      row.querySelector('.shui-dt-column__requestId div')?.textContent.trim() ||
      row.querySelector('.shui-dt-column__fileName div')?.textContent.trim())
    .filter(Boolean);
  console.log('Existing upload IDs:', existingIds);

  document.title = '🔍 Waiting for new row';

  // Wait for new upload row to appear
  const newRow = await pollForElement(
    () => Array.from(document.querySelectorAll('tbody tr.grid-row')).find(row => {
      const id = row.getAttribute('data-request-id') ||
        row.querySelector('.shui-dt-column__requestId div')?.textContent.trim() ||
        row.querySelector('.shui-dt-column__fileName div')?.textContent.trim();
      return id && !existingIds.includes(id);
    }) || null,
    'New upload row to appear', 1000, 360000);
  console.log('New row detected:', newRow);

  // Wait for results link
  const spinnerFrames = ['🔄', '⏳', '⌛'];
  let frameIdx = 0;
  const spinnerText = ' Waiting for results';
  document.title = spinnerFrames[0] + spinnerText;
  const spinner = setInterval(() => {
    frameIdx = (frameIdx + 1) % spinnerFrames.length;
    document.title = spinnerFrames[frameIdx] + spinnerText;
  }, 600);

  console.log('Waiting for "Download results" link…');

  await pollForElement(() => {
    const actionCell = newRow.querySelector('td.shui-dt-column__uploadAction');
    if (!actionCell) return false;
    return Boolean(actionCell.querySelector('a[href*="getfiledetails"][href*="filetype=output"]'));
  }, 'Download results link to appear', 1000, 1080000);

  clearInterval(spinner);
  document.title = '✅ Upload complete!';
  console.log('Upload complete-"Download results" is available.');
}

function dataUriToBlob(dataUri) {
  const [header, base64] = dataUri.split(',');
  const mimeMatch = header.match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
