/**
 * UnicornDS - eBay Prelist Identify Page
 * 
 * EXACT  approach from content_bundle_12.js:
 *   - Runs 4 functions IN PARALLEL as infinite loops
 *   - clickCondition: clicks [name="condition"] until done
 *   - clickLightbox: clicks lightbox category if it appears
 *   - clickContinue: clicks continue button in infinite loop (waits if disabled)
 *   - All run simultaneously - whichever UI appears gets handled
 *
 * Selectors from :
 *   Condition: [name="condition"]
 *   Continue:  .prelist-radix__next-action, [class*="radix__continue-btn"],
 *              .condition-dialog-radix__continue-btn
 *   Lightbox:  .lightbox-dialog__main .se-field-card__container
 */

console.log('[UnicornDS] prelist-identify.js loaded');

let conditionDone = false;
let lightboxDone = false;
let productData = null;

// ── Message Listener ────────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[UnicornDS] identify message:', request.type);

  if (request.type === 'identify_product') {
    productData = request.productData;

    // Tell background we're proceeding
    chrome.runtime.sendMessage({
      type: 'clicked_continued_without_matching',
      productData: productData,
    });

    // Start all handlers in parallel - 's exact approach
    startAllHandlers();
    sendResponse({ received: true });
  }

  // Ignore insert_ebay_data on this page
  if (request.type === 'insert_ebay_data') {
    console.log('[UnicornDS] Ignoring insert_ebay_data on identify page');
    sendResponse({ ignored: true });
  }
});

function startAllHandlers() {
  console.log('[UnicornDS] Starting all handlers in parallel');
  clickConditionLoop();
  clickLightboxLoop();
  clickContinueLoop();
}

// ── 1. CONDITION - click [name="condition"] until done (max 60s) ──
async function clickConditionLoop() {
  const maxAttempts = 60;
  let attempts = 0;
  while (!conditionDone && attempts < maxAttempts) {
    const radio = document.querySelector('[name="condition"]');
    if (radio) {
      radio.click();
      await sleep(1000);
      conditionDone = true;
      console.log('[UnicornDS] ✅ Condition clicked');
    } else {
      await sleep(1000);
    }
    attempts++;
    // Exit if page navigated
    if (window.location.href.includes('/lstng')) return;
  }
}

// ── 2. LIGHTBOX - click category in lightbox if appears (max 60s) ─
async function clickLightboxLoop() {
  const maxAttempts = 60;
  let attempts = 0;
  while (!lightboxDone && attempts < maxAttempts) {
    // Strategy 1: exact  selector
    const card = document.querySelector('.lightbox-dialog__main .se-field-card__container');
    if (card) {
      card.click();
      await sleep(1000);
      lightboxDone = true;
      console.log('[UnicornDS] ✅ Lightbox category clicked (card)');
      return;
    }
    // Strategy 2: any radio in lightbox
    const radio = document.querySelector('.lightbox-dialog__main [role="radio"]') ||
                  document.querySelector('.lightbox-dialog__main input[type="radio"]');
    if (radio) {
      radio.click();
      await sleep(1000);
      lightboxDone = true;
      console.log('[UnicornDS] ✅ Lightbox category clicked (radio)');
      return;
    }
    // Strategy 3: clickable list items in lightbox
    const listItem = document.querySelector('.lightbox-dialog__main li') ||
                     document.querySelector('.lightbox-dialog__main [role="option"]');
    if (listItem) {
      listItem.click();
      await sleep(1000);
      lightboxDone = true;
      console.log('[UnicornDS] ✅ Lightbox category clicked (listitem)');
      return;
    }
    await sleep(1000);
    attempts++;
    if (window.location.href.includes('/lstng')) return;
  }
}

// ── 3. CONTINUE - click continue button (max 2 min) ─────────
async function clickContinueLoop() {
  const maxAttempts = 120;
  for (let i = 0; i < maxAttempts; i++) {
    const btn = findContinueButton();
    if (btn) {
      if (btn.disabled) {
        await sleep(1000);
        continue;
      }
      console.log('[UnicornDS] Clicking continue:', btn.textContent?.trim()?.substring(0, 30));
      btn.click();
    }
    await sleep(1000);

    // Check if we navigated to listing form
    if (window.location.href.includes('/lstng')) {
      console.log('[UnicornDS] Navigated to /lstng - done');
      return;
    }
  }
}

function findContinueButton() {
  return document.querySelector('.prelist-radix__next-action') ||
         document.querySelector('[class*="radix__continue-btn"]') ||
         document.querySelector('.condition-dialog-radix__continue-btn') ||
         document.querySelector('button[aria-label*="Continue" i]') ||
         findButtonByText('Continue to listing') ||
         findButtonByText('Continue');
}

function findButtonByText(text) {
  const lower = text.toLowerCase();
  for (const btn of document.querySelectorAll('button')) {
    if (btn.textContent.trim().toLowerCase().includes(lower)) return btn;
  }
  return null;
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ── Auto-start without message (page may load before background sends) ──
(async function autoStart() {
  await sleep(3000);
  if (!productData) {
    console.log('[UnicornDS] Auto-starting handlers (no message received)');
    startAllHandlers();
  }
})();
