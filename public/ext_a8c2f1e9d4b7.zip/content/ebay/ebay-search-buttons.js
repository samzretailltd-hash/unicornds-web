/**
 * UnicornDS - eBay Search Results Button Injection
 * Injects action buttons on every eBay search result item
 * Works on: /sch/i.html (search, seller items, sold items)
 * Also works on: /str/* (seller stores)
 */

console.log('[UnicornDS] eBay search buttons loaded');

// ═══════════════════════════════════════
// SVG ICONS (inline, no external files)
// ═══════════════════════════════════════
const ICONS = {
  amazon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 01-9 9 9 9 0 01-9-9 9 9 0 019-9 9 9 0 019 9z"/><path d="M8 12h4l-2-3z" fill="currentColor"/><path d="M10.5 14.5c1.5 1 3.5 1 5 0"/></svg>',
  ali: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 10l4 4 4-4" stroke-linecap="round"/><line x1="12" y1="7" x2="12" y2="14" stroke-linecap="round"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>',
  sold: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M2 12h20"/><path d="M17 7l-5 5-5-5" fill="none"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>',
  seller: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>',
  save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>',
  list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
  history: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
  extract: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
};

// ═══════════════════════════════════════
// ITEM DATA EXTRACTION
// ═══════════════════════════════════════
function extractItemData(itemEl) {
  const data = {};

  // Title - try multiple selectors
  const titleEl = itemEl.querySelector('.s-item__title, .s-card__title, h3, [role="heading"]');
  if (titleEl) {
    const clipped = titleEl.querySelector('.clipped');
    if (clipped) clipped.textContent = '';
    data.title = titleEl.textContent.trim();
  }
  if (!data.title || data.title === 'Shop on eBay' || data.title === 'Results matching fewer words') return null;

  // Price - try multiple selectors
  const priceEl = itemEl.querySelector('.s-item__price, .s-card__price, [class*="price"] span');
  if (priceEl) {
    const priceText = priceEl.textContent.replace(/[^0-9.,]/g, '');
    const lastComma = priceText.lastIndexOf(',');
    const lastDot = priceText.lastIndexOf('.');
    let cleaned = priceText;
    if (lastComma > lastDot) cleaned = priceText.replace(/\./g, '').replace(',', '.');
    else cleaned = priceText.replace(/,/g, '');
    data.price = parseFloat(cleaned) || 0;
  }

  // Image - try multiple selectors
  const imgEl = itemEl.querySelector('.s-item__image-wrapper img, .image-treatment img, img[src*="ebayimg"]');
  data.image = imgEl ? (imgEl.src || imgEl.dataset.src || '') : '';

  // Item number from URL
  const linkEl = itemEl.querySelector('a[href*="/itm/"]');
  if (linkEl) {
    const href = linkEl.href.split('?')[0];
    data.itemNumber = href.split('/').pop();
    data.url = linkEl.href;
  }

  // Seller info - try link href first (cleanest source), then text
  let sellerName = '';
  const sellerLink = itemEl.querySelector('a[href*="_ssn="]') ||
                     itemEl.querySelector('a[href*="store_name="]') ||
                     itemEl.querySelector('.s-item__seller-info a') ||
                     itemEl.querySelector('.s-item__etrs a') ||
                     itemEl.querySelector('[class*="seller"] a') ||
                     itemEl.querySelector('a[href*="/usr/"]');
  if (sellerLink) {
    const href = sellerLink.href || '';
    const ssnMatch = href.match(/[_&]ssn=([^&]+)/);
    const storeMatch = href.match(/store_name=([^&]+)/);
    const usrMatch = href.match(/\/usr\/([^/?]+)/);
    if (ssnMatch) sellerName = decodeURIComponent(ssnMatch[1]);
    else if (storeMatch) sellerName = decodeURIComponent(storeMatch[1]);
    else if (usrMatch) sellerName = decodeURIComponent(usrMatch[1]);
    else sellerName = sellerLink.textContent.trim();
  }
  if (!sellerName) {
    const sellerEl = itemEl.querySelector('.s-item__seller-info-text') ||
                     itemEl.querySelector('.s-item__etrs-text') ||
                     itemEl.querySelector('[class*="seller-info"]');
    if (sellerEl) {
      sellerName = sellerEl.textContent.trim();
    }
  }
  // Clean: remove feedback count, percentage, and everything after
  sellerName = sellerName.split('(')[0].trim();
  sellerName = sellerName.replace(/[\d.,]+%.*$/, '').trim();
  sellerName = sellerName.replace(/\s+/g, '').trim();
  if (sellerName) data.seller = sellerName;

  // Sold date (if on sold items page)
  const soldEl = itemEl.querySelector('.s-item__caption--signal.POSITIVE') ||
                 itemEl.querySelector('.s-item__title--tag .POSITIVE') ||
                 itemEl.querySelector('.s-card__caption .positive') ||
                 itemEl.querySelector('.s-item__caption .POSITIVE') ||
                 itemEl.querySelector('[class*="POSITIVE"]');
  if (soldEl) {
    data.soldText = soldEl.textContent.trim();
  }

  return data;
}

// ═══════════════════════════════════════
// BUTTON CREATION
// ═══════════════════════════════════════
function createBtn(label, icon, className, onClick) {
  const btn = document.createElement('a');
  btn.className = 'uds-btn ' + className;
  btn.href = '#';
  btn.title = label;
  btn.innerHTML = (icon || '') + '<span>' + label + '</span>';
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    btn.classList.add('clicked');
    setTimeout(() => btn.classList.remove('clicked'), 400);
    onClick(e);
  });
  return btn;
}

function createButtonPanel(itemEl) {
  const data = extractItemData(itemEl);
  if (!data) return null;

  const panel = document.createElement('div');
  panel.className = 'uds-panel';

  const label = document.createElement('span');
  label.className = 'uds-panel-label';
  label.textContent = 'UDS';
  panel.appendChild(label);

  // 1. Search Amazon
  panel.appendChild(createBtn('Amazon', ICONS.amazon, 'uds-btn-amazon', async () => {
    let searchQuery = data.title;
    // Trim to ~80 chars for better Amazon results
    if (searchQuery.length > 80) searchQuery = searchQuery.substring(0, searchQuery.lastIndexOf(' ', 80));
    const settings = await chrome.storage.local.get(['hunter_domain', 'hunter_sortBy']);
    const domain = settings.hunter_domain || 'co.uk';
    const sort = settings.hunter_sortBy || 'reviews';
    chrome.runtime.sendMessage({
      type: 'search-on-amazon',
      searchQuery: searchQuery,
      options: { isTabActive: true, sort: sort, domain: domain },
      itemData: data,
    });
  }));

  // 1b. Search AliExpress
  panel.appendChild(createBtn('AliExpress', ICONS.ali, 'uds-btn-ali', () => {
    let query = data.title || '';
    // Clean eBay title for AliExpress search
    query = query
      .replace(/\b(brand new|new|sealed|genuine|original|official|uk|fast|free)\b/gi, ' ')
      .replace(/\b(shipping|dispatch|delivery|post|p&p|postage)\b/gi, ' ')
      .replace(/\b(lot|bundle|set of|pack of|x\d+|\d+x)\b/gi, ' ')
      .replace(/[|\-–—,:;\/\\()[\]{}'"!@#$%^&*+=~`]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (query.length > 60) query = query.substring(0, query.lastIndexOf(' ', 60));
    const words = query.split(/\s+/).filter(w => w.length > 2).slice(0, 6).join(' ');
    const url = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(words)}`;
    chrome.runtime.sendMessage({ type: 'openNewTab', url: url });
  }));

  // 2. Search eBay (active listings)
  panel.appendChild(createBtn('eBay', ICONS.search, '', async () => {
    let title = data.title;
    if (title.length > 80) title = title.substring(0, title.lastIndexOf(' ', 80));
    const { unicornds_ebay_domain } = await chrome.storage.local.get('unicornds_ebay_domain');
    const domain = unicornds_ebay_domain || 'co.uk';
    const url = `https://www.ebay.${domain}/sch/i.html?_nkw=${encodeURIComponent(title)}&LH_ItemCondition=1000&LH_FS=1`;
    chrome.runtime.sendMessage({ type: 'openNewTab', url: url });
  }));

  // 3. Sold items
  panel.appendChild(createBtn('Sold', ICONS.sold, 'uds-btn-sold', async () => {
    let title = data.title;
    if (title.length > 80) title = title.substring(0, title.lastIndexOf(' ', 80));
    const { unicornds_ebay_domain } = await chrome.storage.local.get('unicornds_ebay_domain');
    const domain = unicornds_ebay_domain || 'co.uk';
    const url = `https://www.ebay.${domain}/sch/i.html?_nkw=${encodeURIComponent(title)}&LH_Sold=1&LH_ItemCondition=1000&_sop=13`;
    chrome.runtime.sendMessage({ type: 'openNewTab', url: url });
  }));

  // 4. Google Image Search
  if (data.image) {
    panel.appendChild(createBtn('Image', ICONS.image, '', () => {
      const url = `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(data.image)}`;
      chrome.runtime.sendMessage({ type: 'openNewTab', url: url });
    }));
  }

  // 5. Copy Data
  panel.appendChild(createBtn('Copy', ICONS.copy, 'uds-btn-copy', () => {
    const text = JSON.stringify({
      title: data.title,
      price: data.price,
      itemNumber: data.itemNumber,
      seller: data.seller || '',
      image: data.image || '',
    }, null, 2);
    navigator.clipboard.writeText(text).then(() => showToast('Copied to clipboard'));
  }));

  // 6. Seller's Sold Items
  if (data.seller) {
    panel.appendChild(createBtn('Seller', ICONS.seller, 'uds-btn-seller', async () => {
      const { unicornds_ebay_domain } = await chrome.storage.local.get('unicornds_ebay_domain');
      const domain = unicornds_ebay_domain || 'co.uk';
      let seller = data.seller.toLowerCase();
      const url = `https://www.ebay.${domain}/sch/i.html?_dkr=1&_ssn=${encodeURIComponent(seller)}&_ipg=240&LH_Sold=1`;
      chrome.runtime.sendMessage({ type: 'openNewTab', url: url });
    }));
  }

  // 7. Save Seller to competitors
  if (data.seller) {
    const saveBtn = createBtn('Save', ICONS.save, 'uds-btn-save', async () => {
      let seller = data.seller.toLowerCase().trim();
      const { ebayCompetitors } = await chrome.storage.local.get('ebayCompetitors');
      const list = ebayCompetitors || [];
      const idx = list.indexOf(seller);
      if (idx === -1) {
        list.push(seller);
        saveBtn.classList.add('saved');
        saveBtn.querySelector('span').textContent = 'Saved';
        showToast('Seller saved: ' + seller);
      } else {
        list.splice(idx, 1);
        saveBtn.classList.remove('saved');
        saveBtn.querySelector('span').textContent = 'Save';
        showToast('Seller removed: ' + seller);
      }
      await chrome.storage.local.set({ ebayCompetitors: list });
    });
    // Check if already saved
    chrome.storage.local.get('ebayCompetitors', (result) => {
      const list = result.ebayCompetitors || [];
      if (data.seller && list.includes(data.seller.toLowerCase().trim())) {
        saveBtn.classList.add('saved');
        saveBtn.querySelector('span').textContent = 'Saved';
      }
    });
    panel.appendChild(saveBtn);
  }

  // 8. List to eBay (primary action)
  panel.appendChild(createBtn('List', ICONS.list, 'uds-btn-list', () => {
    if (!data.itemNumber) { showToast('No item number found'); return; }
    chrome.runtime.sendMessage({
      type: 'listFromEbayItem',
      itemData: data,
    });
    showToast('Opening lister...');
  }));

  return panel;
}

// ═══════════════════════════════════════
// TOOLBAR (top of search results)
// ═══════════════════════════════════════
function createToolbar() {
  const toolbar = document.createElement('div');
  toolbar.className = 'uds-toolbar';
  toolbar.id = 'uds-toolbar';

  // Brand
  const brand = document.createElement('span');
  brand.className = 'uds-toolbar-brand';
  brand.textContent = 'UnicornDS';
  toolbar.appendChild(brand);

  // Extracted count badge
  const extractBadge = document.createElement('span');
  extractBadge.id = 'uds-extract-badge';
  extractBadge.style.cssText = 'background:#7C3AED;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;margin-right:6px;display:none;';
  extractBadge.textContent = '0 saved';
  toolbar.appendChild(extractBadge);

  // Load saved count
  chrome.storage.local.get('hunter_terms', (r) => {
    const count = (r.hunter_terms || []).length;
    if (count > 0) {
      extractBadge.textContent = count + ' saved';
      extractBadge.style.display = 'inline';
    }
  });

  // Extract All Titles
  const extractBtn = createBtn('📋 Extract Titles', ICONS.extract, '', async () => {
    const items = getAllItems();
    const titles = [];
    items.forEach(item => {
      const d = extractItemData(item);
      if (d && d.title) titles.push(d.title);
    });
    if (!titles.length) { showToast('No items found on page'); return; }

    // Save to storage for Product Hunter (merge with existing)
    const { hunter_terms } = await chrome.storage.local.get('hunter_terms');
    const existing = hunter_terms || [];
    const merged = [...new Set([...existing, ...titles])];
    await chrome.storage.local.set({ hunter_terms: merged });

    // Copy to clipboard
    navigator.clipboard.writeText(titles.join('\n'));

    // Update badge
    extractBadge.textContent = merged.length + ' saved';
    extractBadge.style.display = 'inline';
    extractBadge.style.background = '#10B981';
    setTimeout(() => { extractBadge.style.background = '#7C3AED'; }, 1500);

    // Flash the button
    extractBtn.querySelector('span').textContent = '✅ ' + titles.length + ' extracted!';
    setTimeout(() => { extractBtn.querySelector('span').textContent = '📋 Extract Titles'; }, 2000);

    showToast(titles.length + ' titles extracted → total ' + merged.length + ' saved');
  });
  toolbar.appendChild(extractBtn);

  // View Saved Titles (opens a mini panel)
  toolbar.appendChild(createBtn('📂 View Saved', '', '', async () => {
    const { hunter_terms } = await chrome.storage.local.get('hunter_terms');
    const titles = hunter_terms || [];
    if (!titles.length) { showToast('No saved titles yet'); return; }
    showSavedTitlesPanel(titles);
  }));

  // Clear Saved Titles
  toolbar.appendChild(createBtn('🗑️ Clear Saved', '', '', async () => {
    await chrome.storage.local.set({ hunter_terms: [] });
    extractBadge.textContent = '0 saved';
    extractBadge.style.display = 'none';
    showToast('Saved titles cleared');
  }));

  // Separator
  const sep = document.createElement('span');
  sep.style.cssText = 'width:1px;height:20px;background:#3d3580;margin:0 6px;';
  toolbar.appendChild(sep);

  // Export All Data as CSV
  toolbar.appendChild(createBtn('📥 Export CSV', ICONS.copy, '', () => {
    const items = getAllItems();
    const rows = [['Title', 'Price', 'Item Number', 'Seller', 'Sold', 'Image', 'URL'].join(',')];
    items.forEach(item => {
      const d = extractItemData(item);
      if (!d) return;
      rows.push([
        '"' + (d.title || '').replace(/"/g, '""') + '"',
        d.price || '',
        d.itemNumber || '',
        '"' + (d.seller || '') + '"',
        '"' + (d.soldText || '') + '"',
        d.image || '',
        d.url || '',
      ].join(','));
    });
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'unicornds_ebay_research_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
    showToast(items.length + ' items exported to CSV');
  }));

  // Send All to Product Hunter
  toolbar.appendChild(createBtn('🎯 Send to Hunter', ICONS.amazon, 'uds-btn-amazon', async () => {
    const items = getAllItems();
    const titles = [];
    items.forEach(item => {
      const d = extractItemData(item);
      if (d && d.title) {
        let t = d.title;
        if (t.length > 80) t = t.substring(0, t.lastIndexOf(' ', 80));
        titles.push(t);
      }
    });
    if (!titles.length) { showToast('No items found'); return; }
    await chrome.storage.local.set({ hunter_terms: titles });
    chrome.runtime.sendMessage({ type: 'openProductHunter' });
    showToast(titles.length + ' titles → Product Hunter');
  }));

  // Item count (right side)
  const count = document.createElement('span');
  count.style.cssText = 'margin-left:auto;color:#a5a0cc;font-size:11px;font-weight:600;';
  const items = getAllItems();
  count.textContent = items.length + ' items on page';
  toolbar.appendChild(count);

  return toolbar;
}

// ═══════════════════════════════════════
// SAVED TITLES PANEL (overlay)
// ═══════════════════════════════════════
function showSavedTitlesPanel(titles) {
  // Remove if already showing
  const existing = document.getElementById('uds-titles-panel');
  if (existing) { existing.remove(); return; }

  const overlay = document.createElement('div');
  overlay.id = 'uds-titles-panel';
  overlay.style.cssText = `
    position:fixed;top:0;right:0;width:420px;height:100vh;z-index:999999;
    background:linear-gradient(135deg,#1E1B4B,#2d2766);border-left:2px solid #7C3AED;
    box-shadow:-4px 0 20px rgba(0,0,0,0.5);display:flex;flex-direction:column;
    font-family:system-ui,-apple-system,sans-serif;
  `;

  // Header
  const header = document.createElement('div');
  header.style.cssText = 'padding:16px;border-bottom:1px solid #3d3580;display:flex;align-items:center;justify-content:space-between;';
  header.innerHTML = `
    <span style="color:#F59E0B;font-weight:800;font-size:14px;">📂 Saved Titles (${titles.length})</span>
    <div style="display:flex;gap:6px;">
      <button id="uds-copy-all" style="padding:4px 10px;border:1px solid #4a4280;border-radius:5px;background:#7C3AED;color:#fff;font-size:11px;cursor:pointer;">Copy All</button>
      <button id="uds-close-panel" style="padding:4px 10px;border:1px solid #4a4280;border-radius:5px;background:#EF4444;color:#fff;font-size:11px;cursor:pointer;">✕ Close</button>
    </div>
  `;
  overlay.appendChild(header);

  // Search
  const searchBox = document.createElement('input');
  searchBox.type = 'text';
  searchBox.placeholder = 'Search titles...';
  searchBox.style.cssText = 'margin:8px 16px;padding:8px 12px;border:1px solid #4a4280;border-radius:6px;background:#1a1a2e;color:#e0d8ff;font-size:12px;outline:none;';
  overlay.appendChild(searchBox);

  // List
  const list = document.createElement('div');
  list.style.cssText = 'flex:1;overflow-y:auto;padding:8px 16px;';
  overlay.appendChild(list);

  function renderTitleList(filter) {
    const filtered = filter ? titles.filter(t => t.toLowerCase().includes(filter.toLowerCase())) : titles;
    list.innerHTML = filtered.map((t, i) => `
      <div style="display:flex;align-items:center;gap:8px;padding:6px 8px;margin-bottom:4px;background:rgba(124,58,237,0.1);border-radius:6px;border:1px solid #3d3580;">
        <span style="flex:1;color:#e0d8ff;font-size:11px;line-height:1.3;word-break:break-word;">${i + 1}. ${t}</span>
        <button class="uds-remove-title" data-idx="${titles.indexOf(t)}" style="padding:2px 6px;border:1px solid #7F1D1D;border-radius:4px;background:transparent;color:#EF4444;font-size:10px;cursor:pointer;flex-shrink:0;">✕</button>
      </div>
    `).join('');
  }
  renderTitleList('');

  searchBox.addEventListener('input', () => renderTitleList(searchBox.value));

  document.body.appendChild(overlay);

  // Event listeners
  document.getElementById('uds-close-panel').addEventListener('click', () => overlay.remove());
  document.getElementById('uds-copy-all').addEventListener('click', () => {
    navigator.clipboard.writeText(titles.join('\n'));
    showToast('All ' + titles.length + ' titles copied');
  });

  list.addEventListener('click', async (e) => {
    const btn = e.target.closest('.uds-remove-title');
    if (!btn) return;
    const idx = parseInt(btn.dataset.idx);
    titles.splice(idx, 1);
    await chrome.storage.local.set({ hunter_terms: titles });
    renderTitleList(searchBox.value);
    header.querySelector('span').textContent = '📂 Saved Titles (' + titles.length + ')';
    const badge = document.getElementById('uds-extract-badge');
    if (badge) badge.textContent = titles.length + ' saved';
  });
}

// ═══════════════════════════════════════
// DOM HELPERS
// ═══════════════════════════════════════
function getAllItems() {
  // Try multiple selector patterns - eBay changes HTML frequently
  const selectors = [
    '#srp-river-results .s-item',
    '.srp-results .s-item',
    'ul.srp-results li.s-item',
    '.srp-river-results li.s-item',
    'li.s-item[data-viewport]',
    'li.s-item',
    '.b-list__items_nofooter > li',
    '.srp-river-results [data-gr4]',
  ];
  
  let items = [];
  for (const sel of selectors) {
    items = document.querySelectorAll(sel);
    if (items.length > 1) break; // >1 because first .s-item is often "Shop on eBay" placeholder
  }
  
  // Last resort: find any li elements containing /itm/ links
  if (items.length <= 1) {
    const allLi = document.querySelectorAll('li');
    const itmLis = Array.from(allLi).filter(li => li.querySelector('a[href*="/itm/"]'));
    if (itmLis.length > 0) items = itmLis;
  }

  console.log('[UnicornDS] getAllItems: found', items.length, 'raw items');

  // Filter out "Shop on eBay" placeholder and empty items
  return Array.from(items).filter(item => {
    const title = item.querySelector('.s-item__title, .s-card__title, h3, [role="heading"]');
    if (!title) return false;
    const text = title.textContent.trim();
    return text && text !== 'Shop on eBay' && text !== 'Results matching fewer words';
  });
}

function showToast(message) {
  const existing = document.querySelector('.uds-toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = 'uds-toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2500);
}

// ═══════════════════════════════════════
// INJECT CSS
// ═══════════════════════════════════════
function injectCSS() {
  if (document.getElementById('uds-search-css')) return;
  const link = document.createElement('link');
  link.id = 'uds-search-css';
  link.rel = 'stylesheet';
  link.href = chrome.runtime.getURL('content/ebay/ebay-search-buttons.css');
  document.head.appendChild(link);
}

// ═══════════════════════════════════════
// MAIN INJECTION
// ═══════════════════════════════════════
function injectButtons() {
  injectCSS();

  const items = getAllItems();
  if (!items.length) return;

  console.log('[UnicornDS] Injecting buttons on', items.length, 'items');

  // Inject toolbar (once)
  if (!document.getElementById('uds-toolbar')) {
    const mainContent = document.querySelector('#srp-river-results') ||
                       document.querySelector('.srp-results') ||
                       document.querySelector('#mainContent') ||
                       document.querySelector('[class*="srp-river"]') ||
                       document.querySelector('main');
    if (mainContent) {
      mainContent.insertBefore(createToolbar(), mainContent.firstChild);
    }
  }

  // Inject button panel on each item
  items.forEach(item => {
    if (item.querySelector('.uds-panel')) return; // Already injected

    const panel = createButtonPanel(item);
    if (panel) {
      // Find best insertion point
      const details = item.querySelector('.s-item__details') ||
                     item.querySelector('.s-item__info') ||
                     item.querySelector('.s-card__details') ||
                     item.querySelector('[class*="details"]') ||
                     item;
      details.appendChild(panel);
    }
  });
}

// ═══════════════════════════════════════
// SELLER STORE PAGE INJECTION
// ═══════════════════════════════════════
function injectStoreButtons() {
  injectCSS();

  const items = document.querySelectorAll('.str-item-card.ITEM');
  if (!items.length) return;

  console.log('[UnicornDS] Injecting buttons on', items.length, 'store items');

  items.forEach(item => {
    if (item.querySelector('.uds-panel')) return;

    const titleEl = item.querySelector('.str-card-title .str-text-span');
    const priceEl = item.querySelector('.str-item-card__property-displayPrice');
    const imgEl = item.querySelector('.str-item-card__image img');
    const linkEl = item.querySelector('a[href*="/itm/"]');

    const data = {
      title: titleEl ? titleEl.textContent.trim() : '',
      price: priceEl ? parseFloat(priceEl.textContent.replace(/[^0-9.]/g, '')) : 0,
      image: imgEl ? imgEl.src : '',
      itemNumber: linkEl ? linkEl.href.split('/').pop().split('?')[0] : '',
      url: linkEl ? linkEl.href : '',
    };

    if (!data.title) return;

    const panel = document.createElement('div');
    panel.className = 'uds-panel';

    const label = document.createElement('span');
    label.className = 'uds-panel-label';
    label.textContent = 'UDS';
    panel.appendChild(label);

    // Amazon search
    panel.appendChild(createBtn('Amazon', ICONS.amazon, 'uds-btn-amazon', async () => {
      let q = data.title;
      if (q.length > 80) q = q.substring(0, q.lastIndexOf(' ', 80));
      const s = await chrome.storage.local.get(['hunter_domain']);
      const domain = s.hunter_domain || 'co.uk';
      chrome.runtime.sendMessage({
        type: 'search-on-amazon',
        searchQuery: q,
        options: { isTabActive: true, sort: 'reviews', domain: domain },
        itemData: data,
      });
    }));

    // AliExpress search
    panel.appendChild(createBtn('AliExpress', ICONS.ali, 'uds-btn-ali', () => {
      let q = data.title || '';
      q = q.replace(/\b(brand new|new|sealed|genuine|original|official|uk|fast|free)\b/gi, ' ')
        .replace(/\b(shipping|dispatch|delivery|post|p&p|postage)\b/gi, ' ')
        .replace(/[|\-–—,:;\/\\()[\]{}'"!@#$%^&*+=~`]/g, ' ')
        .replace(/\s+/g, ' ').trim();
      if (q.length > 60) q = q.substring(0, q.lastIndexOf(' ', 60));
      const words = q.split(/\s+/).filter(w => w.length > 2).slice(0, 6).join(' ');
      const url = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(words)}`;
      chrome.runtime.sendMessage({ type: 'openNewTab', url: url });
    }));

    // Copy
    panel.appendChild(createBtn('Copy', ICONS.copy, 'uds-btn-copy', () => {
      navigator.clipboard.writeText(JSON.stringify(data, null, 2));
      showToast('Copied');
    }));

    // List
    panel.appendChild(createBtn('List', ICONS.list, 'uds-btn-list', () => {
      chrome.runtime.sendMessage({ type: 'listFromEbayItem', itemData: data });
      showToast('Opening lister...');
    }));

    item.appendChild(panel);
  });
}

// ═══════════════════════════════════════
// INIT + MUTATION OBSERVER
// ═══════════════════════════════════════
async function init() {
  // Auth check — don't inject buttons if not logged in
  const _s = await new Promise(r => chrome.storage.local.get('unicornds_session', r));
  if (!_s?.unicornds_session?.idToken) {
    console.log('[UnicornDS] Not logged in — eBay search buttons not injected');
    return;
  }

  // Detect page type
  const url = window.location.href;
  const isStore = url.includes('/str/');
  const isSearch = url.includes('/sch/') || url.includes('_nkw=') || url.includes('_dkr=') || url.includes('_ssn');

  if (isStore) {
    injectStoreButtons();
  } else if (isSearch) {
    injectButtons();
  }

  // Watch for dynamic content loading (eBay lazy-loads items)
  const observer = new MutationObserver(() => {
    if (isStore) injectStoreButtons();
    else if (isSearch) injectButtons();
  });

  const target = document.querySelector('#srp-river-results') ||
                document.querySelector('.srp-results') ||
                document.querySelector('#mainContent') ||
                document.querySelector('[class*="srp-river"]') ||
                document.querySelector('main') ||
                document.body;

  observer.observe(target, { childList: true, subtree: true });
}

// Wait for DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  // Small delay for eBay's JS to render items
  setTimeout(init, 1000);
}

// ═══════════════════════════════════════
// MESSAGE HANDLER - Scanner scrape request
// ═══════════════════════════════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'scanner_scrape_page') {
    console.log('[UnicornDS] Scanner: scraping page for seller', msg.seller);
    console.log('[UnicornDS] Scanner: page URL:', window.location.href);

    // Wait longer for eBay to fully render (some pages lazy-load)
    setTimeout(() => {
      const itemEls = getAllItems();
      console.log('[UnicornDS] Scanner: found', itemEls.length, 'item elements on page');
      const scraped = [];

      itemEls.forEach(el => {
        const data = extractItemData(el);
        if (data && data.title) {
          scraped.push(data);
        }
      });

      console.log('[UnicornDS] Scanner: scraped', scraped.length, 'items with data');
      if (scraped.length > 0) {
        console.log('[UnicornDS] Scanner: sample item:', JSON.stringify(scraped[0]).slice(0, 200));
      }
      sendResponse({ items: scraped });
    }, 2000);

    return true; // async response
  }
});
