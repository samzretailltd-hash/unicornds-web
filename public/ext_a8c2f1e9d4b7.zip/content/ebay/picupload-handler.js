/**
 * UnicornDS - Photo Upload Handler
 * Sends switchQueue to SELF right before upload — zero gap between switch and file change.
 */
if (!window.__unicornds_picupload_loaded) {
  window.__unicornds_picupload_loaded = true;
  console.log('[UnicornDS] picupload-handler loaded in iframe');

  window.addEventListener('message', async (event) => {
    if (!event.data || event.data.type !== 'unicornds_upload_variant_image') return;

    const { imageB64, variantName } = event.data;
    console.log('[UnicornDS] picupload: Received image for "' + variantName + '"');

    try {
      const rawB64 = imageB64.includes(',') ? imageB64.split(',')[1] : imageB64;
      const binary = atob(rawB64);
      const arr = new Uint8Array(binary.length);
      for (let j = 0; j < binary.length; j++) arr[j] = binary.charCodeAt(j);
      const file = new File([arr], 'variant_' + variantName + '.jpg', { type: 'image/jpeg' });

      const fileInput = document.querySelector('input[type="file"]');
      if (!fileInput) {
        window.parent.postMessage({ type: 'unicornds_upload_result', success: false, error: 'No file input' }, '*');
        return;
      }

      // Send switchQueue to SELF (eBay's page-level handler picks this up)
      const varClass = 'picupload-variations__MNP__' + variantName.replace(/\s+/g, '_');
      window.postMessage({
        cmd: 'switchQueue',
        currentQueueClass: varClass + ' select',
        currentQueue: variantName
      }, '*');

      // Wait for eBay's page-level code to process the switchQueue
      await new Promise(r => setTimeout(r, 800));

      // NOW set the file — eBay should have the correct queue
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));

      console.log('[UnicornDS] picupload: ✅ Image uploaded for "' + variantName + '" (queue switched inside iframe)');
      window.parent.postMessage({ type: 'unicornds_upload_result', success: true, variantName }, '*');
    } catch (e) {
      console.warn('[UnicornDS] picupload: Error:', e.message);
      window.parent.postMessage({ type: 'unicornds_upload_result', success: false, error: e.message }, '*');
    }
  });
}
