/**
 * UnicornDS - eBay Active Listings Content Script
 * Injects per-row buttons: Amazon link, AliExpress link, Add to Tracker
 * Runs on: ebay active listings pages
 */

console.log('[UnicornDS] Active listings script loaded');

// ═══════════════════════════════════════════════════════
// EXTRACT DATA FROM LISTING ROW ( selectors)
// ═══════════════════════════════════════════════════════
function fetchEbayData(row) {
  const data = {};

  // Title
  const titleEl = row.querySelector('div[class*="title__text"]') || row.querySelector('[class*="item-title"]');
  if (titleEl) data.title = titleEl.textContent.trim();

  // Image
  const imgEl = row.querySelector('td[class*="image"] img') || row.querySelector('[class*="listing-image"] img');
  if (imgEl) data.image = imgEl.getAttribute('src') || '';

  // Custom Label (SKU)
  const skuEl = row.querySelector('td[class*="listingSKU"]') || row.querySelector('[class*="custom-label"]');
  if (skuEl) data.customLabel = skuEl.textContent.trim();

  // Price
  const priceEl = row.querySelector('td[class*="price"] [class*="price__current"]') ||
                  row.querySelector('td[class*="price"] [class*="sh-strikethrough"]') ||
                  row.querySelector('[class*="item-price"]');
  if (priceEl) {
    data.price = parseFloat(priceEl.textContent.trim().replace(/[^0-9.]/g, '')) || 0;
  }

  // Quantity
  const qtyEl = row.querySelector('td[class*="availableQuantity"] [class*="cell-wrapper"]') ||
                row.querySelector('[class*="available-qty"]');
  if (qtyEl) data.quantity = parseInt(qtyEl.textContent.trim().replace(/[^0-9]/g, '')) || 0;

  // Item Number (ID)
  const idEl = row.querySelector('td[class*="listingId"]');
  if (idEl) {
    data.itemNumber = idEl.textContent.trim();
  } else {
    const gridRow = row.querySelector('.grid-row[data-id]') || row.closest('[data-id]');
    if (gridRow) data.itemNumber = gridRow.getAttribute('data-id');
  }

  // Sold Quantity
  const soldEl = row.querySelector('td[class*="soldQuantity"]');
  if (soldEl) data.soldQuantity = parseInt(soldEl.textContent.trim().replace(/[^0-9]/g, '')) || 0;

  return data;
}

// ═══════════════════════════════════════════════════════
// INJECT STYLES
// ═══════════════════════════════════════════════════════
function injectStyles() {
  if (document.getElementById('unicornds-active-styles')) return;
  const style = document.createElement('style');
  style.id = 'unicornds-active-styles';
  style.textContent = `
    .uds-btn-row {
      display: inline-flex; gap: 4px; align-items: center; margin-left: 6px; vertical-align: middle;
    }
    .uds-btn-icon {
      width: 24px; height: 24px; border-radius: 4px; border: 1px solid #ccc;
      display: inline-flex; align-items: center; justify-content: center;
      cursor: pointer; font-size: 13px; transition: all 0.15s; background: #fff;
    }
    .uds-btn-icon:hover { transform: scale(1.15); border-color: #7C3AED; }
    .uds-btn-icon.amz { background: #FF9900; color: #fff; border-color: #FF9900; font-weight: 700; font-size: 11px; }
    .uds-btn-icon.amz:hover { background: #e68a00; }
    .uds-btn-icon.ali { background: #E43225; color: #fff; border-color: #E43225; font-weight: 700; font-size: 10px; }
    .uds-btn-icon.ali:hover { background: #c62b1f; }
    .uds-btn-icon.tracker { background: linear-gradient(135deg, #7C3AED, #6D28D9); color: #fff; border-color: #7C3AED; font-size: 11px; }
    .uds-btn-icon.tracker:hover { background: linear-gradient(135deg, #8B5CF6, #7C3AED); }
    .uds-btn-icon.tracker.added { background: #059669; border-color: #10B981; pointer-events: none; }
    .uds-btn-icon.restock { background: #059669; border-color: #10B981; color: #fff; font-size: 11px; font-weight: 700; }
    .uds-btn-icon.restock:hover { background: #10B981; }
    .uds-btn-icon.stockchk { background: #2563eb; border-color: #3b82f6; color: #fff; font-size: 10px; font-weight: 700; }
    .uds-btn-icon.stockchk:hover { background: #3b82f6; }
    .uds-btn-icon.stockchk.ok { background: #059669; border-color: #10B981; }
    .uds-btn-icon.stockchk.out { background: #dc2626; border-color: #ef4444; }
    .uds-toast {
      position: fixed; bottom: 20px; right: 20px; z-index: 999999;
      background: rgba(15,15,26,0.95); color: #fff; padding: 12px 20px;
      border-radius: 10px; border: 1px solid #7C3AED; font-family: -apple-system, sans-serif;
      font-size: 13px; box-shadow: 0 4px 20px rgba(0,0,0,0.4);
      animation: udsSlideIn 0.3s ease; max-width: 350px;
    }
    .uds-toast .emoji { font-size: 16px; margin-right: 6px; }
    @keyframes udsSlideIn { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

    /* Floating tracker bar */
    .uds-tracker-bar {
      position: fixed; bottom: 0; left: 0; right: 0; z-index: 99999;
      background: rgba(15,15,26,0.97); border-top: 2px solid #7C3AED;
      padding: 10px 20px; display: flex; align-items: center; gap: 16px;
      font-family: -apple-system, sans-serif; color: #fff;
      box-shadow: 0 -4px 20px rgba(0,0,0,0.4);
    }
    .uds-tracker-bar .logo { font-size: 16px; font-weight: 700; }
    .uds-tracker-bar .count { background: #7C3AED; padding: 4px 12px; border-radius: 16px; font-size: 13px; font-weight: 700; }
    .uds-tracker-bar .btn {
      padding: 8px 16px; border-radius: 8px; border: none; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.2s;
    }
    .uds-tracker-bar .btn-open { background: linear-gradient(135deg, #7C3AED, #6D28D9); color: #fff; }
    .uds-tracker-bar .btn-open:hover { background: linear-gradient(135deg, #8B5CF6, #7C3AED); }
    .uds-tracker-bar .btn-add-all { background: #059669; color: #fff; }
    .uds-tracker-bar .btn-add-all:hover { background: #10B981; }
    .uds-tracker-bar .btn-clear { background: #374151; color: #ddd; }
    .uds-tracker-bar .btn-clear:hover { background: #4B5563; }
  `;
  document.head.appendChild(style);
}

// ═══════════════════════════════════════════════════════
// TRACKER QUEUE (stored in chrome.storage)
// ═══════════════════════════════════════════════════════
let trackerQueue = [];

async function loadTrackerQueue() {
  const s = await new Promise(r => chrome.storage.local.get('unicornds_tracker_queue', r));
  trackerQueue = s.unicornds_tracker_queue || [];
  updateTrackerBar();
}

async function saveTrackerQueue() {
  await chrome.storage.local.set({ unicornds_tracker_queue: trackerQueue });
  updateTrackerBar();
}

function addToTracker(item) {
  // Check duplicate
  if (trackerQueue.some(q => q.itemId === item.itemNumber || q.customLabel === item.customLabel)) {
    showToast('⚠️ Already in tracker: ' + (item.customLabel || item.itemNumber));
    return;
  }

  trackerQueue.push({
    itemId: item.itemNumber,
    customLabel: item.customLabel || '',
    title: item.title || '',
    price: item.price || 0,
    quantity: item.quantity || 0,
    image: item.image || '',
    addedAt: Date.now(),
  });

  saveTrackerQueue();
  showToast('🦄 Added to Tracker: ' + (item.title || item.itemNumber).substring(0, 50));
}

function addAllVisibleToTracker() {
  const rows = getListingRows();
  let added = 0;
  for (const row of rows) {
    const data = fetchEbayData(row);
    if (data.itemNumber && data.customLabel) {
      if (!trackerQueue.some(q => q.itemId === data.itemNumber)) {
        trackerQueue.push({
          itemId: data.itemNumber,
          customLabel: data.customLabel,
          title: data.title || '',
          price: data.price || 0,
          quantity: data.quantity || 0,
          image: data.image || '',
          addedAt: Date.now(),
        });
        added++;
      }
    }
  }
  saveTrackerQueue();
  showToast(`🦄 Added ${added} items to Tracker (${trackerQueue.length} total)`);
  // Mark all buttons as added
  document.querySelectorAll('.uds-btn-icon.tracker:not(.added)').forEach(btn => {
    btn.classList.add('added');
    btn.textContent = '✓';
    btn.title = 'Already in tracker';
  });
}

// ═══════════════════════════════════════════════════════
// INJECT BUTTONS INTO LISTING ROWS
// ═══════════════════════════════════════════════════════
function getListingRows() {
  // Seller Hub uses table rows with grid-row class or tr elements
  return [
    ...document.querySelectorAll('tr.grid-row'),
    ...document.querySelectorAll('[class*="listing-row"]'),
    ...document.querySelectorAll('tr[data-id]'),
  ];
}

function injectButtons() {
  const rows = getListingRows();
  console.log('[UnicornDS] Found', rows.length, 'listing rows');

  for (const row of rows) {
    // Skip if already processed
    if (row.querySelector('.uds-btn-row')) continue;

    const data = fetchEbayData(row);
    if (!data.itemNumber) continue;

    // Find where to inject - after the title or in the first cell
    const titleCell = row.querySelector('div[class*="title__text"]') ||
                      row.querySelector('[class*="item-title"]') ||
                      row.querySelector('td:nth-child(2)');
    if (!titleCell) continue;

    const btnContainer = document.createElement('span');
    btnContainer.className = 'uds-btn-row';

    // 1. Amazon button - opens product on Amazon using SKU
    const amzBtn = document.createElement('span');
    amzBtn.className = 'uds-btn-icon amz';
    amzBtn.textContent = 'A';
    amzBtn.title = data.customLabel ? `Open Amazon: ${data.customLabel}` : 'Search Amazon by title';
    amzBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      chrome.storage.local.get('unicornds_primary_market', s => {
        const market = (s.unicornds_primary_market || 'co_uk').replace('_', '.');
        let url;
        // Parse UDS SKU: UDS-AZ-{asin}
        const azMatch = (data.customLabel || '').match(/UDS-AZ-([A-Za-z0-9]+)/);
        if (azMatch) {
          url = `https://www.amazon.${market}/dp/${azMatch[1]}?th=1&psc=1`;
        } else if (data.customLabel && /^B0[A-Z0-9]{8}$/i.test(data.customLabel)) {
          url = `https://www.amazon.${market}/dp/${data.customLabel}?th=1&psc=1`;
        } else {
          const q = encodeURIComponent((data.title || '').substring(0, 80));
          url = `https://www.amazon.${market}/s?k=${q}`;
        }
        chrome.runtime.sendMessage({ type: 'openNewTab', url });
      });
    });
    btnContainer.appendChild(amzBtn);

    // 2. AliExpress button - opens product DIRECTLY using SKU (not search)
    const aliBtn = document.createElement('span');
    aliBtn.className = 'uds-btn-icon ali';
    aliBtn.textContent = 'AE';
    aliBtn.title = data.customLabel ? `Open AliExpress: ${data.customLabel}` : 'Search AliExpress';
    aliBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      let url;
      // Parse UDS SKU: UDS-AE-{id} or UDS-{market}-{id} or UDS-{id} (strip _V suffix)
      const cleanLabel = (data.customLabel || '').replace(/_V\d+$/, '');
      const aeMatch = cleanLabel.match(/UDS-(?:[A-Z]{2}-)?(\d+)/);
      if (aeMatch) {
        url = `https://www.aliexpress.com/item/${aeMatch[1]}.html`;
      } else {
        // Fallback: search by title
        const q = encodeURIComponent((data.title || '').substring(0, 80));
        url = `https://www.aliexpress.com/wholesale?SearchText=${q}`;
      }
      chrome.runtime.sendMessage({ type: 'openNewTab', url });
    });
    btnContainer.appendChild(aliBtn);

    // 3. Add to Tracker button
    const trackBtn = document.createElement('span');
    trackBtn.className = 'uds-btn-icon tracker';
    const isQueued = trackerQueue.some(q => q.itemId === data.itemNumber);
    trackBtn.textContent = isQueued ? '✓' : '⚡';
    trackBtn.title = isQueued ? 'Already in tracker' : 'Add to Fast Tracker';
    if (isQueued) trackBtn.classList.add('added');
    trackBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      addToTracker(data);
      trackBtn.classList.add('added');
      trackBtn.textContent = '✓';
      trackBtn.title = 'Added to tracker';
    });
    btnContainer.appendChild(trackBtn);

    // 4. Restock button — prompt user for qty, open eBay Revise Item with qty pre-filled
    const restockBtn = document.createElement('span');
    restockBtn.className = 'uds-btn-icon restock';
    restockBtn.textContent = '+Q';
    restockBtn.title = 'Restock: set a new quantity for this listing';
    restockBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleRestock(data);
    });
    btnContainer.appendChild(restockBtn);

    // 5. Stock Check button — fetch source (Amazon) and show stock status
    const stockBtn = document.createElement('span');
    stockBtn.className = 'uds-btn-icon stockchk';
    stockBtn.textContent = '📦';
    stockBtn.title = 'Check stock at source (Amazon/AliExpress)';
    stockBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleStockCheck(data, stockBtn);
    });
    btnContainer.appendChild(stockBtn);

    titleCell.appendChild(btnContainer);
  }
}

// ═══════════════════════════════════════════════════════
// RESTOCK — open Revise Item page, let eBay's own UI handle the update
// Safe approach: no reverse-engineered API, no risk of breaking listing.
// ═══════════════════════════════════════════════════════
function handleRestock(data) {
  if (!data.itemNumber) { showToast('⚠️ Missing item number'); return; }
  const currentQty = data.quantity || 0;
  const input = prompt(
    `Restock: "${(data.title || '').substring(0, 60)}"\n\n` +
    `Current quantity: ${currentQty}\n\n` +
    `Enter NEW total quantity:`,
    String(Math.max(10, currentQty))
  );
  if (input === null) return; // cancelled
  const newQty = parseInt(String(input).trim(), 10);
  if (!Number.isFinite(newQty) || newQty < 0 || newQty > 999) {
    showToast('⚠️ Invalid quantity (0-999)');
    return;
  }

  chrome.storage.local.get(['domain', 'unicornds_primary_market'], (s) => {
    const marketToDomain = {
      'com':'com','co_uk':'co.uk','de':'de','com_au':'com.au',
      'ca':'ca','fr':'fr','it':'it','es':'es','nl':'nl',
    };
    const domain = s.domain || marketToDomain[s.unicornds_primary_market] || 'co.uk';
    // eBay's Revise Item page — user confirms & clicks Save. Pre-fills qty via URL hash flag we read later.
    const url = `https://www.ebay.${domain}/lstng?mode=ReviseItem&itemId=${data.itemNumber}#uds_restock=${newQty}`;
    chrome.runtime.sendMessage({ type: 'openNewTab', url });
    showToast(`🔄 Opening Revise Item — set qty to ${newQty}`);
  });
}

// ═══════════════════════════════════════════════════════
// STOCK CHECK — fetch Amazon source page, parse availability
// Uses stored SKU→URL mapping we already save when listing.
// ═══════════════════════════════════════════════════════
function handleStockCheck(data, btn) {
  if (!data.customLabel) {
    showToast('⚠️ No SKU — cannot locate source');
    return;
  }

  // Find source URL: first check stored mapping, fall back to reconstructing from SKU
  chrome.storage.local.get('unicornds_sku_url_map', (s) => {
    const map = s.unicornds_sku_url_map || {};
    let sourceUrl = map[data.customLabel];

    if (!sourceUrl) {
      // Reconstruct from SKU pattern
      const cleanLabel = data.customLabel.replace(/_V\d+$/, '');
      const azMatch = cleanLabel.match(/UDS-AZ-([A-Za-z0-9]{10})/);
      const aeMatch = cleanLabel.match(/UDS-AE-(\d+)/) || cleanLabel.match(/UDS-(\d+)/);
      if (azMatch) {
        sourceUrl = `https://www.amazon.co.uk/dp/${azMatch[1]}`;
      } else if (aeMatch) {
        sourceUrl = `https://www.aliexpress.com/item/${aeMatch[1]}.html`;
      }
    }

    if (!sourceUrl) {
      showToast('⚠️ Source URL not found for this SKU');
      return;
    }

    btn.textContent = '⏳';
    btn.title = 'Checking stock...';

    chrome.runtime.sendMessage(
      { type: 'uds_check_source_stock', url: sourceUrl },
      (res) => {
        if (chrome.runtime.lastError || !res) {
          btn.textContent = '?';
          btn.classList.remove('ok', 'out');
          btn.title = 'Check failed';
          showToast('⚠️ Stock check failed — see console');
          return;
        }
        if (res.error) {
          btn.textContent = '?';
          btn.classList.remove('ok', 'out');
          btn.title = 'Error: ' + res.error;
          showToast('⚠️ ' + res.error);
          return;
        }
        // Update button based on result
        btn.classList.remove('ok', 'out');
        if (res.inStock) {
          btn.classList.add('ok');
          btn.textContent = '✓';
          btn.title = `In stock${res.price ? ' at ' + res.price : ''}${res.source ? ' (' + res.source + ')' : ''}`;
          showToast(`✅ In stock${res.price ? ' at ' + res.price : ''}`);
        } else {
          btn.classList.add('out');
          btn.textContent = '✗';
          btn.title = 'Out of stock at source';
          showToast('⚠️ Out of stock at source');
        }
      }
    );
  });
}

// ═══════════════════════════════════════════════════════
// FLOATING TRACKER BAR (bottom of page)
// ═══════════════════════════════════════════════════════
function createTrackerBar() {
  if (document.getElementById('uds-tracker-bar')) return;

  const bar = document.createElement('div');
  bar.id = 'uds-tracker-bar';
  bar.className = 'uds-tracker-bar';
  bar.innerHTML = `
    <span class="logo">🦄 Fast Tracker</span>
    <span class="count" id="uds-queue-count">0 items queued</span>
    <button class="btn btn-add-all" id="uds-add-all">⚡ Add All Visible</button>
    <button class="btn btn-open" id="uds-open-tracker">📊 Open Tracker</button>
    <button class="btn btn-clear" id="uds-clear-queue">🗑️ Clear Queue</button>
    <button class="btn btn-end" id="uds-end-items" style="background:#e74c3c;color:#fff;">🗑️ End Zero Performers</button>
  `;
  document.body.appendChild(bar);

  document.getElementById('uds-add-all').addEventListener('click', addAllVisibleToTracker);
  document.getElementById('uds-open-tracker').addEventListener('click', () => {
    chrome.runtime.sendMessage({
      type: 'openNewTab',
      url: chrome.runtime.getURL('pages/tracker/tracker.html'),
    });
  });
  document.getElementById('uds-clear-queue').addEventListener('click', () => {
    trackerQueue = [];
    saveTrackerQueue();
    document.querySelectorAll('.uds-btn-icon.tracker.added').forEach(btn => {
      btn.classList.remove('added');
      btn.textContent = '⚡';
    });
    showToast('🗑️ Tracker queue cleared');
  });

  document.getElementById('uds-end-items').addEventListener('click', endZeroPerformers);
}

function updateTrackerBar() {
  const el = document.getElementById('uds-queue-count');
  if (el) el.textContent = trackerQueue.length + ' items queued';
}

// ═══════════════════════════════════════════════════════
// TOAST NOTIFICATION
// ═══════════════════════════════════════════════════════
function showToast(msg) {
  const existing = document.querySelectorAll('.uds-toast');
  existing.forEach(e => e.remove());

  const toast = document.createElement('div');
  toast.className = 'uds-toast';
  toast.innerHTML = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// ═══════════════════════════════════════════════════════
// END ZERO PERFORMERS - select listings with 0 sales + 0 watchers
// ═══════════════════════════════════════════════════════
async function endZeroPerformers() {
  const rows = getListingRows();
  if (!rows.length) { showToast('⚠️ No listings found on page'); return; }

  let zeroCount = 0;
  const checkboxes = [];

  for (const row of rows) {
    // Get sold quantity
    const soldEl = row.querySelector('td[class*="soldQuantity"]') ||
                   row.querySelector('[class*="sold-qty"]');
    const sold = parseInt((soldEl?.textContent || '0').replace(/[^0-9]/g, '')) || 0;

    // Get watcher count
    const watchEl = row.querySelector('td[class*="watchCount"]') ||
                    row.querySelector('[class*="watchers"]');
    const watchers = parseInt((watchEl?.textContent || '0').replace(/[^0-9]/g, '')) || 0;

    if (sold === 0 && watchers === 0) {
      // Find checkbox for this row
      const checkbox = row.querySelector('input[type="checkbox"][id^="shui-dt-checkone"]') ||
                       row.querySelector('input[type="checkbox"]');
      if (checkbox && !checkbox.checked) {
        checkbox.click();
        checkboxes.push(checkbox);
      }
      zeroCount++;
    }
  }

  if (zeroCount === 0) {
    showToast('✅ No zero-performer listings found on this page');
    return;
  }

  const proceed = confirm(
    `🗑️ Found ${zeroCount} listings with 0 sales and 0 watchers.\n\n` +
    `${checkboxes.length} have been selected.\n\n` +
    `Click OK to end these listings, or Cancel to deselect.`
  );

  if (!proceed) {
    // Uncheck all
    checkboxes.forEach(cb => { if (cb.checked) cb.click(); });
    showToast('↩️ Selection cleared');
    return;
  }

  // Find and click eBay's "End" or "End items" button in the bulk action bar
  const endBtn = Array.from(document.querySelectorAll('button, a[role="button"]')).find(btn => {
    const txt = (btn.textContent || '').trim().toLowerCase();
    return (txt === 'end' || txt === 'end items' || txt === 'end listings' ||
            txt.includes('end selected') || txt.includes('end item')) && !btn.disabled;
  });

  if (endBtn) {
    endBtn.click();
    showToast(`🗑️ Ending ${zeroCount} zero-performer listings...`);

    // Wait for confirmation dialog and click confirm
    setTimeout(() => {
      const confirmBtn = Array.from(document.querySelectorAll('button')).find(btn => {
        const txt = (btn.textContent || '').trim().toLowerCase();
        return (txt === 'end' || txt === 'confirm' || txt === 'end listings' || txt === 'end items') && !btn.disabled;
      });
      if (confirmBtn) {
        confirmBtn.click();
        showToast(`✅ Ended ${zeroCount} zero-performer listings`);
      }
    }, 2000);
  } else {
    showToast('⚠️ Could not find eBay\'s End button - try selecting items manually and using eBay\'s End option');
  }
}

// ═══════════════════════════════════════════════════════
// MUTATION OBSERVER - re-inject on page changes (SPA)
// ═══════════════════════════════════════════════════════
function observeChanges() {
  const target = document.querySelector('.sh-lst') || document.querySelector('#mainContent') || document.body;
  const observer = new MutationObserver(() => {
    // Debounce
    clearTimeout(observer._timer);
    observer._timer = setTimeout(() => injectButtons(), 500);
  });
  observer.observe(target, { childList: true, subtree: true });
}

// ═══════════════════════════════════════════════════════
// SEND OFFERS TO WATCHERS — P0-1
// ═══════════════════════════════════════════════════════
//
// Flow (sender → handler → effect):
//   popup.js btnSendWatcherOffers → opens /sh/lst/active?pill_status=sioEligible
//     → sends {type:'send-offers'} to this content script
//     → we tier-check via background `check_tier`
//     → show modal asking for offer % + auto-submit toggle
//     → for each visible row: click eBay's native "Send offer" link,
//       wait for modal, fill % field, optionally click Submit
//     → toast progress, log everything
//
// SAFETY: defaults to "fill only" (no auto-submit). User must enable
// auto-submit explicitly. This prevents mass-sending wrong offers if
// our selectors miss the right input.
//
// SELECTOR FRAGILITY: eBay seller hub uses obfuscated class names.
// Every selector has multiple candidates. Verbose console logs let
// you paste them back to dev to tighten if any miss.

const UDS_OFFERS = {
  STORAGE_KEY_LAST_PERCENT: 'unicornds_last_offer_percent',
  STORAGE_KEY_AUTO_SUBMIT: 'unicornds_offer_auto_submit',
  ROW_DELAY_MS: 2000,         // pause between listings (avoid rate-limit)
  MODAL_WAIT_MS: 4000,        // max wait for eBay's modal to appear
  MODAL_POLL_MS: 200,
  POST_SUBMIT_WAIT_MS: 1500,  // wait after submit before next row
};

// Find the per-row "Send offer" trigger using multiple candidates.
// Logs which selector matched so we can tighten in v2.
function findSendOfferTrigger(row) {
  const candidates = [
    'a[href*="action=sendOffer"]',
    'a[href*="sendOffer"]',
    'button[aria-label*="Send offer" i]',
    'a[aria-label*="Send offer" i]',
    '[data-test-id*="send-offer" i]',
    '[data-testid*="send-offer" i]',
  ];
  for (const sel of candidates) {
    const el = row.querySelector(sel);
    if (el) return { el, selector: sel };
  }
  // Fallback: any clickable element containing the literal text "Send offer"
  const all = row.querySelectorAll('a, button');
  for (const el of all) {
    const txt = (el.textContent || '').trim().toLowerCase();
    if (txt === 'send offer' || txt === 'send offers' || txt.startsWith('send offer')) {
      return { el, selector: 'text-match: "' + txt + '"' };
    }
  }
  return null;
}

// Wait for eBay's offer modal to appear after clicking the trigger.
// eBay typically renders a dialog/lightbox; we look for common containers.
function waitForOfferModal(timeoutMs = UDS_OFFERS.MODAL_WAIT_MS) {
  return new Promise((resolve) => {
    const deadline = Date.now() + timeoutMs;
    const dialogSelectors = [
      '[role="dialog"]',
      '[class*="dialog"][class*="open"]',
      '[class*="lightbox"]',
      '[class*="modal"][class*="open"]',
      '[class*="overlay"][aria-hidden="false"]',
      '[class*="lightbox-dialog"]',
    ];
    const timer = setInterval(() => {
      for (const sel of dialogSelectors) {
        const dialogs = document.querySelectorAll(sel);
        for (const d of dialogs) {
          // Filter: must be visible and contain offer-related text or input
          if (!d.offsetParent) continue;
          const innerTxt = (d.textContent || '').toLowerCase();
          const looksLikeOffer = innerTxt.includes('offer') || innerTxt.includes('discount');
          if (looksLikeOffer) {
            clearInterval(timer);
            console.log('[UnicornDS] Send Offers: modal appeared via', sel);
            resolve(d);
            return;
          }
        }
      }
      if (Date.now() > deadline) {
        clearInterval(timer);
        console.warn('[UnicornDS] Send Offers: modal did not appear within', timeoutMs, 'ms');
        resolve(null);
      }
    }, UDS_OFFERS.MODAL_POLL_MS);
  });
}

// Find the % discount input inside the offer modal.
function findDiscountInput(modal) {
  // Log everything in the modal for debugging
  const allInputs = modal.querySelectorAll('input, select, textarea');
  console.log('[UnicornDS] Send Offers: modal has', allInputs.length, 'input elements:');
  allInputs.forEach((inp, i) => {
    console.log(`[UnicornDS]   input[${i}]: type=${inp.type} name=${inp.name} id=${inp.id} placeholder=${inp.placeholder} class=${(inp.className || '').substring(0, 60)} value=${inp.value}`);
  });

  const candidates = [
    // Standard name/id matches
    'input[name*="discount" i]',
    'input[id*="discount" i]',
    'input[name*="offerPercent" i]',
    'input[name*="percentOff" i]',
    'input[name*="offer" i]',
    'input[name*="amount" i]',
    'input[name*="price" i]',
    // Type-based
    'input[type="number"]',
    'input[type="tel"]',
    // Placeholder matches
    'input[placeholder*="%" i]',
    'input[placeholder*="discount" i]',
    'input[placeholder*="amount" i]',
    'input[placeholder*="price" i]',
    'input[placeholder*="offer" i]',
    // Class-based (eBay common patterns)
    'input[class*="textbox" i]',
    'input[class*="field" i]',
    '.textbox__control',
    // Any visible text input as last resort
    'input[type="text"]',
    'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"])',
  ];

  for (const sel of candidates) {
    const els = modal.querySelectorAll(sel);
    for (const el of els) {
      // Skip hidden elements
      if (!el.offsetParent && getComputedStyle(el).display === 'none') continue;
      // Skip search/filter inputs
      if (el.name?.includes('search') || el.id?.includes('search') || el.placeholder?.toLowerCase().includes('search')) continue;
      console.log('[UnicornDS] Send Offers: found input via', sel, '→ name=', el.name, 'id=', el.id);
      return { el, selector: sel };
    }
  }

  // Try iframes inside modal (eBay sometimes embeds content)
  const iframes = modal.querySelectorAll('iframe');
  if (iframes.length) {
    console.log('[UnicornDS] Send Offers: modal has', iframes.length, 'iframes — inputs may be inside');
  }

  console.warn('[UnicornDS] Send Offers: no discount input found in modal');
  return null;
}

// Find the modal's submit/send button.
function findSubmitButton(modal) {
  const candidates = [
    'button[aria-label*="Send offer" i]:not([disabled])',
    'button[type="submit"]:not([disabled])',
    'button[aria-label*="Send" i]:not([disabled])',
  ];
  for (const sel of candidates) {
    const el = modal.querySelector(sel);
    if (el && el.offsetParent) return { el, selector: sel };
  }
  // Fallback: any non-disabled button with text "Send"
  const buttons = modal.querySelectorAll('button:not([disabled])');
  for (const b of buttons) {
    const txt = (b.textContent || '').trim().toLowerCase();
    if (txt === 'send offer' || txt === 'send' || txt === 'send offers') {
      return { el: b, selector: 'text-match: "' + txt + '"' };
    }
  }
  return null;
}

// Set an input's value in a way React/eBay's framework will pick up.
// Plain `el.value = x` sometimes doesn't trigger React's onChange.
function setInputValue(input, value) {
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  nativeSetter.call(input, String(value));
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new Event('blur', { bubbles: true }));
}

// Close the modal by pressing Escape (used after fill-only mode so we can move on).
function closeOfferModal(modal) {
  // Try ESC key first
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
  // Fallback: find and click a close button
  setTimeout(() => {
    if (!modal || !modal.offsetParent) return;
    const closeBtn = modal.querySelector('button[aria-label*="close" i], button[aria-label*="cancel" i], [class*="close-btn"]');
    if (closeBtn) closeBtn.click();
  }, 300);
}

async function processOneListingForOffer(row, percent, autoSubmit, idx, total) {
  const data = fetchEbayData(row);
  const label = data.itemNumber || `row-${idx}`;
  console.log(`[UnicornDS] Send Offers [${idx + 1}/${total}] processing item ${label} (${data.title || 'no title'})`);

  // 1. Find and click the row's native "Send offer" trigger
  const trigger = findSendOfferTrigger(row);
  if (!trigger) {
    console.warn(`[UnicornDS] Send Offers [${idx + 1}/${total}] no Send Offer link found in this row — skipped`);
    return { ok: false, reason: 'no-trigger', itemNumber: data.itemNumber };
  }
  console.log(`[UnicornDS] Send Offers [${idx + 1}/${total}] clicking trigger via ${trigger.selector}`);

  // Scroll into view so eBay's UI handlers fire correctly
  trigger.el.scrollIntoView({ behavior: 'instant', block: 'center' });
  await new Promise(r => setTimeout(r, 200));
  trigger.el.click();

  // 2. Wait for the offer modal
  const modal = await waitForOfferModal();
  if (!modal) {
    return { ok: false, reason: 'no-modal', itemNumber: data.itemNumber };
  }

  // 3. Find the % input and set it
  const input = findDiscountInput(modal);
  if (!input) {
    console.warn(`[UnicornDS] Send Offers [${idx + 1}/${total}] no discount input in modal`);
    closeOfferModal(modal);
    return { ok: false, reason: 'no-input', itemNumber: data.itemNumber };
  }
  console.log(`[UnicornDS] Send Offers [${idx + 1}/${total}] filling ${percent}% via ${input.selector}`);
  setInputValue(input.el, percent);
  await new Promise(r => setTimeout(r, 400));  // let React rerender

  // 4. Either auto-submit or pause for user
  if (!autoSubmit) {
    console.log(`[UnicornDS] Send Offers [${idx + 1}/${total}] SAFE MODE — modal filled, NOT submitting. Close it manually to continue, or enable Auto Mode.`);
    return { ok: true, reason: 'filled-only', itemNumber: data.itemNumber, paused: true };
  }

  const submit = findSubmitButton(modal);
  if (!submit) {
    console.warn(`[UnicornDS] Send Offers [${idx + 1}/${total}] no Submit button found`);
    closeOfferModal(modal);
    return { ok: false, reason: 'no-submit', itemNumber: data.itemNumber };
  }
  console.log(`[UnicornDS] Send Offers [${idx + 1}/${total}] submitting via ${submit.selector}`);
  submit.el.click();
  await new Promise(r => setTimeout(r, UDS_OFFERS.POST_SUBMIT_WAIT_MS));

  return { ok: true, reason: 'submitted', itemNumber: data.itemNumber };
}

async function runBulkSendOffers(percent, autoSubmit) {
  const rows = getListingRows();
  console.log(`[UnicornDS] Send Offers: starting bulk run on ${rows.length} listings, ${percent}% offer, autoSubmit=${autoSubmit}`);
  if (rows.length === 0) {
    showOffersToast('⚠️ No listings found. Make sure the page loaded fully.', 4000);
    return;
  }

  showOffersToast(`📣 Sending ${percent}% offers to ${rows.length} watchers... (check service worker console for progress)`, 6000);

  let sent = 0, failed = 0, pausedForUser = 0;
  for (let i = 0; i < rows.length; i++) {
    try {
      const result = await processOneListingForOffer(rows[i], percent, autoSubmit, i, rows.length);
      if (result.ok) {
        if (result.paused) pausedForUser++;
        else sent++;
      } else {
        failed++;
      }
      // In safe mode, give the user a few seconds to inspect/click submit
      const waitMs = autoSubmit ? UDS_OFFERS.ROW_DELAY_MS : 8000;
      await new Promise(r => setTimeout(r, waitMs));
    } catch (err) {
      console.error(`[UnicornDS] Send Offers row ${i + 1} crashed:`, err);
      failed++;
    }
  }

  const summary = autoSubmit
    ? `✅ Send Offers complete: ${sent} sent, ${failed} failed`
    : `🐢 Safe mode complete: ${pausedForUser} modals filled (you submit), ${failed} failed`;
  console.log('[UnicornDS] Send Offers:', summary);
  showOffersToast(summary, 8000);
}

function showOffersToast(text, durationMs = 4000) {
  // Reuse existing .uds-toast styles defined by injectStyles()
  const toast = document.createElement('div');
  toast.className = 'uds-toast';
  toast.innerHTML = `<span class="emoji">📣</span>${text}`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), durationMs);
}

function showSendOffersModal(defaultPercent, defaultAutoSubmit) {
  // Remove any existing modal first
  document.getElementById('uds-offers-modal')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'uds-offers-modal';
  overlay.style.cssText = `
    position: fixed; inset: 0; background: rgba(15,15,26,0.7);
    z-index: 9999999; display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  `;

  overlay.innerHTML = `
    <div style="background:#1E1B4B;color:#fff;border-radius:12px;border:2px solid #7C3AED;
                padding:24px;max-width:420px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,0.5);">
      <div style="font-size:18px;font-weight:700;margin-bottom:8px;color:#F59E0B;">
        📣 Send Offers to Watchers
      </div>
      <div style="font-size:13px;opacity:0.85;margin-bottom:18px;line-height:1.5;">
        UnicornDS will walk through each eligible listing on this page and open eBay's
        Send Offer modal with your % pre-filled.
      </div>

      <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">
        Discount % to offer
      </label>
      <input id="uds-offer-percent" type="number" min="1" max="50" step="1" value="${defaultPercent}"
             style="width:100%;padding:10px 12px;font-size:16px;border-radius:8px;border:1px solid #7C3AED;
                    background:#0F0F1A;color:#fff;margin-bottom:16px;box-sizing:border-box;">

      <label style="display:flex;align-items:flex-start;gap:8px;font-size:13px;cursor:pointer;
                    padding:10px;background:#0F0F1A;border-radius:8px;margin-bottom:18px;">
        <input id="uds-offer-auto" type="checkbox" ${defaultAutoSubmit ? 'checked' : ''}
               style="margin-top:2px;width:16px;height:16px;cursor:pointer;">
        <span>
          <strong>⚡ Auto-submit each offer</strong><br>
          <span style="opacity:0.75;font-size:12px;">
            UNCHECKED (recommended first run): just fills the % field, you click Send.
            CHECKED: also clicks Send automatically. Only use after you've verified one offer works.
          </span>
        </span>
      </label>

      <div style="display:flex;gap:10px;justify-content:flex-end;">
        <button id="uds-offer-cancel" style="padding:10px 18px;background:transparent;color:#fff;
                border:1px solid #555;border-radius:8px;cursor:pointer;font-size:14px;">Cancel</button>
        <button id="uds-offer-go" style="padding:10px 22px;background:#7C3AED;color:#fff;
                border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:700;">
          Start Sending
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  document.getElementById('uds-offer-cancel').onclick = () => overlay.remove();
  overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
  document.getElementById('uds-offer-go').onclick = () => {
    const percent = Math.max(1, Math.min(50, parseInt(document.getElementById('uds-offer-percent').value, 10) || defaultPercent));
    const autoSubmit = document.getElementById('uds-offer-auto').checked;
    chrome.storage.local.set({
      [UDS_OFFERS.STORAGE_KEY_LAST_PERCENT]: percent,
      [UDS_OFFERS.STORAGE_KEY_AUTO_SUBMIT]: autoSubmit,
    });
    overlay.remove();
    runBulkSendOffers(percent, autoSubmit);
  };
}

async function handleSendOffersMessage() {
  console.log('[UnicornDS] Send Offers: message received');

  // 1. Tier-check via background
  const tierCheck = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'check_tier', action: 'send_offers' }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ allowed: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response || { allowed: false, error: 'No response from background' });
      }
    });
  });

  if (!tierCheck.allowed) {
    console.warn('[UnicornDS] Send Offers blocked:', tierCheck.error);
    showOffersToast(`⛔ ${tierCheck.error || 'Send Offers requires Growth plan or above.'}`, 6000);
    return;
  }

  // 2. Verify we're on the right page
  if (!location.search.includes('sioEligible') && !location.pathname.includes('/lst/active')) {
    showOffersToast('⚠️ Open the "Eligible for offers" filter on Active Listings first.', 5000);
    return;
  }

  // 3. Show config modal with last-used preferences
  const stored = await new Promise(resolve =>
    chrome.storage.local.get([UDS_OFFERS.STORAGE_KEY_LAST_PERCENT, UDS_OFFERS.STORAGE_KEY_AUTO_SUBMIT], resolve)
  );
  const defaultPercent = stored[UDS_OFFERS.STORAGE_KEY_LAST_PERCENT] || 10;
  const defaultAutoSubmit = !!stored[UDS_OFFERS.STORAGE_KEY_AUTO_SUBMIT];

  showSendOffersModal(defaultPercent, defaultAutoSubmit);
}

// ═══════════════════════════════════════════════════════
// LISTEN FOR MESSAGES FROM BACKGROUND / POPUP
// ═══════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'get_active_listings_data') {
    // Return all listing data from page
    const rows = getListingRows();
    const listings = rows.map(r => fetchEbayData(r)).filter(d => d.itemNumber);
    sendResponse({ listings });
    return true;
  }

  // P0-1: Send Offers to Watchers
  if (msg.type === 'send-offers') {
    handleSendOffersMessage();
    sendResponse({ received: true });
    return false;
  }

  // P0-2: Review Offers (auto-accept/decline based on markup)
  if (msg.type === 'review_offers') {
    handleReviewOffersMessage();
    sendResponse({ received: true });
    return false;
  }
});

// ═══════════════════════════════════════════════════════
// REVIEW OFFERS — P0-2
// ═══════════════════════════════════════════════════════
//
// Flow: popup → background (uds_open_ebay_and_dispatch) → opens
// /sh/lst/active?status=PENDING_OFFERS → sends 'review_offers' here.
// We walk visible rows, find each offer link, and dispatch each to
// background's existing `review_pending_offer` handler which opens
// the offer page, scrapes it, calculates markup, and clicks
// accept/decline.

function findOfferReviewLink(row) {
  const candidates = [
    'a[href*="PENDING_OFFER"]',
    'a[href*="pendingOffer"]',
    'a[href*="reviewOffer"]',
    'a[href*="/offers/"]',
    'a[href*="offer"]',
    'button[aria-label*="Review offer" i]',
    'a[aria-label*="Review offer" i]',
    '[data-test-id*="review-offer" i]',
  ];
  for (const sel of candidates) {
    const el = row.querySelector(sel);
    if (el) {
      const href = el.getAttribute('href');
      if (href) return { url: href.startsWith('http') ? href : 'https://www.ebay.co.uk' + href, selector: sel };
    }
  }
  // Fallback: text match
  const links = row.querySelectorAll('a');
  for (const a of links) {
    const txt = (a.textContent || '').trim().toLowerCase();
    if (txt.includes('review') || txt.includes('offer') || txt.includes('respond')) {
      const href = a.getAttribute('href');
      if (href) return { url: href.startsWith('http') ? href : 'https://www.ebay.co.uk' + href, selector: 'text:"' + txt + '"' };
    }
  }
  return null;
}

function showReviewOffersModal(defaultMarkup) {
  document.getElementById('uds-review-modal')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'uds-review-modal';
  overlay.style.cssText = `
    position: fixed; inset: 0; background: rgba(15,15,26,0.7);
    z-index: 9999999; display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  `;

  overlay.innerHTML = `
    <div style="background:#1E1B4B;color:#fff;border-radius:12px;border:2px solid #7C3AED;
                padding:24px;max-width:420px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,0.5);">
      <div style="font-size:18px;font-weight:700;margin-bottom:8px;color:#F59E0B;">
        📋 Review Pending Offers
      </div>
      <div style="font-size:13px;opacity:0.85;margin-bottom:18px;line-height:1.5;">
        UnicornDS will open each pending offer, check the margin against your SKU cost data,
        and <strong>auto-accept</strong> if markup is above your threshold or
        <strong>auto-decline</strong> if below. If no cost data exists, accepts if offer ≥ 70% of listing price.
      </div>

      <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">
        Minimum markup % to accept
      </label>
      <input id="uds-review-markup" type="number" min="10" max="200" step="5" value="${defaultMarkup}"
             style="width:100%;padding:10px 12px;font-size:16px;border-radius:8px;border:1px solid #7C3AED;
                    background:#0F0F1A;color:#fff;margin-bottom:18px;box-sizing:border-box;">

      <div style="display:flex;gap:10px;justify-content:flex-end;">
        <button id="uds-review-cancel" style="padding:10px 18px;background:transparent;color:#fff;
                border:1px solid #555;border-radius:8px;cursor:pointer;font-size:14px;">Cancel</button>
        <button id="uds-review-go" style="padding:10px 22px;background:#7C3AED;color:#fff;
                border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:700;">
          Start Reviewing
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  document.getElementById('uds-review-cancel').onclick = () => overlay.remove();
  overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
  document.getElementById('uds-review-go').onclick = () => {
    const markup = Math.max(10, Math.min(200, parseInt(document.getElementById('uds-review-markup').value, 10) || defaultMarkup));
    chrome.storage.local.set({ unicornds_last_review_markup: markup });
    overlay.remove();
    runBulkReviewOffers(markup);
  };
}

async function runBulkReviewOffers(markupPercent) {
  const rows = getListingRows();
  console.log(`[UnicornDS] Review Offers: starting on ${rows.length} rows, min markup ${markupPercent}%`);
  if (rows.length === 0) {
    showOffersToast('⚠️ No listings found. Make sure the page loaded fully.', 4000);
    return;
  }

  showOffersToast(`📋 Reviewing offers on ${rows.length} listings... Check service worker console for decisions.`, 6000);

  let accepted = 0, declined = 0, skipped = 0, errors = 0;
  for (let i = 0; i < rows.length; i++) {
    const data = fetchEbayData(rows[i]);
    const label = data.itemNumber || `row-${i}`;
    console.log(`[UnicornDS] Review Offers [${i + 1}/${rows.length}] item ${label}`);

    const link = findOfferReviewLink(rows[i]);
    if (!link) {
      console.warn(`[UnicornDS] Review Offers [${i + 1}/${rows.length}] no offer link found — skipped`);
      skipped++;
      continue;
    }
    console.log(`[UnicornDS] Review Offers [${i + 1}/${rows.length}] sending to background: ${link.url} (via ${link.selector})`);

    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage({
          type: 'review_pending_offer',
          url: link.url,
          options: { markupPercent, keepTabOpen: false }
        }, (res) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
          } else {
            resolve(res || { success: false, error: 'No response' });
          }
        });
      });

      if (result.success) {
        if (result.action === 'accept') accepted++;
        else if (result.action === 'decline') declined++;
        console.log(`[UnicornDS] Review Offers [${i + 1}/${rows.length}] ${result.action}: ${result.reason}`);
      } else {
        errors++;
        console.warn(`[UnicornDS] Review Offers [${i + 1}/${rows.length}] error: ${result.error}`);
      }
    } catch (e) {
      errors++;
      console.error(`[UnicornDS] Review Offers [${i + 1}/${rows.length}] crash:`, e);
    }

    // Pause between offers
    await new Promise(r => setTimeout(r, 2000));
  }

  const summary = `📋 Review complete: ✅${accepted} accepted, ❌${declined} declined, ⏭️${skipped} skipped, ⚠️${errors} errors`;
  console.log('[UnicornDS]', summary);
  showOffersToast(summary, 10000);
}

async function handleReviewOffersMessage() {
  console.log('[UnicornDS] Review Offers: message received');

  // Tier check — reuse send_offers gate (same tier requirement)
  const tierCheck = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'check_tier', action: 'send_offers' }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ allowed: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response || { allowed: false, error: 'No response from background' });
      }
    });
  });

  if (!tierCheck.allowed) {
    console.warn('[UnicornDS] Review Offers blocked:', tierCheck.error);
    showOffersToast(`⛔ ${tierCheck.error || 'Review Offers requires Growth plan or above.'}`, 6000);
    return;
  }

  // Get saved markup preference
  const stored = await new Promise(resolve =>
    chrome.storage.local.get(['unicornds_last_review_markup'], resolve)
  );
  const defaultMarkup = stored.unicornds_last_review_markup || 60;

  showReviewOffersModal(defaultMarkup);
}

// ═══════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════
async function init() {
  // Auth check — don't inject buttons if not logged in
  const _s = await new Promise(r => chrome.storage.local.get('unicornds_session', r));
  if (!_s?.unicornds_session?.idToken) {
    console.log('[UnicornDS] Not logged in — active listing buttons not injected');
    return;
  }

  injectStyles();
  await loadTrackerQueue();
  createTrackerBar();

  // Wait for listing table to render
  let attempts = 0;
  const waitForRows = setInterval(() => {
    const rows = getListingRows();
    if (rows.length > 0 || attempts > 30) {
      clearInterval(waitForRows);
      injectButtons();
      observeChanges();
      console.log('[UnicornDS] Injected buttons into', rows.length, 'listings');
    }
    attempts++;
  }, 1000);
}

// Run when DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
