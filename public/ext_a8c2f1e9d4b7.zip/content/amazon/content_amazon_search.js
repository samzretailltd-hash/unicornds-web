/**
 * UnicornDS - Amazon Search Page Scraper
 * Based on 's proven selectors and extraction logic
 */

console.log('[UnicornDS] Amazon search scraper loaded');

(function() {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'hunter_scrape_search') {
      console.log('[UnicornDS] Scraping Amazon search results...');
      const results = scrapeSearchResults(msg.settings || {});
      console.log('[UnicornDS] Scraped', results.length, 'products, sample:', results[0]);
      sendResponse({ products: results });
    }
    return true;
  });

  // ═══════════════════════════════════════
  // NUMBER PARSER
  // Handles: "1,234" "1.234" "12K" "12k" "(1,234)"
  // ═══════════════════════════════════════
  function parseNumber(raw) {
    if (!raw) return 0;
    raw = raw.replace(/[^\d.,-]/g, '');
    if (!raw) return 0;

    let negative = false;
    if (raw.startsWith('-')) { negative = true; raw = raw.substring(1); }

    let decimalSep = '.', thousandSep = ',';
    if (raw.includes('.') && raw.includes(',')) {
      if (raw.indexOf(',') < raw.indexOf('.')) { decimalSep = '.'; thousandSep = ','; }
      else { decimalSep = ','; thousandSep = '.'; }
    } else if (raw.includes('.')) {
      const parts = raw.split('.');
      if (parts[parts.length - 1].length === 3) { thousandSep = '.'; decimalSep = ''; }
    } else if (raw.includes(',')) {
      const parts = raw.split(',');
      if (parts[parts.length - 1].length === 3) { thousandSep = ','; decimalSep = ''; }
      else { decimalSep = ','; thousandSep = ''; }
    }

    if (thousandSep) raw = raw.replace(new RegExp('\\' + thousandSep, 'g'), '');
    if (decimalSep && decimalSep !== '.') raw = raw.replace(new RegExp('\\' + decimalSep, 'g'), '.');

    let result = parseFloat(raw);
    if (negative) result = -result;
    return isNaN(result) ? 0 : result;
  }

  // ═══════════════════════════════════════
  // REVIEW COUNT
  // ═══════════════════════════════════════
  function extractReviewCount(card) {
    let count = 0;
    try {
      // 's exact selector chain:
      let el = card.querySelector('span.a-size-base.s-underline-text');
      if (!el) el = card.querySelector('[data-cy="reviews-block"] a[aria-label$="ratings"]');
      if (!el) el = card.querySelector('[data-cy="reviews-block"] div[data-csa-c-content-id*="ratings"]');
      if (!el) el = card.querySelector('[data-cy="reviews-block"] a[aria-label*="beoordelingen"]');
      // Fallback: last <a> in reviews block
      if (!el) {
        const links = card.querySelectorAll('[data-cy="reviews-block"] a');
        if (links.length > 0) el = links[links.length - 1];
      }

      if (el && el.textContent.trim() !== '') {
        let text = el.textContent.trim();
        text = text.replace(/\s+|\(|\)/g, '');
        let multiplier = 1;
        if (/[Kk]$/.test(text)) { multiplier = 1000; text = text.slice(0, -1); }
        count = parseNumber(text) * multiplier;
        count = isNaN(count) ? 0 : Math.round(count);
      }
    } catch (e) {
      console.error('[UnicornDS] Error extracting reviews:', e);
    }
    return count;
  }

  // ═══════════════════════════════════════
  // PRICE
  // ═══════════════════════════════════════
  function extractPrice(card) {
    const wholeEl = card.querySelector('.a-price-whole');
    if (!wholeEl) return null;

    let priceText = wholeEl.innerText.replace(/,/g, '');
    priceText = priceText.replace(/\./g, '').replace(/\$/g, '').replace(/\n/g, '');

    const fracEl = card.querySelector('.a-price-fraction');
    if (fracEl) priceText = priceText + '.' + fracEl.innerText;
    priceText = priceText.replace(/,/g, '');

    return parseFloat(priceText);
  }

  // ═══════════════════════════════════════
  // TITLE
  // ═══════════════════════════════════════
  function extractTitle(card) {
    let title = '';
    try {
      const el = card.querySelector('.s-title-instructions-style');
      if (el) title = el.innerText.replace(/\n/g, ' ').trim();
    } catch (e) {}
    // Fallback
    if (!title) {
      const h2 = card.querySelector('h2 a span') || card.querySelector('h2 span');
      if (h2) title = h2.textContent.trim();
    }
    return title;
  }

  // ═══════════════════════════════════════
  // IMAGE
  // ═══════════════════════════════════════
  function extractImage(card) {
    try {
      const img = card.querySelector('img.s-image');
      if (img) return img.src;
    } catch (e) {}
    return '';
  }

  // ═══════════════════════════════════════
  // ASIN
  // ═══════════════════════════════════════
  function extractAsin(card) {
    return card.getAttribute('data-asin') || '';
  }

  // ═══════════════════════════════════════
  // FILTER SPONSORED (from  filterSponsoredCards)
  // ═══════════════════════════════════════
  function isSponsored(card) {
    return !!card.querySelector('.puis-sponsored-label-text');
  }

  // ═══════════════════════════════════════
  // MAIN SCRAPER
  // ═══════════════════════════════════════
  function scrapeSearchResults(settings) {
    const maxProducts = settings.productsPerTerm || 10;

    // Get all result cards -  uses .s-result-item
    let cards = Array.from(document.querySelectorAll('.s-result-item'));
    console.log('[UnicornDS] Found', cards.length, 'raw cards');

    // Filter out sponsored
    cards = cards.filter(c => !isSponsored(c));
    console.log('[UnicornDS] After sponsored filter:', cards.length);

    // Filter cards that have ASINs
    cards = cards.filter(c => {
      const asin = extractAsin(c);
      return asin && asin !== '';
    });
    console.log('[UnicornDS] After ASIN filter:', cards.length);

    // Extract products
    const products = [];
    for (const card of cards) {
      if (products.length >= maxProducts) break;

      const asin = extractAsin(card);
      const title = extractTitle(card);
      const price = extractPrice(card);
      const reviewCount = extractReviewCount(card);
      const image = extractImage(card);

      if (!title || !asin) continue;

      // Rating
      let rating = 0;
      const ratingEl = card.querySelector('[aria-label*="out of"]') ||
                       card.querySelector('span[aria-label*="stars"]') ||
                       card.querySelector('i[data-cy="reviews-ratings-slot"] span');
      if (ratingEl) {
        const m = (ratingEl.getAttribute('aria-label') || '').match(/([\d.]+)/);
        if (m) rating = parseFloat(m[1]);
      }

      // Badges
      const isAmazonChoice = !!card.querySelector('[id*="-amazons-choice-label"]') ||
                             !!card.querySelector('[data-component-type="s-status-badge-component"]');
      const isBestSeller = !!card.querySelector('[id*="-best-seller"]') ||
                           !!card.querySelector('.a-badge-text');

      // URL
      const linkEl = card.querySelector('h2 a') || card.querySelector('a.a-text-normal');
      const url = linkEl ? linkEl.href : '';

      // Prime badge
      const hasPrime = !!card.querySelector('.a-icon-prime, i.a-icon-prime, [data-component-type="s-prime-widget"]');

      // Stock hints from search results (Amazon sometimes shows these)
      let stockHint = '';
      const stockEl = card.querySelector('.a-size-base.a-color-price, [class*="stock"], [class*="left-in"]');
      if (stockEl) {
        const st = stockEl.textContent.trim().toLowerCase();
        if (st.includes('left in stock') || st.includes('only')) stockHint = stockEl.textContent.trim();
      }
      // Also check for "bought in past month"
      let boughtText = '';
      const boughtEl = card.querySelector('[class*="social-proofing"], [class*="bought"]');
      if (boughtEl) boughtText = boughtEl.textContent.trim();

      // Delivery info - can hint at seller type
      const deliveryEl = card.querySelector('[data-cy="delivery-recipe"], .a-row.a-size-base.a-color-secondary');
      const deliveryText = deliveryEl ? deliveryEl.textContent.trim() : '';

      products.push({
        asin, title, price, image, reviewCount, rating,
        isAmazonChoice, isBestSeller, url,
        isSponsored: false,
        currencySymbol: '£',
        prime: hasPrime,
        stockHint,
        boughtText,
      });
    }

    console.log('[UnicornDS] Extracted', products.length, 'products');

    // Sort by review count descending - best products first
    products.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));

    if (products.length > 0) {
      console.log('[UnicornDS] Best match:', products[0].title, '| reviews:', products[0].reviewCount);
    }
    return products;
  }
})();
