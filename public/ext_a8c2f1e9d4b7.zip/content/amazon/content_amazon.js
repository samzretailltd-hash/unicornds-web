/**
 * UnicornDS - Amazon Product Page Scraper
 * Exact  approach: selectors, image extraction, price, brand, specs
 */

console.log('[UnicornDS] Amazon product scraper loaded');

let lastScrapedData = null;

// ═══════════════════════════════════════════════════════
// TITLE
// ═══════════════════════════════════════════════════════
function getTitle() {
  const el = document.querySelector('#productTitle') ||
             document.querySelector('#ebooksProductTitle') ||
             document.querySelector('h1.product-name');
  return el ? el.textContent.trim() : '';
}

function getBrand() {
  // : findSpecific('brand'), then #bylineInfo, then #brand
  let brand = findSpecific('brand') || findSpecific('marke') || '';
  if (!brand) {
    const el = document.querySelector('#bylineInfo') ||
               document.querySelector('#brand') ||
               document.querySelector('#merchant-info .a-link-normal');
    if (el) {
      brand = el.textContent.trim();
      brand = brand.replace(/Brand:\s*/i, '').replace(/brand/i, '').replace(/:/g, '').trim();
      if (brand.includes('Visit the')) {
        brand = brand.substring(brand.indexOf('Visit the') + 9, brand.indexOf('Store')).trim();
      }
    }
  }
  return brand || 'Unbranded';
}

function getFilteredTitle() {
  let title = getTitle();
  const brand = getBrand();
  if (brand && brand !== 'Unbranded' && brand !== 'DoesNotExist') {
    // Remove brand from title (case insensitive)
    title = title.replace(new RegExp(brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '').trim();
    // Remove brand without spaces
    title = title.replace(new RegExp(brand.replace(/\s/g, ''), 'gi'), '').trim();
  }
  // Clean up
  title = title.replace(/®|™|©/g, '')
    .replace(/amazonbasics/gi, '').replace(/amazon basics/gi, '')
    .replace(/\s\s+/g, ' ').replace(/warranty/gi, '')
    .replace(/made in usa/gi, '').replace(/united states/gi, '')
    .replace(/^\s*-\s*/, '').trim();
  // Remove model numbers like ABC123...
  title = title.replace(/\b([A-Z]{3}[0-9].*?)\b/g, '').replace(/\s\s+/g, ' ').trim();
  return title;
}

// ═══════════════════════════════════════════════════════
// PRICE - 's exact selector chain
// ═══════════════════════════════════════════════════════
function getPrice() {
  const el = document.getElementById('price_inside_buybox') ||
             document.getElementById('newBuyBoxPrice') ||
             document.getElementById('priceblock_ourprice') ||
             document.getElementById('priceblock_saleprice') ||
             document.getElementById('buyNewSection') ||
             document.getElementById('buyNew_noncbb') ||
             document.getElementById('priceblock_dealprice') ||
             document.getElementById('usedBuyBoxPrice') ||
             document.getElementById('tp_price_block_total_price_ww') ||
             document.getElementById('apex_offerDisplay_desktop') ||
             document.getElementById('corePrice_desktop');
  if (!el) return 0;
  let text = el.innerText || '';
  // Handle Euro format
  if (text.includes('€')) {
    text = text.replace(',', '.');
    const m = text.match(/\d{1,5}\.\d{0,2}/);
    return m ? parseFloat(m[0]) : 0;
  }
  text = text.replace(/CDN\$\s*/g, '').replace(/,/g, '');
  const m = text.match(/\d{1,5}\.\d{0,2}/);
  return m ? parseFloat(m[0]) : 0;
}

// ═══════════════════════════════════════════════════════
// ASIN
// ═══════════════════════════════════════════════════════
function getASIN() {
  const el = document.getElementById('ASIN');
  if (el) return el.value;
  const metas = document.getElementsByTagName('meta');
  for (let i = 0; i < metas.length; i++) {
    if (metas[i].getAttribute('name') === 'ASIN') return metas[i].getAttribute('content');
  }
  const m = window.location.href.match(/\/dp\/([A-Z0-9]{10})/);
  return m ? m[1] : 'unknown';
}

// ═══════════════════════════════════════════════════════
// IMAGES - : colorImages.initial[].hiRes
// ═══════════════════════════════════════════════════════
function getImages() {
  let urls = [];

  // Method 1: Regex extract hiRes URLs from page scripts
  try {
    const scripts = document.querySelectorAll('script');
    for (const s of scripts) {
      if (s.innerHTML.includes('colorImages') || s.innerHTML.includes('imageGalleryData')) {
        const hiRes = s.innerHTML.match(/"hiRes"\s*:\s*"(https?:\/\/[^"]+)"/g);
        if (hiRes) {
          for (const m of hiRes) {
            const u = m.match(/"(https?:\/\/[^"]+)"/);
            if (u) urls.push(u[1]);
          }
        }
        if (!urls.length) {
          const large = s.innerHTML.match(/"large"\s*:\s*"(https?:\/\/[^"]+)"/g);
          if (large) {
            for (const m of large) {
              const u = m.match(/"(https?:\/\/[^"]+)"/);
              if (u) urls.push(u[1]);
            }
          }
        }
        if (!urls.length) {
          const mainUrl = s.innerHTML.match(/"mainUrl"\s*:\s*"(https?:\/\/[^"]+)"/g);
          if (mainUrl) {
            for (const m of mainUrl) {
              const u = m.match(/"(https?:\/\/[^"]+)"/);
              if (u) urls.push(u[1]);
            }
          }
        }
        if (urls.length) break;
      }
    }
  } catch (e) {}

  // Method 2: data-old-hires
  if (!urls.length) {
    document.querySelectorAll('.imgTagWrapper img').forEach(img => {
      const hr = img.getAttribute('data-old-hires');
      if (hr) urls.push(hr);
    });
  }

  // Method 3: Landing image
  if (!urls.length) {
    const landing = document.querySelector('#landingImage, #imgBlkFront');
    if (landing && landing.src) urls.push(landing.src);
  }

  // Force hi-res: replace any size suffix with _UL1500_
  urls = urls.map(u => u.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.'));
  urls = [...new Set(urls)];
  console.log('[UnicornDS] Amazon images:', urls.length);
  return urls;
}

// ═══════════════════════════════════════════════════════
// VARIANT IMAGES - per-color/variant image mapping
// ═══════════════════════════════════════════════════════
function getVariantImageMap() {
  const variantImages = {};
  try {
    const scripts = document.querySelectorAll('script');
    for (const s of scripts) {
      const text = s.innerHTML;
      if (!text.includes('colorImages')) continue;

      // Extract the colorImages JSON object
      // Amazon format: 'colorImages': { "Color1": [{ hiRes: "url" }], "Color2": [...] }
      const allColors = text.match(/"([^"]{2,40})"\s*:\s*\[\s*\{[^}]*?"hiRes"/g);
      if (allColors) {
        for (const block of allColors) {
          const nameMatch = block.match(/"([^"]+)"\s*:/);
          if (!nameMatch || nameMatch[1] === 'initial') continue;
          const colorName = nameMatch[1];

          // Now find ALL hiRes URLs for this color block
          // Search forward from this position in the text
          const startIdx = text.indexOf('"' + colorName + '"');
          if (startIdx < 0) continue;
          const chunk = text.substring(startIdx, startIdx + 3000);
          const hiResMatches = chunk.match(/"hiRes"\s*:\s*"(https?:\/\/[^"]+)"/g);
          if (hiResMatches) {
            const urls = hiResMatches.map(m => {
              const u = m.match(/"(https?:\/\/[^"]+)"/);
              return u ? u[1].replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.') : null;
            }).filter(Boolean);
            if (urls.length > 0) variantImages[colorName] = urls;
          }
        }
      }

      // Fallback: swatch images
      if (Object.keys(variantImages).length === 0) {
        document.querySelectorAll('#variation_color_name li, [id*="color"] li').forEach(li => {
          const img = li.querySelector('img');
          const name = img?.getAttribute('alt') || li.getAttribute('title') || '';
          const src = img?.src;
          if (name && src) {
            variantImages[name] = [src.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.')];
          }
        });
      }
      break;
    }
  } catch(e) { console.warn('[UnicornDS] Variant image error:', e.message); }
  console.log('[UnicornDS] Variant images:', Object.keys(variantImages).length, 'colors');
  return variantImages;
}

// ═══════════════════════════════════════════════════════
// BULLET POINTS - : #feature-bullets
// ═══════════════════════════════════════════════════════
function getBulletPoints() {
  const list = [];
  let html = '';

  const fb = document.querySelector('#feature-bullets');
  if (fb) {
    html = fb.innerHTML;
    const items = fb.querySelectorAll('li span.a-list-item');
    for (const item of items) {
      const text = item.textContent.trim();
      if (text && !text.toLowerCase().includes('this fits')) {
        list.push(text);
      }
    }
  }

  // Fallback: productFactsDesktopExpander
  if (!html) {
    const pf = document.querySelector('#productFactsDesktopExpander');
    if (pf) {
      const lis = pf.querySelectorAll('li');
      for (const li of lis) {
        const t = li.innerText?.trim();
        if (t) list.push(t);
      }
    }
  }

  return { list, html };
}

// ═══════════════════════════════════════════════════════
// DESCRIPTION
// ═══════════════════════════════════════════════════════
function getDescriptionHTML() {
  const selectors = [
    '#descriptionAndDetails', '#productDescription', '#productDescription_feature_div',
    '#productFactsDesktop_feature_div', '#aplus', '#detail-bullets',
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && el.innerText.trim()) return el.innerHTML;
  }
  return '';
}

function getDescriptionText() {
  const html = getDescriptionHTML();
  if (!html) return '';
  const div = document.createElement('div');
  div.innerHTML = html;
  let text = div.textContent.trim();
  if (text.toLowerCase() === 'product description') return '';
  return text;
}

// ═══════════════════════════════════════════════════════
// ITEM SPECIFICS - : multiple table selectors
// ═══════════════════════════════════════════════════════
function getItemSpecifics() {
  const specs = [];
  const seen = new Set();

  function add(label, value) {
    label = label.replace(/[\u200e\u200f‎]/g, '').replace(/:/g, '').trim().toLowerCase();
    value = value.replace(/[\u200e\u200f‎]/g, '').replace(/\s+$/g, '').trim();
    if (label && value && !seen.has(label)) {
      seen.add(label);
      specs.push({ label, value });
    }
  }

  // detailBullets_feature_div
  document.querySelectorAll('div#detailBullets_feature_div li span.a-list-item').forEach(el => {
    const spans = el.querySelectorAll('span');
    if (spans.length >= 2) add(spans[0].innerText, spans[1].innerText);
  });

  // prodDetails tables
  document.querySelectorAll('div#prodDetails tr').forEach(tr => {
    const th = tr.querySelector('th') || tr.querySelector('td.label');
    const td = tr.querySelector('td.value') || tr.querySelectorAll('td')[1];
    if (th && td) add(th.innerText, td.innerText);
  });

  // productOverview_feature_div
  document.querySelectorAll('div#productOverview_feature_div tr').forEach(tr => {
    const tds = tr.querySelectorAll('td');
    if (tds.length >= 2) add(tds[0].innerText, tds[1].innerText);
  });

  // poExpander
  document.querySelectorAll('#poExpander div[class*="po-"]').forEach(el => {
    const spans = el.querySelectorAll('span');
    if (spans.length >= 2) add(spans[0].innerText, spans[1].innerText);
  });

  // a-keyvalue tables
  document.querySelectorAll('table.a-keyvalue.prodDetTable tr').forEach(tr => {
    const th = tr.querySelector('th');
    const td = tr.querySelector('td');
    if (th && td) add(th.innerText, td.innerText);
  });

  // Product facts
  document.querySelectorAll('.a-fixed-left-grid.product-facts-detail .a-fixed-left-grid-inner').forEach(el => {
    const l = el.querySelector('.a-col-left');
    const r = el.querySelector('.a-col-right');
    if (l && r) add(l.innerText, r.innerText);
  });

  // Variation selectors
  document.querySelectorAll('[id^="variation_"]').forEach(el => {
    const label = el.querySelector('.a-form-label');
    const val = el.querySelector('.selection') || el.querySelector('.a-dropdown-prompt');
    if (label && val) add(label.innerText, val.innerText);
  });

  return specs;
}

function getFilteredItemSpecifics() {
  const specs = getItemSpecifics();
  const exclude = ['model','amazon','asin','customer','date','rank','brand','mpn',
    'model-number','part number','manufacture','business','origin','country','place',
    'seller','import','store','warranty'];
  return specs.filter(s => !exclude.some(ex => s.label.includes(ex)));
}

function getTableSpecifics() {
  const specs = [];
  try {
    const table = document.querySelector('#productDetails_techSpec_section_1') ||
                  document.querySelector('div#prodDetails .pdTab');
    if (!table) return specs;
    const rows = table.querySelectorAll('tr');
    for (const row of rows) {
      const th = row.querySelector('th');
      const td = row.querySelector('td');
      if (th && td) {
        const label = th.innerText.trim();
        const value = td.innerText.trim();
        if (!label.toLowerCase().includes('asin') && !label.toLowerCase().includes('amazon') &&
            !label.toLowerCase().includes('rank') && !label.toLowerCase().includes('date')) {
          specs.push({ label, value });
        }
      }
    }
  } catch (e) {}
  return specs;
}

function findSpecific(key) {
  const specs = getItemSpecifics();
  const found = specs.find(s => s.label === key.toLowerCase());
  return found ? found.value : '';
}

// ═══════════════════════════════════════════════════════
// CATEGORIES
// ═══════════════════════════════════════════════════════
function getCategories() {
  const cats = [];
  try {
    const links = document.getElementById('wayfinding-breadcrumbs_feature_div')?.querySelectorAll('a.a-link-normal') || [];
    for (const link of links) {
      if (link.id !== 'breadcrumb-back-link') cats.push(link.innerText.trim());
    }
  } catch (e) {}
  return cats;
}

// ═══════════════════════════════════════════════════════
// VARIATIONS - extract color/size/style options from Amazon
// ═══════════════════════════════════════════════════════
function getVariations() {
  const variations = [];

  try {
    // Method 1: Standard variation selectors (#variation_color_name, #variation_size_name, etc.)
    const varContainers = document.querySelectorAll(
      '[id^="variation_"], [data-feature-name="variationAttributeSelector"]'
    );

    for (const container of varContainers) {
      const labelEl = container.querySelector('.a-form-label, label, .a-row .a-size-base');
      let varType = '';
      if (labelEl) {
        varType = labelEl.textContent.replace(/:/g, '').trim().toLowerCase();
      }
      // Fallback: extract type from the ID (e.g. "variation_color_name" → "color")
      if (!varType && container.id) {
        varType = container.id.replace('variation_', '').replace(/_name$/i, '').replace(/_/g, ' ');
      }

      // Get currently selected value
      const selectedEl = container.querySelector('.selection, .a-dropdown-prompt');
      const selectedValue = selectedEl ? selectedEl.textContent.trim() : '';

      // Get all options
      const options = [];

      // Button/swatch style (colors, patterns)
      container.querySelectorAll('li[data-defaultasin], li[id^="color_name_"], li[id^="size_name_"]').forEach(li => {
        const img = li.querySelector('img');
        const title = li.getAttribute('title') || img?.getAttribute('alt') || '';
        const name = title.replace(/^Click to select\s*/i, '').replace(/^click to select\s*/i, '').trim();
        const asin = li.getAttribute('data-defaultasin') || li.getAttribute('data-dp-url')?.match(/\/dp\/([A-Z0-9]{10})/)?.[1] || '';
        const isSelected = li.classList.contains('swatchSelect') || li.querySelector('.a-button-selected');
        const imgUrl = img?.src?.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.') || '';

        // Extract price from variation tile
        let varPrice = 0;
        const priceEl = li.querySelector('.a-color-price, .a-price .a-offscreen, [class*="price"]');
        if (priceEl) {
          const pText = priceEl.textContent.replace(/[^0-9.,]/g, '');
          varPrice = parseFloat(pText.replace(',', '')) || 0;
        }
        // Also try the secondary price format
        if (!varPrice) {
          const allSpans = li.querySelectorAll('span');
          for (const sp of allSpans) {
            const t = sp.textContent.trim();
            if (t.match(/^[£$€]\d+[.,]\d{2}$/)) {
              varPrice = parseFloat(t.replace(/[^0-9.,]/g, '').replace(',', '')) || 0;
              break;
            }
          }
        }

        if (name) {
          options.push({
            name,
            asin,
            selected: !!isSelected,
            image: imgUrl,
            price: varPrice,
          });
        }
      });

      // Dropdown style (sizes, etc.)
      if (options.length === 0) {
        const dropdown = container.querySelector('select, #native_dropdown_selected_' + varType);
        if (dropdown) {
          dropdown.querySelectorAll('option').forEach(opt => {
            const val = opt.textContent.trim();
            if (val && !val.startsWith('Select') && !val.startsWith('Choose') && val !== '-') {
              // Try to extract price from option text (e.g. "720 Count - £26.27")
              let optPrice = 0;
              const priceMatch = val.match(/[£$€]\s*([\d.,]+)/);
              if (priceMatch) optPrice = parseFloat(priceMatch[1].replace(',', '')) || 0;

              options.push({
                name: val.replace(/\s*[-–—]\s*[£$€][\d.,]+\s*/g, '').trim(),
                asin: opt.getAttribute('data-a-html-content') || opt.value || '',
                selected: opt.selected,
                image: '',
                price: optPrice,
              });
            }
          });
        }
      }

      // Inline button style (newer Amazon layout)
      if (options.length === 0) {
        container.querySelectorAll('.a-button-text, [class*="swatch-title-text"]').forEach(el => {
          const name = el.textContent.trim();
          if (name && name.length < 50) {
            const parent = el.closest('[data-defaultasin], [data-asin]');
            options.push({
              name,
              asin: parent?.getAttribute('data-defaultasin') || parent?.getAttribute('data-asin') || '',
              selected: !!parent?.classList.contains('swatchSelect'),
              image: '',
            });
          }
        });
      }

      if (options.length > 0) {
        variations.push({
          type: varType || 'option',
          selected: selectedValue,
          options,
        });
      }
    }

    // Method 2: twisterJS data in page scripts
    if (variations.length === 0) {
      const scripts = document.querySelectorAll('script');
      for (const s of scripts) {
        const text = s.innerHTML;
        if (!text.includes('dimensionToAsinMap') && !text.includes('variationValues')) continue;

        // Extract variationValues: {"color_name":["Red","Blue","Green"],"size_name":["S","M","L"]}
        const valMatch = text.match(/"variationValues"\s*:\s*(\{[^}]+\})/);
        if (valMatch) {
          try {
            const vals = JSON.parse(valMatch[1]);
            for (const [key, options] of Object.entries(vals)) {
              const type = key.replace(/_name$/i, '').replace(/_/g, ' ');
              variations.push({
                type,
                selected: '',
                options: options.map(o => ({ name: o, asin: '', selected: false, image: '' })),
              });
            }
          } catch (e) {}
        }
        if (variations.length > 0) break;
      }
    }
  } catch (e) {
    console.warn('[UnicornDS] Variation extraction error:', e.message);
  }

  console.log('[UnicornDS] Variations found:', variations.length, 'types,',
    variations.reduce((sum, v) => sum + v.options.length, 0), 'total options');
  return variations;
}

// Flatten Amazon's grouped variations into the flat {name, price, image} format
// that listing-form.js expects (same format as AliExpress scraper produces).
// Amazon returns: [{type: "color", options: [{name, asin, image, price}, ...]}, ...]
// listing-form needs: [{name: "Red", price: "9.99", image: "..."}, ...]
// For multi-dimension products (color + size), combine names: "Red / Small".
function flattenAmazonVariations(grouped) {
  if (!Array.isArray(grouped) || grouped.length === 0) return [];

  // Single dimension (just color OR just size) — flatten directly
  if (grouped.length === 1) {
    return grouped[0].options.map(opt => ({
      name: opt.name,
      price: opt.price || '',
      image: opt.image || '',
    }));
  }

  // Multi-dimension — Amazon doesn't give us a combined price matrix, so we
  // flatten each dimension separately with a type prefix. eBay's MSKU accepts
  // this; per-variant price defaults to the listing price.
  const flat = [];
  grouped.forEach(group => {
    const typeName = group.type || 'option';
    group.options.forEach(opt => {
      flat.push({
        name: typeName + ': ' + opt.name,
        price: opt.price || '',
        image: opt.image || '',
      });
    });
  });
  return flat;
}

// ═══════════════════════════════════════════════════════
// FULL SCRAPE
// ═══════════════════════════════════════════════════════
function scrapeProduct() {
  const title = getTitle();
  if (!title) return null;

  const price = getPrice();
  const images = getImages();
  const bullets = getBulletPoints();

  const data = {
    title,
    cleanedTitle: getFilteredTitle(),
    custom_title: getFilteredTitle(),
    filteredTitle: getFilteredTitle(),
    price,
    brand: getBrand(),
    sku: getASIN(),
    upc: 'Does Not Apply',
    descriptionHTML: getDescriptionHTML(),
    descriptionText: getDescriptionText(),
    descriptionAndFeatures: getFilteredTitle() + '\n' + bullets.list.join('\n') + '\n' + getDescriptionText(),
    bullet_points: bullets.list,
    bullet_points_html: bullets.html,
    images,
    main_hd_images: images,
    main_sd_images: images,
    variantImages: getVariantImageMap(),
    tableSpecifics: getTableSpecifics(),
    itemSpecifics: getItemSpecifics(),
    filteredItemSpecifics: getFilteredItemSpecifics(),
    categories: getCategories(),
    shippingWeight: findSpecific('item weight') || findSpecific('shipping weight') || '',
    mpn: findSpecific('item model number') || findSpecific('model') || '',
    ean: findSpecific('ean') || findSpecific('gtin') || '',
    upc: findSpecific('upc') || '',
    source: 'amazon',
    url: window.location.href,
    domain_host: window.location.host,
    extra: {},
    variations: flattenAmazonVariations(getVariations()),
    listingType: 'paid',
  };

  lastScrapedData = data;
  chrome.storage.local.set({ unicornds_last_product: data });
  return data;
}

// ═══════════════════════════════════════════════════════
// FLOATING PANEL - same as AliExpress
// ═══════════════════════════════════════════════════════
function injectFloatingPanel() {
  if (!document.querySelector('#dp') || document.getElementById('unicornds-float-container')) return;

  const c = document.createElement('div');
  c.id = 'unicornds-float-container';
  c.innerHTML = `
    <style>
      #unicornds-float-container { position:fixed; bottom:24px; right:24px; z-index:999999; font-family:-apple-system,sans-serif; width:320px; }
      #unicornds-panel { background:rgba(15,15,26,0.97); border:1px solid #2a2a4a; border-radius:16px; padding:14px; box-shadow:0 8px 32px rgba(0,0,0,0.5); }
      #unicornds-list-btn { display:flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:12px;
        background:linear-gradient(135deg,#7B2FBE,#9B59B6); color:#fff; border:none; border-radius:10px;
        font-size:14px; font-weight:700; cursor:pointer; box-shadow:0 4px 20px rgba(123,47,190,0.4); transition:all 0.2s; }
      #unicornds-list-btn:hover { transform:translateY(-1px); }
      #unicornds-list-btn.loading { opacity:0.7; pointer-events:none; }
      .uds-row { display:flex; gap:6px; align-items:center; margin-top:8px; }
      .uds-input { flex:1; padding:6px 8px; background:#1a1a2e; border:1px solid #3a3a5a; border-radius:6px; color:#FFD700; font-size:13px; font-weight:600; text-align:center; }
      .uds-label { font-size:11px; color:#888; white-space:nowrap; }
      .uds-btn-sm { padding:8px; width:100%; background:#1a1a3e; border:1px solid #3a3a5a; border-radius:8px; color:#ddd; font-size:12px; font-weight:600; cursor:pointer; text-align:center; margin-top:6px; transition:all 0.2s; }
      .uds-btn-sm:hover { background:#2a2a5a; border-color:#7C3AED; }
      .uds-btn-sm.active { background:#7C3AED; border-color:#9B59B6; color:#fff; }
      #unicornds-titles-list { margin-top:8px; max-height:200px; overflow-y:auto; }
      .uds-title-item { padding:8px 10px; background:#0d1b3e; border:1px solid #2a2a4a; border-radius:6px; margin-bottom:4px; cursor:pointer; font-size:12px; color:#ddd; transition:all 0.2s; }
      .uds-title-item:hover { border-color:#7C3AED; }
      .uds-title-item.selected { border-color:#FFD700; background:#1a1a3e; }
      .uds-title-item .chars { font-size:10px; color:#666; margin-top:2px; }
      #unicornds-status { margin-top:8px; padding:8px; background:#1a1a2e; border-radius:6px; color:#fff; font-size:11px; text-align:center; display:none; }
      #unicornds-status.visible { display:block; }
      .uds-collapse-btn { position:absolute; top:-12px; right:10px; background:#2a2a4a; border:1px solid #3a3a5a; color:#aaa; border-radius:50%; width:24px; height:24px; font-size:12px; cursor:pointer; display:flex; align-items:center; justify-content:center; }
      .uds-src-badge { display:inline-block; padding:2px 6px; background:#e67e22; border-radius:4px; font-size:9px; color:#fff; font-weight:700; margin-left:4px; }
      .uds-badges { display:flex; gap:4px; margin-top:6px; flex-wrap:wrap; }
      .uds-badge-vero { padding:4px 8px; background:#DC2626; border-radius:6px; font-size:11px; color:#fff; font-weight:700; animation:uds-pulse 1.5s infinite; }
      .uds-badge-safe { padding:4px 8px; background:#059669; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-dup { padding:4px 8px; background:#D97706; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-new { padding:4px 8px; background:#2563EB; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-seller-amz { padding:4px 8px; background:#FF9900; border-radius:6px; font-size:11px; color:#111; font-weight:700; }
      .uds-badge-seller-fba { padding:4px 8px; background:#232F3E; border-radius:6px; font-size:11px; color:#FF9900; font-weight:700; border:1px solid #FF9900; }
      .uds-badge-seller-fbm { padding:4px 8px; background:#6B7280; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-seller-prime { padding:4px 8px; background:#00A8E1; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      @keyframes uds-pulse { 0%,100% { opacity:1; } 50% { opacity:0.6; } }
    </style>
    <div id="unicornds-panel" style="position:relative">
      <button class="uds-collapse-btn">−</button>
      <div id="unicornds-panel-body">
        <div id="unicornds-badges" class="uds-badges"></div>
        <div id="unicornds-demand" style="background:#0f0e2a;border:1px solid #2d2860;border-radius:8px;padding:8px 12px;margin:6px 0;display:none;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="font-size:11px;color:#a5a0cc;">Demand Score</span>
            <span id="uds-demand-score" style="font-size:14px;font-weight:800;"></span>
          </div>
          <div id="uds-demand-bar" style="height:4px;border-radius:2px;background:#1a1535;margin-top:4px;overflow:hidden;">
            <div id="uds-demand-fill" style="height:100%;border-radius:2px;transition:width 0.5s;"></div>
          </div>
          <div id="uds-demand-breakdown" style="font-size:9px;color:#6b6899;margin-top:4px;"></div>
        </div>
        <button id="unicornds-check-ebay-btn" class="uds-btn-sm" style="background:#1e3a8a;border-color:#3b82f6;color:#fff;margin-bottom:8px;padding:10px;font-size:12px">🔍 Check on eBay</button>
        <button id="unicornds-list-btn"><span style="font-size:16px">🦄</span><span id="unicornds-btn-text">List on eBay</span><span class="uds-src-badge">Amazon</span></button>
        <div class="uds-row">
          <span class="uds-label">Sell £</span><input type="text" id="unicornds-price-input" class="uds-input" placeholder="0.00" style="flex:1"/>
          <span class="uds-label">Ad%</span><input type="text" id="unicornds-promoted-input" class="uds-input" value="2.0" style="width:50px;flex:none"/>
        </div>
        <div id="unicornds-profit-display" style="background:#0f0e2a;border:1px solid #2a2a4a;border-radius:6px;padding:6px 10px;margin:4px 0;font-size:10px;color:#a5a0cc;display:none;">
          <div style="display:flex;justify-content:space-between;margin-bottom:2px;">
            <span>Cost: <span id="uds-cost" style="color:#e0d8ff">£0.00</span></span>
            <span>Fees: <span id="uds-fees" style="color:#F59E0B">£0.00</span></span>
            <span>Profit: <span id="uds-profit" style="color:#10B981;font-weight:700">£0.00 (0%)</span></span>
          </div>
        </div>
        <button class="uds-btn-sm" id="unicornds-gen-titles">✨ Generate AI Titles</button>
        <button class="uds-btn-sm" id="unicornds-add-bulk" style="background:#059669;border-color:#10B981;color:#fff">📋 Add to Bulk Lister</button>
        <div id="unicornds-titles-list"></div>
        <div id="unicornds-status"></div>
      </div>
    </div>`;
  document.body.appendChild(c);

  document.getElementById('unicornds-list-btn').addEventListener('click', handleListOnEbay);
  document.getElementById('unicornds-gen-titles').addEventListener('click', generateTitlesInline);
  document.getElementById('unicornds-add-bulk').addEventListener('click', addToBulkLister);
  document.getElementById('unicornds-check-ebay-btn').addEventListener('click', handleCheckOnEbay);
  
  // Live profit breakdown updater
  function updateProfitDisplay() {
    const sellPrice = parseFloat(document.getElementById('unicornds-price-input')?.value) || 0;
    const adRate = parseFloat(document.getElementById('unicornds-promoted-input')?.value) || 0;
    const costPrice = getPrice();
    const profitDiv = document.getElementById('unicornds-profit-display');
    if (!profitDiv || costPrice <= 0 || sellPrice <= 0) { if (profitDiv) profitDiv.style.display = 'none'; return; }
    
    const ebayFVF = (sellPrice * 0.128) + 0.30;
    const promoFee = sellPrice * (adRate / 100);
    const totalFees = ebayFVF + promoFee;
    const profit = sellPrice - costPrice - totalFees;
    const profitPct = (profit / costPrice * 100);
    
    document.getElementById('uds-cost').textContent = '£' + costPrice.toFixed(2);
    document.getElementById('uds-fees').textContent = '£' + totalFees.toFixed(2);
    const profitEl = document.getElementById('uds-profit');
    profitEl.textContent = '£' + profit.toFixed(2) + ' (' + profitPct.toFixed(0) + '%)';
    profitEl.style.color = profit > 0 ? '#10B981' : '#EF4444';
    profitDiv.style.display = 'block';
  }
  
  document.getElementById('unicornds-price-input').addEventListener('input', updateProfitDisplay);
  document.getElementById('unicornds-promoted-input').addEventListener('input', updateProfitDisplay);
  // Initial update after price is set
  setTimeout(updateProfitDisplay, 500);
  document.querySelector('.uds-collapse-btn').addEventListener('click', function() {
    const body = document.getElementById('unicornds-panel-body');
    body.hidden = !body.hidden;
    this.textContent = body.hidden ? '+' : '−';
  });

  // Set price and ad rate from settings (Amazon-specific) — uses background.js shared module (Fixes C1)
  const amazonCostPrice = getPrice();
  if (amazonCostPrice > 0) {
    chrome.runtime.sendMessage({ type: 'calculate_profit', costPrice: amazonCostPrice, source: 'amazon' }, resp => {
      if (resp?.profit) {
        const el = document.getElementById('unicornds-price-input');
        if (el) el.value = resp.profit.sellPrice.toFixed(2);
      }
    });
  }
  chrome.storage.local.get(['unicornds_promo_rate_amz', 'unicornds_promo_rate', 'unicornds_ad_rate'], s => {
    const promoRate = [s.unicornds_promo_rate_amz, s.unicornds_promo_rate, s.unicornds_ad_rate].map(v => parseFloat(v)).find(v => !isNaN(v)) ?? 0;
    const adEl = document.getElementById('unicornds-promoted-input');
    if (adEl) adEl.value = promoRate.toFixed(1);
  });
}

function showStatus(t, err) {
  const el = document.getElementById('unicornds-status');
  if (!el) return;
  el.textContent = t;
  el.style.background = err ? 'rgba(231,76,60,0.9)' : 'rgba(0,0,0,0.85)';
  el.classList.add('visible');
  if (!err) setTimeout(() => el.classList.remove('visible'), 5000);
}

async function handleListOnEbay() {
  const btn = document.getElementById('unicornds-list-btn');
  const btnText = document.getElementById('unicornds-btn-text');
  if (!btn || btn.classList.contains('loading')) return;

  btn.classList.add('loading');
  btnText.textContent = 'Scraping...';

  const data = scrapeProduct();
  if (!data?.title) {
    showStatus('Scrape failed', true);
    btn.classList.remove('loading');
    btnText.textContent = 'List on eBay';
    return;
  }

  const productData = {
    ...data,
    custom_price: document.getElementById('unicornds-price-input')?.value || '',
    promoted_listing_ad_rate: document.getElementById('unicornds-promoted-input')?.value || '10',
  };

  btnText.textContent = 'Opening eBay...';
  chrome.runtime.sendMessage({ type: 'list_to_ebay', product_data: productData }, res => {
    if (res?.success) {
      showStatus('✓ eBay tab opened!');
      btnText.textContent = '✓ Started';
      setTimeout(() => { btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; }, 3000);
    } else if (res?.blocked) {
      showStatus('🔒 ' + (res.error || 'Login required'), true);
      btn.classList.remove('loading');
      btnText.textContent = '🔒 Login First';
      setTimeout(() => { btnText.textContent = 'List on eBay'; }, 5000);
    } else {
      showStatus('Failed: ' + (res?.error || 'Unknown'), true);
      btn.classList.remove('loading');
      btnText.textContent = 'List on eBay';
    }
  });
}

// Opens eBay search in a new tab with the smartest identifier available.
// Priority: EAN/UPC (exact) > MPN (near-exact) > brand + 4 title keywords (broad fallback).
// URL uses LH_ItemCondition=1000 (new) so user can toggle Sold on eBay's own UI.
function handleCheckOnEbay() {
  const btn = document.getElementById('unicornds-check-ebay-btn');
  if (!btn) return;
  const originalText = btn.textContent;

  const data = scrapeProduct();
  if (!data?.title) {
    showStatus('Could not read product details', true);
    return;
  }

  // Build smartest query available
  let query = '';
  let identifier = '';
  const eanClean = String(data.ean || '').replace(/\s/g, '');
  const upcClean = String(data.upc || '').replace(/\s/g, '');
  if (eanClean && /^\d{8,14}$/.test(eanClean)) {
    query = eanClean;
    identifier = 'EAN';
  } else if (upcClean && /^\d{8,14}$/.test(upcClean)) {
    query = upcClean;
    identifier = 'UPC';
  } else if (data.mpn && data.mpn.length > 3 && data.mpn.toLowerCase() !== 'does not apply') {
    query = data.mpn;
    identifier = 'MPN';
  } else {
    // Fallback: brand + first 4 meaningful words of title
    const brand = (data.brand && data.brand !== 'Unbranded') ? data.brand : '';
    let titleClean = (data.title || '')
      .replace(/\([^)]*\)/g, ' ')
      .replace(/[|\-–—,:;]/g, ' ')
      .replace(/[^\w\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (brand) {
      titleClean = titleClean.replace(new RegExp(brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '').trim();
    }
    const words = titleClean.split(/\s+/).filter(w => w.length > 2).slice(0, 4);
    query = (brand ? brand + ' ' : '') + words.join(' ');
    identifier = 'Title';
  }

  if (!query || query.length < 3) {
    showStatus('Could not build search query', true);
    return;
  }

  chrome.storage.local.get(['domain', 'unicornds_primary_market'], (s) => {
    const marketToDomain = {
      'com':'com', 'co_uk':'co.uk', 'de':'de', 'com_au':'com.au',
      'ca':'ca', 'fr':'fr', 'it':'it', 'es':'es', 'nl':'nl',
      'at':'at', 'be':'be', 'ch':'ch', 'ie':'ie', 'in':'in',
    };
    const domain = s.domain || marketToDomain[s.unicornds_primary_market] || 'co.uk';
    const url = `https://www.ebay.${domain}/sch/i.html?_nkw=${encodeURIComponent(query)}&LH_ItemCondition=1000&_sop=12`;
    chrome.runtime.sendMessage({ type: 'openNewTab', url, options: { active: true } });
    btn.textContent = '✓ Searched by ' + identifier;
    showStatus('Searched eBay: "' + query + '" (' + identifier + ')');
    setTimeout(() => { btn.textContent = originalText; }, 4000);
  });
}

function addToBulkLister() {
  const url = window.location.href;
  const btn = document.getElementById('unicornds-add-bulk');

  chrome.storage.local.get('bulk_links', s => {
    let existing = s.bulk_links || '';
    // Check if already added
    if (existing.includes(url.split('?')[0])) {
      btn.textContent = '⚠️ Already Added';
      setTimeout(() => { btn.textContent = '📋 Add to Bulk Lister'; }, 2000);
      return;
    }
    // Append URL
    existing = existing.trim();
    if (existing) existing += '\n';
    existing += url.split('?')[0];

    chrome.storage.local.set({ bulk_links: existing }, () => {
      const count = existing.split('\n').filter(l => l.trim()).length;
      btn.textContent = '✅ Added! (' + count + ' total)';
      btn.style.background = '#7C3AED';
      setTimeout(() => {
        btn.textContent = '📋 Add to Bulk Lister';
        btn.style.background = '#059669';
      }, 2000);
    });
  });
}

function generateTitlesInline() {
  const btn = document.getElementById('unicornds-gen-titles');
  btn.textContent = '⏳ Generating...';
  btn.classList.add('active');

  const data = scrapeProduct();
  if (!data?.title) { btn.textContent = '✨ Generate AI Titles'; btn.classList.remove('active'); return; }

  const specs = (data.filteredItemSpecifics || []).map(s => s.label + ': ' + s.value).join(', ');

  chrome.runtime.sendMessage({
    type: 'call_openai',
    systemPrompt: 'You are an eBay SEO expert. Generate 5 optimized eBay listing titles.\n' +
      'Rules: max 80 chars each, remove brand names, remove "1pc/Hot Sale/Free Shipping",\n' +
      'keep material/size/quantity/features, Title Case, no emojis.\n' +
      'First title = BEST.\nReturn JSON: {"titles": ["t1","t2","t3","t4","t5"]}',
    userMessage: 'Product: ' + data.title + (specs ? '\nSpecs: ' + specs : ''),
    jsonMode: true,
  }, (resp) => {
    btn.textContent = '✨ Generate AI Titles';
    btn.classList.remove('active');
    if (!resp?.result) { showStatus('AI failed - check API key', true); return; }

    try {
      const parsed = JSON.parse(resp.result);
      const titles = parsed.titles || [];
      const list = document.getElementById('unicornds-titles-list');
      list.innerHTML = '';

      titles.forEach((title, i) => {
        const div = document.createElement('div');
        div.className = 'uds-title-item' + (i === 0 ? ' selected' : '');
        div.innerHTML = (i === 0 ? '⭐ ' : '') + title + '<div class="chars">' + title.length + '/80</div>';
        div.addEventListener('click', () => {
          list.querySelectorAll('.uds-title-item').forEach(d => d.classList.remove('selected'));
          div.classList.add('selected');
          if (lastScrapedData) {
            lastScrapedData.custom_title = title;
            lastScrapedData.cleanedTitle = title;
          }
          showStatus('✅ Title: ' + title.substring(0, 40) + '...');
        });
        list.appendChild(div);
      });

      if (titles[0] && lastScrapedData) {
        lastScrapedData.custom_title = titles[0];
        lastScrapedData.cleanedTitle = titles[0];
      }
    } catch (e) { showStatus('Parse error', true); }
  });
}

// ═══════════════════════════════════════════════════════
// MESSAGE LISTENER
// ═══════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'list_item_to_ebay') {
    const data = scrapeProduct();
    sendResponse({ autoListing: { product_data: data } });
    return true;
  }
  if (request.type === 'get_supplier_product_data') {
    const data = scrapeProduct();
    sendResponse({ autoListing: { product_data: data } });
    return true;
  }
});

// ═══════════════════════════════════════════════════════
// INIT - only on product pages
// ═══════════════════════════════════════════════════════
if (window.location.href.includes('/dp/') || document.querySelector('#dp')) {
  // Auth check — don't inject panel if not logged in
  chrome.storage.local.get('unicornds_session', (s) => {
    if (!s?.unicornds_session?.idToken) {
      console.log('[UnicornDS] Not logged in — Amazon panel not injected');
      return;
    }
    if (document.readyState === 'complete') {
      setTimeout(() => { scrapeProduct(); injectFloatingPanel(); checkVeroAndDuplicate(); }, 1000);
    } else {
      window.addEventListener('load', () => {
        setTimeout(() => { scrapeProduct(); injectFloatingPanel(); checkVeroAndDuplicate(); }, 1000);
      });
    }
  });
}

// ═══════════════════════════════════════════════════════
// VERO + DUPLICATE CHECK
// ═══════════════════════════════════════════════════════
async function checkVeroAndDuplicate() {
  const badges = document.getElementById('unicornds-badges');
  if (!badges) return;

  const brand = getBrand();
  const title = getTitle();
  const sku = getASIN();

  // VERO check
  try {
    const veroEnabled = await getStorageVal('unicornds_vero_enabled');
    if (veroEnabled !== false) {
      let veroBrands = await getStorageVal('unicornds_vero_brands');
      if (!veroBrands || !veroBrands.length) {
        try {
          const resp = await fetch(chrome.runtime.getURL('data/VeroList.txt'));
          const text = await resp.text();
          veroBrands = text.split('\n').map(b => b.trim().toLowerCase()).filter(Boolean);
          chrome.storage.local.set({ unicornds_vero_brands: veroBrands });
        } catch (e) { veroBrands = []; }
      }

      if (veroBrands.length) {
        const titleLower = title.toLowerCase().replace(/[-–—]/g, ' ');
        const brandLower = brand.toLowerCase().replace(/[-–—]/g, ' ');
        const combined = brandLower + ' ' + titleLower;
        const isVero = veroBrands.some(v => {
          const vLower = v.replace(/[-–—]/g, ' ');
          // Multi-word brand: check if combined text contains it
          if (vLower.includes(' ')) return combined.includes(vLower);
          // Single word: exact word boundary match only (no substring false positives)
          try {
            const escaped = vLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const re = new RegExp('\\b' + escaped + '\\b', 'i');
            return re.test(combined);
          } catch { return combined.includes(vLower); }
        });

        if (isVero) {
          badges.innerHTML += '<span class="uds-badge-vero">⚠️ VERO BRAND</span>';
          console.log('[UnicornDS] ⚠️ VERO detected:', brand);
        } else {
          badges.innerHTML += '<span class="uds-badge-safe">✅ Not VERO</span>';
        }
      }
    }
  } catch (e) { console.warn('[UnicornDS] VERO check error:', e); }

  // Duplicate check
  try {
    let skuList = await getStorageVal('unicornds_listed_skus') || [];
    if (skuList.includes(sku)) {
      badges.innerHTML += '<span class="uds-badge-dup">⚠️ ALREADY LISTED</span>';
      console.log('[UnicornDS] ⚠️ Duplicate SKU:', sku);
    } else {
      badges.innerHTML += '<span class="uds-badge-new">🆕 New Product</span>';
    }
  } catch (e) { console.warn('[UnicornDS] Duplicate check error:', e); }

  // Seller type badge: Amazon 1P / FBA / FBM / FBM+Prime
  try {
    const merchantInfo = document.getElementById('merchant-info') ||
                         document.querySelector('#tabular-buybox') ||
                         document.querySelector('#buyBoxAccordion');
    const mText = merchantInfo ? merchantInfo.innerText.toLowerCase() : '';

    const hasPrime = !!document.querySelector('#primeBadge, .a-icon-prime, [data-feature-name="primeExclusive"], i.a-icon-prime');

    // Detect seller type
    const isSoldByAmazon = mText.includes('sold by amazon') || mText.includes('dispatched from and sold by amazon') || mText.includes('ships from and sold by amazon');
    const isFulfilledByAmazon = mText.includes('fulfilled by amazon') || mText.includes('dispatches from amazon') || mText.includes('ships from amazon');

    if (isSoldByAmazon) {
      badges.innerHTML += '<span class="uds-badge-seller-amz">🏷️ Amazon 1P</span>';
      console.log('[UnicornDS] Seller: Amazon 1P (sold by Amazon)');
    } else if (isFulfilledByAmazon) {
      badges.innerHTML += '<span class="uds-badge-seller-fba">📦 FBA Seller</span>';
      console.log('[UnicornDS] Seller: FBA (third party, fulfilled by Amazon)');
    } else if (hasPrime) {
      badges.innerHTML += '<span class="uds-badge-seller-prime">⚡ FBM + Prime</span>';
      console.log('[UnicornDS] Seller: FBM + Seller Fulfilled Prime');
    } else {
      badges.innerHTML += '<span class="uds-badge-seller-fbm">🚚 FBM Seller</span>';
      console.log('[UnicornDS] Seller: FBM (merchant fulfilled)');
    }
  } catch (e) { console.warn('[UnicornDS] Seller type check error:', e); }

  // DEMAND SCORE — calculate from page data
  try {
    // Reviews
    const reviewEl = document.getElementById('acrCustomerReviewCount') || document.querySelector('[data-hook="total-review-count"]');
    const reviewText = reviewEl ? reviewEl.textContent.replace(/[^\d]/g, '') : '0';
    const reviews = parseInt(reviewText) || 0;

    // Rating
    const ratingEl = document.querySelector('[data-hook="rating-out-of-text"]') || document.querySelector('.a-icon-alt');
    const ratingText = ratingEl ? ratingEl.textContent : '';
    const rating = parseFloat(ratingText.match(/[\d.]+/)?.[0]) || 0;

    // Amazon's Choice badge
    const isAmazonChoice = !!document.querySelector('.ac-badge-wrapper, [class*="amazons-choice"], [data-feature-name="acBadge"]');

    // Best Seller badge
    const isBestSeller = !!document.querySelector('#zeitgeistBadge, .p13n-best-seller-badge, [class*="best-seller"]');

    // "X bought in past month"
    const boughtEl = document.getElementById('social-proofing-faceout-title-tk_bought') || 
                     document.querySelector('[class*="social-proofing"]');
    const hasBoughtText = boughtEl ? boughtEl.textContent.includes('bought') : false;

    // Calculate score (same formula as Product Hunter)
    const reviewScore = Math.min(reviews / 500, 1) * 40;
    const ratingScore = (rating / 5) * 25;
    const badgeBonus = (isAmazonChoice ? 15 : 0) + (isBestSeller ? 15 : 0);
    const boughtBonus = hasBoughtText ? 10 : 0;
    const demandScore = Math.min(Math.round(reviewScore + ratingScore + badgeBonus + boughtBonus), 100);

    const demandDiv = document.getElementById('unicornds-demand');
    const scoreEl = document.getElementById('uds-demand-score');
    const fillEl = document.getElementById('uds-demand-fill');
    const breakdownEl = document.getElementById('uds-demand-breakdown');

    if (demandDiv && scoreEl) {
      const color = demandScore >= 70 ? '#10B981' : demandScore >= 40 ? '#F59E0B' : '#6b7280';
      const label = demandScore >= 70 ? '🔥 Hot' : demandScore >= 40 ? '🌤 Warm' : '❄️ Cold';
      scoreEl.textContent = label + ' ' + demandScore + '/100';
      scoreEl.style.color = color;
      fillEl.style.width = demandScore + '%';
      fillEl.style.background = color;
      breakdownEl.textContent = 'Reviews: ' + reviews.toLocaleString() + ' · Rating: ' + rating.toFixed(1) + 
        (isAmazonChoice ? ' · Choice' : '') + (isBestSeller ? ' · Bestseller' : '') + (hasBoughtText ? ' · Trending' : '');
      demandDiv.style.display = 'block';
      console.log('[UnicornDS] Demand score:', demandScore, '(' + label + ')');
    }
  } catch (e) { console.warn('[UnicornDS] Demand score error:', e); }
}

function getStorageVal(key) {
  return new Promise(r => chrome.storage.local.get(key, s => r(s[key])));
}

// ═══════════════════════════════════════
// STOCK / QUANTITY CHECKER
// ═══════════════════════════════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'check_stock') {
    console.log('[UnicornDS] Checking stock...');
    const result = checkStockInfo();
    console.log('[UnicornDS] Stock result:', result);
    sendResponse(result);
    return true;
  }
});

function checkStockInfo() {
  const info = {
    inStock: false,
    quantity: 0,
    quantityText: '',
    price: 0,
    seller: '',
    fulfilledBy: '',
    prime: false,
    freeShipping: false,
    condition: 'new',
  };

  try {
    // 1. Check availability text
    const availEl = document.getElementById('availability') ||
                    document.querySelector('#availability span') ||
                    document.querySelector('.a-size-medium.a-color-success');
    const availText = availEl ? availEl.innerText.trim().toLowerCase() : '';

    if (availText.includes('in stock')) {
      info.inStock = true;
      info.quantityText = 'In Stock';
    } else if (availText.includes('only') && availText.includes('left')) {
      info.inStock = true;
      const match = availText.match(/only\s+(\d+)\s+left/i);
      if (match) {
        info.quantity = parseInt(match[1]);
        info.quantityText = 'Only ' + info.quantity + ' left';
      }
    } else if (availText.includes('unavailable') || availText.includes('out of stock')) {
      info.inStock = false;
      info.quantityText = 'Out of Stock';
    }

    // 2. Try quantity dropdown (some pages have this)
    const qtySelect = document.getElementById('quantity') || document.querySelector('#quantity select');
    if (qtySelect) {
      const options = qtySelect.querySelectorAll('option');
      if (options.length > 0) {
        const lastOpt = options[options.length - 1];
        const maxQty = parseInt(lastOpt.value || lastOpt.textContent);
        if (maxQty > 0) {
          info.quantity = maxQty;
          info.inStock = true;
          if (!info.quantityText || info.quantityText === 'In Stock') {
            info.quantityText = maxQty + '+ available';
          }
        }
      }
    }

    // 3. Check "Only X left in stock - order soon" anywhere on page
    if (info.quantity === 0) {
      const bodyText = document.body.innerText;
      const leftMatch = bodyText.match(/Only\s+(\d+)\s+left\s+in\s+stock/i);
      if (leftMatch) {
        info.quantity = parseInt(leftMatch[1]);
        info.inStock = true;
        info.quantityText = 'Only ' + info.quantity + ' left in stock';
      }
    }

    // 4. If still no quantity but in stock, assume good stock
    if (info.inStock && info.quantity === 0) {
      info.quantity = 999; // high stock indicator
      info.quantityText = info.quantityText || 'In Stock (qty unknown)';
    }

    // 5. Price
    const priceEl = document.querySelector('.a-price .a-offscreen') ||
                    document.querySelector('#priceblock_ourprice') ||
                    document.querySelector('#price_inside_buybox');
    if (priceEl) {
      const priceText = priceEl.textContent.replace(/[^0-9.,]/g, '');
      info.price = parseFloat(priceText.replace(',', '')) || 0;
    }

    // 6. Seller info
    const sellerEl = document.getElementById('sellerProfileTriggerId') ||
                     document.querySelector('#merchant-info a') ||
                     document.querySelector('#tabular-buybox .tabular-buybox-text a');
    if (sellerEl) info.seller = sellerEl.textContent.trim();

    // Check if Amazon is the seller
    const merchantInfo = document.getElementById('merchant-info') ||
                        document.querySelector('#tabular-buybox');
    if (merchantInfo) {
      const mText = merchantInfo.innerText.toLowerCase();
      if (mText.includes('dispatches from amazon') || mText.includes('ships from amazon') ||
          mText.includes('sold by amazon') || mText.includes('dispatched from amazon')) {
        info.seller = 'Amazon';
      }
    }

    // 7. Fulfilled by
    if (merchantInfo) {
      const fText = merchantInfo.innerText.toLowerCase();
      if (fText.includes('fulfilled by amazon') || fText.includes('dispatches from amazon')) {
        info.fulfilledBy = 'Amazon (FBA)';
      } else {
        info.fulfilledBy = 'Seller';
      }
    }

    // 8. Prime check
    info.prime = !!document.querySelector('#primeBadge') ||
                 !!document.querySelector('.a-icon-prime') ||
                 !!document.querySelector('[data-feature-name="primeExclusive"]');

    // 9. Free shipping check
    const deliveryEl = document.getElementById('deliveryBlockMessage') ||
                      document.querySelector('#delivery-message');
    if (deliveryEl) {
      info.freeShipping = deliveryEl.innerText.toLowerCase().includes('free');
    }
    if (info.prime) info.freeShipping = true;

    // 10. Condition
    const condEl = document.getElementById('newBuyBoxPrice') ? 'new' :
                  (document.querySelector('#usedBuySection') ? 'used' : 'new');
    info.condition = condEl;

    // 11. Seller type classification
    const isSoldByAmazon = info.seller === 'Amazon' || (merchantInfo && merchantInfo.innerText.toLowerCase().includes('sold by amazon'));
    const isFBA = info.fulfilledBy === 'Amazon (FBA)';
    if (isSoldByAmazon) {
      info.sellerType = 'Amazon 1P';
    } else if (isFBA) {
      info.sellerType = 'FBA';
    } else if (info.prime) {
      info.sellerType = 'FBM+Prime';
    } else {
      info.sellerType = 'FBM';
    }

  } catch (e) {
    console.error('[UnicornDS] Stock check error:', e);
  }

  return info;
}
