// ─────────────────────────────────────────────────────────
// UNICORNDS ONBOARDING - No OAuth needed
// Works via browser session cookies, exactly like your
// existing eBay content script bundles.
// ─────────────────────────────────────────────────────────

const TOTAL = 4;
let current = 1;

const state = {
  ebayUsername:     '',
  markets:          ['com', 'co_uk', 'de', 'com_au'],
  primaryMarket:    'co_uk',
  markupMultiplier: 100,  // Desired profit % after all fees
  minMargin:        30,
  roundingStyle:    '0.99',
  hasStore:         false,
  vatRate:          0,
  safety: {
    veroCheck: true, rateLimiting: true, preListingReview: true,
    clothingBlock: true, duplicateCheck: true, profitFloor: true,
  },
};

// ── Navigation ─────────────────────────────────────────
function goTo(n) {
  document.getElementById('step' + current)?.classList.remove('active');
  document.querySelectorAll('.step-indicator').forEach((el, i) => {
    el.classList.remove('active', 'completed');
    if (i + 1 < n)  el.classList.add('completed');
    if (i + 1 === n) el.classList.add('active');
  });
  current = n;
  document.getElementById('step' + current)?.classList.add('active');

  const back    = document.getElementById('btnBack');
  const next    = document.getElementById('btnNext');
  const counter = document.getElementById('stepCounter');

  back.style.visibility = current > 1 ? 'visible' : 'hidden';

  if (current > TOTAL) {
    next.textContent = '🚀 Start UnicornDS';
    next.className   = 'btn btn-finish';
    counter.textContent = '';
  } else {
    next.textContent = 'Continue →';
    next.className   = 'btn btn-primary';
    counter.textContent = 'Step ' + current + ' of ' + TOTAL;
  }
}

document.getElementById('btnNext').addEventListener('click', () => {
  collectStep(current);
  if (current === TOTAL + 1) {
    saveAndLaunch();
  } else {
    goTo(current + 1);
  }
});

document.getElementById('btnBack').addEventListener('click', () => {
  if (current > 1) { collectStep(current); goTo(current - 1); }
});

// ── Collect step data ──────────────────────────────────
function collectStep(s) {
  if (s === 1) {
    state.ebayUsername = document.getElementById('ebayUsername').value.trim();
  }
  if (s === 2) {
    state.markets = [...document.querySelectorAll('.market-card.selected')]
      .map(c => c.dataset.market);
    state.primaryMarket = document.getElementById('primaryMarket').value;
  }
  if (s === 3) {
    state.markupMultiplier = parseFloat(document.getElementById('markupSlider').value);
    state.minMargin        = parseInt(document.getElementById('marginSlider').value);
    state.roundingStyle    = document.getElementById('roundingStyle').value;
    state.hasStore         = document.getElementById('hasStore').value === 'true';
    state.vatRate          = parseFloat(document.getElementById('vatRate').value) || 0;
  }
  if (s === 4) {
    document.querySelectorAll('.toggle[data-setting]').forEach(t => {
      state.safety[t.dataset.setting] = t.classList.contains('on');
    });
  }
}

// ── Market cards ───────────────────────────────────────
document.querySelectorAll('.market-card').forEach(card => {
  card.addEventListener('click', () => {
    card.classList.toggle('selected');
    card.querySelector('.market-check').textContent =
      card.classList.contains('selected') ? '✓' : '';
  });
});

// ── Toggles ────────────────────────────────────────────
document.querySelectorAll('.toggle').forEach(t =>
  t.addEventListener('click', () => t.classList.toggle('on'))
);

// ── Sliders ────────────────────────────────────────────
document.getElementById('markupSlider').addEventListener('input', e => {
  document.getElementById('markupVal').textContent = e.target.value + '%';
});
document.getElementById('marginSlider').addEventListener('input', e => {
  document.getElementById('marginVal').textContent = e.target.value + '%';
});

// ── Save and finish ────────────────────────────────────
async function saveAndLaunch() {
  const settings = {
    unicornds_onboarded:        true,
    unicornds_ebay_username:    state.ebayUsername,
    unicornds_markets:          state.markets,
    unicornds_primary_market:   state.primaryMarket,
    unicornds_markup:           state.markupMultiplier,  // Desired profit % after all fees
    unicornds_round_prices:     state.roundingStyle !== 'none',
    unicornds_rounding_style:   state.roundingStyle,  // '0.99', '0.95', or 'none'
    unicornds_pricing_settings: {
      desiredProfit:       state.markupMultiplier,
      minProfitMargin:     state.minMargin,
      roundingStyle:       state.roundingStyle,
      hasEbayStore:        state.hasStore,
      vatRate:             state.vatRate,
      returnCostBuffer:    0,
    },
    unicornds_safety_settings:  { ...state.safety, minProfitMargin: state.minMargin },
    unicornds_setup_date:       new Date().toISOString(),
  };

  if (typeof chrome !== 'undefined' && chrome.storage) {
    await chrome.storage.local.set(settings);
    window.close();
  } else {
    alert('✅ UnicornDS setup complete!');
  }
}

goTo(1);
