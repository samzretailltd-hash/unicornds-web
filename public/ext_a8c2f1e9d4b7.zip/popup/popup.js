// ══════════════════════════════════════════════════════════
// UnicornDS - Popup Controller with Firebase Auth
// ══════════════════════════════════════════════════════════

// ── Firebase Config ──────────────────────────────────────
const FIREBASE = {
  apiKey:    'AIzaSyCOLnljoCmGWKCseXTSJv0zYVJhLUGVhN4',
  projectId: 'unicorn-ds-7f831',
  authDomain: 'unicorn-ds-7f831.firebaseapp.com',
};

const AUTH_URL    = 'https://identitytoolkit.googleapis.com/v1/accounts';
const FIRESTORE   = `https://firestore.googleapis.com/v1/projects/${FIREBASE.projectId}/databases/(default)/documents`;

// ── State ────────────────────────────────────────────────
let currentUser    = null;  // { uid, email, idToken, refreshToken }
let currentProduct = null;
let currentTitles  = null;

// ══════════════════════════════════════════════════════════
// AUTH - Firebase REST API
// ══════════════════════════════════════════════════════════

async function signIn(email, password) {
  const res = await fetch(`${AUTH_URL}:signInWithPassword?key=${FIREBASE.apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return {
    uid: data.localId,
    email: data.email,
    idToken: data.idToken,
    refreshToken: data.refreshToken,
    expiresAt: Date.now() + parseInt(data.expiresIn) * 1000,
  };
}

async function signUp(email, password) {
  const res = await fetch(`${AUTH_URL}:signUp?key=${FIREBASE.apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return {
    uid: data.localId,
    email: data.email,
    idToken: data.idToken,
    refreshToken: data.refreshToken,
    expiresAt: Date.now() + parseInt(data.expiresIn) * 1000,
  };
}

async function refreshIdToken(refreshToken) {
  const res = await fetch(`https://securetoken.googleapis.com/v1/token?key=${FIREBASE.apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ grant_type: 'refresh_token', refresh_token: refreshToken }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || 'Token refresh failed');
  return {
    idToken: data.id_token,
    refreshToken: data.refresh_token,
    expiresAt: Date.now() + parseInt(data.expires_in) * 1000,
  };
}

async function getValidToken() {
  if (!currentUser) return null;
  // Refresh if token expires within 5 minutes
  if (Date.now() > currentUser.expiresAt - 300000) {
    try {
      const refreshed = await refreshIdToken(currentUser.refreshToken);
      currentUser.idToken = refreshed.idToken;
      currentUser.refreshToken = refreshed.refreshToken;
      currentUser.expiresAt = refreshed.expiresAt;
      await saveSession(currentUser);
    } catch (err) {
      console.error('[UnicornDS] Token refresh failed:', err);
      logout();
      return null;
    }
  }
  return currentUser.idToken;
}

// ── Session persistence (chrome.storage.local) ──────────
async function saveSession(user) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ unicornds_session: user }, resolve);
  });
}

async function loadSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get('unicornds_session', (data) => {
      resolve(data.unicornds_session || null);
    });
  });
}

async function clearSession() {
  return new Promise((resolve) => {
    chrome.storage.local.remove('unicornds_session', resolve);
  });
}

// ══════════════════════════════════════════════════════════
// FIRESTORE - User Document
// ══════════════════════════════════════════════════════════

async function getUserDoc() {
  const token = await getValidToken();
  if (!token) return null;

  try {
    const res = await fetch(`${FIRESTORE}/users/${currentUser.uid}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (res.status === 404) {
      // First login - create user document
      return await createUserDoc();
    }

    if (!res.ok) {
      console.error('[UnicornDS] Firestore read failed:', res.status);
      return null;
    }

    const doc = await res.json();
    return parseFirestoreDoc(doc.fields);
  } catch (err) {
    console.error('[UnicornDS] Firestore error:', err);
    return null;
  }
}

async function createUserDoc() {
  const token = await getValidToken();
  if (!token) return null;

  const body = {
    fields: {
      email:       { stringValue: currentUser.email },
      tier:        { stringValue: 'free' },
      tokensUsed:  { integerValue: '0' },
      tokensTotal: { integerValue: '10' },
      created_at:  { timestampValue: new Date().toISOString() },
      createdAt:   { timestampValue: new Date().toISOString() },
    },
  };

  try {
    const res = await fetch(`${FIRESTORE}/users?documentId=${currentUser.uid}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      // Might already exist (race condition) - try reading
      console.warn('[UnicornDS] Create user doc failed, trying read');
      const readRes = await fetch(`${FIRESTORE}/users/${currentUser.uid}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (readRes.ok) {
        const doc = await readRes.json();
        return parseFirestoreDoc(doc.fields);
      }
      return { tier: 'free', tokensUsed: 0, tokensTotal: 10, email: currentUser.email };
    }

    return { tier: 'free', tokensUsed: 0, tokensTotal: 10, email: currentUser.email };
  } catch (err) {
    console.error('[UnicornDS] Create user doc error:', err);
    return { tier: 'free', tokensUsed: 0, tokensTotal: 10, email: currentUser.email };
  }
}

function parseFirestoreDoc(fields) {
  if (!fields) return null;
  const result = {};
  for (const [key, val] of Object.entries(fields)) {
    if (val.stringValue !== undefined)    result[key] = val.stringValue;
    else if (val.integerValue !== undefined) result[key] = parseInt(val.integerValue);
    else if (val.booleanValue !== undefined) result[key] = val.booleanValue;
    else if (val.doubleValue !== undefined)  result[key] = val.doubleValue;
    else if (val.timestampValue !== undefined) result[key] = val.timestampValue;
    else result[key] = val;
  }
  return result;
}

// ══════════════════════════════════════════════════════════
// UI HELPERS
// ══════════════════════════════════════════════════════════

const $ = (id) => document.getElementById(id);
function show(id) { $(id)?.classList.remove('hidden'); }
function hide(id) { $(id)?.classList.add('hidden'); }
function enable(id) { if ($(id)) $(id).disabled = false; }
function disable(id) { if ($(id)) $(id).disabled = true; }
function setText(id, text) { if ($(id)) $(id).textContent = text; }

function setStatus(msg, type = 'idle') {
  const el = $('aliStatus');
  if (el) { el.textContent = msg; el.className = `status-banner ${type}`; }
}

function showAuthError(msg) {
  const el = $('authError');
  el.textContent = msg;
  el.classList.add('visible');
}

function hideAuthError() {
  $('authError').classList.remove('visible');
}

// ══════════════════════════════════════════════════════════
// SCREEN MANAGEMENT
// ══════════════════════════════════════════════════════════

function showAuthScreen() {
  $('authScreen').style.display = 'flex';
  $('mainApp').style.display = 'none';
}

function showMainApp() {
  $('authScreen').style.display = 'none';
  $('mainApp').style.display = 'block';
}

// ── Update UI with user data from Firestore ─────────────
function updateUserUI(userData) {
  const tier = userData?.tier || 'free';
  const used = userData?.tokensUsed || 0;
  const total = userData?.tokensTotal || 10;
  const remaining = Math.max(0, total - used);
  const isUnlimited = tier === 'empire' || total >= 999999;

  // Header badge
  const badge = $('tierBadge');
  const tierLabels = { free: 'FREE', starter: 'STARTER', growth: 'GROWTH', empire: 'EMPIRE', ultimate: 'EMPIRE', pro: 'GROWTH' };
  badge.textContent = tierLabels[tier] || 'FREE';
  badge.className = 'tier-badge tier-' + tier;

  // Token counter
  setText('tokenUsed', isUnlimited ? '∞' : String(remaining));
  setText('tokenTotal', isUnlimited ? '∞' : String(total));

  // Progress bar
  const pct = isUnlimited ? 100 : (total > 0 ? (remaining / total) * 100 : 0);
  $('tokenBarFill').style.width = pct + '%';
  if (pct > 50) $('tokenBarFill').style.background = '#2ecc71';
  else if (pct > 20) $('tokenBarFill').style.background = '#f39c12';
  else $('tokenBarFill').style.background = '#e74c3c';

  setText('tokenBarText', isUnlimited ? 'Unlimited listings' : remaining + ' of ' + total + ' listings remaining');

  // Upgrade button
  try {
    $('btnUpgrade').style.display = '';
    $('btnUpgrade').textContent = tier === 'empire' ? 'Manage Plan' : 'Upgrade';
  } catch(e) {}

  // Settings panel
  setText('settingsEmail', currentUser?.email || '-');
  setText('settingsPlan', tierLabels[tier] || 'Free');
  setText('settingsTokens', isUnlimited ? 'Unlimited' : remaining + ' / ' + total);

  // Store locally for background.js to check
  chrome.storage.local.set({
    unicornds_credits: remaining,
    unicornds_membership: tier || 'free',
    unicornds_tokens_used: used,
    unicornds_tokens_total: total,
    unicornds_tier: tier,
  });
}

// ══════════════════════════════════════════════════════════
// AUTH ACTIONS
// ══════════════════════════════════════════════════════════

function showSubscribeScreen() {
  $('authScreen').style.display = 'none';
  $('mainApp').style.display = 'none';
  const vScreen = $('verifyScreen');
  if (vScreen) vScreen.style.display = 'none';

  let sScreen = $('subscribeScreen');
  if (!sScreen) {
    sScreen = document.createElement('div');
    sScreen.id = 'subscribeScreen';
    sScreen.style.cssText = 'padding:32px 24px; text-align:center; background:linear-gradient(180deg,#1a1a2e,#16213e); min-height:400px; display:flex; flex-direction:column; align-items:center; justify-content:center;';
    sScreen.innerHTML = `
      <div style="font-size:48px; margin-bottom:12px;">💳</div>
      <h2 style="color:#FFD700; font-size:18px; font-weight:800; margin-bottom:8px;">Choose Your Plan</h2>
      <p style="color:#aaa; font-size:12px; margin-bottom:16px; line-height:1.5;">
        Start your <b style="color:#10B981;">14-day free trial</b> to use UnicornDS.<br>
        Your card won't be charged until day 15.
      </p>
      <div style="width:100%; max-width:280px; display:flex; flex-direction:column; gap:8px; margin-bottom:16px;">
        <button class="uds-sub-btn" data-tier="starter" style="width:100%; padding:12px; background:linear-gradient(135deg,#7C3AED,#6D28D9); color:#fff; border:none; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer;">
          Starter — \u00a329.99/mo
        </button>
        <button class="uds-sub-btn" data-tier="growth" style="width:100%; padding:14px; background:linear-gradient(135deg,#10B981,#059669); color:#fff; border:2px solid #34D399; border-radius:8px; font-size:14px; font-weight:800; cursor:pointer;">
          \u2b50 Growth — \u00a359.99/mo (Most Popular)
        </button>
        <button class="uds-sub-btn" data-tier="empire" style="width:100%; padding:12px; background:linear-gradient(135deg,#F59E0B,#D97706); color:#1a1a2e; border:none; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer;">
          \ud83d\udc51 Empire — \u00a399.99/mo
        </button>
      </div>
      <p style="color:#888; font-size:10px; margin-bottom:12px;">14-day free trial on all plans. Cancel anytime.</p>
      <a href="https://www.unicornds.io/pricing" target="_blank" style="color:#A78BFA; font-size:11px; text-decoration:underline;">Compare plans on our website</a>
      <button onclick="logout()" style="background:none; border:none; color:#666; font-size:11px; cursor:pointer; margin-top:12px;">Sign Out</button>
    `;
    document.body.appendChild(sScreen);

    // Handle plan selection — open Stripe checkout on website
    sScreen.querySelectorAll('.uds-sub-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tier = btn.dataset.tier;
        chrome.tabs.create({ url: 'https://www.unicornds.io/pricing?plan=' + tier });
      });
    });
  } else {
    sScreen.style.display = 'flex';
  }
}

async function handleLogin() {
  const email = $('authEmail').value.trim();
  const password = $('authPassword').value;
  if (!email || !password) { showAuthError('Please enter email and password'); return; }

  hideAuthError();
  disable('btnLogin');
  $('btnLogin').textContent = 'Signing in…';

  try {
    currentUser = await signIn(email, password);
    await saveSession(currentUser);

    // Check email verification
    const verified = await checkEmailVerified(currentUser.idToken);
    if (!verified) {
      showEmailVerificationScreen();
      return;
    }

    showMainApp();
    const userData = await getUserDoc();
    updateUserUI(userData);

    // Check if user has a paid subscription (card verification)
    const tier = userData?.tier || 'free';
    const hasSub = userData?.stripe_subscription_id || userData?.stripe_customer_id;
    if (tier === 'free' && !hasSub) {
      showSubscribeScreen();
      return;
    }

    initMainApp();
  } catch (err) {
    const msg = friendlyError(err.message);
    showAuthError(msg);
  } finally {
    enable('btnLogin');
    $('btnLogin').textContent = 'Sign In';
  }
}

// Check if user's email is verified via Firebase REST API
async function checkEmailVerified(idToken) {
  try {
    const res = await fetch(`${AUTH_URL}:lookup?key=${FIREBASE.apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idToken }),
    });
    const data = await res.json();
    return data.users?.[0]?.emailVerified === true;
  } catch { return false; }
}

// Send verification email via Firebase REST API
async function sendVerificationEmail() {
  try {
    const token = await getValidToken();
    if (!token) return;
    await fetch(`${AUTH_URL}:sendOobCode?key=${FIREBASE.apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requestType: 'VERIFY_EMAIL', idToken: token }),
    });
    return true;
  } catch { return false; }
}

function showEmailVerificationScreen() {
  $('authScreen').style.display = 'none';
  $('mainApp').style.display = 'none';
  // Show verification message
  let vScreen = $('verifyScreen');
  if (!vScreen) {
    vScreen = document.createElement('div');
    vScreen.id = 'verifyScreen';
    vScreen.style.cssText = 'padding:32px 24px; text-align:center; background:linear-gradient(180deg,#1a1a2e,#16213e); min-height:400px; display:flex; flex-direction:column; align-items:center; justify-content:center;';
    vScreen.innerHTML = `
      <div style="font-size:48px; margin-bottom:12px;">📧</div>
      <h2 style="color:#FFD700; font-size:18px; font-weight:800; margin-bottom:8px;">Verify Your Email</h2>
      <p style="color:#aaa; font-size:12px; margin-bottom:4px;">We sent a verification link to:</p>
      <p style="color:#A78BFA; font-size:13px; font-weight:600; margin-bottom:20px;">${currentUser?.email || ''}</p>
      <p style="color:#888; font-size:11px; margin-bottom:20px; line-height:1.5;">
        Open your email and click the link.<br>Then come back and click the button below.
      </p>
      <button id="btnCheckVerified" style="width:100%; max-width:260px; padding:12px; background:#7B2FBE; color:#fff; border:none; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer; margin-bottom:8px;">
        I've Verified My Email ✓
      </button>
      <button id="btnResendVerify" style="width:100%; max-width:260px; padding:10px; background:none; color:#A78BFA; border:1px solid #3d3580; border-radius:8px; font-size:12px; cursor:pointer; margin-bottom:12px;">
        Resend Verification Email
      </button>
      <p id="verifyStatus" style="color:#888; font-size:11px;"></p>
      <button onclick="logout()" style="background:none; border:none; color:#666; font-size:11px; cursor:pointer; margin-top:12px;">Sign Out</button>
    `;
    document.body.appendChild(vScreen);

    $('btnCheckVerified').addEventListener('click', async () => {
      $('btnCheckVerified').textContent = 'Checking...';
      const token = await getValidToken();
      if (token && await checkEmailVerified(token)) {
        vScreen.style.display = 'none';
        showMainApp();
        const userData = await getUserDoc();
        updateUserUI(userData);
        initMainApp();
      } else {
        $('verifyStatus').textContent = 'Not verified yet. Check your inbox and click the link.';
        $('verifyStatus').style.color = '#e74c3c';
      }
      $('btnCheckVerified').textContent = "I've Verified My Email ✓";
    });

    $('btnResendVerify').addEventListener('click', async () => {
      const ok = await sendVerificationEmail();
      $('verifyStatus').textContent = ok ? 'Verification email sent! Check your inbox.' : 'Please wait a minute before resending.';
      $('verifyStatus').style.color = ok ? '#2ecc71' : '#e74c3c';
    });
  } else {
    vScreen.style.display = 'flex';
  }
}

async function handleRegister() {
  const email = $('authEmail').value.trim();
  const password = $('authPassword').value;
  const confirm = $('authPasswordConfirm').value;

  if (!email || !password) { showAuthError('Please enter email and password'); return; }
  if (password !== confirm) { showAuthError('Passwords do not match'); return; }
  if (password.length < 6) { showAuthError('Password must be at least 6 characters'); return; }

  hideAuthError();
  disable('btnRegister');
  $('btnRegister').textContent = 'Creating account…';

  try {
    currentUser = await signUp(email, password);
    await saveSession(currentUser);

    showMainApp();
    const userData = await getUserDoc();
    updateUserUI(userData);
    initMainApp();
  } catch (err) {
    showAuthError(friendlyError(err.message));
  } finally {
    enable('btnRegister');
    $('btnRegister').textContent = 'Create Account';
  }
}

function logout() {
  currentUser = null;
  clearSession();
  chrome.storage.local.remove([
    'unicornds_credits', 'unicornds_membership',
    'unicornds_tokens_used', 'unicornds_tokens_total',
    'unicornds_email_verified',
  ]);
  // Hide verify screen if showing
  const vScreen = $('verifyScreen');
  if (vScreen) vScreen.style.display = 'none';
  const sScreen = $('subscribeScreen');
  if (sScreen) sScreen.style.display = 'none';
  showAuthScreen();
}

function friendlyError(code) {
  const map = {
    'EMAIL_NOT_FOUND': 'No account found with this email',
    'INVALID_PASSWORD': 'Incorrect password',
    'INVALID_LOGIN_CREDENTIALS': 'Incorrect email or password',
    'EMAIL_EXISTS': 'An account with this email already exists',
    'TOO_MANY_ATTEMPTS_TRY_LATER': 'Too many attempts - try again later',
    'WEAK_PASSWORD': 'Password must be at least 6 characters',
    'INVALID_EMAIL': 'Please enter a valid email address',
    'USER_DISABLED': 'This account has been disabled',
  };
  return map[code] || code || 'Something went wrong - please try again';
}

// ══════════════════════════════════════════════════════════
// MAIN APP LOGIC
// ══════════════════════════════════════════════════════════

async function initMainApp() {
  // Check current tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  const isAli = /aliexpress\.[^/]+\/item\/\d+\.html/.test(tab.url || '');

  if (isAli) {
    setStatus('🟡 AliExpress product page detected', 'loading');
    enable('btnScrapeAli');

    chrome.storage.local.get('unicornds_last_product', (data) => {
      if (data.unicornds_last_product) {
        displayProduct(data.unicornds_last_product);
        setStatus('✅ Product loaded', 'success');
      } else {
        setStatus('⏳ Click "Scrape This Product" to begin', 'waiting');
      }
    });
  } else {
    setStatus('ℹ️ Navigate to an AliExpress product page', 'idle');
    disable('btnScrapeAli');
  }
}

function displayProduct(product) {
  currentProduct = product;
  setStatus('✅ Product scraped', 'success');
  show('aliProductCard');
  setText('aliProductTitle', product.cleanedTitle || product.title || '-');
  setText('aliProductId', 'ID: ' + (product.productId || '-'));
  setText('aliMarketplace', (product.marketplace || '').toUpperCase());
  setText('aliStockStatus', product.stockStatus?.status || '-');
  enable('btnScrapeAli');
  enable('btnBuildTitles');

  // Calculate and show profit
  const costPrice = parseFloat(product.price?.minAmount || product.price) || 0;
  if (costPrice > 0) {
    chrome.runtime.sendMessage({
      type: 'calculate_profit',
      costPrice: costPrice,
      sellPrice: parseFloat(product.custom_price) || 0,
    }, (resp) => {
      if (resp?.profit) {
        const p = resp.profit;
        show('aliPricingRow');
        setText('aliEbayPrice', p.currency + p.sellPrice.toFixed(2));
        setText('aliCostPrice', p.currency + p.costPrice.toFixed(2));

        const profitEl = $('aliProfit');
        if (profitEl) {
          profitEl.textContent = p.currency + p.profit.toFixed(2);
          profitEl.style.color = p.profit > 0 ? '#4ade80' : '#ff6b6b';
        }

        setText('aliMargin', p.margin.toFixed(1) + '%');
        setText('aliMarkup', p.breakdown);
      }
    });
  }
}

function displayTitles(result) {
  currentTitles = result;
  const list = $('aliTitlesList');
  list.innerHTML = '';

  (result.titles || []).slice(0, 6).forEach((t) => {
    const item = document.createElement('div');
    item.className = 'title-item' + (t.title === result.recommended ? ' recommended' : '');
    const validLabel = t.valid
      ? '<span class="title-valid">✅ Valid</span>'
      : `<span class="title-invalid">⚠️ ${(t.issues || []).join('; ')}</span>`;
    item.innerHTML = `
      <div class="title-text">${t.title}</div>
      <div class="title-meta">${t.charCount} chars · ${t.strategy || ''} · ${validLabel}</div>
    `;
    item.addEventListener('click', () => {
      navigator.clipboard.writeText(t.title);
      item.style.background = '#0d2818';
      setTimeout(() => { item.style.background = ''; }, 1200);
    });
    list.appendChild(item);
  });

  show('aliTitlesOutput');
  if (result.recommended) enable('btnCopyRecommended');
}

// ── eBay page helper ─────────────────────────────────────
function openEbayPageAndSend(urlPath, messageType, btnId) {
  // Popup windows are killed the moment they lose focus — and opening a new
  // tab shifts focus, so any setTimeout/listener we set here dies too.
  // Instead, delegate to the background service worker, which stays alive.
  const btn = $(btnId);
  if (btn) { btn.textContent = '⏳ Opening…'; btn.disabled = true; }

  chrome.runtime.sendMessage({
    type: 'uds_open_ebay_and_dispatch',
    urlPath,
    messageType,
  }, () => {
    // No-op callback — popup is about to close anyway. Background handles the rest.
    if (btn) { btn.textContent = btn.dataset.label; btn.disabled = false; }
  });
}

// ══════════════════════════════════════════════════════════
// EVENT LISTENERS
// ══════════════════════════════════════════════════════════

// ── Auth ─────────────────────────────────────────────────
$('btnLogin').addEventListener('click', handleLogin);
$('btnRegister').addEventListener('click', handleRegister);
$('btnLogout').addEventListener('click', logout);

$('showRegister').addEventListener('click', (e) => {
  e.preventDefault();
  hide('loginButtons');
  show('registerButtons');
  hideAuthError();
});
$('showLogin').addEventListener('click', (e) => {
  e.preventDefault();
  show('loginButtons');
  hide('registerButtons');
  hideAuthError();
});

// Enter key on password fields
$('authPassword').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    if ($('registerButtons').classList.contains('hidden')) {
      handleLogin();
    }
  }
});
$('authPasswordConfirm')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') handleRegister();
});

// ── Tabs ─────────────────────────────────────────────────
document.querySelectorAll('.tab-item').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab-item').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
    tab.classList.add('active');
    $(tab.dataset.panel)?.classList.add('active');
  });
});

// ── Listing Panel ────────────────────────────────────────
$('btnScrapeAli').addEventListener('click', async () => {
  setStatus('🔍 Scraping product…', 'loading');
  disable('btnScrapeAli');

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { setStatus('❌ No active tab', 'error'); enable('btnScrapeAli'); return; }

  chrome.tabs.sendMessage(tab.id, { type: 'scrape_aliexpress_product' }, (res) => {
    if (chrome.runtime.lastError) {
      setStatus('❌ Reload the AliExpress page first', 'error');
      enable('btnScrapeAli');
      return;
    }
    if (res?.success && res.data) {
      displayProduct(res.data);
    } else {
      setStatus('❌ ' + (res?.error || 'Scrape failed'), 'error');
      enable('btnScrapeAli');
    }
  });
});

// btnBuildTitles and btnCopyRecommended removed - AI generates titles automatically during listing
// AI Title Builder page still available in Tools tab for manual use

// ── Tools Panel ──────────────────────────────────────────
$('btnProductHunter').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/product-hunter/hunter.html') });
});
$('btnCompetitorScanner').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/competitor-scanner/scanner.html') });
});
// ── PRE-GATE: check tier before opening premium pages ──
// Shows a notification if blocked, opens page if allowed.
function premiumPageOpen(action, url) {
  chrome.runtime.sendMessage({ type: 'check_tier', action }, (r) => {
    if (chrome.runtime.lastError || !r) {
      // Background not ready — open page anyway, let the page-level gate catch it
      chrome.tabs.create({ url });
      return;
    }
    if (!r.allowed) {
      // Show a styled alert inside the popup instead of opening the page
      const msg = r.error || 'This feature requires a higher plan.';
      const existing = document.getElementById('uds-upgrade-alert');
      if (existing) existing.remove();
      const alert = document.createElement('div');
      alert.id = 'uds-upgrade-alert';
      alert.style.cssText = 'position:fixed;top:0;left:0;right:0;padding:12px;background:#7C3AED;color:#fff;text-align:center;font-size:13px;z-index:9999;font-family:-apple-system,sans-serif;';
      alert.innerHTML = `⛔ ${msg} <a href="https://unicornds.io/pricing" target="_blank" style="color:#F59E0B;text-decoration:underline;margin-left:8px;">Upgrade</a>`;
      document.body.appendChild(alert);
      setTimeout(() => alert.remove(), 5000);
      return;
    }
    chrome.tabs.create({ url });
  });
}

$('btnOrderManager').addEventListener('click', () => {
  premiumPageOpen('orders_sync', chrome.runtime.getURL('pages/orders/orders.html'));
});
$('btnFastTracker').addEventListener('click', () => {
  premiumPageOpen('tracker', chrome.runtime.getURL('pages/tracker/tracker.html'));
});
$('btnBulkLister').addEventListener('click', () => {
  premiumPageOpen('bulk_lister', chrome.runtime.getURL('pages/bulk-lister/bulk-lister.html'));
});
$('btnBulkListerFromPanel').addEventListener('click', () => {
  premiumPageOpen('bulk_lister', chrome.runtime.getURL('pages/bulk-lister/bulk-lister.html'));
});
$('btnImageDesigner').addEventListener('click', () => {
  premiumPageOpen('image_designer', chrome.runtime.getURL('pages/image-designer/designer.html'));
});
$('btnTitleBuilder').addEventListener('click', () => {
  premiumPageOpen('ai_title', chrome.runtime.getURL('pages/title-builder/title-builder.html'));
});
$('btnDownloadListings').addEventListener('click', () => {
  openEbayPageAndSend('/sh/reports/downloads', 'download_active_listings_csv', 'btnDownloadListings');
});
$('btnUploadListings').addEventListener('click', () => {
  openEbayPageAndSend('/sh/reports/uploads', 'upload_csv', 'btnUploadListings');
});
$('btnSendWatcherOffers').addEventListener('click', () => {
  openEbayPageAndSend('/sh/lst/active?pill_status=sioEligible', 'send-offers', 'btnSendWatcherOffers');
});
$('btnReviewOffers').addEventListener('click', () => {
  openEbayPageAndSend('/sh/lst/active?status=PENDING_OFFERS', 'review_offers', 'btnReviewOffers');
});
$('btnDuplicateChecker').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/scanner/page_updated.html') });
});
$('btnMessageTemplates').addEventListener('click', () => {
  chrome.storage.local.get('unicornds_primary_market', (data) => {
    const market = data.unicornds_primary_market || 'co_uk';
    const domains = { com: 'www.ebay.com', co_uk: 'www.ebay.co.uk', de: 'www.ebay.de', com_au: 'www.ebay.com.au', ca: 'www.ebay.ca', fr: 'www.ebay.fr' };
    const domain = domains[market] || 'www.ebay.co.uk';
    chrome.tabs.create({ url: 'https://' + domain + '/sh/msg' });
  });
});

// ── Settings Panel ───────────────────────────────────────
$('btnPricingSettings').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/options/options.html#pricing') });
});
$('btnTemplateEditor').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/options/options.html#templates') });
});
$('btnPromptEditor').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/options/options.html#prompts') });
});
$('btnOpenOptions').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});
$('btnUpgrade').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/upgrade/upgrade.html') });
});

// ── Quick Settings Save/Load ────────────────────────────
// Load saved settings (per-source: AliExpress vs Amazon)
chrome.storage.local.get([
  'unicornds_markup_ali', 'unicornds_markup_amz', 'unicornds_markup',
  'unicornds_stock_qty_ali', 'unicornds_stock_qty_amz', 'unicornds_stock_qty',
  'unicornds_promo_rate_ali', 'unicornds_promo_rate_amz', 'unicornds_promo_rate',
  'unicornds_shipping_ali', 'unicornds_shipping_amz',
  'unicornds_vat', 'unicornds_ai_enabled', 'unicornds_auto_approve',
], (data) => {
  // AliExpress (fall back to generic if per-source not set yet)
  $('settingsMarkupAli').value = data.unicornds_markup_ali || data.unicornds_markup || 50;
  $('settingsStockQtyAli').value = data.unicornds_stock_qty_ali || data.unicornds_stock_qty || 10;
  $('settingsPromoRateAli').value = data.unicornds_promo_rate_ali ?? data.unicornds_promo_rate ?? 10;
  $('settingsShippingAli').value = data.unicornds_shipping_ali || 0;
  // Amazon
  $('settingsMarkupAmz').value = data.unicornds_markup_amz || data.unicornds_markup || 25;
  $('settingsStockQtyAmz').value = data.unicornds_stock_qty_amz || data.unicornds_stock_qty || 10;
  $('settingsPromoRateAmz').value = data.unicornds_promo_rate_amz ?? data.unicornds_promo_rate ?? 10;
  $('settingsShippingAmz').value = data.unicornds_shipping_amz || 0;
  // Shared
  if (data.unicornds_vat) $('settingsVat').value = data.unicornds_vat;
  if (data.unicornds_ai_enabled === false) $('settingsAiEnabled').checked = false;
  if (data.unicornds_auto_approve === false) $('settingsAutoApprove').checked = false;
});

$('btnSaveSettings').addEventListener('click', () => {
  const settings = {
    // Per-source
    unicornds_markup_ali: parseFloat($('settingsMarkupAli').value) || 50,
    unicornds_markup_amz: parseFloat($('settingsMarkupAmz').value) || 25,
    unicornds_stock_qty_ali: parseInt($('settingsStockQtyAli').value) || 10,
    unicornds_stock_qty_amz: parseInt($('settingsStockQtyAmz').value) || 10,
    unicornds_promo_rate_ali: parseFloat($('settingsPromoRateAli').value) || 10,
    unicornds_promo_rate_amz: parseFloat($('settingsPromoRateAmz').value) || 10,
    unicornds_shipping_ali: parseFloat($('settingsShippingAli').value) || 0,
    unicornds_shipping_amz: parseFloat($('settingsShippingAmz').value) || 0,
    // Backward compat — use AliExpress values as default
    unicornds_markup: parseFloat($('settingsMarkupAli').value) || 50,
    unicornds_stock_qty: parseInt($('settingsStockQtyAli').value) || 10,
    unicornds_promo_rate: parseFloat($('settingsPromoRateAli').value) || 10,
    // Shared
    unicornds_vat: $('settingsVat').value.trim(),
    unicornds_ai_enabled: $('settingsAiEnabled').checked,
    unicornds_auto_approve: $('settingsAutoApprove').checked,
  };
  chrome.storage.local.set(settings, () => {
    $('btnSaveSettings').textContent = '✅ Saved!';
    $('btnSaveSettings').style.background = '#27ae60';
    setTimeout(() => {
      $('btnSaveSettings').textContent = '💾 Save Settings';
      $('btnSaveSettings').style.background = '#7C3AED';
    }, 2000);
  });
});

// ── Background messages ──────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'aliexpress_product_ready') displayProduct(message.product);
  if (message.type === 'aliexpress_scrape_failed') setStatus('❌ ' + message.reason, 'error');
});

// ══════════════════════════════════════════════════════════
// INIT - Check if already logged in
// ══════════════════════════════════════════════════════════

(async function init() {
  // Check for existing session
  const session = await loadSession();
  if (session?.uid && session?.idToken) {
    // Restore session
    currentUser = session;

    // Check email verification (check every time, cache for 24h)
    const verifyCache = await new Promise(r => chrome.storage.local.get('unicornds_email_verified', r));
    let isVerified = verifyCache.unicornds_email_verified;
    
    // Re-check every 24 hours or if not cached
    if (!isVerified) {
      isVerified = await checkEmailVerified(currentUser.idToken);
      if (isVerified) chrome.storage.local.set({ unicornds_email_verified: true });
    }

    if (!isVerified) {
      showEmailVerificationScreen();
      return;
    }

    showMainApp();
    // Fetch latest user data from Firestore
    let userData = null;
    try {
      userData = await getUserDoc();
      updateUserUI(userData || {});
    } catch (e) {
      console.warn('[UnicornDS] Firestore read failed, using stored data');
      const s = await new Promise(r => chrome.storage.local.get(['unicornds_tier', 'unicornds_credits', 'unicornds_tokens_used', 'unicornds_tokens_total'], r));
      userData = { tier: s.unicornds_tier || 'free', tokensUsed: s.unicornds_tokens_used || 0, tokensTotal: s.unicornds_tokens_total || 10 };
      updateUserUI(userData);
    }

    // Check subscription (card verification)
    const tier = userData?.tier || 'free';
    const hasSub = userData?.stripe_subscription_id || userData?.stripe_customer_id;
    if (tier === 'free' && !hasSub) {
      showSubscribeScreen();
      return;
    }

    initMainApp();
  } else {
    // No session - show login screen
    showAuthScreen();
  }
})();

// ============================================================
// ADDRESS HELPER (Growth+ only)
// ============================================================
(function initAddressHelper() {
  const btnToggle = document.getElementById('btnAddressHelper');
  const panel = document.getElementById('addressHelperPanel');
  const btnCopy = document.getElementById('addrCopy');
  const btnPaste = document.getElementById('addrPaste');
  const review = document.getElementById('addrReview');
  const status = document.getElementById('addrStatus');
  const histPanel = document.getElementById('addrHistoryPanel');
  const histList = document.getElementById('addrHistList');
  const histCount = document.getElementById('addrHistCount');

  if (!btnToggle) return;

  // Toggle panel
  btnToggle.addEventListener('click', () => {
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    // Load any saved address
    chrome.runtime.sendMessage({ action: 'getOrderInfo' }, (r) => {
      if (r?.orderInfo) {
        fillReview(r.orderInfo);
        review.style.display = 'block';
        btnPaste.disabled = false;
        status.textContent = 'Ready: ' + (r.orderInfo.firstName || '') + ' ' + (r.orderInfo.lastName || '');
        status.style.color = '#10B981';
      }
    });
  });

  // COPY
  btnCopy.addEventListener('click', () => {
    btnCopy.textContent = '⏳ Copying...';
    chrome.runtime.sendMessage({ action: 'copyAddress' }, (r) => {
      btnCopy.textContent = '📋 Copy Address';
      if (r?.success && r.orderInfo) {
        fillReview(r.orderInfo);
        review.style.display = 'block';
        histPanel.style.display = 'none';
        btnPaste.disabled = false;
        status.textContent = '✅ Copied from ' + (r.source || 'page') + ': ' + r.orderInfo.firstName + ' ' + r.orderInfo.lastName;
        status.style.color = '#10B981';
      } else {
        status.textContent = '❌ ' + (r?.error || 'Could not capture');
        status.style.color = '#EF4444';
      }
    });
  });

  // PASTE (with duplicate check)
  btnPaste.addEventListener('click', () => {
    const info = getReviewVals();
    chrome.runtime.sendMessage({ action: 'checkDuplicate', orderInfo: info }, (r) => {
      if (r?.duplicate) {
        const d = new Date(r.duplicate.savedAt);
        document.getElementById('addrDupDate').textContent = d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
        document.getElementById('addrDupWarning').style.display = 'block';
      } else {
        doPaste();
      }
    });
  });

  document.getElementById('addrDupYes')?.addEventListener('click', () => {
    document.getElementById('addrDupWarning').style.display = 'none';
    doPaste();
  });
  document.getElementById('addrDupNo')?.addEventListener('click', () => {
    document.getElementById('addrDupWarning').style.display = 'none';
    status.textContent = 'Cancelled';
    status.style.color = '#888';
  });

  function doPaste() {
    btnPaste.textContent = '⏳ Pasting...';
    btnPaste.disabled = true;
    // Save any edits first
    const info = getReviewVals();
    chrome.storage.local.set({ orderInfo: info }, () => {
      chrome.runtime.sendMessage({ action: 'pasteAddress' }, (r) => {
        btnPaste.textContent = '📋 Paste to AliExpress';
        btnPaste.disabled = false;
        if (r?.success) {
          status.textContent = '✅ Filled ' + r.fieldsFilled + ' fields';
          status.style.color = '#10B981';
        } else {
          status.textContent = '❌ ' + (r?.error || 'Not on AliExpress');
          status.style.color = '#EF4444';
        }
      });
    });
  }

  // SAVE EDITS
  document.getElementById('addrSave')?.addEventListener('click', () => {
    const info = getReviewVals();
    chrome.runtime.sendMessage({ action: 'saveOrderInfo', orderInfo: info }, (r) => {
      if (r?.success) {
        status.textContent = '✅ Saved: ' + info.firstName + ' ' + info.lastName;
        status.style.color = '#10B981';
        btnPaste.disabled = false;
      }
    });
  });

  // CLEAR
  document.getElementById('addrClear')?.addEventListener('click', () => {
    review.style.display = 'none';
    ['addr-fn','addr-ln','addr-pc','addr-pn','addr-st','addr-zip','addr-co'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    btnPaste.disabled = true;
    document.getElementById('addrDupWarning').style.display = 'none';
    chrome.runtime.sendMessage({ action: 'clearOrderInfo' });
    status.textContent = 'No address copied';
    status.style.color = '#888';
  });

  // HISTORY
  document.getElementById('addrHistory')?.addEventListener('click', () => {
    if (histPanel.style.display === 'none') {
      loadHistory();
      histPanel.style.display = 'block';
    } else {
      histPanel.style.display = 'none';
    }
  });

  document.getElementById('addrClearHist')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'clearHistory' }, () => {
      loadHistory();
      status.textContent = 'History cleared';
      status.style.color = '#888';
    });
  });

  function loadHistory() {
    chrome.runtime.sendMessage({ action: 'getHistory' }, (r) => {
      const h = r?.history || [];
      histCount.textContent = h.length;
      histList.innerHTML = '';
      if (!h.length) {
        histList.innerHTML = '<div style="color:#666; font-size:11px; text-align:center; padding:10px;">No history</div>';
        return;
      }
      for (const e of h) {
        const d = new Date(e.savedAt);
        const div = document.createElement('div');
        div.style.cssText = 'padding:6px 8px; border-bottom:1px solid #2d3a5c; cursor:pointer; font-size:11px;';
        div.innerHTML = '<div style="color:#fff; font-weight:bold;">' + (e.firstName || '') + ' ' + (e.lastName || '') + '</div>' +
          '<div style="color:#888;">' + (e.street1 || '') + ', ' + (e.zip || '') + '</div>' +
          '<div style="color:#666; font-size:10px;">' + d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}) + '</div>';
        div.addEventListener('click', () => {
          chrome.runtime.sendMessage({ action: 'loadFromHistory', orderInfo: e }, () => {
            fillReview(e);
            review.style.display = 'block';
            histPanel.style.display = 'none';
            status.textContent = '✅ Loaded: ' + e.firstName + ' ' + e.lastName;
            status.style.color = '#10B981';
            btnPaste.disabled = false;
          });
        });
        div.addEventListener('mouseenter', () => { div.style.background = 'rgba(255,255,255,0.05)'; });
        div.addEventListener('mouseleave', () => { div.style.background = 'none'; });
        histList.appendChild(div);
      }
    });
  }

  function fillReview(info) {
    const $ = id => document.getElementById(id);
    $('addr-fn').value = info.firstName || '';
    $('addr-ln').value = info.lastName || '';
    $('addr-pc').value = info.phoneCode || '';
    $('addr-pn').value = info.phoneNumber || '';
    $('addr-st').value = info.street1 || '';
    $('addr-zip').value = info.zip || '';
    $('addr-co').value = info.country || '';
  }

  function getReviewVals() {
    const $ = id => (document.getElementById(id)?.value || '').trim();
    const fn = $('addr-fn'), ln = $('addr-ln') || fn;
    return {
      firstName: fn, lastName: ln, name: (fn + ' ' + ln).trim(),
      phoneCode: $('addr-pc'), phoneNumber: $('addr-pn'),
      phone: $('addr-pc') + $('addr-pn'),
      street1: $('addr-st'), zip: $('addr-zip'), country: $('addr-co')
    };
  }
})();

// ══════════════════════════════════════════════════════════
// UPDATE CHECKER — checks unicornds.io/api/version on popup open
// ══════════════════════════════════════════════════════════
(async function checkForUpdates() {
  try {
    const currentVersion = chrome.runtime.getManifest().version;
    const storage = await chrome.storage.local.get(['unicornds_dismissed_version']);
    
    const res = await fetch('https://www.unicornds.io/api/version', { cache: 'no-cache' });
    if (!res.ok) return;
    const data = await res.json();
    const latestVersion = data.version;
    
    // Compare version numbers (e.g. "7.11" vs "7.11.2")
    const current = currentVersion.split('.').map(Number);
    const latest = latestVersion.split('.').map(Number);
    let needsUpdate = false;
    for (let i = 0; i < Math.max(current.length, latest.length); i++) {
      const c = current[i] || 0;
      const l = latest[i] || 0;
      if (l > c) { needsUpdate = true; break; }
      if (c > l) break;
    }
    if (!needsUpdate) return;
    
    // Skip if already dismissed (unless critical update)
    if (storage.unicornds_dismissed_version === latestVersion && !data.critical) return;
    
    // Show the update banner
    const banner = document.getElementById('updateBanner');
    const title = document.getElementById('updateTitle');
    const desc = document.getElementById('updateDesc');
    if (banner && title && desc) {
      title.textContent = 'Update Available \u2014 v' + latestVersion;
      desc.textContent = data.changelog?.[0] || 'Bug fixes and improvements.';
      banner.style.display = 'block';
    }
    
    // Store for background.js badge
    chrome.storage.local.set({ unicornds_update_available: latestVersion });
  } catch (e) { /* silent */ }
})();

function dismissUpdate() {
  const banner = document.getElementById('updateBanner');
  if (banner) banner.style.display = 'none';
  const title = document.getElementById('updateTitle')?.textContent || '';
  const ver = title.match(/v([\d.]+)/)?.[1] || '';
  if (ver) chrome.storage.local.set({ unicornds_dismissed_version: ver });
}
