/**
 * UnicornDS - Message Templates
 * Injects a floating template panel on eBay messaging pages
 * Click a template → auto-fills the message textbox
 * Supports variables: {buyer}, {title}, {tracking}, {days}
 */

console.log('[UnicornDS] Message Templates loaded');

// ═══════════════════════════════════════════════════════
// DEFAULT TEMPLATES
// ═══════════════════════════════════════════════════════
const DEFAULT_TEMPLATES = [
  { id: 'd1', category: 'Shipping', name: 'Item Dispatched', message: 'Hi there,\n\nYour order has been dispatched and is on its way! Please allow 15-25 working days for delivery as the item ships from our international warehouse.\n\nIf you have any questions, feel free to message us.\n\nThank you for your purchase!' },
  { id: 'd2', category: 'Shipping', name: 'Tracking Number', message: 'Hi there,\n\nHere is your tracking information:\n\nTracking Number: {tracking}\n\nYou can track your parcel using the tracking number above. Please allow a few days for tracking to update.\n\nThank you!' },
  { id: 'd3', category: 'Shipping', name: 'Delivery Delay', message: 'Hi there,\n\nThank you for your patience. There is a slight delay with your order due to high demand. Your item should arrive within the next 7-10 working days.\n\nWe sincerely apologise for any inconvenience.\n\nKind regards' },
  { id: 'd4', category: 'Shipping', name: 'Item In Transit', message: 'Hi there,\n\nYour item is currently in transit. International deliveries can take 15-25 working days. If your item has not arrived after 30 working days, please contact us and we will resolve this for you.\n\nThank you for your patience!' },
  { id: 'd5', category: 'Returns', name: 'Return Accepted', message: 'Hi there,\n\nI am sorry to hear you would like to return the item. Your return request has been accepted.\n\nPlease send the item back and once received, a full refund will be issued.\n\nApologies for any inconvenience.\n\nKind regards' },
  { id: 'd6', category: 'Returns', name: 'Refund Issued', message: 'Hi there,\n\nYour refund has been processed. Please allow 3-5 working days for the funds to appear in your account.\n\nWe are sorry for any inconvenience and hope to serve you again in the future.\n\nKind regards' },
  { id: 'd7', category: 'Returns', name: 'Keep Item + Refund', message: 'Hi there,\n\nWe are sorry to hear you are not satisfied. To save you the hassle of returning the item, please keep it and we will issue a full refund.\n\nYour refund has been processed. Please allow 3-5 working days.\n\nKind regards' },
  { id: 'd8', category: 'Service', name: 'Thank You', message: 'Thank you for your purchase! We hope you are happy with your item.\n\nIf everything is satisfactory, we would really appreciate a positive review - it helps our small business greatly.\n\nIf there are any issues at all, please message us first and we will make it right.\n\nThank you!' },
  { id: 'd9', category: 'Service', name: 'Out of Stock', message: 'Hi there,\n\nWe sincerely apologise but unfortunately this item is currently out of stock from our supplier. We have issued a full refund to your account.\n\nPlease allow 3-5 working days for the refund to process.\n\nWe are very sorry for the inconvenience.\n\nKind regards' },
  { id: 'd10', category: 'Service', name: 'Wrong Item', message: 'Hi there,\n\nWe are very sorry that you received the wrong item. Please keep the incorrect item and we will send the correct one right away, or if you prefer, we can issue a full refund.\n\nPlease let us know how you would like to proceed.\n\nApologies for the mix-up.\n\nKind regards' },
  { id: 'd11', category: 'Service', name: 'Damaged Item', message: 'Hi there,\n\nWe are very sorry to hear your item arrived damaged. Could you please send us a photo of the damage so we can resolve this quickly?\n\nWe will either send a replacement or issue a full refund - whichever you prefer.\n\nApologies for the inconvenience.\n\nKind regards' },
  { id: 'd12', category: 'Service', name: 'Case Opened', message: 'Hi there,\n\nWe have noticed a case has been opened. We would like to resolve this for you as quickly as possible.\n\nWe can offer a full refund or send a replacement. Please let us know your preference and we will action it immediately.\n\nKind regards' },
];

// ═══════════════════════════════════════════════════════
// LOAD TEMPLATES FROM STORAGE (merge defaults + custom)
// ═══════════════════════════════════════════════════════
async function loadTemplates() {
  return new Promise(resolve => {
    chrome.storage.local.get('unicornds_message_templates', s => {
      const stored = s.unicornds_message_templates;
      if (stored && stored.length) {
        resolve(stored);
      } else {
        // First time - save defaults
        chrome.storage.local.set({ unicornds_message_templates: DEFAULT_TEMPLATES });
        resolve(DEFAULT_TEMPLATES);
      }
    });
  });
}

async function saveTemplates(templates) {
  return new Promise(r => chrome.storage.local.set({ unicornds_message_templates: templates }, r));
}

// ═══════════════════════════════════════════════════════
// INJECT FLOATING PANEL
// ═══════════════════════════════════════════════════════
async function injectPanel() {
  if (document.getElementById('uds-msg-panel')) return;

  const templates = await loadTemplates();
  const categories = [...new Set(templates.map(t => t.category))];

  const panel = document.createElement('div');
  panel.id = 'uds-msg-panel';
  panel.innerHTML = `
    <div class="uds-msg-header">
      <span class="uds-msg-logo">🦄 Templates</span>
      <div class="uds-msg-header-btns">
        <button id="uds-msg-add" class="uds-msg-hbtn" title="Add custom template">+</button>
        <button id="uds-msg-toggle" class="uds-msg-hbtn" title="Minimise">−</button>
      </div>
    </div>
    <div class="uds-msg-body" id="uds-msg-body">
      <div class="uds-msg-vars-hint" title="Available placeholders that auto-fill with order data">
        Variables: <code>{buyer}</code> <code>{first_name}</code> <code>{item}</code> <code>{tracking}</code> <code>{carrier}</code> <code>{order_id}</code> <code>{delivery_date}</code> <code>{shop_name}</code>
      </div>
      ${categories.map(cat => `
        <div class="uds-msg-cat">
          <div class="uds-msg-cat-title">${cat}</div>
          ${templates.filter(t => t.category === cat).map(t => `
            <button class="uds-msg-btn" data-id="${t.id}" title="${escHtml(t.message.substring(0, 100))}...">
              ${escHtml(t.name)}
            </button>
          `).join('')}
        </div>
      `).join('')}
      <div class="uds-msg-cat" id="uds-msg-add-form" style="display:none">
        <div class="uds-msg-cat-title">Add Template</div>
        <input type="text" id="uds-msg-new-name" placeholder="Template name" class="uds-msg-input" />
        <select id="uds-msg-new-cat" class="uds-msg-input">
          <option>Shipping</option><option>Returns</option><option>Service</option><option>Custom</option>
        </select>
        <textarea id="uds-msg-new-text" rows="4" placeholder="Message text — use {buyer}, {item}, {tracking}, etc." class="uds-msg-input"></textarea>
        <div class="uds-msg-add-btns">
          <button id="uds-msg-save-new" class="uds-msg-btn uds-msg-btn-save">💾 Save</button>
          <button id="uds-msg-cancel-new" class="uds-msg-btn">Cancel</button>
        </div>
      </div>
      <div class="uds-msg-footer">
        <button id="uds-msg-reset" class="uds-msg-link">Reset to defaults</button>
      </div>
    </div>
  `;

  // Inject styles
  const style = document.createElement('style');
  style.textContent = `
    #uds-msg-panel {
      position: fixed; top: 80px; right: 16px; width: 260px; z-index: 999999;
      background: #1E1B4B; border: 1px solid #7C3AED; border-radius: 12px;
      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif; color: #e0e0e0;
      box-shadow: 0 8px 32px rgba(0,0,0,0.4); overflow: hidden;
      transition: all 0.3s ease;
    }
    .uds-msg-header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 10px 14px; background: linear-gradient(135deg, #7C3AED, #6D28D9);
      cursor: move; user-select: none;
    }
    .uds-msg-logo { font-size: 14px; font-weight: 700; color: #fff; }
    .uds-msg-header-btns { display: flex; gap: 4px; }
    .uds-msg-hbtn {
      width: 24px; height: 24px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.3);
      background: rgba(255,255,255,0.1); color: #fff; font-size: 14px; cursor: pointer;
      display: flex; align-items: center; justify-content: center; transition: all 0.15s;
    }
    .uds-msg-hbtn:hover { background: rgba(255,255,255,0.25); }
    .uds-msg-body { padding: 8px; max-height: 500px; overflow-y: auto; }
    .uds-msg-body.collapsed { display: none; }
    .uds-msg-cat { margin-bottom: 8px; }
    .uds-msg-cat-title {
      font-size: 10px; font-weight: 700; color: #F59E0B; text-transform: uppercase;
      letter-spacing: 0.5px; padding: 4px 6px; margin-bottom: 4px;
    }
    .uds-msg-btn {
      display: block; width: 100%; padding: 8px 10px; margin-bottom: 3px;
      background: rgba(124,58,237,0.15); border: 1px solid rgba(124,58,237,0.3);
      border-radius: 6px; color: #ddd; font-size: 12px; text-align: left;
      cursor: pointer; transition: all 0.15s; white-space: nowrap;
      overflow: hidden; text-overflow: ellipsis;
    }
    .uds-msg-btn:hover { background: rgba(124,58,237,0.35); border-color: #7C3AED; color: #fff; }
    .uds-msg-btn-save { background: #059669 !important; border-color: #10B981 !important; color: #fff !important; }
    .uds-msg-btn-save:hover { background: #10B981 !important; }
    .uds-msg-input {
      width: 100%; padding: 6px 8px; margin-bottom: 4px; background: #0a0a1a;
      border: 1px solid #2a2a4a; border-radius: 6px; color: #ddd; font-size: 11px;
      font-family: inherit; resize: vertical;
    }
    .uds-msg-input:focus { outline: none; border-color: #7C3AED; }
    .uds-msg-add-btns { display: flex; gap: 4px; }
    .uds-msg-footer { padding: 6px; text-align: center; border-top: 1px solid #2a2a4a; margin-top: 4px; }
    .uds-msg-link {
      background: none; border: none; color: #888; font-size: 10px; cursor: pointer;
      text-decoration: underline;
    }
    .uds-msg-link:hover { color: #F59E0B; }
    .uds-msg-vars-hint {
      font-size: 9.5px; color: #a5a0cc; padding: 6px 8px; margin-bottom: 6px;
      background: rgba(124,58,237,0.08); border-radius: 6px; line-height: 1.5;
    }
    .uds-msg-vars-hint code {
      background: rgba(245,158,11,0.18); color: #FCD34D; padding: 1px 4px;
      border-radius: 3px; font-family: 'SF Mono', Menlo, monospace; font-size: 9px;
      margin: 0 1px; display: inline-block;
    }
    .uds-msg-toast {
      position: fixed; bottom: 20px; right: 20px; padding: 10px 18px; border-radius: 8px;
      background: #059669; color: #fff; font-size: 13px; font-weight: 600; z-index: 9999999;
      animation: udsMsgSlide 0.3s ease; box-shadow: 0 4px 16px rgba(0,0,0,0.3);
    }
    @keyframes udsMsgSlide { from { transform: translateY(20px); opacity: 0; } }
    #uds-msg-panel ::-webkit-scrollbar { width: 4px; }
    #uds-msg-panel ::-webkit-scrollbar-track { background: #1E1B4B; }
    #uds-msg-panel ::-webkit-scrollbar-thumb { background: #7C3AED; border-radius: 2px; }
  `;
  document.head.appendChild(style);
  document.body.appendChild(panel);

  // ── EVENT HANDLERS ──

  // Toggle minimise
  document.getElementById('uds-msg-toggle').addEventListener('click', () => {
    const body = document.getElementById('uds-msg-body');
    body.classList.toggle('collapsed');
    document.getElementById('uds-msg-toggle').textContent = body.classList.contains('collapsed') ? '+' : '−';
  });

  // Add template form
  document.getElementById('uds-msg-add').addEventListener('click', () => {
    const form = document.getElementById('uds-msg-add-form');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
  });
  document.getElementById('uds-msg-cancel-new').addEventListener('click', () => {
    document.getElementById('uds-msg-add-form').style.display = 'none';
  });
  document.getElementById('uds-msg-save-new').addEventListener('click', async () => {
    const name = document.getElementById('uds-msg-new-name').value.trim();
    const cat = document.getElementById('uds-msg-new-cat').value;
    const msg = document.getElementById('uds-msg-new-text').value.trim();
    if (!name || !msg) { alert('Please enter a name and message'); return; }
    const templates = await loadTemplates();
    templates.push({ id: 'c' + Date.now(), category: cat, name, message: msg });
    await saveTemplates(templates);
    document.getElementById('uds-msg-add-form').style.display = 'none';
    refreshPanel();
    showToast('✅ Template saved: ' + name);
  });

  // Reset defaults
  document.getElementById('uds-msg-reset').addEventListener('click', async () => {
    if (!confirm('Reset all templates to defaults? Custom templates will be lost.')) return;
    await saveTemplates(DEFAULT_TEMPLATES);
    refreshPanel();
    showToast('🔄 Templates reset to defaults');
  });

  // Template click - type into message box
  panel.addEventListener('click', async (e) => {
    const btn = e.target.closest('.uds-msg-btn[data-id]');
    if (!btn) return;
    const id = btn.dataset.id;
    const templates = await loadTemplates();
    const tmpl = templates.find(t => t.id === id);
    if (!tmpl) return;

    // Replace variables — pull from order context if available
    let msg = tmpl.message;
    const ctx = await getOrderContext();

    msg = msg.replace(/\{buyer\}/gi, ctx.buyerName || 'there');
    msg = msg.replace(/\{first_name\}/gi, ctx.firstName || ctx.buyerName || 'there');
    msg = msg.replace(/\{item\}/gi, ctx.itemTitle || 'your item');
    msg = msg.replace(/\{title\}/gi, ctx.itemTitle || 'your item');
    msg = msg.replace(/\{tracking\}/gi, ctx.tracking || '{tracking}');
    msg = msg.replace(/\{carrier\}/gi, ctx.carrier || 'Royal Mail');
    msg = msg.replace(/\{order_id\}/gi, ctx.orderId || '');
    msg = msg.replace(/\{days\}/gi, '15-25');
    msg = msg.replace(/\{delivery_date\}/gi, getDeliveryEstimate(15));
    msg = msg.replace(/\{shop_name\}/gi, ctx.shopName || 'our shop');

    // Type into textbox
    const success = await typeMessage(msg);
    if (success) {
      const dataInfo = ctx.buyerName ? ` for ${ctx.firstName || ctx.buyerName}` : '';
      showToast('📝 Template loaded: ' + tmpl.name + dataInfo);
    } else {
      showToast('⚠️ Could not find message textbox - please click on a conversation first');
    }
  });

  // Draggable
  makeDraggable(panel, panel.querySelector('.uds-msg-header'));
}

// ═══════════════════════════════════════════════════════
// PULL ORDER CONTEXT — from URL params + order storage
// ═══════════════════════════════════════════════════════
async function getOrderContext() {
  const ctx = {};

  // 1. Try buyer name from page
  ctx.buyerName = extractBuyerName();
  if (ctx.buyerName) {
    ctx.firstName = ctx.buyerName.split(' ')[0];
  }

  // 2. Try to find URL params with order/item ID
  const urlParams = new URLSearchParams(window.location.search);
  const itemId = urlParams.get('itemid') || urlParams.get('item') || urlParams.get('itemId');
  const orderId = urlParams.get('orderid') || urlParams.get('orderId') ||
                  urlParams.get('transactionId') || urlParams.get('transId');

  // 3. Try to look up order in storage
  if (itemId || orderId) {
    try {
      const data = await new Promise(r => chrome.storage.local.get('unicornds_orders', r));
      const orders = data.unicornds_orders || [];
      const match = orders.find(o =>
        (orderId && (o.ebayOrderId === orderId || o.ebayOrderIdFull === orderId)) ||
        (itemId && o.itemNumber === itemId)
      );
      if (match) {
        ctx.buyerName = ctx.buyerName || match.buyerName || match.buyerAddress?.name;
        if (ctx.buyerName && !ctx.firstName) ctx.firstName = ctx.buyerName.split(' ')[0];
        ctx.itemTitle = match.itemTitle;
        ctx.tracking = match.trackingNumber;
        ctx.carrier = match.trackingCarrier;
        ctx.orderId = match.ebayOrderId;
      }
    } catch(e) {}
  }

  // 4. Get user-set shop name from storage
  try {
    const shop = await new Promise(r => chrome.storage.local.get('unicornds_shop_name', r));
    ctx.shopName = shop.unicornds_shop_name || '';
  } catch(e) {}

  return ctx;
}

function getDeliveryEstimate(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long' });
}

// ═══════════════════════════════════════════════════════
// REFRESH PANEL (after add/delete/reset)
// ═══════════════════════════════════════════════════════
async function refreshPanel() {
  const panel = document.getElementById('uds-msg-panel');
  if (panel) panel.remove();
  await injectPanel();
}

// ═══════════════════════════════════════════════════════
// TYPE MESSAGE INTO TEXTBOX
// ═══════════════════════════════════════════════════════
async function typeMessage(text) {
  // Find the message textbox - check main page and iframes
  let textbox = findTextbox(document);

  // Search iframes
  if (!textbox) {
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      try {
        const doc = iframe.contentDocument;
        if (doc) {
          textbox = findTextbox(doc);
          if (textbox) break;
        }
      } catch (e) { /* cross-origin */ }
    }
  }

  if (!textbox) return false;

  // Clear existing text
  textbox.focus();
  await sleep(100);

  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set ||
                       Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;

  if (nativeSetter) {
    nativeSetter.call(textbox, text);
  } else {
    textbox.value = text;
  }

  textbox.dispatchEvent(new Event('input', { bubbles: true }));
  textbox.dispatchEvent(new Event('change', { bubbles: true }));
  await sleep(200);

  // Also try character-by-character for React forms
  try {
    textbox.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
  } catch (e) {}

  return true;
}

function findTextbox(doc) {
  const selectors = [
    '#imageupload__sendmessage--textbox',
    '[data-testid="send-message-textbox"]',
    'textarea[name="message"]',
    'textarea#message',
    'textarea[placeholder*="message"]',
    'textarea[placeholder*="Message"]',
    'textarea[placeholder*="type"]',
    'textarea[placeholder*="Type"]',
    'textarea',
  ];

  for (const sel of selectors) {
    const el = doc.querySelector(sel);
    if (el && isVisible(el) && !el.disabled && !el.readOnly) return el;
  }
  return null;
}

function isVisible(el) {
  if (!el || !el.isConnected) return false;
  const s = getComputedStyle(el);
  return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
}

// ═══════════════════════════════════════════════════════
// EXTRACT BUYER NAME FROM PAGE
// ═══════════════════════════════════════════════════════
function extractBuyerName() {
  // eBay messaging page shows buyer name in various places
  const selectors = [
    '.msg-header__user-name', '.participant-name', '[data-testid="participant-name"]',
    '.msg-thread__header-name', '.conversation-header__name',
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) return el.textContent.trim().split(' ')[0]; // First name only
  }
  return null;
}

// ═══════════════════════════════════════════════════════
// DRAGGABLE PANEL
// ═══════════════════════════════════════════════════════
function makeDraggable(panel, handle) {
  let isDragging = false, startX, startY, origX, origY;
  handle.addEventListener('mousedown', (e) => {
    if (e.target.closest('.uds-msg-hbtn')) return;
    isDragging = true;
    startX = e.clientX; startY = e.clientY;
    const rect = panel.getBoundingClientRect();
    origX = rect.left; origY = rect.top;
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    panel.style.right = 'auto';
    panel.style.left = (origX + e.clientX - startX) + 'px';
    panel.style.top = (origY + e.clientY - startY) + 'px';
  });
  document.addEventListener('mouseup', () => { isDragging = false; });
}

// ═══════════════════════════════════════════════════════
// UTILS
// ═══════════════════════════════════════════════════════
function escHtml(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function showToast(msg) {
  document.querySelectorAll('.uds-msg-toast').forEach(e => e.remove());
  const t = document.createElement('div');
  t.className = 'uds-msg-toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ═══════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════
function init() {
  // Wait for page to stabilise then inject
  let attempts = 0;
  const waitForPage = setInterval(() => {
    attempts++;
    if (document.body && (document.querySelector('textarea') || document.querySelector('iframe') || attempts > 15)) {
      clearInterval(waitForPage);
      injectPanel();
    }
  }, 1000);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
