/**
 * UnicornDS - eBay Orders Page
 * - Original feature: scrapes orders awaiting dispatch (for extension orders page)
 * - v7.8 additions: per-order-row buttons to compose pre-filled message to buyer
 *   - AliExpress Message (delivery 3-4 days)
 *   - Amazon Message (delivery 1-2 days)
 *   Auto-fills {buyer} and {store} from order context + user settings.
 */
'use strict';
console.log('[UnicornDS] eBay orders scraper + message buttons loaded');

// --- MESSAGE TEMPLATES ---
const UDS_ORDER_TEMPLATES = {
  aliexpress: (buyer, store) =>
`Hi ${buyer || 'there'},

Thank you so much for your order - we really appreciate your support for our small family-run shop!

We're thrilled to let you know your item is on its way and should be with you within 3 to 4 working days. We'll send you tracking details shortly so you can follow the journey.

If you have any questions or anything at all we can help with, please don't hesitate to reach out - we're always happy to hear from you.

Wishing you a wonderful day,
${store || 'Your Store'}`,

  amazon: (buyer, store) =>
`Hi ${buyer || 'there'},

Thank you so much for your order - we really appreciate your support for our small family-run shop!

We're delighted to let you know your item has been dispatched and should arrive within 1 to 2 working days. We'll send you the tracking details shortly so you can keep an eye on delivery.

If there's anything at all we can help with, please don't hesitate to reach out - we're always here and happy to help.

Wishing you a wonderful day,
${store || 'Your Store'}`,
};

// --- SCRAPER ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'scrape_ebay_orders') {
    setTimeout(() => {
      const orders = scrapeOrders();
      sendResponse({ orders });
    }, 3000);
    return true;
  }
});

function scrapeOrders() {
  const orders = [];
  const orderRows = document.querySelectorAll(
    '.order-info, [data-test-id="order-line-item"], .sold-order-info, tr.order-row, .sh-tbl__row, [class*="order-line"], [class*="OrderLineItem"]'
  );

  orderRows.forEach(row => {
    try {
      const order = {};
      const orderIdEl = row.querySelector('[class*="order-id"] a, [data-test-id="order-id"] a, a[href*="orderId"]');
      if (orderIdEl) order.ebayOrderId = orderIdEl.textContent.trim();
      const buyerEl = row.querySelector(
        '[class*="buyer"] a, [data-test-id="buyer-id"], [class*="Buyer"] a, ' +
        'a[href*="usr/"], [class*="buyer-name"], [class*="buyerName"], ' +
        '[class*="winner"] a, [class*="buyer-id"], ' +
        '[class*="buyer"] span, [class*="buyer"] button'
      );
      order.buyerName = buyerEl ? buyerEl.textContent.trim() : '';
      // Fallback: find any link to eBay user profile
      if (!order.buyerName) {
        const userLink = row.querySelector('a[href*="/usr/"], a[href*="ViewUserInfo"]');
        if (userLink) order.buyerName = userLink.textContent.trim();
      }
      const titleEl = row.querySelector('[class*="item-title"] a, [data-test-id="item-title"], a[href*="/itm/"]');
      order.itemTitle = titleEl ? titleEl.textContent.trim() : '';
      if (titleEl && titleEl.href) {
        const match = titleEl.href.match(/\/itm\/(\d+)/);
        if (match) order.itemNumber = match[1];
      }
      const priceEl = row.querySelector(
        '[class*="total"] .sh-bold, [data-test-id="order-total"], ' +
        '[class*="order-price"], [class*="line-item-price"], ' +
        '[class*="item-price"] span, [class*="Amount"] span, ' +
        '.sold-order-info [class*="price"], [class*="total-price"], ' +
        '[class*="orderPrice"], [class*="sold-price"], ' +
        'span[class*="BOLD"], [class*="total"] span'
      );
      if (priceEl) {
        const priceText = priceEl.textContent.replace(/[^0-9.,]/g, '');
        order.soldPrice = parseFloat(priceText.replace(',', '')) || 0;
      }
      // Fallback: scan all spans/divs for £/$/€ pattern
      if (!order.soldPrice) {
        const allEls = row.querySelectorAll('span, div, td');
        for (const el of allEls) {
          const txt = el.textContent.trim();
          // Match currency amounts like £12.99, $45.00, €9.99
          const m = txt.match(/^[£$€]\s?([\d,]+\.\d{2})$/);
          if (m) {
            const val = parseFloat(m[1].replace(',', ''));
            if (val > 0 && val < 10000) {
              order.soldPrice = val;
              break;
            }
          }
        }
      }
      const dateEl = row.querySelector('[class*="date"], [data-test-id="order-date"], time');
      order.soldDate = dateEl ? dateEl.textContent.trim() : '';
      const imgEl = row.querySelector('img[src*="ebayimg"]');
      order.image = imgEl ? imgEl.src : '';
      const statusEl = row.querySelector('[class*="status"], [data-test-id="order-status"]');
      const statusText = statusEl ? statusEl.textContent.trim().toLowerCase() : '';
      // delivered/complete FIRST — rows often contain dispatch text too
      if (statusText.includes('deliver') || statusText.includes('complete')) order.ebayStatus = 'delivered';
      else if (statusText.includes('dispatch') || statusText.includes('ship') || statusText.includes('awaiting') || statusText.includes('post')) order.ebayStatus = 'awaiting_dispatch';
      else if (statusText.includes('paid')) order.ebayStatus = 'paid';
      else order.ebayStatus = statusText;
      if (order.itemTitle) orders.push(order);
    } catch (e) { console.warn('[UnicornDS] Error scraping order row:', e); }
  });

  if (orders.length === 0) {
    const soldItems = document.querySelectorAll('.s-item, li[data-viewport], [class*="sold-item"]');
    soldItems.forEach(item => {
      try {
        const titleEl = item.querySelector('.s-item__title, h3, [role="heading"]');
        const priceEl = item.querySelector('.s-item__price, [class*="price"]');
        const linkEl = item.querySelector('a[href*="/itm/"]');
        const buyerEl = item.querySelector('[class*="buyer"], [class*="winner"], a[href*="/usr/"]');
        if (titleEl && titleEl.textContent.trim() !== 'Shop on eBay') {
          orders.push({
            itemTitle: titleEl.textContent.trim(),
            soldPrice: priceEl ? parseFloat(priceEl.textContent.replace(/[^0-9.,]/g, '')) || 0 : 0,
            itemNumber: linkEl ? linkEl.href.split('/').pop().split('?')[0] : '',
            buyerName: buyerEl ? buyerEl.textContent.trim() : 'eBay Buyer',
            soldDate: new Date().toLocaleDateString('en-GB'),
            ebayStatus: 'awaiting_dispatch',
          });
        }
      } catch (e) { /* skip */ }
    });
  }
  return orders;
}

// --- MESSAGE BUTTON INJECTION ---
function injectStyles() {
  if (document.getElementById('uds-orders-style')) return;
  const s = document.createElement('style');
  s.id = 'uds-orders-style';
  s.textContent = `
    .uds-msg-btns { display: inline-flex; gap: 6px; margin: 4px 0; vertical-align: middle; flex-wrap: wrap; }
    .uds-msg-btn {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600;
      cursor: pointer; border: 1px solid transparent; transition: all 0.15s;
      text-decoration: none; color: #fff !important; white-space: nowrap;
      font-family: inherit;
    }
    .uds-msg-btn.ali { background: #E43225; border-color: #E43225; }
    .uds-msg-btn.ali:hover { background: #c62b1f; transform: translateY(-1px); }
    .uds-msg-btn.amz { background: #FF9900; border-color: #FF9900; color: #111 !important; }
    .uds-msg-btn.amz:hover { background: #e68a00; transform: translateY(-1px); }
    .uds-toast-uds {
      position: fixed; bottom: 20px; right: 20px; background: #7C3AED; color: #fff;
      padding: 10px 16px; border-radius: 8px; font-size: 13px; z-index: 999999;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
  `;
  document.documentElement.appendChild(s);
}

function showToastUds(msg) {
  const t = document.createElement('div');
  t.className = 'uds-toast-uds';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

function getBuyerFromRow(row) {
  const buyerEl = row.querySelector(
    'a[href*="usr/"], [class*="buyer"] a, [data-test-id="buyer-id"], ' +
    '[class*="Buyer"] a, [class*="buyer-name"], [class*="buyerName"], ' +
    '[class*="buyer"] span, [class*="buyer"] button, a[href*="ViewUserInfo"]'
  );
  if (!buyerEl) return '';
  const txt = buyerEl.textContent.trim();
  const parts = txt.split(/\s+/);
  return parts[0] || '';
}

async function copyToClipboard(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch (e) { return false; }
}

async function handleMsgClick(e, source, row) {
  e.preventDefault();
  e.stopPropagation();

  const s = await new Promise(r => chrome.storage.local.get('unicornds_store_name', r));
  const store = s.unicornds_store_name || 'Your Store';
  const buyer = getBuyerFromRow(row);
  const message = UDS_ORDER_TEMPLATES[source](buyer, store);

  const copied = await copyToClipboard(message);

  let openUrl = '';
  const contactLink = row.querySelector('a[href*="/mesgdetl/"], a[href*="contactBuyer"], a[href*="Contact+buyer"]');
  if (contactLink) openUrl = contactLink.href;
  if (!openUrl) {
    const orderLink = row.querySelector('a[href*="orderDetail"], a[href*="orderId"]');
    if (orderLink) openUrl = orderLink.href;
  }

  if (openUrl) {
    chrome.runtime.sendMessage({ type: 'openNewTab', url: openUrl });
    const label = source === 'amazon' ? 'Amazon' : 'AliExpress';
    showToastUds(copied
      ? `Message copied (${label}) - paste into eBay message box`
      : `Opening order - copy failed, see console for message text`);
  } else {
    showToastUds('Could not find Contact buyer link on this row');
  }

  if (!copied) {
    console.log('[UnicornDS] Pre-filled message (copy manually):\n' + message);
  }
}

function injectOrderButtons() {
  injectStyles();
  const rows = document.querySelectorAll(
    '.order-info, [data-test-id="order-line-item"], .sold-order-info, tr.order-row, .sh-tbl__row, [class*="order-line"], [class*="OrderLineItem"]'
  );
  let injected = 0;
  rows.forEach(row => {
    if (row.querySelector('.uds-msg-btns')) return;
    const hasBuyer = !!row.querySelector(
      'a[href*="usr/"], [class*="buyer"] a, [data-test-id="buyer-id"], ' +
      '[class*="Buyer"] a, [class*="buyer-name"], [class*="buyer"] span, a[href*="ViewUserInfo"]'
    );
    if (!hasBuyer) return;

    const wrap = document.createElement('div');
    wrap.className = 'uds-msg-btns';

    const aliBtn = document.createElement('button');
    aliBtn.className = 'uds-msg-btn ali';
    aliBtn.type = 'button';
    aliBtn.textContent = 'AliExpress Msg';
    aliBtn.title = 'Copy AliExpress delivery message (3-4 days) and open buyer contact';
    aliBtn.addEventListener('click', (e) => handleMsgClick(e, 'aliexpress', row));

    const amzBtn = document.createElement('button');
    amzBtn.className = 'uds-msg-btn amz';
    amzBtn.type = 'button';
    amzBtn.textContent = 'Amazon Msg';
    amzBtn.title = 'Copy Amazon delivery message (1-2 days) and open buyer contact';
    amzBtn.addEventListener('click', (e) => handleMsgClick(e, 'amazon', row));

    wrap.appendChild(aliBtn);
    wrap.appendChild(amzBtn);

    const anchor = row.querySelector('[class*="buyer"]') ||
                   row.querySelector('[data-test-id="buyer-id"]') ||
                   row.querySelector('td:last-child') ||
                   row;
    anchor.appendChild(wrap);
    injected++;
  });
  if (injected > 0) console.log('[UnicornDS] Injected message buttons on', injected, 'orders');
}

function startObserver() {
  injectOrderButtons();
  const obs = new MutationObserver(() => {
    clearTimeout(window.__udsOrderBtnTimer);
    window.__udsOrderBtnTimer = setTimeout(injectOrderButtons, 500);
  });
  obs.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(startObserver, 1500);
} else {
  window.addEventListener('load', () => setTimeout(startObserver, 1500));
}
