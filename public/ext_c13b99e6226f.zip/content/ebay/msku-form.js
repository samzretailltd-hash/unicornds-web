/**
 * UnicornDS - MSKU Variation Form
 * Runs on: bulkedit.ebay.co.uk/msku* (inside iframe dialog on listing form)
 *
 * Flow:
 *   1. Reads variation data from chrome.storage (set by listing-form.js)
 *   2. Clicks "+ Add" -> UNCHECKS all existing -> checks "Add your own" -> types "MNP" -> Save
 *   3. Clicks MNP tag -> for each variant: types name in input -> clicks Add
 *   4. Clicks "Continue" -> fills price/qty/SKU/EAN per row
 *   5. Sets photos to "Use default photos"
 *   6. Clicks "Save and close" -> signals done via chrome.storage
 */

if (!window.__unicornds_msku_loaded) {
window.__unicornds_msku_loaded = true;

console.log('[UnicornDS] msku-form.js loaded on', window.location.href.substring(0, 80));

const sleep = ms => new Promise(r => setTimeout(r, ms));

function fireEvents(el) {
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

// Get React-compatible native setter ONCE (works around controlled input ignoring direct .value = X)
const _nativeInputSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;

function setInput(el, value) {
  if (!el) return false;
  el.focus();
  // Clear React's tracker so it sees the value as actually changing
  if (el._valueTracker) el._valueTracker.setValue('');
  // Use native setter to bypass React's controlled-input override
  _nativeInputSetter.call(el, String(value));
  // Fire all events React listens for
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  el.dispatchEvent(new Event('blur', { bubbles: true }));
  return true;
}

// ── Localized label matching ──────────────────────────────────────────────
// eBay's bulkedit (MSKU) editor renders in the MARKETPLACE language, even when
// the seller's main UI is English. Matching button text in English only meant
// FR/DE/ES/IT variations silently failed. Match all EU languages.
const MSKU_L = {
  addAttr:   ['+ add', '+ ajouter', '+ hinzufügen', '+ añadir', '+ aggiungi', '+ toevoegen'],
  save:      ['save', 'enregistrer', 'speichern', 'guardar', 'salva', 'opslaan'],
  cont:      ['continue', 'continuer', 'weiter', 'fortfahren', 'continuar', 'continua', 'doorgaan'],
  addOpt:    ['add', 'ajouter', 'hinzufügen', 'añadir', 'aggiungi', 'toevoegen'],
  createOwn: ['create your own', 'créer le vôtre', 'créez le vôtre', 'créer', 'eigene erstellen', 'crear el tuyo', 'crea il tuo', 'crea'],
  addOwn:    ['add your own', 'ajouter le vôtre', 'ajoutez le vôtre', 'eigenes hinzufügen', 'eigenes attribut', 'añadir el tuyo', 'aggiungi il tuo'],
  enterPrice:['enter price', 'saisir le prix', 'indiquer le prix', 'saisir un prix', 'preis eingeben', 'introducir precio', 'inserisci prezzo'],
  enterQty:  ['enter quantity', 'saisir la quantité', 'indiquer la quantité', 'saisir une quantité', 'menge eingeben', 'introducir cantidad', 'inserisci quantità'],
  saveClose: ['save and close', 'enregistrer et fermer', 'speichern und schließen', 'guardar y cerrar', 'salva e chiudi'],
};
const _t = (el) => (el && el.textContent || '').trim().toLowerCase();
const eqL = (el, key) => { const t = _t(el); return MSKU_L[key].some(s => t === s); };
const incL = (txt, key) => { const t = (txt || '').trim().toLowerCase(); return MSKU_L[key].some(s => t.includes(s)); };

// eBay's MSKU iframe URL carries the locale decimal symbol (?decimalSymbol=%2C on FR).
function mskuDecimalSymbol() {
  try { const m = (location.search || '').match(/[?&]decimalSymbol=([^&]+)/); if (m) return decodeURIComponent(m[1]); } catch (e) {}
  return '.';
}
const MSKU_DEC = mskuDecimalSymbol();
function fmtPrice(n) {
  const v = (Math.round((parseFloat(n) || 0) * 100) / 100).toFixed(2);
  return MSKU_DEC === ',' ? v.replace('.', ',') : v;
}

// Check if data was stored by listing-form.js (with retry for race condition — Fixes H3)
(async () => {
  let data = null;
  // Retry up to 10 times (10 × 1s = 10s max wait)
  for (let attempt = 0; attempt < 10; attempt++) {
    const s = await new Promise(r => chrome.storage.local.get('unicornds_msku_data', r));
    if (s.unicornds_msku_data) {
      data = s.unicornds_msku_data;
      break;
    }
    if (attempt === 0) console.log('[UnicornDS] MSKU: No stored data found, retrying...');
    await sleep(1000);
  }
  
  if (data) {
    console.log('[UnicornDS] MSKU: Found stored data,', data.variations.length, 'variations');
    console.log('[UnicornDS] MSKU: Variant images:', Object.keys(data.variantImages || {}).length, 'variants');
    chrome.storage.local.remove('unicornds_msku_data');
    await sleep(2000);
    await fillVariations(data);
  } else {
    console.warn('[UnicornDS] MSKU: No stored data after 10 retries — signalling failure');
    // Signal failure so listing-form.js doesn't wait forever
    try {
      chrome.storage.local.set({ unicornds_msku_done: { success: false, error: 'No variation data received', timestamp: Date.now() } });
    } catch(e) {}
  }
})();

// Fallback: listen for direct messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'fill_msku_variations') {
    console.log('[UnicornDS] MSKU: Received message with', msg.variations.length, 'variations');
    fillVariations({ variations: msg.variations, variantImages: msg.variantImages || {}, price: msg.price, quantity: msg.quantity, sku: msg.sku });
    sendResponse({ received: true });
  }
});

// FR/EU categories pre-pick attributes (e.g. "Matière", "Epoque") shown as
// removable TAGS, not checkboxes. Any attribute left with no options blocks
// "Continue". Strip them so only our own attribute remains — same as UK.
async function removeAllAttributeTags() {
  let last = -1;
  for (let pass = 0; pass < 12; pass++) {
    const tags = Array.from(document.querySelectorAll('[class*="msku-parent-tag"]'));
    if (!tags.length) break;
    if (tags.length === last) { console.log('[UnicornDS] MSKU: attribute tag did not clear — stopping'); break; }
    last = tags.length;
    const tag = tags[0];
    const x = tag.querySelector('[aria-label*="remove" i],[aria-label*="supprim" i],[aria-label*="retir" i],[aria-label*="entfern" i],[aria-label*="quitar" i],[aria-label*="rimuov" i]')
           || tag.querySelector('button, a, [role="button"]')
           || Array.from(tag.querySelectorAll('span,i,svg')).find(e => ['x', '×', '✕'].includes((e.textContent || '').trim().toLowerCase()))
           || tag;
    try { x.click(); } catch (e) {}
    console.log('[UnicornDS] MSKU: Removing pre-picked attribute:', (tag.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 30));
    await sleep(450);
  }
}

// Safety net before Continue: if our own "MNP" attribute exists, remove every
// OTHER attribute (the empty pre-picked ones that block Continue). Only runs
// when MNP is present, so we never delete the attribute holding our options.
async function removeNonMnpAttributes() {
  const has = Array.from(document.querySelectorAll('[class*="msku-parent-tag"]')).some(t => /\bMNP\b/i.test(t.textContent || ''));
  if (!has) { console.log('[UnicornDS] MSKU: No MNP attribute present — leaving attributes as-is'); return; }
  let last = -1;
  for (let pass = 0; pass < 12; pass++) {
    const list = Array.from(document.querySelectorAll('[class*="msku-parent-tag"]'));
    const bad = list.find(t => !/\bMNP\b/i.test(t.textContent || ''));
    if (!bad) break;
    if (list.length === last) break;
    last = list.length;
    const x = bad.querySelector('[aria-label*="remove" i],[aria-label*="supprim" i],[aria-label*="retir" i]')
           || bad.querySelector('button, a, [role="button"]')
           || Array.from(bad.querySelectorAll('span,i,svg')).find(e => ['x', '×', '✕'].includes((e.textContent || '').trim().toLowerCase()))
           || bad;
    try { x.click(); } catch (e) {}
    console.log('[UnicornDS] MSKU: Removed extra attribute before Continue:', (bad.textContent || '').trim().slice(0, 30));
    await sleep(450);
  }
}

async function fillVariations(data) {
  const variations = data.variations;
  const sellPrice = data.price;
  const quantity = data.quantity;
  const baseSku = data.sku;
  console.log('[UnicornDS] MSKU: === Starting variation fill ===');
  console.log('[UnicornDS] MSKU: Price:', sellPrice, 'Qty:', quantity, 'SKU:', baseSku, '| decimal="' + MSKU_DEC + '" → formatted=' + fmtPrice(sellPrice));
  console.log('[UnicornDS] MSKU: Variations:', variations.map(v => v.name).join(', '));

  await sleep(2000);

  // =======================================================
  // STEP 0-5: Build variations using eBay's STABLE element IDs
  // (identical on UK/FR/DE/ES/IT/...). No translated-text matching.
  // =======================================================
  const VAR_ATTR = 'MNP'; // our single custom variation attribute name

  // 0) Remove every pre-picked attribute tag (e.g. Matiere, Activite...)
  for (let p = 0; p < 25; p++) {
    const closeBtns = document.querySelectorAll('.var-tag-close-button');
    if (!closeBtns.length) break;
    try { closeBtns[0].click(); } catch (e) {}
    await sleep(350);
  }
  console.log('[UnicornDS] MSKU: Cleared pre-picked attribute tags');

  // 1) Open the "Add attribute" panel
  const addAttrBtn = document.querySelector('#msku-attribute-add');
  if (addAttrBtn) { addAttrBtn.click(); console.log('[UnicornDS] MSKU: Opened add-attribute panel'); await sleep(1200); }

  // 2) Uncheck any eBay-suggested attribute checkboxes still ticked
  document.querySelectorAll('#msku-variation-checkbox-list input[type="checkbox"]').forEach(cb => { if (cb.checked) { try { cb.click(); } catch (e) {} } });
  await sleep(400);

  // 3) Tick "Add your own attribute" -> type our name -> Save
  const ownCb = document.querySelector('#msku-own-parent-tag-checkbox');
  if (ownCb && !ownCb.checked) { ownCb.click(); console.log('[UnicornDS] MSKU: Ticked "add your own attribute"'); await sleep(700); }

  const attrInput = document.querySelector('#msku-custom-parent-attribute-input');
  if (attrInput) {
    setInput(attrInput, VAR_ATTR);
    console.log('[UnicornDS] MSKU: Typed attribute name "' + VAR_ATTR + '"');
    await sleep(500);
  } else {
    console.warn('[UnicornDS] MSKU: #msku-custom-parent-attribute-input NOT found');
  }

  const saveAttrBtn = document.querySelector('#msku-add-parent-tag-btn');
  if (saveAttrBtn) {
    for (let w = 0; w < 12 && saveAttrBtn.disabled; w++) { if (attrInput) setInput(attrInput, VAR_ATTR); await sleep(300); }
    saveAttrBtn.click();
    console.log('[UnicornDS] MSKU: Saved custom attribute (was disabled=' + saveAttrBtn.disabled + ')');
    await sleep(1500);
  } else {
    console.warn('[UnicornDS] MSKU: #msku-add-parent-tag-btn NOT found');
  }

  // Make sure our attribute tab is the active one
  const ourTag = Array.from(document.querySelectorAll('[id^="msku-variation-tag-"]')).find(sp => (sp.textContent || '').trim() === VAR_ATTR);
  if (ourTag) { ourTag.click(); console.log('[UnicornDS] MSKU: Selected our attribute tab'); await sleep(600); }

  // 4) Add each AliExpress variant (verbatim) as an option via stable IDs
  for (let i = 0; i < variations.length; i++) {
    const v = variations[i];
    const optLink = document.querySelector('#msku-custom-option-link');
    if (optLink) { try { optLink.click(); } catch (e) {} await sleep(300); }
    const optInput = document.querySelector('#msku-custom-option-input');
    if (optInput) {
      setInput(optInput, v.name);
      await sleep(250);
      const optAdd = document.querySelector('#msku-custom-option-add');
      if (optAdd) {
        optAdd.click();
        console.log('[UnicornDS] MSKU: Added option ' + (i + 1) + '/' + variations.length + ': "' + v.name + '"');
      } else {
        optInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
        console.log('[UnicornDS] MSKU: Enter to add option "' + v.name + '"');
      }
      await sleep(600);
    } else {
      console.warn('[UnicornDS] MSKU: #msku-custom-option-input NOT found for "' + v.name + '"');
    }
  }
  console.log('[UnicornDS] MSKU: All variant options added');
  await sleep(800);

  // 5) Continue -> builds the price/qty table
  const continueBtn = document.querySelector('#msku-create-variations-button')
                   || Array.from(document.querySelectorAll('button')).find(b => eqL(b, 'cont'));
  if (continueBtn) {
    continueBtn.click();
    console.log('[UnicornDS] MSKU: Clicked Continue (#msku-create-variations-button)');
    await sleep(3000);
  } else {
    console.warn('[UnicornDS] MSKU: Continue button NOT found');
  }

  // If eBay shows the auto/manual regenerate dialog, confirm it
  const regen = document.querySelector('#msku-manual-only-regen-button, #msku-auto-regen-button, #msku-auto-only-regen-button');
  if (regen && regen.offsetParent !== null) { regen.click(); console.log('[UnicornDS] MSKU: Confirmed regenerate dialog'); await sleep(2000); }

  // Wait for table to appear (may take a few seconds).
  // FR/EU can render a header table first, so pick the table that has DATA rows.
  let table = null;
  const _dataRows = (t) => t ? t.querySelectorAll('tbody tr, tr[role="row"], tr') : [];
  for (let waitAttempt = 0; waitAttempt < 12; waitAttempt++) {
    const candidates = Array.from(document.querySelectorAll('table, [role="grid"]'));
    table = candidates.find(t => Array.from(_dataRows(t)).some(r => r.querySelector('td, [role="cell"], input'))) || null;
    if (table) {
      console.log('[UnicornDS] MSKU: Table found after', waitAttempt, 'waits (' + Array.from(_dataRows(table)).length + ' rows)');
      break;
    }
    console.log('[UnicornDS] MSKU: Waiting for table... attempt', waitAttempt + 1);
    await sleep(1000);
  }
  if (!table) {
    console.warn('[UnicornDS] MSKU: No data table — DOM has ' + document.querySelectorAll('table').length + ' <table>(s), ' + document.querySelectorAll('[role="grid"]').length + ' grid(s). Variant options likely were not added before Continue.');
  }

  // =======================================================
  // STEP 5.5: Upload per-variant photos (after Continue, before price)
  // =======================================================
  const variantImages = data.variantImages || {};
  const hasVariantImages = Object.keys(variantImages).length > 0;

  if (hasVariantImages) {
    console.log('[UnicornDS] MSKU: Uploading variant images for', Object.keys(variantImages).length, 'variants');

    const photoSelect = document.getElementById('msku-photos_options');
    if (photoSelect) {
      photoSelect.value = 'MNP';
      fireEvents(photoSelect);
      console.log('[UnicornDS] MSKU: Selected MNP for per-variant photos');
      await sleep(3000);

      // Find the picupload variations iframe
      let targetIframe = null;
      const iframes = document.querySelectorAll('iframe');
      for (const iframe of iframes) {
        const src = iframe.src || iframe.name || '';
        if (src.includes('picupload') && src.includes('variation')) {
          targetIframe = iframe;
          break;
        }
      }
      if (!targetIframe) {
        for (const iframe of iframes) {
          if ((iframe.src || '').includes('picupload')) {
            targetIframe = iframe;
            break;
          }
        }
      }

      if (targetIframe) {
        console.log('[UnicornDS] MSKU: Found picupload iframe:', (targetIframe.src || targetIframe.name || '').substring(0, 60));
      } else {
        console.warn('[UnicornDS] MSKU: No picupload iframe found');
      }

      // Listen for upload results
      let uploadResolve = null;
      window.addEventListener('message', (event) => {
        if (event.data?.type === 'unicornds_upload_result') {
          console.log('[UnicornDS] MSKU: Upload result:', event.data.success ? '✅ ' + event.data.variantName : '❌ ' + event.data.error);
          if (uploadResolve) uploadResolve(event.data);
        }
      });

      const variationList = document.getElementById('msku-photos_variations');
      if (variationList) {
        const varItems = variationList.querySelectorAll('li');
        console.log('[UnicornDS] MSKU: Found', varItems.length, 'photo slots');

        for (let i = 0; i < varItems.length; i++) {
          const li = varItems[i];
          const varName = li.textContent.trim().replace(/\s*\(\d+\/\d+\s*photos?\)\s*$/i, '').trim();

          // Click the <a> tag inside the li (eBay's click handler is on <a>)
          const anchor = li.querySelector('a');
          if (anchor) {
            anchor.click();
          } else {
            li.click();
          }
          
          // Wait for this li to get the 'select' class (eBay switches active variant)
          for (let wait = 0; wait < 10; wait++) {
            if (li.classList.contains('select')) break;
            await sleep(500);
          }
          await sleep(1000); // Extra wait for iframe to be ready
          console.log('[UnicornDS] MSKU: Clicked photo slot:', varName, '- selected:', li.classList.contains('select'));

          // Match image
          let imgUrl = '';
          if (variantImages[varName]) {
            imgUrl = variantImages[varName][0];
          } else {
            for (const [key, urls] of Object.entries(variantImages)) {
              if (varName.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(varName.toLowerCase())) {
                imgUrl = urls[0]; break;
              }
            }
          }
          if (!imgUrl) { console.log('[UnicornDS] MSKU: No image for "' + varName + '"'); continue; }
          

          // Download image
          const b64 = await new Promise(resolve => {
            chrome.runtime.sendMessage({ type: 'url-to-b64', url: imgUrl }, resp => {
              
              resolve(resp?.b64Image || resp?.b64 || null);
            });
          });
          if (!b64) { console.warn('[UnicornDS] MSKU: Download failed for "' + varName + '" URL:', imgUrl.substring(0, 60)); continue; }

          if (targetIframe && targetIframe.contentWindow) {
            // KEY FIX: RELOAD the iframe to get a fresh init with correct currentQueue
            // When iframe reloads, eBay's parent code sends init with currentQueue = selected variant
            const varClass = 'picupload-variations__MNP__' + varName.replace(/\s+/g, '_');
            targetIframe.className = 'photo-iframe-picupload-variations photo-framework select ' + varClass;
            
            // Force iframe reload by toggling src
            const origSrc = targetIframe.src;
            targetIframe.src = 'about:blank';
            await sleep(500);
            targetIframe.src = origSrc;
            console.log('[UnicornDS] MSKU: Reloaded iframe for "' + varName + '"');
            
            // Wait for iframe to fully load and receive init message
            await sleep(4000);
            
            // Re-find the iframe reference (it reloaded)
            const newIframes = document.querySelectorAll('iframe');
            let newIframe = null;
            for (const f of newIframes) {
              if ((f.src || '').includes('picupload') && (f.src || '').includes('variation')) {
                newIframe = f;
                break;
              }
            }
            if (!newIframe) {
              for (const f of newIframes) {
                if ((f.src || '').includes('picupload')) { newIframe = f; break; }
              }
            }

            if (newIframe && newIframe.contentWindow) {
              const uploadPromise = new Promise(resolve => {
                uploadResolve = resolve;
                setTimeout(() => resolve({ success: false, error: 'timeout' }), 10000);
              });
              newIframe.contentWindow.postMessage({
                type: 'unicornds_upload_variant_image', imageB64: b64, variantName: varName
              }, '*');
              const result = await uploadPromise;
              console.log('[UnicornDS] MSKU: ' + (result.success ? '✅' : '❌') + ' Photo for "' + varName + '"');
              
              if (result.success) {
                for (let w = 0; w < 15; w++) {
                  const countEl = li.querySelector('.pics-count');
                  if (countEl && parseInt(countEl.textContent) > 0) {
                    console.log('[UnicornDS] MSKU: Photo confirmed for "' + varName + '" count:', countEl.textContent);
                    break;
                  }
                  await sleep(500);
                }
              }
              await sleep(1000);
            } else {
              console.warn('[UnicornDS] MSKU: Reloaded iframe not found for "' + varName + '"');
            }
          } else {
            console.warn('[UnicornDS] MSKU: Cannot find picupload iframe');
          }
        }
      } else {
        console.warn('[UnicornDS] MSKU: No variation photo list found');
      }
    } else {
      console.warn('[UnicornDS] MSKU: Photo options dropdown not found');
    }
  }

  // =======================================================
  // STEP 6: Fill price, quantity, SKU, EAN per row
  // =======================================================
  if (!table) {
    table = document.querySelector('table');
    console.log('[UnicornDS] MSKU: Final table check:', table ? 'FOUND' : 'NOT FOUND');
  }
  if (table) {
    let rows = table.querySelectorAll('tbody tr');
    if (!rows.length) rows = table.querySelectorAll('tr[role="row"]');
    if (!rows.length) rows = table.querySelectorAll('tr');
    console.log('[UnicornDS] MSKU: Table has', rows.length, 'rows');

    // Debug: log all inputs in first row
    if (rows.length > 0) {
      const firstRowInputs = rows[0].querySelectorAll('input');
      console.log('[UnicornDS] MSKU: First row inputs:');
      firstRowInputs.forEach((inp, i) => {
        console.log('[UnicornDS] MSKU:   ' + i + ': name=' + inp.name + ' id=' + inp.id + ' type=' + inp.type + ' value=' + inp.value);
      });
    }

    // Fill each row individually (supports different prices per variant)
    // Inputs have NO name/id - identified by POSITION in row:
    //   textInputs[0] = SKU
    //   textInputs[1] = Quantity
    //   textInputs[2] = Price
    // NOTE: eBay table has alternating real/detail rows - only real rows have inputs
    let variantIdx = 0; // tracks which variation we're on (separate from row index)
    for (let r = 0; r < rows.length; r++) {
      const textInputs = rows[r].querySelectorAll('input[type="text"]');
      
      if (textInputs.length >= 3) {
        // This is a real variant row - match to variation by variantIdx
        const variant = variations[variantIdx] || {};
        let rowPrice = sellPrice;
        if (variant.price) {
          const vPrice = self.UDSCurrency.parsePrice(variant.price);
          if (vPrice > 0) rowPrice = vPrice;
        }

        // ─── Build VARIANT-AWARE SKU ───
        // For AliExpress: append -S{skuId} so we can rebuild ?skuId=... URL on fulfill
        // For Amazon: variant.asin if present (each Amazon variant has unique ASIN)
        // Fallback: _V{n}
        let variantSku = baseSku + '_V' + (variantIdx + 1);
        if (variant.skuId && /^\d+$/.test(String(variant.skuId))) {
          // AliExpress variant ID — encode short version (last 10 digits to stay under eBay 50-char SKU limit)
          const shortSkuId = String(variant.skuId).slice(-10);
          variantSku = baseSku + '-S' + shortSkuId;
          // Store full mapping for fulfill flow
          try {
            chrome.runtime.sendMessage({
              type: 'store_variant_sku',
              variantSku,
              fullSkuId: String(variant.skuId),
              productId: baseSku.replace(/^UDS-(AE|AZ)-/, ''),
              source: 'aliexpress',
              properties: variant.properties || {},
            });
          } catch(e) {}
        } else if (variant.asin && /^B0[A-Z0-9]{8}$/i.test(variant.asin)) {
          // Amazon variant has its own ASIN
          variantSku = 'UDS-AZ-' + variant.asin;
          try {
            chrome.runtime.sendMessage({
              type: 'store_variant_sku',
              variantSku,
              asin: variant.asin,
              source: 'amazon',
              properties: variant.properties || {},
            });
          } catch(e) {}
        }

        // SKU = textInputs[0]
        setInput(textInputs[0], variantSku);
        // Quantity = textInputs[1]
        setInput(textInputs[1], String(quantity));
        // Price = textInputs[2]
        setInput(textInputs[2], fmtPrice(rowPrice));
        console.log('[UnicornDS] MSKU: Variant', variantIdx, '- SKU:', variantSku, 'Qty:', quantity, 'Price:', rowPrice, 'Props:', JSON.stringify(variant.properties || {}));
        variantIdx++;
      } else if (textInputs.length === 2) {
        // Only 2 inputs visible (qty + price) — SKU field might be hidden or missing
        // Try to find SKU input by looking for any input with placeholder/label containing "SKU" or "Custom label"
        let skuInput = null;
        const allInputs = rows[r].querySelectorAll('input');
        for (const inp of allInputs) {
          const placeholder = (inp.placeholder || '').toLowerCase();
          const ariaLabel = (inp.getAttribute('aria-label') || '').toLowerCase();
          const name = (inp.name || '').toLowerCase();
          if (placeholder.includes('sku') || placeholder.includes('custom label') ||
              ariaLabel.includes('sku') || ariaLabel.includes('custom label') ||
              name.includes('sku') || name.includes('customlabel')) {
            skuInput = inp;
            break;
          }
        }
        if (skuInput) {
          setInput(skuInput, baseSku + '_V' + (variantIdx + 1));
          console.log('[UnicornDS] MSKU: Found hidden SKU input for variant', variantIdx);
        }

        let rowPrice = sellPrice;
        if (variations[variantIdx] && variations[variantIdx].price) {
          const vPrice = self.UDSCurrency.parsePrice(variations[variantIdx].price);
          if (vPrice > 0) rowPrice = vPrice;
        }
        setInput(textInputs[0], String(quantity));
        setInput(textInputs[1], fmtPrice(rowPrice));
        console.log('[UnicornDS] MSKU: Variant', variantIdx, '- SKU:', skuInput ? baseSku + '_V' + (variantIdx+1) : 'NOT SET (no field)', 'Qty:', quantity, 'Price:', rowPrice, '(2 inputs)');
        variantIdx++;
      }
      // Skip detail rows (0 text inputs) silently
      await sleep(200);
    }

    // Click "Does not apply" for all EAN/Product Identifier fields
    // eBay uses various elements: buttons, links, checkboxes
    let eanHandled = 0;

    // Method 1: Look for "Does not apply" buttons
    const eanButtons = Array.from(document.querySelectorAll('button, a, [role="button"]')).filter(b =>
      b.textContent.trim().toLowerCase().includes('does not apply') ||
      b.textContent.trim().toLowerCase().includes('doesn\'t apply')
    );
    for (const eanBtn of eanButtons) {
      eanBtn.click();
      await sleep(300);
      eanHandled++;
    }

    // Method 2: Look for "Add EAN" or "Product identifiers" links and click "Does not apply"
    if (eanHandled === 0) {
      const eanLinks = Array.from(document.querySelectorAll('a, button, [role="link"]')).filter(el => {
        const txt = el.textContent.trim().toLowerCase();
        return txt.includes('add ean') || txt.includes('product identifier') || txt.includes('add upc');
      });
      for (const link of eanLinks) {
        link.click();
        await sleep(500);
        // After clicking, look for "Does not apply" option that appeared
        const dnaBtn = Array.from(document.querySelectorAll('button, a, [role="button"], [role="option"]')).find(b =>
          b.textContent.trim().toLowerCase().includes('does not apply') ||
          b.textContent.trim().toLowerCase().includes('doesn\'t apply')
        );
        if (dnaBtn) { dnaBtn.click(); await sleep(300); eanHandled++; }
      }
    }

    // Method 3: Look for checkbox inputs near "EAN" or "Does not apply" text
    if (eanHandled === 0) {
      const allLabels = Array.from(document.querySelectorAll('label'));
      for (const label of allLabels) {
        const txt = label.textContent.trim().toLowerCase();
        if (txt.includes('does not apply') || txt.includes('doesn\'t apply')) {
          const checkbox = label.querySelector('input[type="checkbox"]') || label.previousElementSibling;
          if (checkbox && checkbox.type === 'checkbox' && !checkbox.checked) {
            checkbox.click();
            await sleep(200);
            eanHandled++;
          }
        }
      }
    }

    // Method 4: Fill EAN text inputs with "Does not apply"
    if (eanHandled === 0) {
      const allInputs = table.querySelectorAll('input[type="text"]');
      // EAN input is usually the 4th text input per row (after SKU, qty, price)
      let rIdx = 0;
      for (let r = 0; r < rows.length; r++) {
        const rowInputs = rows[r].querySelectorAll('input[type="text"]');
        if (rowInputs.length >= 4) {
          // 4+ inputs: SKU, Qty, Price, EAN
          setInput(rowInputs[3], 'Does not apply');
          eanHandled++;
        }
      }
    }

    if (eanHandled > 0) {
      console.log('[UnicornDS] MSKU: Set EAN "Does not apply" for', eanHandled, 'items');
    } else {
      console.log('[UnicornDS] MSKU: No EAN fields found (may not be required for this category)');
    }

    // If per-row didn't work, try bulk buttons
    const emptyPriceInputs = table.querySelectorAll('input[name*="prc"]');
    let hasEmptyPrice = false;
    emptyPriceInputs.forEach(inp => { if (!inp.value) hasEmptyPrice = true; });
    
    if (hasEmptyPrice) {
      console.log('[UnicornDS] MSKU: Trying bulk price/qty...');
      const enterPriceBtn = Array.from(document.querySelectorAll('button')).find(b => incL(b.textContent, 'enterPrice'));
      if (enterPriceBtn) {
        enterPriceBtn.click();
        await sleep(500);
        const priceInput = document.querySelector('input[name*="prc"]');
        if (priceInput) {
          setInput(priceInput, fmtPrice(sellPrice));
          await sleep(300);
          const savePrc = Array.from(document.querySelectorAll('button')).find(b => eqL(b, 'save'));
          if (savePrc) savePrc.click();
          await sleep(1000);
        }
      }

      const enterQtyBtn = Array.from(document.querySelectorAll('button')).find(b => incL(b.textContent, 'enterQty'));
      if (enterQtyBtn) {
        enterQtyBtn.click();
        await sleep(500);
        const qtyInput = document.querySelector('input[name*="qty"]');
        if (qtyInput) {
          setInput(qtyInput, String(quantity));
          await sleep(300);
          const saveQty = Array.from(document.querySelectorAll('button')).find(b => eqL(b, 'save'));
          if (saveQty) saveQty.click();
          await sleep(1000);
        }
      }
    }

    console.log('[UnicornDS] MSKU: Table rows filled');
  } else {
    console.warn('[UnicornDS] MSKU: !! Table NOT FOUND - variations may not have prices/qty');
  }

  // =======================================================
  // STEP 8: Click "Save and close" - closes the dialog
  // =======================================================
  const saveCloseBtn = Array.from(document.querySelectorAll('button')).find(b => incL(b.textContent, 'saveClose'));
  if (saveCloseBtn) {
    saveCloseBtn.click();
    console.log('[UnicornDS] MSKU: Clicked "Save and close"');
  }

  console.log('[UnicornDS] MSKU: === Variation fill DONE ===');

  // Signal completion to listing-form.js via chrome.storage
  try {
    chrome.storage.local.set({ unicornds_msku_done: { success: true, timestamp: Date.now() } });
    console.log('[UnicornDS] MSKU: Signalled completion');
  } catch(e) {}

  // Notify background
  try {
    chrome.runtime.sendMessage({ type: 'msku_complete' });
  } catch(e) {}
}

} // end guard
