/**
 * UnicornDS - eBay Item Page Button Injection
 * Injects action buttons on individual eBay product pages (/itm/*)
 * Reuses same button styling as ebay-search-buttons.css
 */

console.log('[UnicornDS] eBay item page buttons loaded');

const ICONS = {
  amazon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 01-9 9 9 9 0 01-9-9 9 9 0 019-9 9 9 0 019 9z"/><path d="M8 12h4l-2-3z" fill="currentColor"/><path d="M10.5 14.5c1.5 1 3.5 1 5 0"/></svg>',
  ali: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 10l4 4 4-4" stroke-linecap="round"/><line x1="12" y1="7" x2="12" y2="14" stroke-linecap="round"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>',
  sold: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M2 12h20"/><path d="M17 7l-5 5-5-5" fill="none"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>',
  seller: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>',
  save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>',
  list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
  walmart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M2 12h3M19 12h3M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1"/></svg>',
  hunter: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
};

// Detect eBay marketplace from the CURRENT page (fixes UK-only bug)
function udsCurrentEbayDomain() {
  const m = location.hostname.match(/(?:^|\.)ebay\.([a-z.]+)$/i);
  return m ? m[1].toLowerCase() : '';
}

function createBtn(label, icon, className, onClick) {
  const btn = document.createElement('a');
  btn.className = 'uds-btn ' + className;
  btn.href = '#';
  btn.title = label;
  btn.innerHTML = (icon || '') + '<span>' + label + '</span>';
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    btn.classList.add('clicked');
    setTimeout(() => btn.classList.remove('clicked'), 400);
    onClick(e);
  });
  return btn;
}

function showToast(msg) {
  const old = document.querySelector('.uds-toast');
  if (old) old.remove();
  const t = document.createElement('div');
  t.className = 'uds-toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2500);
}

function injectCSS() {
  if (document.getElementById('uds-item-css')) return;
  const link = document.createElement('link');
  link.id = 'uds-item-css';
  link.rel = 'stylesheet';
  link.href = chrome.runtime.getURL('content/ebay/ebay-search-buttons.css');
  document.head.appendChild(link);
}

// ═══════════════════════════════════════
// EXTRACT ITEM PAGE DATA
// ═══════════════════════════════════════
function getTitle() {
  const el = document.querySelector('#mainContent [class*="item-title"] span') ||
             document.querySelector('.x-item-title__mainTitle span') ||
             document.querySelector('h1.x-item-title__mainTitle');
  return el ? el.textContent.trim() : '';
}

function getPrice() {
  const el = document.querySelector('#mainContent [class*="price-primary"] span') ||
             document.querySelector('.x-price-primary span');
  if (!el) return 0;
  const text = el.textContent.replace(/[^0-9.,]/g, '');
  const lastComma = text.lastIndexOf(',');
  const lastDot = text.lastIndexOf('.');
  let cleaned = text;
  if (lastComma > lastDot) cleaned = text.replace(/\./g, '').replace(',', '.');
  else cleaned = text.replace(/,/g, '');
  return parseFloat(cleaned) || 0;
}

function getImages() {
  const imgs = document.querySelectorAll('.ux-image-carousel-container img, .ux-image-carousel img');
  const urls = [];
  imgs.forEach(img => {
    const src = img.src || img.dataset?.src;
    if (src && !urls.includes(src)) urls.push(src);
  });
  return urls;
}

function getSellerName() {
  // Try href parameters first (cleanest)
  const links = document.querySelectorAll('a[href*="ssn="], a[href*="_ssn="]');
  for (const link of links) {
    const match = link.href.match(/[_&]ssn=([^&]+)/);
    if (match) return decodeURIComponent(match[1]);
  }

  // Try "Seller's other items" link
  const allSpans = document.querySelectorAll('span');
  for (const span of allSpans) {
    if (span.textContent.includes("Seller's other items") || span.textContent.includes("seller's other items")) {
      const parent = span.closest('a');
      if (parent?.href) {
        const match = parent.href.match(/[_&]ssn=([^&]+)/);
        if (match) return decodeURIComponent(match[1]);
      }
    }
  }

  // Try sellercard selectors
  const selectors = [
    '.x-sellercard-atf__info__about-seller',
    '.ux-seller-section__item--seller span',
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) {
      let name = el.getAttribute('title') || el.textContent.trim();
      name = name.split('(')[0].trim();
      name = name.replace(/[\d.,]+%.*$/, '').trim();
      if (name) return name;
    }
  }
  return '';
}

function getItemNumber() {
  const match = window.location.href.match(/itm\/([^?/]+)/);
  return match ? match[1] : '';
}

// ═══════════════════════════════════════
// INJECT BUTTONS ON ITEM PAGE
// ═══════════════════════════════════════
function injectItemPageButtons() {
  if (document.getElementById('uds-item-panel')) return;
  injectCSS();

  const title = getTitle();
  if (!title) return;

  const price = getPrice();
  const images = getImages();
  const seller = getSellerName();
  const itemNumber = getItemNumber();
  const image = images[0] || '';

  console.log('[UnicornDS] Item page:', { title: title.substring(0, 50), price, seller, itemNumber });

  const data = { title, price, image, seller, itemNumber, url: window.location.href };

  // Build panel
  const panel = document.createElement('div');
  panel.className = 'uds-panel';
  panel.id = 'uds-item-panel';
  panel.style.padding = '10px 0';
  panel.style.marginTop = '10px';

  const label = document.createElement('span');
  label.className = 'uds-panel-label';
  label.textContent = 'UnicornDS';
  label.style.fontSize = '12px';
  panel.appendChild(label);

  // Amazon search
  panel.appendChild(createBtn('Search Amazon', ICONS.amazon, 'uds-btn-amazon', async () => {
    let q = title;
    if (q.length > 80) q = q.substring(0, q.lastIndexOf(' ', 80));
    const s = await chrome.storage.local.get(['hunter_domain', 'hunter_sortBy']);
    chrome.runtime.sendMessage({
      type: 'search-on-amazon',
      searchQuery: q,
      options: { isTabActive: true, sort: s.hunter_sortBy || 'reviews', domain: udsCurrentEbayDomain() || s.hunter_domain || 'co.uk' },
      itemData: data,
    });
  }));

  // AliExpress search
  panel.appendChild(createBtn('AliExpress', ICONS.ali, 'uds-btn-ali', () => {
    let q = title || '';
    q = q.replace(/\b(brand new|new|sealed|genuine|original|official|uk|fast|free)\b/gi, ' ')
      .replace(/\b(shipping|dispatch|delivery|post|p&p|postage)\b/gi, ' ')
      .replace(/[|\-–—,:;\/\\()[\]{}'"!@#$%^&*+=~`]/g, ' ')
      .replace(/\s+/g, ' ').trim();
    if (q.length > 60) q = q.substring(0, q.lastIndexOf(' ', 60));
    const words = q.split(/\s+/).filter(w => w.length > 2).slice(0, 6).join(' ');
    chrome.runtime.sendMessage({
      type: 'openNewTab',
      url: `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(words)}`,
    });
  }));

  // Walmart search — eBay US & Canada ONLY
  (() => {
    const eb = udsCurrentEbayDomain();
    if (eb !== 'com' && eb !== 'ca') return;
    const wm = eb === 'ca' ? 'walmart.ca' : 'walmart.com';
    panel.appendChild(createBtn('Search Walmart', ICONS.walmart, 'uds-btn-walmart', () => {
      let q = (title || '')
        .replace(/\b(brand new|new|sealed|genuine|original|official|fast|free)\b/gi, ' ')
        .replace(/\b(shipping|dispatch|delivery|post|p&p|postage)\b/gi, ' ')
        .replace(/[|\-–—,:;\/\\()[\]{}'"!@#$%^&*+=~`]/g, ' ')
        .replace(/\s+/g, ' ').trim();
      if (q.length > 70) q = q.substring(0, q.lastIndexOf(' ', 70));
      chrome.runtime.sendMessage({ type: 'openNewTab', url: `https://www.${wm}/search?q=${encodeURIComponent(q)}` });
    }));
  })();

  // eBay search
  panel.appendChild(createBtn('Similar', ICONS.search, '', async () => {
    let q = title;
    if (q.length > 80) q = q.substring(0, q.lastIndexOf(' ', 80));
    const { unicornds_ebay_domain } = await chrome.storage.local.get('unicornds_ebay_domain');
    const domain = udsCurrentEbayDomain() || unicornds_ebay_domain || 'co.uk';
    chrome.runtime.sendMessage({
      type: 'openNewTab',
      url: `https://www.ebay.${domain}/sch/i.html?_nkw=${encodeURIComponent(q)}&LH_ItemCondition=1000&LH_FS=1`,
    });
  }));

  // Sold items
  panel.appendChild(createBtn('Sold', ICONS.sold, 'uds-btn-sold', async () => {
    let q = title;
    if (q.length > 80) q = q.substring(0, q.lastIndexOf(' ', 80));
    const { unicornds_ebay_domain } = await chrome.storage.local.get('unicornds_ebay_domain');
    const domain = udsCurrentEbayDomain() || unicornds_ebay_domain || 'co.uk';
    chrome.runtime.sendMessage({
      type: 'openNewTab',
      url: `https://www.ebay.${domain}/sch/i.html?_nkw=${encodeURIComponent(q)}&LH_Sold=1&_sop=13`,
    });
  }));

  // Google Image
  if (image) {
    panel.appendChild(createBtn('Image Search', ICONS.image, '', () => {
      chrome.runtime.sendMessage({
        type: 'openNewTab',
        url: `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(image)}`,
      });
    }));
  }

  // Send to Product Hunter
  panel.appendChild(createBtn('Hunt on Amazon', ICONS.hunter, 'uds-btn-amazon', async () => {
    let q = title;
    if (q.length > 80) q = q.substring(0, q.lastIndexOf(' ', 80));
    await chrome.storage.local.set({ hunter_terms: [q] });
    chrome.runtime.sendMessage({ type: 'openProductHunter' });
    showToast('Sent to Product Hunter');
  }));

  // Copy data
  panel.appendChild(createBtn('Copy Data', ICONS.copy, 'uds-btn-copy', () => {
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    showToast('Copied to clipboard');
  }));

  // Seller items
  if (seller) {
    panel.appendChild(createBtn('Seller Items', ICONS.seller, 'uds-btn-seller', async () => {
      const { unicornds_ebay_domain } = await chrome.storage.local.get('unicornds_ebay_domain');
      const domain = udsCurrentEbayDomain() || unicornds_ebay_domain || 'co.uk';
      const s = seller.toLowerCase();
      chrome.runtime.sendMessage({
        type: 'openNewTab',
        url: `https://www.ebay.${domain}/sch/i.html?_dkr=1&_ssn=${encodeURIComponent(s)}&_ipg=240&LH_Sold=1`,
      });
    }));

    // Save seller
    const saveBtn = createBtn('Save Seller', ICONS.save, 'uds-btn-save', async () => {
      const s = seller.toLowerCase().trim();
      const { ebayCompetitors } = await chrome.storage.local.get('ebayCompetitors');
      const list = ebayCompetitors || [];
      const idx = list.indexOf(s);
      if (idx === -1) {
        list.push(s);
        saveBtn.classList.add('saved');
        saveBtn.querySelector('span').textContent = 'Saved';
        showToast('Seller saved: ' + s);
      } else {
        list.splice(idx, 1);
        saveBtn.classList.remove('saved');
        saveBtn.querySelector('span').textContent = 'Save Seller';
        showToast('Seller removed: ' + s);
      }
      await chrome.storage.local.set({ ebayCompetitors: list });
    });
    chrome.storage.local.get('ebayCompetitors', (r) => {
      if ((r.ebayCompetitors || []).includes(seller.toLowerCase().trim())) {
        saveBtn.classList.add('saved');
        saveBtn.querySelector('span').textContent = 'Saved';
      }
    });
    panel.appendChild(saveBtn);
  }

  // List to eBay (relist)
  panel.appendChild(createBtn('Relist This Item', ICONS.list, 'uds-btn-list', () => {
    chrome.runtime.sendMessage({ type: 'listFromEbayItem', itemData: data });
    showToast('Opening lister...');
  }));

  // Find insertion point - near the buy box
  const buybox = document.querySelector('.x-buybox-cta') ||
                document.querySelector('.vim.x-buybox-cta') ||
                document.querySelector('.ux-seller-section__item--seller') ||
                document.querySelector('#mainContent .x-atc-action') ||
                document.querySelector('#CenterPanelInternal');

  if (buybox) {
    buybox.parentNode.insertBefore(panel, buybox.nextSibling);
  } else {
    // Fallback - prepend to main content
    const main = document.querySelector('#mainContent') || document.querySelector('#CenterPanelInternal');
    if (main) main.prepend(panel);
  }

  console.log('[UnicornDS] Item page buttons injected');
}

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
async function init() {
  // Auth check — don't inject buttons if not logged in
  const _s = await new Promise(r => chrome.storage.local.get('unicornds_session', r));
  if (!_s?.unicornds_session?.idToken) {
    console.log('[UnicornDS] Not logged in — eBay item buttons not injected');
    return;
  }

  // eBay item pages load dynamically - retry a few times
  let attempts = 0;
  const tryInject = () => {
    if (document.getElementById('uds-item-panel')) return;
    if (getTitle()) {
      injectItemPageButtons();
    } else if (attempts < 10) {
      attempts++;
      setTimeout(tryInject, 500);
    }
  };
  tryInject();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(init, 1000));
} else {
  setTimeout(init, 1000);
}
