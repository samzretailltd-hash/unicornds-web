/**
 * UnicornDS - eBay Listing Form v4.0
 * runs at: document_start
 *
 * KEY ARCHITECTURE (learned from ):
 *   Item specifics are filled via eBay's internal listing draft API:
 *   PUT /lstng/api/listing_draft/{draftId}?mode=AddItem&forceValidation=true
 *   Body: { "attributes": { "Brand": ["Unbranded"], "Material": ["Plastic"], ... } }
 *   NO dropdown clicking. Instant. Reliable. Fills ALL fields at once.
 */

if (!window.__unicornds_listing_loaded) {
window.__unicornds_listing_loaded = true;

console.log('[UnicornDS] listing-form.js loaded at', document.readyState, 'on', window.location.pathname);

if (!window.location.href.includes('/lstng')) {
  console.log('[UnicornDS] Not on /lstng page - standing by');
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
let isProcessing = false;

// ═══════════════════════════════════════════════════════
// SRT TOKEN CAPTURE - from background.js webRequest headers
// The srt CSRF token is captured by chrome.webRequest.onBeforeSendHeaders
// in background.js, which intercepts eBay's own API calls during page load.
// The headers are forwarded here via message. We extract srt from them.
// ═══════════════════════════════════════════════════════
let capturedSrt = null;
let capturedWebRequestHeaders = null;

// Receive headers from background.js webRequest
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'ebay_request_headers' && msg.headers) {
    capturedWebRequestHeaders = msg.headers;
    // Extract srt token
    for (const h of msg.headers) {
      if (h.name.toLowerCase() === 'srt' && h.value) {
        if (!capturedSrt) {
          capturedSrt = h.value;
          console.log('[UnicornDS] srt captured from webRequest:', capturedSrt.substring(0, 40) + '...');
        }
      }
    }
  }
});

// Also listen for srt from MAIN world script (if CSP allows it)
window.addEventListener('message', (event) => {
  if (event.data && event.data.type === '__unicornds_srt__' && !capturedSrt) {
    capturedSrt = event.data.srt;
    console.log('[UnicornDS] srt captured from MAIN world:', capturedSrt.substring(0, 40) + '...');
  }
});

// Ensure we have srt before making API calls
async function ensureSrt() {
  if (capturedSrt) return capturedSrt;

  // Wait a bit - webRequest headers may arrive late
  for (let i = 0; i < 10; i++) {
    await sleep(500);
    if (capturedSrt) return capturedSrt;
  }

  // Still no srt - request headers from background
  try { chrome.runtime.sendMessage({ type: 'get_ebay_headers' }); } catch(e) {}
  await sleep(1000);
  if (capturedSrt) return capturedSrt;

  // Last resort - trigger eBay to make an XHR by clicking a dropdown
  console.log('[UnicornDS] No srt from webRequest - triggering dropdown...');
  const btn = document.querySelector('.summary__attributes--value .fake-menu-button__button') ||
               document.querySelector('.summary__attributes--value button');
  if (btn) {
    btn.scrollIntoView({ block: 'center' });
    await sleep(300);
    btn.click();
    await sleep(3000);
    if (btn.getAttribute('aria-expanded') === 'true') {
      btn.click();
      await sleep(300);
    }
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await sleep(500);
  }

  if (capturedSrt) {
    console.log('[UnicornDS] srt captured after dropdown trigger');
  } else {
    console.warn('[UnicornDS] Could not capture srt token');
  }
  return capturedSrt;
}

// ═══════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════
function fireChange(el) {
  const evt = document.createEvent('HTMLEvents');
  evt.initEvent('change', true, true);
  el.dispatchEvent(evt);
}

function scrollTo(el) {
  try { el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' }); } catch(e) {}
}

function highlight(el) { if (el) el.style.border = '3px solid #DFFF00'; }

function setInputValue(el, value) {
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  nativeSetter.call(el, value);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

function escHtml(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ═══════════════════════════════════════════════════════
// WAIT HELPERS
// ═══════════════════════════════════════════════════════
function waitForComplete() {
  return new Promise(resolve => {
    if (document.readyState === 'complete') return resolve();
    const check = setInterval(() => { if (document.readyState === 'complete') { clearInterval(check); resolve(); } }, 1000);
  });
}

function waitForStable(quietMs = 1000) {
  return new Promise(resolve => {
    let lastMutation = Date.now();
    let observer, resolved = false;
    function finish() { if (resolved) return; resolved = true; if (observer) observer.disconnect(); resolve(); }
    function checkQuiet() { if (Date.now() - lastMutation > quietMs) finish(); else setTimeout(checkQuiet, quietMs); }
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      observer = new MutationObserver(() => { lastMutation = Date.now(); });
      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      setTimeout(checkQuiet, quietMs);
    } else {
      window.addEventListener('DOMContentLoaded', () => {
        observer = new MutationObserver(() => { lastMutation = Date.now(); });
        observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
        setTimeout(checkQuiet, quietMs);
      });
    }
    setTimeout(finish, 15000);
  });
}

// ═══════════════════════════════════════════════════════
// NOTIFICATION
// ═══════════════════════════════════════════════════════
function showNotification(msg, type) {
  const existing = document.getElementById('unicornds-notif');
  if (existing) existing.remove();
  const b = document.createElement('div');
  b.id = 'unicornds-notif';
  b.style.cssText = `position:fixed;top:0;left:0;right:0;z-index:999999;padding:12px 20px;
    font-family:-apple-system,sans-serif;font-size:14px;font-weight:600;text-align:center;
    color:#fff;background:${type==='error'?'#e74c3c':type==='success'?'#27ae60':'#7B2FBE'};`;
  b.textContent = '\u{1F984} UnicornDS: ' + msg;
  document.body.prepend(b);
  setTimeout(() => { b.style.opacity = '0'; setTimeout(() => b.remove(), 500); }, 8000);
}

// ═══════════════════════════════════════════════════════
// eBay LISTING DRAFT API
// PUT to /lstng/api/listing_draft/{draftId}?mode=AddItem
// eBay's own React UI uses XHR with:
//   - srt header (CSRF token) - REQUIRED or data silently ignored
//   - Body: {requestId, removedFields, attributes, requestMeta}
// ═══════════════════════════════════════════════════════
function getDraftId() {
  return new URLSearchParams(window.location.search).get('draftId');
}

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

async function updateDraftAPI(payload) {
  const draftId = getDraftId();
  if (!draftId) { console.warn('[UnicornDS] No draftId'); return null; }

  // Ensure we have the srt CSRF token
  const srt = await ensureSrt();
  if (!srt) {
    console.warn('[UnicornDS] No srt token - API will likely fail silently');
  }

  const apiUrl = '/lstng/api/listing_draft/' + draftId + '?mode=AddItem';

  const body = {
    requestId: generateUUID(),
    removedFields: [],
    ...payload,
    requestMeta: { lastDeltaTimestamp: Date.now() },
  };

  console.log('[UnicornDS] API PUT:', Object.keys(payload).join(', '), srt ? '(with srt)' : '(NO srt!)');

  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', apiUrl, true);
    xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');
    if (srt) xhr.setRequestHeader('srt', srt);

    xhr.onload = function() {
      console.log('[UnicornDS] API response:', xhr.status, xhr.responseText.substring(0, 300));
      resolve(xhr.status >= 200 && xhr.status < 300 ? { status: xhr.status, body: xhr.responseText } : null);
    };
    xhr.onerror = function() {
      console.warn('[UnicornDS] API XHR error');
      resolve(null);
    };
    xhr.send(JSON.stringify(body));
  });
}

async function waitForPageUpdate() {
  await sleep(2000);
  await waitForStable(500);
}

// ═══════════════════════════════════════════════════════
// MESSAGE LISTENER
// ═══════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'ebay_request_headers') return; // no longer used
  console.log('[UnicornDS] listing-form message:', request.type);
  if (!window.location.href.includes('/lstng')) return;
  if ((request.type === 'insert_ebay_data' || request.type === 'identify_product') && !isProcessing) {
    isProcessing = true;
    fillForm(request.productData);
    sendResponse({ received: true });
  }
});

// ═══════════════════════════════════════════════════════
// HANDSHAKE
// ═══════════════════════════════════════════════════════
(async function init() {
  console.log('[UnicornDS] Waiting for page to stabilize...');
  await waitForStable(1000);
  if (window.location.href.includes('/lstng')) {
    console.log('[UnicornDS] Page stable - sending page-loaded-and-stable');
    chrome.runtime.sendMessage({ type: 'page-loaded-and-stable' });
  }
})();

// ═══════════════════════════════════════════════════════
// MAIN FILL FORM
// ═══════════════════════════════════════════════════════
async function fillForm(data) {
  console.log('[UnicornDS] \u2550\u2550\u2550 fillForm START \u2550\u2550\u2550');
  console.log('[UnicornDS] title:', data?.title?.substring(0, 50));
  console.log('[UnicornDS] price:', data?.price, 'custom_price:', data?.custom_price);
  console.log('[UnicornDS] auto_approve:', data?.auto_approve);
  if (data?.variations?.length > 0) console.log('[UnicornDS] variations:', data.variations.length);

  // Save draftId NOW before any navigation changes the URL
  const savedDraftId = getDraftId();

  // Report progress via chrome.storage (reliable across all extension contexts)
  const listingId = data._listing_id || Date.now().toString();
  let popupDismisser = null; // Track for cleanup (Fixes C6)

  function reportProgress(step, detail) {
    try {
      chrome.storage.local.set({
        unicornds_bulk_progress: { step, detail, listing_id: listingId, timestamp: Date.now() }
      });
    } catch(e) {}
  }

  function reportDone(success, error, listingTitle) {
    try {
      chrome.storage.local.set({
        unicornds_bulk_done: { success, error: error || '', title: listingTitle || '', listing_id: listingId, timestamp: Date.now() }
      });
    } catch(e) {}
  }

  // Fixes C6: wrap entire flow in try/finally so bulk_done is ALWAYS signalled
  const title = data.custom_title || data.cleanedTitle || data.title || '';
  try {
    await _fillFormInner(data, listingId, title, reportProgress, reportDone, (pd) => { popupDismisser = pd; });
  } catch(e) {
    console.error('[UnicornDS] fillForm CRASHED:', e.message);
    reportDone(false, 'fillForm error: ' + e.message, title);
  } finally {
    // Always clean up intervals (Fixes C6)
    if (popupDismisser) clearInterval(popupDismisser);
    // Stop heartbeat — tells background watcher we're done
    try { chrome.storage.local.remove('unicornds_listing_heartbeat'); } catch(e) {}
    isProcessing = false;
    console.log('[UnicornDS] \u2550\u2550\u2550 fillForm DONE \u2550\u2550\u2550');
  }
}

async function _fillFormInner(data, listingId, title, reportProgress, reportDone, setPopupDismisser) {

  // ── HEARTBEAT: Tell background.js we're alive every 30 seconds ──
  // No artificial timeouts — the watcher just checks if we're still beating.
  // When we finish (success or fail), we clear the heartbeat.
  const HEARTBEAT_KEY = 'unicornds_listing_heartbeat';
  chrome.storage.local.set({ [HEARTBEAT_KEY]: Date.now() });
  const heartbeatInterval = setInterval(() => {
    chrome.storage.local.set({ [HEARTBEAT_KEY]: Date.now() });
  }, 30000); // every 30 seconds
  const stopHeartbeat = () => {
    clearInterval(heartbeatInterval);
    chrome.storage.local.remove(HEARTBEAT_KEY);
  };
  // Ensure heartbeat stops if page unloads (content script dying)
  window.addEventListener('beforeunload', stopHeartbeat);

  reportProgress('starting', 'Opening listing form...');

  const popupDismisser = setInterval(() => {    // Only dismiss surveys and cookie popups - NOT the condition lightbox
    document.querySelectorAll('[class*="survey"] button[aria-label="Close"], [class*="cookie"] button').forEach(btn => btn.click());
    document.querySelectorAll('[class*="feedback"] button[aria-label="Close"], [class*="nps"] button[aria-label="Close"]').forEach(btn => btn.click());
  }, 3000);
  setPopupDismisser(popupDismisser); // Pass to outer scope for cleanup (Fixes C6)

  await waitForComplete();
  await sleep(500);
  showNotification('Auto-filling listing...', 'info');

  // ══════════════════════════════════════════════════════
  // PHASE 1: DOM fills (eBay auto-saves these to draft)
  // ══════════════════════════════════════════════════════

  // ── TITLE (DOM) ──
  reportProgress('title', data.custom_title || data.title || '');
  let listingTitle = data.custom_title || data.cleanedTitle || data.title || '';
  if (listingTitle.length > 80) listingTitle = listingTitle.substring(0, 77) + '...';
  const titleEl = document.querySelector(".smry.summary__title input[name='title']");
  if (titleEl) { setInputValue(titleEl, listingTitle); scrollTo(titleEl); fireChange(titleEl); highlight(titleEl); console.log('[UnicornDS] \u2705 Title:', listingTitle.substring(0, 50)); }
  await sleep(200);

  // ── SKU (DOM) ──
  let sku = data.sku || '';
  let productId = data.productId || data.itemID || '';
  const sourceUrl = data.url || data.aliexpressUrl || '';
  if (!productId && sku && /^\d+$/.test(sku)) productId = sku;
  if ((!sku || !sku.startsWith('UDS')) && productId) {
    // Match background.js format: UDS-AE-{id} or UDS-AZ-{asin} (Fixes H2)
    const source = data.source || (sourceUrl.includes('amazon') ? 'amazon' : 'aliexpress');
    if (source === 'amazon') {
      sku = 'UDS-AZ-' + productId;
    } else {
      sku = 'UDS-AE-' + productId;
    }
  }
  if (sku) {
    const cb = document.querySelector('[name="customLabelPref"]');
    if (cb && !cb.checked) { cb.click(); cb.dispatchEvent(new Event('change', { bubbles: true })); await sleep(1000); }
    const skuEl = document.querySelector("input[name='customLabel']");
    if (skuEl) { scrollTo(skuEl); setInputValue(skuEl, sku); highlight(skuEl); console.log('[UnicornDS] \u2705 SKU:', sku); }
    try { chrome.runtime.sendMessage({ type: 'store_sku_with_url', sku, productId, sourceUrl, title: data.custom_title || data.title || '', marketplace: data.marketplace || 'com' }); } catch(e) {}
  }
  await sleep(100);

  // ── PRICE (DOM) ──
  let sellPrice = parseFloat(data.custom_price) || 0;
  if (!sellPrice || sellPrice <= 0) {
    // Request pricing from background.js shared module (no duplication)
    const rawPrice = parseFloat(data.price) || 0;
    if (rawPrice > 0) {
      try {
        const profitResp = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'calculate_profit', costPrice: rawPrice }, resolve);
        });
        if (profitResp?.profit?.sellPrice) {
          sellPrice = profitResp.profit.sellPrice;
          console.log('[UnicornDS] Price from background:', sellPrice);
        }
      } catch(e) { console.warn('[UnicornDS] Price request failed:', e.message); }
    }
    // Last resort fallback — simple 2.5x markup
    if (!sellPrice || sellPrice <= 0) {
      sellPrice = Math.max((rawPrice || 0) * 2.5, 0.99);
      console.warn('[UnicornDS] Using last-resort 2.5x markup:', sellPrice);
    }
  }
  sellPrice = Math.max(sellPrice, 0.99);
  const priceEl = document.querySelector(".smry.summary__price input[name='price']");
  if (priceEl) { setInputValue(priceEl, sellPrice.toFixed(2)); scrollTo(priceEl); fireChange(priceEl); highlight(priceEl); console.log('[UnicornDS] \u2705 Price:', sellPrice.toFixed(2)); }
  await sleep(100);

  // ── QUANTITY (DOM) ──
  const qty = parseInt(data.stock_quantity) || 10;
  const qtyEl = document.querySelector("input[name='quantity']") || document.querySelector("input[aria-label*='uantity' i]");
  if (qtyEl) { setInputValue(qtyEl, String(qty)); fireChange(qtyEl); highlight(qtyEl); console.log('[UnicornDS] \u2705 Quantity:', qty); }
  await sleep(100);

  // ── CONDITION (DOM - radio dialog) ──
  // eBay URL already includes condition=1000 (New) from prelist.
  // Only open the popup if condition is NOT already set.
  try {
    const section = document.querySelector('.smry.summary__condition');
    if (section) {
      const currentCondition = section.textContent.toLowerCase();
      if (currentCondition.includes('new')) {
        console.log('[UnicornDS] ✅ Condition: already New');
      } else {
        // Condition not set - open popup and select New
        const condBtn = section.querySelector('button');
        if (condBtn) condBtn.click();
        await sleep(500);
        for (const radio of document.querySelectorAll('input[type="radio"], [role="radio"]')) {
          const label = radio.closest('label, div')?.textContent || '';
          if (label.includes('New') && !label.includes('New other') && !label.includes('refurbished')) { radio.click(); break; }
        }
        await sleep(300);
        const doneBtn = document.querySelector('[aria-label="Done" i]') || document.querySelector('.lightbox-dialog__close') ||
                         Array.from(document.querySelectorAll('button')).find(b => b.textContent.trim() === 'Done');
        if (doneBtn) doneBtn.click();
        console.log('[UnicornDS] ✅ Condition: set to New');
      }
    }
  } catch(e) {}
  await sleep(200);

  // ── IMAGES (DOM - file upload) ──
  reportProgress('images', 'Uploading images...');
  let imageUploadCount = 0;
  const imageList = data.images || data.main_hd_images || [];
  try {
    imageUploadCount = await uploadImages(imageList);
  } catch(e) { console.warn('[UnicornDS] Images error:', e.message); }

  // Retry once if 0 images uploaded but we had images to upload
  if (imageUploadCount === 0 && imageList.length > 0) {
    console.log('[UnicornDS] ⚠️ 0 images uploaded — retrying in 3s...');
    await sleep(3000);
    try { imageUploadCount = await uploadImages(imageList); } catch(e) { console.warn('[UnicornDS] Images retry error:', e.message); }
  }
  await sleep(200);

  // ── VARIATIONS (inside iframe dialog - BEFORE specs/description) ──
  const variations = data.variations || [];
  if (variations.length > 1) {
    console.log('[UnicornDS] ═══ VARIATIONS: ' + variations.length + ' variants found ═══');
    reportProgress('variations', 'Setting up ' + variations.length + ' variations...');

    // BRIEFLY ACTIVATE TAB - MSKU iframe needs focus to render
    try { chrome.runtime.sendMessage({ type: 'activate_this_tab' }); } catch(e) {}
    await sleep(1000);
    console.log('[UnicornDS] Tab activated for MSKU');

    // Clear any old done flag
    await new Promise(r => chrome.storage.local.remove('unicornds_msku_done', r));

    // Calculate per-variant prices with profit-based formula
    const isAmazonSrc = (data.source || '').includes('amazon') || (data.sku || '').includes('AZ');
    
    // Read rounding settings so variant prices also get .99 ending
    const roundingSettings = await new Promise(r => chrome.storage.local.get([
      'unicornds_round_prices', 'unicornds_rounding_style'
    ], r));
    const useRounding = !!roundingSettings.unicornds_round_prices;
    const roundStyle = roundingSettings.unicornds_rounding_style || '0.99';

    // Variant pricing: prefer pre-calculated prices from background.js (already uses shared module)
    // Only recalculate if variants have raw supplier prices but no ebayPrice
    const variationsWithPrices = variations.map(v => {
      let varPrice = sellPrice; // default to listing price
      
      // If background.js already calculated ebayPrice, use it
      if (v.ebayPrice && v.ebayPrice > 0) {
        varPrice = v.ebayPrice;
      } else if (v.price) {
        const rawVarPrice = parseFloat(String(v.price).replace(/[^0-9.]/g, ''));
        if (rawVarPrice > 0 && data.price > 0) {
          // Scale variant price proportionally to the main product's cost→sell ratio
          const mainCost = parseFloat(data.price) || 1;
          const ratio = sellPrice / mainCost;
          varPrice = rawVarPrice * ratio;
        }
      }
      // Apply .99/.95 rounding to EVERY variant price (was missing — caused £6.86 instead of £6.99)
      if (useRounding) {
        const ending = roundStyle === '0.95' ? 0.95 : 0.99;
        const floored = Math.floor(varPrice);
        varPrice = (floored + ending) >= varPrice ? (floored + ending) : (floored + 1 + ending);
      } else {
        varPrice = Math.round(varPrice * 100) / 100;
      }
      varPrice = Math.max(varPrice, 0.99);
      console.log('[UnicornDS] Variant: ' + v.name + ' | AliPrice: ' + (v.price || 'none') + ' | EbayPrice: ' + varPrice.toFixed(2) + ' | Img: ' + (v.image ? 'YES' : 'no'));
      return {
        name: v.name,
        price: varPrice,
        image: v.image || '',
        skuId: v.skuId || '',       // AliExpress variant ID — needed for SKU encoding
        properties: v.properties || {}, // {Color: "Red", Size: "L"}
        asin: v.asin || '',         // Amazon variant ASIN
      };
    });

    // Build variantImages map from variations that have images
    const variantImages = {};
    variationsWithPrices.forEach(v => {
      if (v.image) {
        let imgUrl = v.image;
        if (imgUrl.startsWith('//')) imgUrl = 'https:' + imgUrl;
        variantImages[v.name] = [imgUrl];
      }
    });
    console.log('[UnicornDS] Built variant images map:', Object.keys(variantImages).length, 'variants with images');

    // Store variation data for msku-form.js to read
    await new Promise(r => chrome.storage.local.set({
      unicornds_msku_data: {
        variations: variationsWithPrices,
        variantImages: variantImages,
        price: sellPrice,
        quantity: qty,
        sku: sku || productId || ''
      }
    }, r));
    console.log('[UnicornDS] Stored MSKU data with per-variant prices');

    // Click "Edit" on the Variations section to open the MSKU iframe dialog
    // Retry finding the section — page may still be rendering if tab was backgrounded
    let varSection = null;
    for (let findAttempt = 0; findAttempt < 15; findAttempt++) {
      varSection = document.querySelector('.smry.summary__variations');
      if (varSection) break;
      await sleep(1000);
      if (findAttempt === 5) console.log('[UnicornDS] ⏳ Waiting for variations section to render...');
    }

    if (varSection) {
      // Retry finding the edit button too
      let editBtn = null;
      for (let findAttempt = 0; findAttempt < 10; findAttempt++) {
        editBtn = varSection.querySelector('button[aria-label*="Edit"], button.summary__header-edit-button');
        if (editBtn) break;
        await sleep(1000);
      }

      if (editBtn) {
        // Double-click + synthetic MouseEvent — same rescue pattern as submit
        // Chrome can drop the first click on a backgrounded tab
        editBtn.click();
        await sleep(200);
        editBtn.click();
        try {
          editBtn.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true }));
        } catch(e) {}
        console.log('[UnicornDS] ✅ Clicked Edit Variations (double-click + MouseEvent) - iframe dialog opening');
        // Adaptive wait for iframe to actually appear (max 3s, often 500-1000ms)
        for (let i = 0; i < 6; i++) {
          await sleep(500);
          if (document.querySelector('iframe[src*="bulkedit"]')) break;
        }

        // SIGNAL-BASED WAITING: poll msku_done until it arrives or sanity cap hit.
        // No artificial timeout — MSKU takes as long as it takes for big variation counts.
        // Sanity cap = 5 min; a normal 50-variant listing completes in <3 min.
        const MSKU_SANITY_MS = 5 * 60 * 1000; // 5 min sanity cap (normal listing completes in <3 min)
        const mskuStartTime = Date.now();
        let mskuDone = false;
        let lastLogBucket = -1;

        while (!mskuDone) {
          await sleep(2000);
          const s = await new Promise(r => chrome.storage.local.get('unicornds_msku_done', r));
          if (s.unicornds_msku_done?.success) {
            mskuDone = true;
            const elapsedSec = Math.round((Date.now() - mskuStartTime) / 1000);
            console.log('[UnicornDS] ✅ MSKU variations completed! (' + elapsedSec + 's, ' + variations.length + ' variants)');
            break;
          }

          const elapsedMs = Date.now() - mskuStartTime;
          if (elapsedMs > MSKU_SANITY_MS) {
            console.warn('[UnicornDS] ⚠️ MSKU sanity cap hit (5 min) — aborting to keep batch moving');
            break;
          }

          // Progress log every 30 seconds so user knows it's alive
          const logBucket = Math.floor(elapsedMs / 30000);
          if (logBucket !== lastLogBucket) {
            lastLogBucket = logBucket;
            console.log('[UnicornDS] ⏳ MSKU working... ' + Math.round(elapsedMs / 1000) + 's elapsed, ' + variations.length + ' variants');
          }
        }

        // Clean up
        await new Promise(r => chrome.storage.local.remove(['unicornds_msku_done', 'unicornds_msku_data'], r));

        if (!mskuDone) {
          console.warn('[UnicornDS] ⚠️ MSKU timed out — ABORTING listing to prevent wrong-price single item');
          reportProgress('complete', 'MSKU failed — variations not set. Listing NOT submitted to prevent wrong pricing.');
          reportDone(false, 'MSKU timeout — variations not set', title);
          try { chrome.runtime.sendMessage({ type: 'close_current_tab' }); } catch(e) {}
          return;
        }

        // Adaptive post-MSKU settle — wait until dialog is gone, max 3s
        for (let i = 0; i < 6; i++) {
          await sleep(500);
          const dialog = document.querySelector('iframe[src*="bulkedit"], .summary__variations-open');
          if (!dialog) break;
        }

        try { chrome.runtime.sendMessage({ type: 'deactivate_ebay_tab' }); } catch(e) {}
        console.log('[UnicornDS] Tab deactivated - back to user');
      } else {
        console.warn('[UnicornDS] ⚠️ Edit Variations button not found after 10s retry — ABORTING to prevent single-item listing');
        reportProgress('complete', 'Edit Variations button missing — listing NOT submitted');
        reportDone(false, 'Edit Variations button missing', title);
        try { chrome.runtime.sendMessage({ type: 'close_current_tab' }); } catch(e) {}
        return;
      }
    } else {
      console.warn('[UnicornDS] ⚠️ Variations section not found after 15s retry — ABORTING to prevent single-item listing');
      reportProgress('complete', 'Variations section missing — listing NOT submitted');
      reportDone(false, 'Variations section missing', title);
      try { chrome.runtime.sendMessage({ type: 'close_current_tab' }); } catch(e) {}
      return;
    }
  } else {
    console.log('[UnicornDS] No variations (or only 1) - skipping MSKU');
  }

  // ── DESCRIPTION - prepare but do NOT inject yet ──
  //  order: specs FIRST, then description LAST
  // Reason: specs API calls trigger page re-renders that wipe description
  const descHtml = data.ai_description || buildFallbackDescription(data);

  // ── PROMOTED LISTING (DOM) ──
  try { await fillPromotedListing(data); } catch(e) {}
  await sleep(100);

  // ── LOG PROFIT ──
  if (data.profit_data) {
    const p = data.profit_data;
    console.log('[UnicornDS] \u{1F4B0} Profit: ' + p.currency + p.profit + ' (' + (p.profitPct || p.margin) + '% of cost)');
  }

  if (sku) {
    chrome.storage.local.get('unicornds_listed_skus', s => {
      const skus = s.unicornds_listed_skus || [];
      if (!skus.includes(sku)) { skus.push(sku); chrome.storage.local.set({ unicornds_listed_skus: skus }); }
    });
  }

  // ══════════════════════════════════════════════════════
  // PHASE 2: SPECS + DESCRIPTION + SUBMIT
  // MINIMAL FOCUS: API PUT saves data server-side without needing active tab
  // Only brief activation for submit click
  // ══════════════════════════════════════════════════════
  
  // Quick flash — activate 1s to let any pending reloads process, then deactivate
  try { chrome.runtime.sendMessage({ type: 'activate_this_tab' }); } catch(e) {}
  await sleep(1000);
  try { chrome.runtime.sendMessage({ type: 'deactivate_ebay_tab' }); } catch(e) {}
  console.log('[UnicornDS] Quick flash for specs');

  reportProgress('specs', 'Filling item specifics...');
  try { await fillSpecificsViaAPI(data.filteredItemSpecifics || data.itemSpecifics || [], data); }
  catch(e) { console.warn('[UnicornDS] Specifics error:', e.message); }

  // ── POST-FILL CHECK: catch required fields wiped by API reload ──
  // The API PUT returns {"reload":true} which refreshes the page and can
  // wipe DOM-filled dropdown values. Re-check and fill empty required fields.
  await sleep(2000); // let reload settle
  try {
    const errorBanner = document.querySelector('[class*="error"], [class*="inline-notice--attention"]');
    if (errorBanner && errorBanner.textContent.includes('required')) {
      console.log('[UnicornDS] ⚠️ Required fields still empty after specs fill — retrying...');
      // Find all required fields that are still empty
      const requiredSection = document.querySelector('.smry.summary__attributes');
      if (requiredSection) {
        const fields = requiredSection.querySelectorAll('.se-field, [class*="field"]');
        for (const field of fields) {
          const label = field.querySelector('.se-field-label, [class*="label"]');
          const input = field.querySelector('input[type="text"], .textbox__control');
          const dropdown = field.querySelector('.fake-menu-button__button, button[aria-haspopup]');
          if (!label) continue;
          const labelText = label.textContent.trim();
          const inputVal = input ? input.value.trim() : '';
          const dropdownVal = dropdown ? dropdown.textContent.trim() : '';
          
          // Skip if already filled
          if (inputVal && inputVal !== 'Select' && inputVal !== 'Choose') continue;
          if (dropdownVal && dropdownVal !== 'Select' && dropdownVal !== 'Choose' && dropdownVal.length > 2) continue;

          // Try to type "Does Not Apply" for empty required fields
          if (input) {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
            if (nativeSetter) nativeSetter.call(input, 'Does Not Apply'); else input.value = 'Does Not Apply';
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
            await sleep(300);
            console.log('[UnicornDS]   🔄 Retry filled "' + labelText + '" = Does Not Apply');
          }
        }
      }
    }
  } catch(e) { console.warn('[UnicornDS] Post-fill check error:', e.message); }

  // Fill EAN/UPC/ISBN
  await fillProductIdentifiers();

  // ══════════════════════════════════════════════════════
  // PHASE 3: DESCRIPTION
  // ══════════════════════════════════════════════════════
  // Strategy: Use API PUT FIRST (most reliable way to persist description to draft),
  // then DOM as verification/backup. API PUT causes reload:true but that's OK because
  // description is the LAST field before submit — we WANT it saved to the draft.
  // ══════════════════════════════════════════════════════
  // Wait for spec reload to finish — poll DOM stability
  {
    let stableCount = 0;
    let lastHTML = document.body.innerHTML.length;
    for (let w = 0; w < 20; w++) {
      await sleep(500);
      const currentHTML = document.body.innerHTML.length;
      if (Math.abs(currentHTML - lastHTML) < 50) {
        stableCount++;
        if (stableCount >= 3) break;
      } else {
        stableCount = 0;
      }
      lastHTML = currentHTML;
    }
    console.log('[UnicornDS] Page stable after specs — injecting description');
  }

  reportProgress('description', 'Adding description...');

  // METHOD 1 (PRIMARY): Save description via eBay Draft API — most reliable
  let descSavedViaAPI = false;
  try {
    await updateDraftAPI({ description: descHtml, descriptionEditorMode: 'RTE_EDITOR' });
    descSavedViaAPI = true;
    console.log('[UnicornDS] ✅ Description saved via API (' + descHtml.length + ' chars)');
    // Wait for any page reload triggered by the API call
    await sleep(4000);
    // Re-check page stability after reload
    let stableCount2 = 0;
    let lastHTML2 = document.body.innerHTML.length;
    for (let w2 = 0; w2 < 10; w2++) {
      await sleep(500);
      const currentHTML2 = document.body.innerHTML.length;
      if (Math.abs(currentHTML2 - lastHTML2) < 50) {
        stableCount2++;
        if (stableCount2 >= 2) break;
      } else {
        stableCount2 = 0;
      }
      lastHTML2 = currentHTML2;
    }
  } catch(e) {
    console.warn('[UnicornDS] API description save failed:', e.message, '— trying DOM methods');
  }

  // METHOD 2 (BACKUP): DOM injection via "Show HTML code" checkbox → textarea
  // Only if API failed, or as extra insurance
  let descDomDone = false;
  try {
    const checkboxEl = document.querySelector('input[name="descriptionEditorMode"]') ||
                       document.querySelector('input[id*="descriptionEditorMode"]');
    const textarea = document.querySelector('textarea[name="description"]') ||
                     document.querySelector('textarea[id*="rawEditor"]');

    if (checkboxEl && textarea) {
      if (!checkboxEl.checked) {
        checkboxEl.click();
        await sleep(1500);
      }
      textarea.classList.remove('hidden');
      textarea.style.display = '';
      await sleep(500);

      textarea.focus();
      textarea.value = descHtml;
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.dispatchEvent(new Event('change', { bubbles: true }));
      textarea.dispatchEvent(new Event('blur', { bubbles: true }));
      await sleep(1000);

      // Switch back to visual mode
      checkboxEl.click();
      await sleep(2000);

      descDomDone = true;
      console.log('[UnicornDS] ✅ Description also set via HTML editor (' + descHtml.length + ' chars)');
    }
  } catch(e) { console.warn('[UnicornDS] HTML code editor error:', e.message); }

  // METHOD 3 (FALLBACK): iframe approach
  if (!descDomDone && !descSavedViaAPI) {
    try {
      const iframe = document.getElementById('se-rte-frame__summary');
      if (iframe) {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        const editor = iframeDoc.body.querySelector('.se-rte-editor__rich') || iframeDoc.body;
        editor.focus(); await sleep(200);
        iframeDoc.execCommand('selectAll', false, null);
        iframeDoc.execCommand('insertHTML', false, descHtml);
        if (editor.innerHTML.length < 50) editor.innerHTML = descHtml;
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        editor.dispatchEvent(new Event('blur', { bubbles: true }));
        descDomDone = true;
        console.log('[UnicornDS] ✅ Description set via iframe (' + editor.innerHTML.length + ' chars)');
      }
    } catch(e) {}
  }

  // If nothing worked at all, try API one more time
  if (!descDomDone && !descSavedViaAPI) {
    try {
      await updateDraftAPI({ description: descHtml, descriptionEditorMode: 'RTE_EDITOR' });
      console.log('[UnicornDS] ✅ Description saved via API (last resort)');
      await sleep(3000);
    } catch(e) {
      console.error('[UnicornDS] ❌ ALL description methods failed!');
    }
  }

  showNotification('Listing filled!', 'success');

  // ── AUTO-SUBMIT - click IMMEDIATELY, no more API calls ──
  const autoApprove = data.auto_approve !== false;
  console.log('[UnicornDS] Auto-approve:', autoApprove);
  if (autoApprove) {
    reportProgress('submitting', 'Submitting listing...');

    // Find submit button - search multiple selectors and text patterns
    const ctaSection = document.querySelector('.smry.summary__cta');
    let listBtn = null;
    if (ctaSection) {
      listBtn = ctaSection.querySelector("button[aria-label*='List']") ||
                ctaSection.querySelector('.btn--primary');
    }
    if (!listBtn) {
      // Search ALL buttons and links for listing-related text
      listBtn = Array.from(document.querySelectorAll('button, a[role="button"], [role="button"]')).find(btn => {
        const txt = btn.textContent.trim().toLowerCase();
        return (txt.includes('list it') || txt.includes('list with') || txt.includes('list item')) && !btn.disabled;
      });
    }

    if (listBtn && !listBtn.disabled) {
      // ACTIVATE TAB — stay active through submit + fee confirmation + success
      try { chrome.runtime.sendMessage({ type: 'activate_this_tab' }); } catch(e) {}
      await sleep(800);
      console.log('[UnicornDS] Tab activated for submit');

      listBtn.scrollIntoView({ behavior: 'instant', block: 'center' });
      await sleep(300);
      // EcomSniper technique: double-click + synthetic MouseEvent
      // Chrome often drops the first click on backgrounded/throttled tabs
      listBtn.click();
      await sleep(200);
      listBtn.click();
      try {
        listBtn.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true }));
      } catch(e) {}
      console.log('[UnicornDS] ✅ Clicked submit (double-click + MouseEvent)');
      // Adaptive post-submit wait — exits as soon as URL changes or fee button appears.
      // Max 3s (same as before), often completes in 500-1000ms.
      for (let i = 0; i < 6; i++) {
        await sleep(500);
        if (window.location.href.includes('/sl/success')) break;
        const feeBtnQuick = Array.from(document.querySelectorAll('button, a[role="button"]')).find(b => {
          const t = b.textContent.trim().toLowerCase();
          return (t.includes('list with displayed') || t.includes('list with fee')) && !b.disabled;
        });
        if (feeBtnQuick) break;
      }
      // Tab stays active — fee confirmation needs it

      // Re-check description — use HTML editor if wiped (NOT API PUT which causes reload)
      try {
        const recheckIframe = document.getElementById('se-rte-frame__summary');
        if (recheckIframe) {
          const recheckDoc = recheckIframe.contentDocument || recheckIframe.contentWindow.document;
          const recheckEditor = recheckDoc.body.querySelector('.se-rte-editor__rich') || recheckDoc.body;
          const currentDesc = (recheckEditor.innerHTML || '').trim();
          if (!currentDesc || currentDesc.length < 50 || currentDesc === '<br>' || currentDesc === '<p><br></p>') {
            console.log('[UnicornDS] !! Description was wiped! Re-injecting via HTML editor...');
            const cb = document.querySelector('input[name="descriptionEditorMode"]');
            const ta = document.querySelector('textarea[name="description"]') || document.querySelector('textarea[id*="rawEditor"]');
            if (cb && ta) {
              if (!cb.checked) { cb.click(); await sleep(1500); }
              ta.classList.remove('hidden'); ta.style.display = '';
              ta.focus(); ta.value = descHtml;
              ta.dispatchEvent(new Event('input', { bubbles: true }));
              ta.dispatchEvent(new Event('change', { bubbles: true }));
              await sleep(1000);
              cb.click(); await sleep(3000);
              console.log('[UnicornDS] ✅ Description re-injected via HTML editor');
            } else {
              // Last resort — API PUT
              await updateDraftAPI({ description: descHtml, descriptionEditorMode: 'RTE_EDITOR' });
              await sleep(3000);
              console.log('[UnicornDS] ✅ Description re-saved via API (last resort)');
            }
          } else {
            console.log('[UnicornDS] ✅ Description still intact (' + currentDesc.length + ' chars)');
          }
        }
      } catch(e) { console.warn('[UnicornDS] Description re-check error:', e.message); }

      listBtn.scrollIntoView({ block: 'center' });
      await sleep(300);

      // SIGNAL-BASED SUBMIT POLLING
      // Wait for real success signal (URL change to /sl/success OR success header in DOM).
      // Faster poll (2s instead of 5s) so we detect success quickly.
      // Per-listing sanity cap = 5 min — if submit doesn't complete, abort
      // this listing and move to next so the whole batch doesn't get stuck.
      let listed = false;
      let ebayItemLink = '';
      let feeClicked = false;
      let rescueClickFired = false;
      const SUBMIT_SANITY_MS = 5 * 60 * 1000; // 5 min submit cap — background watcher is the absolute timer
      const submitStartTime = Date.now();
      let submitLogBucket = -1;

      while (!listed) {
        await sleep(2000);
        const attempt = Math.floor((Date.now() - submitStartTime) / 2000);
        // Check URL - eBay navigates to /sl/success on success
        if (window.location.href.includes('/sl/success')) {
          listed = true;
          try { ebayItemLink = document.querySelector('a[href*="/itm/"]')?.href || ''; } catch(e) {}
          console.log('[UnicornDS] ✅ Listing confirmed! Success URL detected');
          break;
        }
        // Check DOM - fallback
        const successHeader = document.querySelector('.success__header');
        if (successHeader) {
          listed = true;
          try { ebayItemLink = document.querySelector('.success__body-link a')?.href || ''; } catch(e) {}
          console.log('[UnicornDS] ✅ Listing confirmed! Success header detected');
          break;
        }

        // WATCHDOG: if still on /lstng after 30s and no fee page appeared, Chrome likely
        // dropped the initial click. Re-click submit as a rescue attempt (once only).
        if (!rescueClickFired && (Date.now() - submitStartTime) >= 30000 && window.location.href.includes('/lstng')) {
          const rescueBtn = Array.from(document.querySelectorAll('button, a[role="button"], [role="button"]')).find(btn => {
            const txt = btn.textContent.trim().toLowerCase();
            return (txt.includes('list it') || txt.includes('list item')) && !btn.disabled;
          });
          if (rescueBtn) {
            console.log('[UnicornDS] 🔁 Watchdog: still on /lstng after 30s — re-clicking submit');
            try { chrome.runtime.sendMessage({ type: 'activate_this_tab' }); } catch(e) {}
            await sleep(500);
            rescueBtn.click();
            await sleep(200);
            rescueBtn.click();
            try {
              rescueBtn.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true }));
            } catch(e) {}
            rescueClickFired = true;
            await sleep(3000);
            continue;
          }
        }

        // FEE CONFIRMATION PAGE - brief activate, click ONCE, deactivate
        if (!feeClicked) {
          const feeBtn = Array.from(document.querySelectorAll('button, a[role="button"]')).find(btn => {
            const txt = btn.textContent.trim().toLowerCase();
            return (txt.includes('list with displayed') || txt.includes('list with fee')) && !btn.disabled;
          });
          if (feeBtn) {
            console.log('[UnicornDS] 💰 Fee confirmation - clicking ONCE: "' + feeBtn.textContent.trim() + '"');
            // Keep tab active through fee + re-inject + re-submit
            try { chrome.runtime.sendMessage({ type: 'activate_this_tab' }); } catch(e) {}
            await sleep(500);
            // Description already saved via API PUT earlier — no need to re-save here
            // (re-saving would cause page reload and lose the fee button)
            // EcomSniper double-click for fee confirmation
            feeBtn.click();
            await sleep(200);
            feeBtn.click();
            try {
              feeBtn.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true }));
            } catch(e) {}
            feeClicked = true;
            console.log('[UnicornDS] 💰 Fee button clicked (double-click + MouseEvent) — waiting for page to settle...');
            // Adaptive wait: check every 500ms if description editor is ready.
            // Exits as soon as page is usable (typically 3-6s), caps at 12s (safety).
            let feeReadyTime = 0;
            for (let i = 0; i < 24; i++) {
              await sleep(500);
              feeReadyTime += 500;
              // Page is ready when the description textarea or editor is present AND we're not on /sl/success yet
              if (window.location.href.includes('/sl/success')) break;
              const ready = document.querySelector('textarea[name="description"]') ||
                            document.querySelector('input[name="descriptionEditorMode"]') ||
                            document.querySelector('.se-rte-editor__rich');
              if (ready && feeReadyTime >= 3000) break; // minimum 3s + DOM ready
            }
            console.log('[UnicornDS] 💰 Fee page settled in ' + feeReadyTime + 'ms');

            // RE-INJECT description via HTML code editor (NO API PUT — causes reload that wipes it)
            let descFixed = false;
            try {
              const checkboxEl = document.querySelector('input[name="descriptionEditorMode"]') ||
                                 document.querySelector('input[id*="descriptionEditorMode"]');
              const textarea = document.querySelector('textarea[name="description"]') ||
                               document.querySelector('textarea[id*="rawEditor"]');

              if (checkboxEl && textarea) {
                if (!checkboxEl.checked) { checkboxEl.click(); await sleep(1500); }
                textarea.classList.remove('hidden');
                textarea.style.display = '';
                await sleep(500);
                textarea.focus();
                textarea.value = descHtml;
                textarea.dispatchEvent(new Event('input', { bubbles: true }));
                textarea.dispatchEvent(new Event('change', { bubbles: true }));
                textarea.dispatchEvent(new Event('blur', { bubbles: true }));
                await sleep(1000);
                checkboxEl.click();
                await sleep(3000);
                descFixed = true;
                console.log('[UnicornDS] 💰 Description re-injected via HTML editor');
              }
            } catch(e) { console.warn('[UnicornDS] 💰 HTML editor error:', e.message); }

            if (!descFixed) {
              // Last resort: API PUT
              try {
                await updateDraftAPI({ description: descHtml, descriptionEditorMode: 'RTE_EDITOR' });
                console.log('[UnicornDS] 💰 Description saved via API fallback');
                await sleep(3000);
              } catch(e) {}
            }

            // Re-click submit
            const reSubmitBtn = Array.from(document.querySelectorAll('button, a[role="button"], [role="button"]')).find(btn => {
              const txt = btn.textContent.trim().toLowerCase();
              return (txt.includes('list it') || txt.includes('list with') || txt.includes('list item')) && !btn.disabled;
            });
            if (reSubmitBtn) {
              // EcomSniper double-click + MouseEvent for reliability
              reSubmitBtn.click();
              await sleep(200);
              reSubmitBtn.click();
              try {
                reSubmitBtn.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true }));
              } catch(e) {}
              console.log('[UnicornDS] 💰 Re-clicked submit after fee + description DOM fix (double-click + MouseEvent)');
              await sleep(3000);
            }
            continue;
          }
        }

        // Sanity cap check — abort this listing if it's taken too long
        const submitElapsed = Date.now() - submitStartTime;
        if (submitElapsed > SUBMIT_SANITY_MS) {
          console.warn('[UnicornDS] ⚠️ Submit sanity cap hit (5 min) — moving to next listing');
          break;
        }

        // Progress log every 30s so user knows it's alive
        const bucket = Math.floor(submitElapsed / 30000);
        if (bucket !== submitLogBucket) {
          submitLogBucket = bucket;
          console.log('[UnicornDS] ⏳ Waiting for success page... ' + Math.round(submitElapsed/1000) + 's elapsed, URL:', window.location.href);
        }
      }

      if (listed) {
        reportProgress('complete', 'Listed successfully');
        reportDone(true, '', title);
        // Deduct 1 credit for successful listing
        try { chrome.runtime.sendMessage({ type: 'deductCredits', amount: 1 }); } catch(e) {}
        // Switch back to user's tab before closing
        try { chrome.runtime.sendMessage({ type: 'deactivate_ebay_tab' }); } catch(e) {}
        await sleep(1000);
        try { chrome.runtime.sendMessage({ type: 'close_current_tab' }); } catch(e) {}
      } else {
        // Not on success page - check for REAL error banners only
        // The red error banner says "Looks like something is missing or invalid"
        // Filter out "Suggested item specifics" which is NOT an error
        let errMsg = 'Submit failed - no success page detected';
        const allNotices = document.querySelectorAll('[class*="inline-notice--attention"], [class*="notice--error"], [role="alert"], [class*="field-error"], .page-notice--attention, .error-message, [class*="validation-error"]');
        const errors = [];
        for (const notice of allNotices) {
          const txt = (notice.textContent || '').trim();
          if (txt && txt.length > 5 && txt.length < 300 && !txt.includes('Suggested item specifics')) {
            errors.push(txt.substring(0, 150));
          }
        }
        if (errors.length) {
          errMsg = errors[0];
          console.log('[UnicornDS] ❌ Page errors found:', errors.length);
          errors.forEach((e, i) => console.log('[UnicornDS] ❌ Error ' + (i+1) + ':', e));
        } else {
          // Check if page is still loading/processing
          const spinner = document.querySelector('.progress-bar, [class*="spinner"], [class*="loading"]');
          if (spinner) {
            console.log('[UnicornDS] ⏳ Page still has spinner/loading indicator');
          }
        }
        // If description error, retry once - re-activate, re-inject, re-submit
        if (errMsg.toLowerCase().includes('description')) {
          console.log('[UnicornDS] 🔄 Description error - retrying via API...');
          try {
            // Re-save description via API (the reliable method)
            await updateDraftAPI({ description: descHtml, descriptionEditorMode: 'RTE_EDITOR' });
            console.log('[UnicornDS] 🔄 Description re-saved via API');
            await sleep(2000);

            // Also re-inject via execCommand as visual feedback
            try {
              const retryIframe = document.getElementById('se-rte-frame__summary');
              if (retryIframe) {
                const retryDoc = retryIframe.contentDocument || retryIframe.contentWindow.document;
                const retryEditor = retryDoc.body.querySelector('.se-rte-editor__rich') || retryDoc.body;
                retryEditor.focus();
                await sleep(200);
                retryDoc.execCommand('selectAll', false, null);
                retryDoc.execCommand('delete', false, null);
                retryDoc.execCommand('insertHTML', false, descHtml);
                await sleep(500);
              }
            } catch(e) {}

            // Re-click submit
            console.log('[UnicornDS] 🔄 Retrying submit...');
            listBtn.click();
            // Check for success again - give more time (6 attempts x 5s = 30s)
            let retryListed = false;
            for (let r = 0; r < 6; r++) {
              await sleep(5000);
              if (window.location.href.includes('/sl/success')) { retryListed = true; break; }
              const retrySuccess = document.querySelector('.success__header');
              if (retrySuccess) { retryListed = true; break; }
            }
            if (retryListed) {
              console.log('[UnicornDS] ✅ Listing succeeded on retry!');
              reportProgress('complete', 'Listed successfully (retry)');
              reportDone(true, '', title);
              try { chrome.runtime.sendMessage({ type: 'deactivate_ebay_tab' }); } catch(e) {}
              await sleep(1000);
              try { chrome.runtime.sendMessage({ type: 'close_current_tab' }); } catch(e) {}
              clearInterval(popupDismisser);
              console.log('[UnicornDS] ═══ fillForm DONE ═══');
              isProcessing = false;
              return;
            }
          } catch(retryErr) { console.warn('[UnicornDS] Retry error:', retryErr.message); }
        }
        console.warn('[UnicornDS] \u26a0\ufe0f Listing failed:', errMsg);
        reportProgress('error', errMsg);
        reportDone(false, errMsg, title);
        try { chrome.runtime.sendMessage({ type: 'deactivate_ebay_tab' }); } catch(e) {}
      }
    } else {
      reportProgress('error', 'Submit button not found');
      reportDone(false, 'Submit button not found', title);
      try { chrome.runtime.sendMessage({ type: 'deactivate_ebay_tab' }); } catch(e) {}
    }
  } else {
    reportProgress('waiting', 'Manual review required');
    reportDone(true, '', title);
  }

  // Cleanup handled by outer fillForm finally block (Fixes C6)
}

// ═══════════════════════════════════════════════════════
// DESCRIPTION - persistent watcher approach
// eBay's React replaces the iframe on every API reload.
// We use an interval that checks every 2s and re-injects if empty.
// ═══════════════════════════════════════════════════════

function buildFallbackDescription(data) {
  const title = data.title || data.custom_title || '';
  const specs = data.filteredItemSpecifics || data.itemSpecifics || [];
  let html = '<div style="font-family:Arial,sans-serif;max-width:800px;margin:0 auto;padding:20px;">';
  html += '<h2 style="color:#333;font-size:22px;margin-bottom:16px;">' + escHtml(title) + '</h2>';
  if (specs.length > 0) {
    html += '<h3 style="color:#555;font-size:16px;margin:16px 0 8px;">Product Details</h3>';
    html += '<table style="width:100%;border-collapse:collapse;margin-bottom:16px;">';
    specs.forEach(s => {
      html += '<tr><td style="padding:8px 12px;border:1px solid #e0e0e0;font-weight:bold;background:#f8f8f8;width:35%;">' + escHtml(s.label) + '</td>';
      html += '<td style="padding:8px 12px;border:1px solid #e0e0e0;">' + escHtml(s.value) + '</td></tr>';
    });
    html += '</table>';
  }
  html += '<p style="margin-top:20px;font-size:13px;color:#888;border-top:1px solid #eee;padding-top:12px;">Thank you for shopping with us.</p></div>';
  return html;
}

// Start a watcher that re-injects description every 2 seconds if it's empty
function startDescriptionWatcher(html) {
  if (!html) return null;
  let injectCount = 0;

  const watcher = setInterval(() => {
    try {
      const iframe = document.getElementById('se-rte-frame__summary');
      if (!iframe) return;

      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      if (!iframeDoc || !iframeDoc.body) return;

      const editor = iframeDoc.body.querySelector('.se-rte-editor__rich') || iframeDoc.body;
      const content = editor.innerHTML || '';
      const isEmpty = !content.trim() ||
        content.trim().length < 30 ||
        editor.classList.contains('placeholder') ||
        content.includes('Write a detailed description');

      if (isEmpty) {
        injectCount++;
        injectDescriptionIntoEditor(html);
        console.log('[UnicornDS] 🔄 Description re-injected by watcher (#' + injectCount + ')');
      }
    } catch(e) {}
  }, 2000);

  console.log('[UnicornDS] 👁 Description watcher started');
  return watcher;
}

// THE REAL PERMANENT FIX: Use execCommand('selectAll') + execCommand('insertText')
// This is the ONLY method that updates React's contenteditable internal state.
// Proven: when we run this, eBay's "List with displayed fees" button works.
// execCommand('insertHTML') does NOT work. execCommand('insertText') DOES.
function injectDescriptionIntoEditor(html) {
  if (!html) return false;
  try {
    const iframe = document.getElementById('se-rte-frame__summary');
    if (!iframe) { console.warn('[UnicornDS] Description iframe not found'); return false; }

    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    const editor = iframeDoc.body.querySelector('.se-rte-editor__rich') || iframeDoc.body;

    // Remove placeholder class
    editor.classList.remove('placeholder');
    editor.focus();

    // Strip HTML tags → plain text for insertText
    // The real HTML is already saved via API PUT - this is just for React validation
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    const plainText = tmp.textContent || tmp.innerText || html;

    // Select all + insertText - proven to update React's internal state
    iframeDoc.execCommand('selectAll');
    iframeDoc.execCommand('insertText', false, plainText);

    highlight(iframe);
    console.log('[UnicornDS] ✅ Description injected (' + plainText.length + ' chars)');
    return true;
  } catch(e) {
    console.warn('[UnicornDS] Description inject error:', e.message);
    return false;
  }
}

// ═══════════════════════════════════════════════════════
// PROMOTED LISTING
// ═══════════════════════════════════════════════════════
async function fillPromotedListing(data) {
  let adRate = parseFloat(data.promoted_listing_ad_rate) || 0;
  if (!adRate) {
    try {
      const s = await new Promise(r => chrome.storage.local.get(['unicornds_promo_rate', 'unicornds_ad_rate'], r));
      adRate = parseFloat(s.unicornds_promo_rate) || parseFloat(s.unicornds_ad_rate) || 0;
    } catch(e) {}
  }
  if (!adRate) return;
  const section = document.querySelector('.smry.summary__promoted-listing') || document.querySelector('[class*="promoted"]');
  if (!section) return;
  const toggle = section.querySelector('input[type="checkbox"]') || section.querySelector('button[role="switch"]');
  if (toggle && ((toggle.type === 'checkbox' && !toggle.checked) || toggle.getAttribute('aria-checked') === 'false')) {
    toggle.click(); await sleep(500);
  }
  await sleep(300);
  const rateInput = section.querySelector('input[type="text"]') || section.querySelector('input[type="number"]');
  if (rateInput) { setInputValue(rateInput, String(adRate)); fireChange(rateInput); highlight(rateInput); console.log('[UnicornDS] \u2705 Ad rate:', adRate); }
}

// ═══════════════════════════════════════════════════════
// IMAGES
// ═══════════════════════════════════════════════════════
async function uploadImages(images) {
  if (!images || !images.length) return;
  const fileInput = document.querySelector('#fehelix-uploader');
  if (!fileInput) { console.warn('[UnicornDS] #fehelix-uploader not found'); return; }

  const seenBases = new Set();
  const validImages = [];

  // Known placeholder/store icon patterns to skip
  const skipPatterns = [
    /\/kf\/S906ef2f1/i,       // Generic AliExpress placeholder
    /\/avatar\//i,
    /\/store\//i,
    /placeholder/i,
    /default_img/i,
    /no[_-]?image/i,
  ];

  // Junk size patterns in URLs - these are icons, swatches, banners, not product photos
  const junkSizePatterns = [
    /\/\d{2,3}x\d{2,3}\.(png|jpg|gif)/i,   // 27x27.png, 48x48.png, 56x57.png etc
    /\/\d{3}x\d{2}\.(png|jpg)/i,            // 422x42.png, 232x98.png (banners)
    /\/\d{2}x\d{3}\.(png|jpg)/i,            // 42x422.png
  ];

  for (const url of images) {
    if (!url) continue;
    let u = (typeof url === 'string' ? url : (url.url || ''));
    if (!u) continue;
    const uLow = u.toLowerCase();

    // Skip videos
    if (uLow.endsWith('.mp4') || uLow.endsWith('.webm') || uLow.endsWith('.mov') || uLow.includes('/video/')) continue;

    // Skip known placeholders
    if (skipPatterns.some(p => p.test(uLow))) {
      console.log('[UnicornDS] Skipping placeholder:', u.substring(0, 60));
      continue;
    }

    // Skip tiny icon/swatch/banner URLs (27x27, 48x48, 56x57, 422x42, etc)
    if (junkSizePatterns.some(p => p.test(u))) {
      console.log('[UnicornDS] Skipping icon/swatch:', u.substring(0, 60));
      continue;
    }

    // Extract base URL (without size suffix) for deduplication
    const base = u.replace(/_\d+x\d+q?\d*\..*$/i, '').replace(/\?.*$/, '').toLowerCase();
    if (seenBases.has(base)) continue;
    seenBases.add(base);

    // Convert thumbnail URLs to HD
    // _220x220q75.jpg_.avif → strip suffix to get base .jpg
    if (u.includes('_220x220') || u.includes('_100x100') || u.includes('_50x50')) {
      u = u.replace(/_\d+x\d+q?\d*\.[^/]*$/i, '');
    }

    validImages.push(u);
  }

  // Limit to 24 images max (eBay's limit)
  const max = Math.min(validImages.length, 24);
  console.log('[UnicornDS] Uploading', max, 'of', images.length, 'images (filtered', images.length - validImages.length, ' junk,', validImages.length - max, ' overflow)');

  let uploadedCount = 0;
  for (let i = 0; i < max; i++) {
    let url = validImages[i];
    if (!url) continue;
    if (url.startsWith('//')) url = 'https:' + url;
    if (url.includes('amazon') || url.includes('media-amazon')) url = url.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.');
    if (url.includes('aliexpress-media.com') || (url.includes('alicdn.com') && url.includes('/kf/'))) url = url.replace(/\d+x\d+q\d+/g, '960x960q75');

    try {
      let b64;
      if (i === 0) b64 = await generateTemplatedImage(url, validImages);
      if (!b64) {
        b64 = await new Promise((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error('timeout')), 10000);
          chrome.runtime.sendMessage({ type: 'url-to-b64', url }, resp => {
            clearTimeout(timer);
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            if (!resp || resp.error) return reject(new Error(resp?.error || 'empty'));
            resolve(resp.b64Image);
          });
        });
      }
      if (!b64 || !b64.startsWith('data:')) continue;

      // STRIP METADATA: re-encode through canvas to remove ALL EXIF/XMP/IPTC data
      // This removes any AliExpress identifiers, GPS coords, software tags, etc.
      try {
        b64 = await new Promise((resolve, reject) => {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            const c = document.createElement('canvas');
            c.width = img.width;
            c.height = img.height;
            const ctx = c.getContext('2d');
            ctx.drawImage(img, 0, 0);
            resolve(c.toDataURL('image/jpeg', 0.92));
          };
          img.onerror = () => reject(new Error('canvas decode'));
          img.src = b64;
        });
      } catch(e) {
        console.warn('[UnicornDS] Canvas re-encode failed, using raw');
      }

      const parts = b64.split(',');
      const raw = atob(parts[1]);

      // Skip tiny images (< 10KB or < 500px wide) - eBay requires 500px minimum
      if (raw.length < 10000) {
        console.log('[UnicornDS] ⏭ Skipping tiny image ' + (i+1) + ' (' + (raw.length/1024).toFixed(0) + 'KB)');
        continue;
      }

      // Check pixel dimensions - eBay requires minimum 500px wide
      try {
        const testImg = await new Promise((res, rej) => {
          const im = new Image();
          im.onload = () => res(im);
          im.onerror = () => rej(new Error('decode'));
          im.src = b64;
        });
        if (testImg.width < 500) {
          console.log('[UnicornDS] ⏭ Skipping small image ' + (i+1) + ' (' + testImg.width + 'x' + testImg.height + 'px)');
          continue;
        }
      } catch(e) {}

      const arr = new Uint8Array(raw.length);
      for (let j = 0; j < raw.length; j++) arr[j] = raw.charCodeAt(j);
      const file = new File([arr], 'img_' + (uploadedCount+1) + '.jpg', { type: 'image/jpeg' });
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      uploadedCount++;
      console.log('[UnicornDS] ✅ Image ' + uploadedCount + ' (' + (file.size/1024).toFixed(0) + 'KB)');
      await sleep(3000);
    } catch (err) { console.warn('[UnicornDS] ❌ Image ' + (i+1) + ':', err.message); }
  }
  console.log('[UnicornDS] 📸 Upload complete: ' + uploadedCount + ' images uploaded');
  return uploadedCount;
}

async function generateTemplatedImage(productImgUrl, allImages) {
  const storage = await new Promise(r => chrome.storage.local.get('unicornds_image_template', r));
  const tmpl = storage.unicornds_image_template;
  if (!tmpl || !tmpl.objects || !tmpl.objects.length) return null;
  const placeholders = tmpl.objects.filter(o => o.type === 'placeholder').sort((a,b) => a.num - b.num);
  if (!placeholders.length) return null;

  const SIZE = 1500;
  const canvas = document.createElement('canvas');
  canvas.width = SIZE; canvas.height = SIZE;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, SIZE, SIZE);

  // Render all objects in order (same z-order as designer)
  const imgs = allImages || [productImgUrl];

  for (const o of tmpl.objects) {
    ctx.save();
    ctx.globalAlpha = o.opacity ?? 1;

    // ── PLACEHOLDER - fill with product image ──
    if (o.type === 'placeholder') {
      const imgUrl = imgs[o.num - 1] || imgs[0];
      if (!imgUrl) { ctx.restore(); continue; }
      let url = imgUrl;
      if (url.startsWith('//')) url = 'https:' + url;
      if (url.includes('aliexpress-media.com') || (url.includes('alicdn.com') && url.includes('/kf/'))) url = url.replace(/\d+x\d+q\d+/g, '960x960q75');
      if (url.includes('amazon') || url.includes('media-amazon')) url = url.replace(/\._[A-Za-z]+[0-9_]+_\./, '._UL1500_.');
      try {
        const b64 = await new Promise((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error('timeout')), 10000);
          chrome.runtime.sendMessage({ type: 'url-to-b64', url }, resp => { clearTimeout(timer); resolve(resp?.b64Image || null); });
        });
        if (!b64) { ctx.restore(); continue; }
        const img = await new Promise((resolve, reject) => { const i = new Image(); i.onload = () => resolve(i); i.onerror = () => reject(new Error('img')); i.src = b64; });
        ctx.beginPath(); ctx.rect(o.x, o.y, o.w, o.h); ctx.clip();
        // CONTAIN mode - fit entire product image, no cropping
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(o.x, o.y, o.w, o.h);
        const ia = img.width / img.height, ba = o.w / o.h;
        let dw, dh, dx, dy;
        if (ia > ba) { dw = o.w; dh = o.w / ia; dx = o.x; dy = o.y + (o.h - dh) / 2; }
        else { dh = o.h; dw = o.h * ia; dx = o.x + (o.w - dw) / 2; dy = o.y; }
        ctx.drawImage(img, dx, dy, dw, dh);
      } catch (e) {
        console.warn('[UnicornDS] Template placeholder', o.num, 'failed:', e.message);
      }
    }

    // ── UPLOADED IMAGE (logo, badge, watermark) - render from stored b64 ──
    if (o.type === 'image' && o.b64) {
      try {
        const img = await new Promise((resolve, reject) => {
          const i = new Image();
          i.onload = () => resolve(i);
          i.onerror = () => reject(new Error('b64 decode failed'));
          i.src = o.b64;
        });
        ctx.beginPath(); ctx.rect(o.x, o.y, o.w, o.h); ctx.clip();
        const ia = img.width / img.height, ba = o.w / o.h;
        let dw, dh, dx, dy;
        if (ia > ba) { dh = o.h; dw = o.h * ia; dx = o.x + (o.w - dw) / 2; dy = o.y; }
        else { dw = o.w; dh = o.w / ia; dx = o.x; dy = o.y + (o.h - dh) / 2; }
        ctx.drawImage(img, dx, dy, dw, dh);
        console.log('[UnicornDS] Template image rendered:', o.name || 'uploaded');
      } catch (e) {
        console.warn('[UnicornDS] Template image failed:', o.name, e.message);
      }
    }

    // ── BANNER (text overlay) ──
    if (o.type === 'banner') {
      let text = o.text || '';
      const productTitle = (await new Promise(r => chrome.storage.local.get('unicornds_last_product', r)))?.unicornds_last_product?.custom_title || '';
      if (text === '{{productTitle}}') text = productTitle;
      ctx.fillStyle = o.bg || '#e74c3c';
      const r = 6;
      ctx.beginPath(); ctx.moveTo(o.x+r,o.y); ctx.lineTo(o.x+o.w-r,o.y); ctx.arcTo(o.x+o.w,o.y,o.x+o.w,o.y+r,r);
      ctx.lineTo(o.x+o.w,o.y+o.h-r); ctx.arcTo(o.x+o.w,o.y+o.h,o.x+o.w-r,o.y+o.h,r);
      ctx.lineTo(o.x+r,o.y+o.h); ctx.arcTo(o.x,o.y+o.h,o.x,o.y+o.h-r,r);
      ctx.lineTo(o.x,o.y+r); ctx.arcTo(o.x,o.y,o.x+r,o.y,r); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ffffff'; ctx.font = 'bold ' + (o.fontSize || 48) + 'px ' + (o.font || 'Arial Black');
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(text, o.x + o.w/2, o.y + o.h/2);
    }

    ctx.restore();
  }

  // Border (drawn last, on top of everything)
  if (tmpl.borderCfg) {
    ctx.strokeStyle = tmpl.borderCfg.color || '#ff0000';
    ctx.lineWidth = tmpl.borderCfg.thick || 20;
    ctx.strokeRect(0, 0, SIZE, SIZE);
  }

  console.log('[UnicornDS] Template rendered:', tmpl.objects.length, 'objects');
  return canvas.toDataURL('image/jpeg', 0.92);
}

// ═══════════════════════════════════════════════════════
// ITEM SPECIFICS - VIA eBay LISTING DRAFT API
// ═══════════════════════════════════════════════════════
//  approach:
// 1. Read ALL field labels from the page DOM
// 2. Ask AI for values
// 3. PUT {"attributes": {"Brand": ["Unbranded"], ...}} to listing draft API
// 4. Page re-renders with all values filled
// NO dropdown clicking. NO selector issues. NO timing problems.
// ═══════════════════════════════════════════════════════

function getCleanLabel(field) {
  // Try standard Additional fields structure
  const labelEl = field.querySelector('.summary__attributes--label');
  if (labelEl) {
    const btn = labelEl.querySelector('button');
    if (btn) return btn.textContent.trim();
    const firstSpan = labelEl.querySelector('span');
    if (firstSpan) return firstSpan.textContent.trim().split('\n')[0].trim();
    return labelEl.textContent.trim().split(/[~\n]/)[0].trim();
  }

  // Try Required fields structure - label is often a link/button or plain text before the dropdown
  const reqLabel = field.querySelector('.field-label, .se-field-label, label, [class*="label"]');
  if (reqLabel) {
    let txt = reqLabel.textContent.trim().split(/[~\n]/)[0].trim();
    // Remove search count hints like "~ 880 searches" or "Trending"
    txt = txt.replace(/~?\s*\d+\.?\d*k?\s*searches?/gi, '').replace(/Trending/gi, '').trim();
    if (txt) return txt;
  }

  // Broadest fallback: first text node or link inside the field
  const firstLink = field.querySelector('a, button');
  if (firstLink) {
    const txt = firstLink.textContent.trim();
    if (txt && txt.length < 40 && !txt.includes('Select') && !txt.includes('Choose')) return txt;
  }

  return '';
}

async function fillSpecificsViaAPI(scrapedSpecs, productData) {
  console.log('[UnicornDS] \u2550\u2550 fillSpecificsViaAPI START \u2550\u2550');

  const draftId = getDraftId();
  if (!draftId) { console.log('[UnicornDS] No draftId'); return; }

  // Step 1: GET the draft to find valid options for each field
  let attributeList = [];
  try {
    const resp = await fetch('/lstng/api/listing_draft/' + draftId + '?mode=AddItem&forceValidation=false', { credentials: 'same-origin' });
    const data = await resp.json();
    attributeList = data?.ATTRIBUTES?.attributeList || [];
    console.log('[UnicornDS] Fetched', attributeList.length, 'attribute definitions from eBay');
  } catch(e) {
    console.warn('[UnicornDS] Failed to fetch attribute list:', e.message);
  }

  if (!attributeList.length) {
    // Fallback: read field names from DOM (include Required + Additional sections)
    const fields = document.querySelectorAll(
      '.summary__attributes--field[data-testid="attribute"], .se-field, ' +
      '.smry [class*="field"], [class*="required"] [class*="field"]'
    );
    for (const field of fields) {
      const label = getCleanLabel(field);
      if (label) attributeList.push({ name: 'attributes.' + label, label: { textSpans: [{ text: label }] }, options: [] });
    }
  }

  // Step 2: Build field info with valid options for AI
  const fieldInfoForAI = [];
  const fieldMap = {}; // label → { options, customAllowed, name }

  for (const attr of attributeList) {
    const label = attr.label?.textSpans?.[0]?.text || attr.name?.replace('attributes.', '') || '';
    if (!label) continue;

    const options = (attr.options || []).map(o => o.value).filter(Boolean);
    const customAllowed = attr.customValuesAllowed !== false;

    fieldMap[label] = { options, customAllowed, name: attr.name };

    if (options.length > 0) {
      // Show AI the valid options (max 30 to save tokens)
      const optionList = options.slice(0, 30).join(', ');
      fieldInfoForAI.push(label + ' [OPTIONS: ' + optionList + ']' + (customAllowed ? ' (custom allowed)' : ' (MUST pick from options)'));
    } else {
      fieldInfoForAI.push(label + ' [FREE TEXT]');
    }
  }

  console.log('[UnicornDS] Fields with options:');
  for (const info of fieldInfoForAI) console.log('[UnicornDS]   ', info.substring(0, 100));

  // Step 3: Ask AI to generate values - now with valid options
  let aiValues = null;
  try {
    aiValues = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('timeout 45s')), 45000);
      chrome.runtime.sendMessage({
        type: 'generate_item_specifics',
        ebayFields: fieldInfoForAI,
        scrapedSpecs: scrapedSpecs || [],
        productData: productData || {},
      }, resp => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        resolve(resp?.values || null);
      });
    });
  } catch (e) { console.warn('[UnicornDS] AI specs error:', e.message); }

  if (!aiValues || Object.keys(aiValues).length === 0) {
    console.warn('[UnicornDS] No AI values');
    return;
  }

  // Clean AI keys - strip [OPTIONS: ...] suffix if AI included it
  const cleanValues = {};
  for (const [key, val] of Object.entries(aiValues)) {
    const cleanKey = key.replace(/\s*\[OPTIONS:.*$/, '').replace(/\s*\[FREE TEXT\].*$/, '').trim();
    cleanValues[cleanKey] = val;
  }
  aiValues = cleanValues;

  console.log('[UnicornDS] AI generated', Object.keys(aiValues).length, 'values');

  // Step 4: Build attributes - validate against options
  // CRITICAL: Use the attribute's API name (e.g. "attributes.Brand"), NOT the label
  // name (e.g. "Brand"). eBay's API is lenient for some standard fields but rejects
  // custom-allowed fields when keyed by label. This was the root cause of the
  // "9/18 fields don't stick" bug (C7).
  const attributes = {};
  for (const [key, val] of Object.entries(aiValues)) {
    if (!val || val === 'N/A' || val === 'Not Applicable') continue;
    const strVal = String(val);

    const fieldDef = fieldMap[key];
    const attrName = fieldDef?.name || ('attributes.' + key); // API name, e.g. "attributes.Brand"

    if (fieldDef && fieldDef.options.length > 0 && !fieldDef.customAllowed) {
      // Strict dropdown - must match an option
      const exact = fieldDef.options.find(o => o.toLowerCase() === strVal.toLowerCase());
      const partial = fieldDef.options.find(o => o.toLowerCase().includes(strVal.toLowerCase()) || strVal.toLowerCase().includes(o.toLowerCase()));
      if (exact) {
        attributes[attrName] = [exact];
      } else if (partial) {
        attributes[attrName] = [partial];
      } else {
        // Pick first option as fallback rather than skipping
        console.log('[UnicornDS] "' + strVal + '" not in options for', key, '- using first option');
        attributes[attrName] = [fieldDef.options[0]];
      }
    } else {
      // Free text — eBay has a 65 character limit on most spec values
      attributes[attrName] = [strVal.length > 65 ? strVal.substring(0, 65).trim() : strVal];
    }
  }

  // FORCE critical defaults - always set these regardless of AI
  for (const label of Object.keys(fieldMap)) {
    const fl = label.toLowerCase();
    const fd = fieldMap[label];
    const attrName = fd.name || ('attributes.' + label);

    if (fl === 'brand' && !attributes[attrName]) {
      const opt = fd.options.find(o => o.toLowerCase() === 'unbranded');
      attributes[attrName] = [opt || 'Unbranded'];
    }
    if (fl === 'mpn' && !attributes[attrName]) {
      attributes[attrName] = ['Does Not Apply'];
    }
    if (fl === 'ean' && !attributes[attrName]) {
      attributes[attrName] = ['Does not apply'];
    }
    if ((fl.includes('country') || fl.includes('region of manufacture')) && !attributes[attrName]) {
      const opt = fd.options.find(o => o.toLowerCase() === 'china');
      attributes[attrName] = [opt || 'China'];
    }
    if (fl === 'colour' || fl === 'color') {
      if (!attributes[attrName]) {
        const opt = fd.options.find(o => o.toLowerCase() === 'multicoloured') || fd.options.find(o => o.toLowerCase() === 'black');
        if (opt) attributes[attrName] = [opt];
      }
    }
    if (fl === 'department' && !attributes[attrName]) {
      const opt = fd.options.find(o => o.toLowerCase() === 'unisex') || fd.options.find(o => o.toLowerCase().includes('unisex'));
      if (opt) attributes[attrName] = [opt];
    }
  }

  console.log('[UnicornDS] Sending', Object.keys(attributes).length, 'validated attributes:');
  for (const [k, v] of Object.entries(attributes)) {
    // Final safety: truncate ALL values to 65 chars (eBay's limit)
    if (v[0] && v[0].length > 65) {
      console.log('[UnicornDS]   ⚠️ Truncated:', k, v[0].length, '→ 65 chars');
      v[0] = v[0].substring(0, 65).trim();
    }
    console.log('[UnicornDS]   ', k, '=', v[0]);
  }

  // Step 5: PUT via API (saves server-side as backup)
  const result = await updateDraftAPI({ attributes });
  if (result) console.log('[UnicornDS] ✅ Specs saved via API');

  // Step 6: Click "Apply all" first - let eBay's AI fill what it can
  await sleep(2000);
  const applyAll = Array.from(document.querySelectorAll('a, button, span')).find(el => {
    const txt = el.textContent.trim().toLowerCase();
    return txt === 'apply all' || txt === 'apply all suggested';
  });
  if (applyAll) {
    applyAll.scrollIntoView({ block: 'center' });
    await sleep(300);
    applyAll.click();
    console.log('[UnicornDS] ✅ Clicked "Apply all"');
    // Apply all triggers a full page re-render - wait for it to settle
    await sleep(1500);
  }

  // Step 7: Click any "Suggested: X" links
  const suggestedLinks = document.querySelectorAll('a, button, span');
  let sugClicked = 0;
  for (const el of suggestedLinks) {
    const txt = el.textContent.trim();
    if (txt.startsWith('Suggested:') || txt.match(/^Suggested:\s/)) {
      el.click(); sugClicked++; await sleep(300);
    }
  }
  if (sugClicked > 0) {
    console.log('[UnicornDS] ✅ Clicked', sugClicked, 'suggested values');
    await sleep(1500);
  }

  // Step 8: Now fill remaining empty fields by clicking dropdowns
  console.log('[UnicornDS] 🖱 Filling remaining empty fields...');
  await fillVisibleEmptyFields(attributes);

  // Step 9: Check for Required fields that are still empty - retry them
  await sleep(1000);
  const errorNotice = document.querySelector('[class*="inline-notice--attention"], [class*="error"]');
  if (errorNotice && errorNotice.textContent.toLowerCase().includes('required')) {
    console.log('[UnicornDS] ⚠️ Required fields still empty - retrying...');
    await sleep(500);
    await fillVisibleEmptyFields(attributes);
  }

  console.log('[UnicornDS] ══ fillSpecificsViaAPI DONE ══');
}

// Fill EAN/UPC/ISBN fields - these are standalone inputs, not part of the attributes API
async function fillProductIdentifiers() {
  const identifiers = { 'ean': 'Does not apply', 'upc': 'Does not apply', 'isbn': 'Does not apply' };

  for (const [id, value] of Object.entries(identifiers)) {
    // Method 1: Find by label text near an input
    const allLabels = document.querySelectorAll('label, .field-label, span, div');
    for (const lbl of allLabels) {
      const txt = lbl.textContent.trim().toLowerCase();
      if (txt !== id && txt !== id.toUpperCase()) continue;

      // Find the nearest input
      const parent = lbl.closest('[data-testid]') || lbl.closest('.se-field') || lbl.closest('.field') || lbl.parentElement;
      if (!parent) continue;

      const input = parent.querySelector('input[type="text"], input:not([type])');
      if (input && !input.value) {
        input.focus();
        await sleep(100);
        setInputValue(input, value);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
        input.blur();
        await sleep(200);
        console.log('[UnicornDS] ✅', id.toUpperCase(), '=', value);
        break;
      }
    }

    // Method 2: Find by placeholder text
    const inputs = document.querySelectorAll('input[placeholder*="number"], input[placeholder*="Enter"]');
    for (const input of inputs) {
      const field = input.closest('[data-testid]') || input.closest('.se-field') || input.closest('.field');
      if (!field) continue;
      const fieldText = field.textContent.toLowerCase();
      if (fieldText.includes(id) && !input.value) {
        input.focus();
        await sleep(100);
        setInputValue(input, value);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
        input.blur();
        await sleep(200);
        console.log('[UnicornDS] ✅', id.toUpperCase(), '=', value, '(by placeholder)');
        break;
      }
    }
  }
}

// Fill every visible field we have a value for - handles dropdowns, radio buttons, text inputs
async function fillVisibleEmptyFields(attributes) {
  let filled = 0;

  // Helper: React-compatible click
  function reactClick(el) {
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
    el.click();
  }

  // Helper: close any open dropdown/menu in the entire page
  function closeOpenMenus() {
    document.querySelectorAll('[aria-expanded="true"]').forEach(el => {
      try { el.click(); } catch(e) {}
    });
  }

  // Iterate by attribute (not by field) - re-query DOM fresh each time
  for (const [attrKey, valueArr] of Object.entries(attributes)) {
    const value = valueArr[0];
    if (!value) continue;
    const vl = value.toLowerCase().trim();
    // C7 fix: attrKey may be "attributes.Brand" — strip prefix for DOM label matching
    const attrLabel = attrKey.replace(/^attributes\./, '');

    // Close any leftover open menus from previous field
    closeOpenMenus();
    await sleep(200);

    // Re-query fields fresh (DOM changes after each interaction)
    // Include Required + Additional + any se-field containers
    const fields = document.querySelectorAll(
      '[data-testid="attribute"], .summary__attributes--field, .se-field, ' +
      '.smry [class*="field"], .summary [class*="field"], ' +
      '[class*="required"] [class*="field"], [class*="aspect"] [class*="field"]'
    );
    let targetField = null;

    for (const field of fields) {
      const label = getCleanLabel(field);
      if (label && label.toLowerCase() === attrLabel.toLowerCase()) {
        targetField = field;
        break;
      }
    }

    if (!targetField) {
      // Broader search: check if any field's text contains our label name
      for (const field of fields) {
        const allText = field.textContent || '';
        // Match label at start of field text (avoid matching inside dropdown options)
        const cleanText = allText.split('\n')[0].trim().toLowerCase();
        if (cleanText.includes(attrLabel.toLowerCase()) && cleanText.length < 100) {
          targetField = field;
          break;
        }
      }
    }

    if (!targetField) continue; // Field not visible on page - API saved it anyway

    targetField.scrollIntoView({ block: 'center' });
    await sleep(200);

    try {
      // ── RADIO BUTTONS ──
      const radios = targetField.querySelectorAll('input[type="radio"], [role="radio"]');
      if (radios.length > 0) {
        let picked = false;
        for (const radio of radios) {
          const rl = (radio.closest('label') || radio.parentElement)?.textContent?.trim().toLowerCase() || '';
          const rv = (radio.value || '').toLowerCase();
          if (rl === vl || rv === vl || rl.includes(vl) || vl.includes(rl)) {
            reactClick(radio);
            picked = true;
            break;
          }
        }
        if (picked) { console.log('[UnicornDS]   \u2705', attrLabel, '=', value, '(radio)'); filled++; }
        else { console.log('[UnicornDS]   \u26a0\ufe0f', attrLabel, '\u2014 no matching radio for:', value); }
        continue;
      }

      // ── CHECKBOXES (multi-select) ──
      const checkboxes = targetField.querySelectorAll('input[type="checkbox"]');
      if (checkboxes.length > 1) {
        for (const cb of checkboxes) {
          const cl = (cb.closest('label') || cb.parentElement)?.textContent?.trim().toLowerCase() || '';
          if (cl === vl || cl.includes(vl) || vl.includes(cl)) {
            if (!cb.checked) reactClick(cb);
            console.log('[UnicornDS]   \u2705', attrLabel, '=', value, '(checkbox)'); filled++;
            break;
          }
        }
        continue;
      }

      // ── TEXT INPUT (no dropdown button nearby) ──
      const hasDropdown = targetField.querySelector('.fake-menu-button__button, button[aria-haspopup], [role="combobox"]');
      if (!hasDropdown) {
        const textInput = targetField.querySelector('input[type="text"], input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), .textbox__control');
        if (textInput) {
          if (textInput.value && textInput.value.trim()) {
            console.log('[UnicornDS]   \u23ed', attrLabel, '\u2014 text already has:', textInput.value.trim());
            continue;
          }
          textInput.focus();
          await sleep(100);
          setInputValue(textInput, value);
          textInput.dispatchEvent(new Event('input', { bubbles: true }));
          textInput.dispatchEvent(new Event('change', { bubbles: true }));
          textInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
          textInput.blur();
          await sleep(300);
          console.log('[UnicornDS]   \u2705', attrLabel, '=', value, '(text)');
          filled++;
          continue;
        }
      }

      // ── DROPDOWN / COMBOBOX -  approach: input+value+Enter ──
      // NO getBoundingClientRect (returns 0 in background tabs)
      // NO dropdown clicking - just type value and press Enter
      const input = targetField.querySelector(
        'input[type="text"], input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), ' +
        '.textbox__control, [role="combobox"] input'
      );

      if (input) {
        const curVal = (input.value || '').trim().toLowerCase();
        if (curVal && curVal !== 'select' && curVal !== 'choose') {
          console.log('[UnicornDS]   ⏭', attrLabel, '- already has:', input.value.trim());
          continue;
        }
        input.focus();
        await sleep(100);
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (nativeSetter) nativeSetter.call(input, value); else input.value = value;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        await sleep(150);
        input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
        await sleep(100);
        input.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(200);
        input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Escape', keyCode: 27 }));
        await sleep(300);

        // VERIFY: did the value actually stick? If not, fall through to dropdown click
        const afterVal = (input.value || '').trim();
        if (afterVal && afterVal.toLowerCase() !== 'select' && afterVal.toLowerCase() !== 'choose' && afterVal.length > 0) {
          console.log('[UnicornDS]   ✅', attrLabel, '=', value, '(input+enter)');
          filled++;
          continue;
        }
        // Value didn't stick - try dropdown click below
        console.log('[UnicornDS]   ⚠️', attrLabel, '- input+enter didn\'t stick, trying dropdown click...');
      }

      // Fallback: dropdown clicking - tab is active so getBoundingClientRect works
      const comboBtn = targetField.querySelector(
        '.fake-menu-button__button, button[aria-haspopup], [role="combobox"], ' +
        'button:not([aria-label="Close"])'
      );
      if (comboBtn) {
        reactClick(comboBtn);
        await sleep(500);

        // Try to type in search filter if available
        let searchInput = targetField.querySelector('.textbox__control, input[type="text"]') ||
                          document.querySelector('.listbox-button__input') ||
                          (document.activeElement?.tagName === 'INPUT' ? document.activeElement : null);
        if (searchInput) {
          searchInput.focus();
          setInputValue(searchInput, value);
          searchInput.dispatchEvent(new Event('input', { bubbles: true }));
          await sleep(400);
        }

        // Find visible menu items — C7 fix: don't use getBoundingClientRect
        // (returns 0 in background tabs during Bulk Listing). Use offsetParent
        // and getComputedStyle instead, which work reliably in both foreground
        // and background tabs.
        const allItems = document.querySelectorAll(
          '[role="option"], [role="menuitemradio"], .menu__item, .listbox__option'
        );
        const visible = Array.from(allItems).filter(el => {
          // offsetParent is null if element or ancestor is display:none
          // Also check that it has some computed dimensions
          if (!el.offsetParent && el.offsetParent !== document.body) {
            // Special case: offsetParent is null for position:fixed elements too,
            // so also check computed display
            const style = getComputedStyle(el);
            return style.display !== 'none' && style.visibility !== 'hidden';
          }
          return true;
        });

        let clicked = false;
        // Exact match
        for (const item of visible) {
          const t = (item.querySelector('span')?.textContent || item.textContent || '').trim().toLowerCase();
          if (t === vl) { reactClick(item); clicked = true; break; }
        }
        // Partial match
        if (!clicked) {
          for (const item of visible) {
            const t = (item.querySelector('span')?.textContent || item.textContent || '').trim().toLowerCase();
            if (t && vl && (t.includes(vl) || vl.includes(t))) { reactClick(item); clicked = true; break; }
          }
        }
        // Enter key if search input typed
        if (!clicked && searchInput) {
          searchInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
          await sleep(300);
          clicked = true;
        }

        await sleep(250);
        // Close any open menus
        document.querySelectorAll('[aria-expanded="true"]').forEach(el => { try { el.click(); } catch(e) {} });
        await sleep(300);

        if (clicked) {
          console.log('[UnicornDS]   ✅', attrLabel, '=', value, '(dropdown)');
          filled++;
        } else {
          // Fallback: force-type the value into the input field
          const fallbackInput = targetField.querySelector('input[type="text"], .textbox__control');
          if (fallbackInput) {
            const ns = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
            if (ns) ns.call(fallbackInput, value); else fallbackInput.value = value;
            fallbackInput.dispatchEvent(new Event('input', { bubbles: true }));
            fallbackInput.dispatchEvent(new Event('change', { bubbles: true }));
            fallbackInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
            await sleep(300);
            console.log('[UnicornDS]   ✅', attrLabel, '=', value, '(typed fallback)');
            filled++;
          } else {
            console.log('[UnicornDS]   ⚠️', attrLabel, '- no match in dropdown, no input to type into');
          }
        }
        continue;
      }

      // Last resort: type "Does Not Apply" if field has an input
      const lastResortInput = targetField.querySelector('input[type="text"], .textbox__control');
      if (lastResortInput && (!lastResortInput.value || lastResortInput.value.trim() === '')) {
        const ns = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (ns) ns.call(lastResortInput, value); else lastResortInput.value = value;
        lastResortInput.dispatchEvent(new Event('input', { bubbles: true }));
        lastResortInput.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(200);
        console.log('[UnicornDS]   ✅', attrLabel, '=', value, '(last resort typed)');
        filled++;
      } else {
        console.log('[UnicornDS]   ⏭', attrLabel, '- no input or dropdown found');
      }

    } catch (err) {
      console.warn('[UnicornDS]   \u274c', attrLabel, ':', err.message);
      closeOpenMenus();
    }
  }

  console.log('[UnicornDS] \ud83d\uddb1 Filled', filled, 'of', Object.keys(attributes).length, 'fields');
}

} // end guard
