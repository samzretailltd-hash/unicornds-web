/**
 * UnicornDS — Device Fingerprint Collector (content script)
 *
 * Runs in a REAL web page (not the background service worker), so it has
 * genuine access to screen size, canvas and WebGL. The background worker's
 * OffscreenCanvas + self.screen returned 0x0 / empty, which made every user
 * on the same OS+timezone look identical. This collects a proper, stable
 * per-device signature and hands it to the background on request.
 *
 * It sends NOTHING by itself — the background asks for it via a message,
 * once per session, and forwards it to the server.
 */
(function () {
  "use strict";

  function safeCanvasHash() {
    try {
      const canvas = document.createElement("canvas");
      canvas.width = 240;
      canvas.height = 60;
      const ctx = canvas.getContext("2d");
      if (!ctx) return "";
      ctx.textBaseline = "top";
      ctx.font = "16px 'Arial'";
      ctx.fillStyle = "#f60";
      ctx.fillRect(125, 1, 62, 20);
      ctx.fillStyle = "#069";
      ctx.fillText("UnicornDS:fp:\u2764", 2, 15);
      ctx.fillStyle = "rgba(102,204,0,0.7)";
      ctx.fillText("UnicornDS:fp:\u2764", 4, 17);
      const data = canvas.toDataURL();
      let hash = 0;
      for (let i = 0; i < data.length; i++) {
        hash = ((hash << 5) - hash) + data.charCodeAt(i);
        hash = hash & hash; // 32-bit
      }
      return Math.abs(hash).toString(36);
    } catch (e) {
      return "";
    }
  }

  function safeWebglRenderer() {
    try {
      const canvas = document.createElement("canvas");
      const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
      if (!gl) return "";
      const dbg = gl.getExtension("WEBGL_debug_renderer_info");
      if (!dbg) return "";
      return gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || "";
    } catch (e) {
      return "";
    }
  }

  function collect() {
    // Real screen values from the page context (NOT 0x0 like the worker).
    const sw = (window.screen && window.screen.width) || 0;
    const sh = (window.screen && window.screen.height) || 0;
    const avail = (window.screen && window.screen.availWidth && window.screen.availHeight)
      ? `${window.screen.availWidth}x${window.screen.availHeight}` : "";
    const depth = (window.screen && window.screen.colorDepth) || 0;

    return {
      screenWidth: sw,
      screenHeight: sh,
      availScreen: avail,
      colorDepth: depth,
      pixelRatio: window.devicePixelRatio || 1,
      timezone: (Intl.DateTimeFormat().resolvedOptions().timeZone) || "",
      language: navigator.language || "",
      languages: (navigator.languages || []).join(",") || "",
      platform: (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || "",
      cores: navigator.hardwareConcurrency || 0,
      memory: navigator.deviceMemory || 0,
      userAgent: navigator.userAgent || "",
      touchPoints: navigator.maxTouchPoints || 0,
      canvasHash: safeCanvasHash(),
      webglRenderer: safeWebglRenderer(),
    };
  }

  // Cache once per page load.
  let cached = null;
  function getFingerprint() {
    if (!cached) cached = collect();
    return cached;
  }

  // Respond to the background's request for a fingerprint.
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "uds_get_device_fingerprint") {
      try {
        sendResponse({ ok: true, fingerprint: getFingerprint() });
      } catch (e) {
        sendResponse({ ok: false });
      }
      return true; // async-safe
    }
  });

  // Also push it proactively once, shortly after load, so the background has
  // it even if it never asks (belt and braces). Fire-and-forget.
  setTimeout(() => {
    try {
      chrome.runtime.sendMessage({ type: "uds_device_fingerprint_data", fingerprint: getFingerprint() }, () => void chrome.runtime.lastError);
    } catch (e) { /* background may be asleep — that's fine */ }
  }, 2500);
})();
