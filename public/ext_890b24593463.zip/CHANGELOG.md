# UnicornDS — Changelog

All notable changes to the UnicornDS Chrome extension are documented here.

## v7.21.0 — 21 June 2026

### ✨ New
- **Walmart product variations** — size, colour and style options now import automatically, each with its own price and image (multi-variant eBay listings instead of a single variant).
- **Walmart strict mode** — only list products **sold *and shipped* by Walmart.com**. Third-party marketplace sellers (including "Fulfilled by Walmart" / WFS) are detected and blocked, so you avoid unreliable stock, price swings and nested dropshippers. Third-party items are skipped in the product hunter too.
- **Multi-currency support** — correct symbols and decimals for €, $, CHF and C$. Fixes European comma prices (e.g. `€1,43` was being read as `143`).
- **Native-language listings** — titles and descriptions are written in the marketplace's language automatically (German for .de, French for .fr, and so on), based on the eBay market you sell on.

### 🛠 Order Manager fixes
- **Delivered orders now show correctly** — they were getting stuck on "pending" because the status check read dispatch text before delivery. Delivered is now detected first, and re-syncing promotes existing orders to **Completed** when eBay marks them delivered.
- **All your orders import reliably** — orders are now saved progressively during a sync, so a slow or interrupted sync no longer loses everything. Rows that were previously dropped are now kept.
- **More accurate earnings** — the per-order earnings limit was raised (30 → 60 per sync, orders missing earnings fetched first), and the amount parser was fixed so totals over £1,000 are read correctly (e.g. `£1,234.56` is no longer read as `£1.23`).

### ⚙️ Under the hood
- Added eBay fee rates for Austria, Belgium, Ireland and Switzerland (AT, BE, IE, CH).
- Security and stability hardening; quieter console output in production.

---

## v7.20.0 — Previous release
- Walmart support (beta), order count badge on the popup, and earlier improvements.
