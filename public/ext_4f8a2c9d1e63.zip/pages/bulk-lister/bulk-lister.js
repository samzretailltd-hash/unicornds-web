/**
 * Unicorn DS - Bulk Lister v4
 * - Listing ID matching: done signals matched to correct queue items
 * - Retry failed items
 * - Real-time step display via chrome.storage.onChanged
 * - Proper sequential flow: waits for each listing to truly complete
 */

const $ = id => document.getElementById(id);

let queue = [];
let isRunning = false;
let isPaused = false;
let isStopped = false;
let successCount = 0;
let failedCount = 0;
let skippedCount = 0;
let startTime = null;
let timerInterval = null;
let activeFilter = 'all';
let currentListingId = null;
let listingDoneResolver = null;
// P0-5: Concurrent listing tracking
let activeListings = new Map(); // listingId → { resolver, item }
let bulkConcurrency = 1;        // fetched from tier limits on startup
let listedSkus = []; // Already-listed SKUs for duplicate detection
let veroBrands = []; // VERO brand list

// Load VERO brands
(async function loadVeroList() {
  try {
    const resp = await fetch(chrome.runtime.getURL('data/VeroList.txt'));
    const text = await resp.text();
    veroBrands = text.replace(/\r/g, '').split('\n').map(b => b.trim().toLowerCase()).filter(Boolean);
    console.log('[UnicornDS] Bulk Lister: loaded', veroBrands.length, 'VERO brands');
  } catch (e) { console.warn('[UnicornDS] VERO list load error:', e); }
})();

function checkVero(title) {
  if (!veroBrands.length || !title) return false;
  const lower = title.toLowerCase().replace(/[-–—]/g, ' ').replace(/\s+/g, ' ');
  
  // Accessory signals — "for GoPro", "mount for", "case compatible" etc.
  const accessoryWords = [
    'for', 'fits', 'compatible', 'works with', 'suitable for',
    'mount', 'case', 'cover', 'strap', 'band', 'holder', 'stand', 'bracket',
    'bag', 'pouch', 'sleeve', 'protector', 'guard', 'bumper',
    'cable', 'charger', 'adapter', 'dock', 'cradle',
    'replacement', 'aftermarket', 'generic', 'third party',
    'screen protector', 'tempered glass', 'tripod', 'selfie stick',
    'filter', 'lens', 'cap', 'remote',
  ];
  const isAccessory = accessoryWords.some(w => lower.includes(w));

  return veroBrands.some(brand => {
    if (brand.includes(' ')) {
      if (!lower.includes(brand)) return false;
    } else {
      const words = lower.split(/\s+/);
      if (!words.some(w => w === brand)) return false;
    }
    // Brand matched — but skip if it's an accessory
    if (isAccessory) return false;
    return true;
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Load saved links (but reset position to 0 - fresh start)
  chrome.storage.local.get(['bulk_links', 'bulk_lister_urls', 'unicornds_listed_skus'], s => {
    if (s.bulk_links) $('linksInput').value = s.bulk_links;
    // Pick up URLs from Competitor Scanner
    if (s.bulk_lister_urls && s.bulk_lister_urls.length) {
      const existing = $('linksInput').value.trim();
      const newUrls = s.bulk_lister_urls.join('\n');
      $('linksInput').value = existing ? existing + '\n' + newUrls : newUrls;
      chrome.storage.local.remove('bulk_lister_urls');
      console.log('[UnicornDS] Bulk Lister: loaded', s.bulk_lister_urls.length, 'URLs from Competitor Scanner');
    }
    listedSkus = s.unicornds_listed_skus || [];
    $('positionInput').value = 0;
    updateLinkCount();
  });

  $('startBtn').addEventListener('click', startListing);
  $('pauseBtn').addEventListener('click', () => { isPaused = true; $('pauseBtn').disabled = true; $('resumeBtn').disabled = false; log('⏸ Paused', 'info'); });
  $('resumeBtn').addEventListener('click', () => { isPaused = false; $('pauseBtn').disabled = false; $('resumeBtn').disabled = true; log('▶ Resumed', 'info'); });
  $('clearBtn').addEventListener('click', () => { $('linksInput').value = ''; chrome.storage.local.remove('bulk_links'); updateLinkCount(); });
  $('resetBtn').addEventListener('click', resetAll);
  $('linksInput').addEventListener('input', updateLinkCount);

  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.dataset.filter;
      renderQueue();
    });
  });

  // EVENT DELEGATION for queue buttons (no inline onclick - MV3 CSP)
  $('queueContainer').addEventListener('click', (e) => {
    const retryBtn = e.target.closest('.q-retry');
    if (retryBtn) { retryItem(parseInt(retryBtn.dataset.idx)); return; }
    const skipBtn = e.target.closest('.q-skip');
    if (skipBtn) { skipItem(parseInt(skipBtn.dataset.idx)); return; }
  });

  // LISTEN FOR PROGRESS VIA CHROME.STORAGE - bulletproof cross-context
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;

    // CAPTCHA detection — show alert banner
    if (changes.unicornds_captcha_detected) {
      const detected = changes.unicornds_captcha_detected.newValue;
      let banner = document.getElementById('captchaBanner');
      if (detected) {
        if (!banner) {
          banner = document.createElement('div');
          banner.id = 'captchaBanner';
          banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;background:linear-gradient(135deg,#F59E0B,#D97706);color:#1a1a2e;padding:14px 20px;text-align:center;font-weight:800;font-size:14px;box-shadow:0 4px 12px rgba(0,0,0,0.3);animation:pulse 1.5s infinite;';
          banner.innerHTML = '⚠️ CAPTCHA DETECTED — Please solve the CAPTCHA in the AliExpress tab, then bulk listing will continue automatically.';
          const style = document.createElement('style');
          style.textContent = '@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.8; } }';
          document.head.appendChild(style);
          document.body.appendChild(banner);
        }
        log('⚠️ CAPTCHA detected on AliExpress! Please solve it manually.', 'warning');
      } else if (banner) {
        banner.remove();
        log('✅ CAPTCHA solved — continuing...', 'info');
      }
    }

    if (changes.unicornds_bulk_progress) {
      const data = changes.unicornds_bulk_progress.newValue;
      // P0-5: check against all active listings, not just one
      if (data && (data.listing_id === currentListingId || activeListings.has(data.listing_id))) {
        updateActiveItemStep(data.step, data.detail);
      }
    }

    if (changes.unicornds_bulk_done) {
      const data = changes.unicornds_bulk_done.newValue;
      // P0-5: resolve the correct listing's promise from the Map
      if (data && data.listing_id) {
        // Legacy single-listing path (backward compat)
        if (data.listing_id === currentListingId && listingDoneResolver) {
          listingDoneResolver(data);
          listingDoneResolver = null;
        }
        // Concurrent path
        const entry = activeListings.get(data.listing_id);
        if (entry?.resolver) {
          entry.resolver(data);
          activeListings.delete(data.listing_id);
        }
      }
    }
  });

  // Speed selector — DOM-based listing maxes out at 2 concurrent
  // (Chrome throttles inactive tabs, so 3+ just creates chaos)
  chrome.runtime.sendMessage({ type: 'get_tier_limits' }, (r) => {
    bulkConcurrency = 1;
    console.log(`[UnicornDS] Bulk Lister: tier=${r?.tier || 'unknown'}, speed=1 (default)`);

    document.querySelectorAll('.speed-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.speed-btn').forEach(b => {
          b.classList.remove('active');
          b.style.background = '#0d1b3e';
          b.style.borderColor = '#555';
        });
        btn.classList.add('active');
        btn.style.background = '#7C3AED';
        btn.style.borderColor = '#7C3AED';
        bulkConcurrency = parseInt(btn.dataset.speed);
        chrome.storage.local.set({ bulk_user_speed: bulkConcurrency });
        console.log(`[UnicornDS] Bulk Lister: speed set to ${bulkConcurrency}`);
      });
    });

    // Restore saved preference (cap at 2)
    chrome.storage.local.get('bulk_user_speed', (s) => {
      const saved = Math.min(s.bulk_user_speed || 1, 2);
      bulkConcurrency = saved;
      document.querySelectorAll('.speed-btn').forEach(b => {
        const sp = parseInt(b.dataset.speed);
        b.classList.remove('active');
        b.style.background = '#0d1b3e';
        b.style.borderColor = '#555';
        if (sp === saved) {
          b.classList.add('active');
          b.style.background = '#7C3AED';
          b.style.borderColor = '#7C3AED';
        }
      });
    });
  });

  updateLinkCount();
  updateStats();
});

function updateLinkCount() {
  const text = $('linksInput').value.trim();
  const count = text ? text.split('\n').filter(l => {
    const t = l.trim();
    return t && (t.includes('amazon') || t.includes('aliexpress') || t.includes('/dp/') || t.includes('/item/'));
  }).length : 0;
  $('totalLinks').textContent = count;
}

function parseLinks() {
  const text = $('linksInput').value.trim();
  if (!text) return [];
  return text.split('\n').map(l => l.trim())
    .filter(l => l && (l.includes('amazon') || l.includes('aliexpress') || l.includes('/dp/') || l.includes('/item/')))
    .map((url, idx) => {
      if (!url.startsWith('http')) url = 'https://' + url;
      // Clean up URL - remove tracking params
      try { const u = new URL(url); url = u.origin + u.pathname; } catch(e) {}
      let source = 'unknown', sku = '';
      if (url.includes('amazon')) { source = 'amazon'; const m = url.match(/\/dp\/([A-Z0-9]{10})/i); if (m) sku = m[1]; }
      else if (url.includes('aliexpress')) {
        source = 'aliexpress';
        // Match: /item/1234567890.html OR /item/1234567890 (no .html)
        const m = url.match(/item\/(\d+)/);
        if (m) sku = m[1];
        // Ensure URL ends with .html for eBay scraper
        if (sku && !url.includes('.html')) url = url.replace(/\/$/, '') + '.html';
      }
      return { idx, url, source, sku, status: 'pending', step: '', title: '', price: null, error: '' };
    });
}

async function startListing() {
  const parsed = parseLinks();
  if (!parsed.length) { alert('No valid Amazon or AliExpress links found.'); return; }
  const startPos = parseInt($('positionInput').value) || 0;
  queue = parsed.slice(startPos);

  // Fix 4: Check already-listed SKUs - mark duplicates before starting
  let dupCount = 0;
  for (const item of queue) {
    if (item.sku && listedSkus.includes(item.sku)) {
      item.status = 'skipped'; item.step = '📋 Already listed (SKU: ' + item.sku + ')';
      dupCount++;
    }
  }
  if (dupCount > 0) log('📋 ' + dupCount + ' item(s) already listed - skipped', 'warning');

  successCount = 0; failedCount = 0; skippedCount = dupCount;
  isRunning = true; isPaused = false; isStopped = false;
  chrome.storage.local.set({ bulk_links: $('linksInput').value, bulk_position: startPos });
  setRunningUI(true); startTimer(); renderQueue();
  log('🚀 Starting: ' + queue.length + ' items (' + (queue.length - dupCount) + ' to process, ' + bulkConcurrency + ' concurrent)', 'info');

  const minPrice = parseFloat($('minPrice').value) || 0;
  const maxPrice = parseFloat($('maxPrice').value) || 9999;
  const maxListings = parseInt($('maxListings').value) || 0;
  const delaySec = parseInt($('delaySeconds').value) || 3;

  // P0-5: Worker pool — runs `bulkConcurrency` items in parallel.
  // Each worker pulls the next pending item from the queue atomically.
  let nextIdx = 0;  // shared index into queue
  const getNextItem = () => {
    while (nextIdx < queue.length) {
      const item = queue[nextIdx];
      nextIdx++;
      if (item.status === 'skipped') continue;
      if (maxListings > 0 && successCount >= maxListings) return null;
      return item;
    }
    return null;
  };

  const worker = async (workerId) => {
    while (isRunning && !isStopped) {
      while (isPaused && isRunning && !isStopped) await sleep(500);
      if (!isRunning || isStopped) break;

      const item = getNextItem();
      if (!item) break;

      await processItem(item, workerId, minPrice, maxPrice);
      renderQueue(); updateStats();

      if (item.status === 'success') {
        removeListedUrlFromTextarea(item.url);
      }

      chrome.storage.local.set({ bulk_position: startPos + nextIdx });

      if (isRunning && !isStopped) {
        await sleep(delaySec * 1000);
      }
    }
  };

  const workerCount = Math.max(1, Math.min(bulkConcurrency, queue.length - dupCount));
  console.log(`[UnicornDS] Bulk Lister: launching ${workerCount} workers`);
  const workers = [];
  for (let w = 1; w <= workerCount; w++) {
    workers.push(worker(w));
  }
  await Promise.all(workers);

  stopListing();
  if (isStopped) {
    const doneCount = successCount + failedCount + skippedCount;
    log('⛔ Stopped at position ' + doneCount + '/' + queue.length + '. Resume from position ' + doneCount, 'warning');
  } else {
    log('🏁 Done! ✅ ' + successCount + ' listed, ❌ ' + failedCount + ' failed, ⏭ ' + skippedCount + ' skipped', 'info');
  }
}

// P0-5: Sequential runThreadPool removed — replaced by worker pool in startListing()

async function processItem(item, tid, minPrice, maxPrice) {
  item.status = 'active'; item.step = '🔍 Scraping...'; item.error = '';
  renderQueue(); updateStats();
  log('🧵' + tid + ' [' + (item.idx + 1) + '/' + queue.length + '] ' + item.url.substring(0, 55), 'info');

  try {
    // SCRAPE — with auto-retry (up to 2 attempts)
    let scrapeResult = null;
    for (let attempt = 1; attempt <= 2; attempt++) {
      item.step = attempt === 1 ? '🔍 Scraping...' : '🔄 Retry scraping...';
      renderQueue();
      
      try {
        scrapeResult = await sendMessage({ type: 'bulk_scrape_product', url: item.url, source: item.source, sku: item.sku });
      } catch (e) {
        console.warn('[UnicornDS] Bulk scrape attempt', attempt, 'error:', e.message);
        scrapeResult = null;
      }
      
      if (scrapeResult?.product) break;
      
      if (attempt < 2) {
        log('🧵' + tid + '   ⚠️ Scrape failed, retrying in 5s...', 'warning');
        await sleep(5000);
      }
    }
    
    if (!scrapeResult?.product) { setFailed(item, 'Scrape failed after 2 attempts — page may not have loaded'); return; }

    const product = scrapeResult.product;
    item.title = (product.custom_title || product.title || '').substring(0, 60);
    item.price = product.price;
    item.step = '✅ Scraped';
    renderQueue();
    log('🧵' + tid + '   📋 "' + item.title + '" - £' + item.price, 'info');

    // COMPLIANCE CHECK - warn or block risky products
    if (product._compliance) {
      const c = product._compliance;
      if (!c.safe && c.blocks.length > 0) {
        item.status = 'skipped';
        item.step = '🚫 ' + c.blocks[0].message.substring(0, 60);
        item.error = c.blocks[0].message;
        skippedCount++;
        log('🧵' + tid + '   🚫 BLOCKED: ' + c.blocks[0].message, 'error');
        return;
      }
      if (c.warnings.length > 0) {
        c.warnings.forEach(w => log('🧵' + tid + '   ' + w.message, 'warning'));
      }
    }

    if (product.price < minPrice || product.price > maxPrice) {
      item.status = 'skipped'; item.step = '⏭ Price filtered'; skippedCount++; return;
    }

    // STOCK GATE — skip out-of-stock / low-stock (and optionally non-Amazon sellers).
    // Safe defaults: minStock=3, amazonOnly OFF — behaviour unchanged unless you set these.
    try {
      const _sc = await new Promise(r => chrome.storage.local.get(['unicornds_min_stock','unicornds_amazon_seller_only'], s => r(s || {})));
      const minStock = (_sc.unicornds_min_stock != null) ? parseInt(_sc.unicornds_min_stock) : 3;
      const amazonOnly = !!_sc.unicornds_amazon_seller_only;
      // Walmart: JSON availability gate (out of stock / uncertain)
      if (product.source === 'walmart') {
        if (product.inStock === false && !product.qtyUnknown) {
          item.status = 'skipped'; item.step = '📦 Out of stock — skipped'; skippedCount++;
          log('🧵' + tid + '   📦 SKIP (Walmart out of stock): ' + item.title, 'skip'); return;
        }
        if (amazonOnly && product.soldByWalmart === false) {
          item.status = 'skipped'; item.step = '🏷 Not sold by Walmart — skipped'; skippedCount++;
          log('🧵' + tid + '   🏷 SKIP (3rd-party Walmart seller): ' + item.title, 'skip'); return;
        }
      }
      if (product.source === 'amazon') {
        if (product.inStock === false) {
          item.status = 'skipped'; item.step = '📦 Out of stock — skipped'; skippedCount++;
          log('🧵' + tid + '   📦 SKIP (out of stock): ' + item.title, 'skip'); return;
        }
        if (typeof product.quantity === 'number' && product.quantity > 0 && product.quantity < minStock) {
          item.status = 'skipped'; item.step = '📦 Low stock (' + product.quantity + ') — skipped'; skippedCount++;
          log('🧵' + tid + '   📦 SKIP (low stock ' + product.quantity + '): ' + item.title, 'skip'); return;
        }
        if (amazonOnly && product.soldByAmazon === false) {
          item.status = 'skipped'; item.step = '🏷 Not sold by Amazon — skipped'; skippedCount++;
          log('🧵' + tid + '   🏷 SKIP (3rd-party seller): ' + item.title, 'skip'); return;
        }
      }
    } catch (e) { console.warn('[UnicornDS] Stock gate error:', e.message); }

    // VERO CHECK — critical safety gate before listing
    // BUT skip accessories (e.g. "Mount for GoPro Hero" is NOT a VERO violation)
    try {
      const vBrands = await new Promise(r => chrome.storage.local.get('unicornds_vero_brands', s => r(s.unicornds_vero_brands || [])));
      if (vBrands.length) {
        const tLower = (product.custom_title || product.title || '').toLowerCase().replace(/[-–—]/g, ' ');
        const bLower = (product.brand || '').toLowerCase().replace(/[-–—]/g, ' ');
        const combined = tLower + ' ' + bLower;
        
        // Accessory signals
        const accWords = ['for', 'fits', 'compatible', 'works with', 'mount', 'case', 'cover', 'strap',
          'band', 'holder', 'stand', 'bracket', 'bag', 'pouch', 'sleeve', 'protector', 'guard',
          'cable', 'charger', 'adapter', 'replacement', 'aftermarket', 'generic', 'third party',
          'screen protector', 'tempered glass', 'tripod', 'selfie stick', 'filter', 'lens', 'cap', 'remote'];
        const isAccessory = accWords.some(w => tLower.includes(w));
        
        const isVero = vBrands.some(v => {
          const vl = v.replace(/[-–—]/g, ' ');
          let matched = false;
          if (vl.includes(' ')) { matched = combined.includes(vl); }
          else {
            const escaped = vl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const re = new RegExp('\\b' + escaped + '\\b');
            matched = re.test(combined);
          }
          if (matched && isAccessory) return false; // accessory, not counterfeit
          return matched;
        });
        if (isVero) {
          item.status = 'skipped';
          item.step = '⛔ VERO brand — skipped';
          item.error = 'VERO brand detected in: ' + (product.brand || item.title);
          skippedCount++;
          log('🧵' + tid + '   ⛔ VERO BLOCKED: "' + (product.brand || item.title).substring(0, 50) + '"', 'error');
          return;
        }
      }
    } catch(e) { console.warn('[UnicornDS] Bulk VERO check error:', e.message); }

    // LIST ON EBAY
    item.step = '🛒 Opening eBay...'; renderQueue();

    // Unique listing ID - used to match progress/done signals
    const listingId = 'L' + Date.now() + '_' + item.idx + '_' + tid;
    currentListingId = listingId;  // backward compat for storage listener
    product._listing_id = listingId;

    // Clear stale values (only safe for single-thread; concurrent workers
    // share these keys, so each worker's signals may overlap — the
    // listing_id matching in the storage listener handles disambiguation)
    if (activeListings.size === 0) {
      chrome.storage.local.remove(['unicornds_bulk_progress', 'unicornds_bulk_done']);
    }
    await sleep(300);

    // Set up done listener BEFORE sending — P0-5: use Map for concurrent tracking
    // No artificial timeout — background.js heartbeat watcher handles timing.
    // This is just a safety net matching the watcher's 8 min absolute max.
    const timeoutMs = 8 * 60 * 1000; // 8 min safety net (MSKU=5min + 3min buffer)
    const donePromise = new Promise((resolve) => {
      listingDoneResolver = resolve;  // backward compat
      activeListings.set(listingId, { resolver: resolve, item });
      setTimeout(() => {
        if (activeListings.has(listingId)) {
          activeListings.delete(listingId);
          resolve({ success: false, error: 'Timeout (8 min) — skipped to next item' });
        }
      }, timeoutMs);
    });

    log('🧵' + tid + '   🛒 Opening eBay listing form...', 'info');
    const listResult = await sendMessage({ type: 'list_to_ebay', product_data: product });
    if (!listResult?.success) { setFailed(item, listResult?.error || 'Failed to open eBay'); activeListings.delete(listingId); currentListingId = null; return; }

    // WAIT FOR LISTING TO COMPLETE
    item.step = '⏳ Filling form...'; renderQueue();
    const done = await donePromise;
    activeListings.delete(listingId);
    currentListingId = null;

    if (done.success) {
      item.status = 'success'; item.step = '✅ Listed!'; successCount++;
      if (item.sku) listedSkus.push(item.sku); // Track for duplicate detection
      // Save for Order Manager matching
      if (done.ebayItemNumber || item.sku) {
        chrome.storage.local.get('unicornds_listed_products', (data) => {
          const listed = data.unicornds_listed_products || {};
          listed[done.ebayItemNumber || item.sku] = {
            sourceUrl: item.url,
            sourceCost: item.price || 0,
            title: item.title,
            listedAt: Date.now(),
          };
          chrome.storage.local.set({ unicornds_listed_products: listed });
        });
      }
      log('🧵' + tid + '   ✅ Listed: "' + item.title + '"', 'success');
    } else {
      setFailed(item, done.error || 'Listing failed');
      log('🧵' + tid + '   ❌ ' + (done.error || 'Failed'), 'error');
    }
  } catch (e) {
    setFailed(item, e.message);
    log('🧵' + tid + '   ❌ ' + e.message, 'error');
  }
}

function setFailed(item, error) {
  item.status = 'error'; item.error = error; item.step = '❌ ' + error; failedCount++;
}

// RETRY a failed item
async function retryItem(idx) {
  const item = queue[idx];
  if (!item || item.status !== 'error') return;
  failedCount = Math.max(0, failedCount - 1);
  item.status = 'active'; item.step = '🔄 Retrying...'; item.error = '';
  renderQueue(); updateStats();
  log('🔄 Retrying item ' + (idx + 1) + ': ' + (item.title || item.url.substring(0, 50)), 'info');
  const minPrice = parseFloat($('minPrice').value) || 0;
  const maxPrice = parseFloat($('maxPrice').value) || 9999;
  await processItem(item, 'R', minPrice, maxPrice);
  renderQueue(); updateStats();
}

// SKIP a pending item
function skipItem(idx) {
  const item = queue[idx];
  if (!item || (item.status !== 'pending' && item.status !== 'error')) return;
  if (item.status === 'error') failedCount = Math.max(0, failedCount - 1);
  item.status = 'skipped'; item.step = '⏭ Manually skipped'; skippedCount++;
  renderQueue(); updateStats();
  log('⏭ Skipped item ' + (idx + 1) + ': ' + (item.title || item.url.substring(0, 50)), 'skip');
}

function updateActiveItemStep(step, detail) {
  const active = queue.find(q => q.status === 'active');
  if (!active) return;
  const labels = {
    'starting': '⏳ Opening form...', 'title': '📝 Title: ' + (detail || '').substring(0, 40),
    'images': '🖼 Uploading images...', 'description': '📄 Injecting description...',
    'specs': '🔧 Filling specs...', 'submitting': '🚀 Submitting...',
    'complete': '✅ Listed!', 'error': '❌ ' + (detail || ''), 'waiting': '⏸ Manual review',
  };
  active.step = labels[step] || step;
  renderQueue();
  log('   → ' + step + ': ' + (detail || ''), 'info');
}

function resetAll() {
  isStopped = true; isRunning = false; isPaused = false;
  currentListingId = null; listingDoneResolver = null;
  activeListings.clear();
  setRunningUI(false); stopTimer(); updateStats(); renderQueue();
}

function stopListing() { isRunning = false; setRunningUI(false); stopTimer(); }

function setRunningUI(running) {
  $('startBtn').disabled = running; $('pauseBtn').disabled = !running; $('resumeBtn').disabled = true;
  $('linksInput').disabled = running;
}

function renderQueue() {
  const container = $('queueContainer');
  if (!queue.length) { container.innerHTML = '<p class="muted">Add links and click Start</p>'; return; }
  let items = activeFilter === 'all' ? queue : queue.filter(q => q.status === activeFilter || (activeFilter === 'error' && q.status === 'skipped'));
  const counts = { all: queue.length, pending: 0, active: 0, success: 0, error: 0, skipped: 0 };
  queue.forEach(q => { if (counts[q.status] !== undefined) counts[q.status]++; });
  document.querySelectorAll('.filter-btn').forEach(btn => {
    const f = btn.dataset.filter;
    if (f === 'all') btn.textContent = 'All (' + counts.all + ')';
    else if (f === 'pending') btn.textContent = 'Pending (' + counts.pending + ')';
    else if (f === 'active') btn.textContent = 'Active (' + counts.active + ')';
    else if (f === 'success') btn.textContent = 'Done (' + counts.success + ')';
    else if (f === 'error') btn.textContent = 'Failed (' + (counts.error + counts.skipped) + ')';
  });

  const frag = document.createDocumentFragment();
  items.slice(0, 200).forEach(item => {
    const row = document.createElement('div');
    row.className = 'q-item' + (item.status === 'active' ? ' q-active' : '');
    row.innerHTML =
      '<span class="q-num">' + (item.idx + 1) + '</span>' +
      '<span class="q-source ' + item.source + '">' + (item.source === 'aliexpress' ? 'ALI' : 'AMZ') + '</span>' +
      (item.title && checkVero(item.title) ? '<span class="q-vero">⚠️ VERO</span>' : '') +
      '<div class="q-info">' +
        '<div class="q-title">' + (item.title || item.sku || item.url.substring(0, 50)) + '</div>' +
        '<div class="q-step ' + item.status + '">' + (item.step || (item.status === 'pending' ? '⏳ Waiting...' : '')) + '</div>' +
      '</div>' +
      '<span class="q-price">' + (item.price ? '£' + item.price.toFixed(2) : '') + '</span>' +
      (item.status === 'pending' ? '<button class="q-skip" data-idx="' + item.idx + '" title="Skip">⏭</button>' : '') +
      (item.status === 'error' ? '<button class="q-retry" data-idx="' + item.idx + '" title="Retry">🔄</button>' : '') +
      (item.status === 'error' ? '<button class="q-skip" data-idx="' + item.idx + '" title="Skip">⏭</button>' : '') +
      '<span class="q-status ' + item.status + '">' +
        ({ pending: '⏳', active: '🔄', success: '✅', error: '❌', skipped: '⏭' }[item.status] || '') +
      '</span>';
    frag.appendChild(row);
  });
  container.innerHTML = '';
  container.appendChild(frag);
}

function updateStats() {
  const total = queue.length;
  const done = successCount + failedCount + skippedCount;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  $('progressFill').style.width = pct + '%';
  $('progressPercent').textContent = pct + '%';
  $('statSuccess').textContent = successCount;
  $('statFailed').textContent = failedCount;
  $('statSkipped').textContent = skippedCount;
  $('statRemaining').textContent = total > 0 ? Math.max(0, total - done) : 0;
  if (startTime && successCount > 0) {
    const elapsed = (Date.now() - startTime) / 1000 / 3600;
    $('statRate').textContent = Math.round(successCount / elapsed) + '/hr';
  } else {
    $('statRate').textContent = '0/hr';
  }
}

function startTimer() {
  startTime = Date.now();
  timerInterval = setInterval(() => {
    const s = Math.floor((Date.now() - startTime) / 1000);
    $('statElapsed').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }, 1000);
}
function stopTimer() { clearInterval(timerInterval); }

function log(msg, type = 'info') {
  const c = $('logContainer');
  const e = document.createElement('div');
  e.className = 'log-entry ' + type;
  e.innerHTML = '<span class="log-time">' + new Date().toLocaleTimeString() + '</span>' + msg;
  c.appendChild(e); c.scrollTop = c.scrollHeight;
  while (c.childElementCount > 500) c.removeChild(c.firstChild);
  console.log('[BulkLister] ' + msg);
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// Remove a successfully listed URL from the textarea so user doesn't re-list it
function removeListedUrlFromTextarea(url) {
  try {
    const lines = $('linksInput').value.split('\n');
    const cleaned = lines.filter(line => {
      const t = line.trim();
      if (!t) return false;
      // Match by SKU or exact URL
      return !t.includes(url.split('/item/')[1]?.split('.html')[0] || '___NOMATCH___');
    });
    $('linksInput').value = cleaned.join('\n');
    chrome.storage.local.set({ bulk_links: $('linksInput').value });
    updateLinkCount();
  } catch(e) { /* don't break listing flow */ }
}
function sendMessage(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, resp => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      resolve(resp);
    });
  });
}
