/**
 * Unicorn DS - Fast Tracker
 * Monitors eBay listings against Amazon/AliExpress stock & prices
 * Generates updates (price changes, OOS removals)
 */

// ═══════════════════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════════════════
let rawItems = [];
let processedRows = [];
let isRunning = false;

// Resolve eBay and Amazon TLD from the user's primary market (extension pages have no current eBay page)
const UDS_MKT_DOMAIN = { com:'com', co_uk:'co.uk', de:'de', com_au:'com.au', ca:'ca', fr:'fr', it:'it', es:'es', nl:'nl', at:'at', be:'be', ch:'ch', ie:'ie', in:'in' };
function udsMarketDomain(m) { return UDS_MKT_DOMAIN[m] || 'co.uk'; }

let isPaused = false;
let timerInterval = null;
let startTime = null;
let processedCount = 0;
let inStockCount = 0;
let oosCount = 0;
let errorCount = 0;

// ═══════════════════════════════════════════════════════
// DOM REFS
// ═══════════════════════════════════════════════════════
const $ = id => document.getElementById(id);
const rawTbody = $('rawTable').querySelector('tbody');
const processedTbody = $('processedTable').querySelector('tbody');

// ═══════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  // Load saved state
  chrome.storage.local.get(['tracker_raw', 'tracker_processed', 'tracker_settings', 'unicornds_tracker_queue'], s => {
    if (s.tracker_raw?.length) { rawItems = s.tracker_raw; renderRawTable(); }
    if (s.tracker_processed?.length) { processedRows = s.tracker_processed; renderProcessedTable(); }
    if (s.tracker_settings) applySettings(s.tracker_settings);

    // Auto-import from tracker queue (items added from eBay active listings page)
    if (s.unicornds_tracker_queue?.length) {
      const queue = s.unicornds_tracker_queue;
      let added = 0;
      for (const item of queue) {
        if (!rawItems.some(r => r.itemId === item.itemId)) {
          rawItems.push({
            itemId: item.itemId,
            customLabel: item.customLabel,
            title: item.title || '',
            price: item.price || 0,
            quantity: item.quantity || 0,
          });
          added++;
        }
      }
      if (added) {
        renderRawTable();
        saveState();
        // Clear the queue after importing
        chrome.storage.local.set({ unicornds_tracker_queue: [] });
        showNotification(`⚡ Imported ${added} items from eBay active listings`);
      }
    }
  });

  // Load saved site preference
  chrome.storage.local.get('unicornds_primary_market', s => {
    if (s.unicornds_primary_market) {
      const sel = $('listingSiteSelect');
      const val = s.unicornds_primary_market.replace('_', '.');
      if ([...sel.options].some(o => o.value === val)) sel.value = val;
    }
  });

  // Button handlers
  $('quickStartBtn').addEventListener('click', quickStart);
  $('downloadListingsBtn').addEventListener('click', downloadListings);
  $('startBtn').addEventListener('click', startProcessing);
  $('pauseBtn').addEventListener('click', togglePause);
  $('clearRawBtn').addEventListener('click', () => { rawItems = []; renderRawTable(); saveState(); });
  $('clearProcessedBtn').addEventListener('click', () => { processedRows = []; renderProcessedTable(); saveState(); });
  $('retryFailedBtn').addEventListener('click', retryFailed);
  $('updateListingsBtn').addEventListener('click', () => showExportModal());
  $('exportProcessedBtn').addEventListener('click', exportCSV);
  $('importProcessedBtn').addEventListener('click', importProcessed);
  $('fileInput').addEventListener('change', handleFileUpload);

  // Manual Add handlers
  $('manualAddBtn').addEventListener('click', () => {
    $('manualAddSection').classList.toggle('hidden');
  });
  $('manualAddCancelBtn').addEventListener('click', () => {
    $('manualAddSection').classList.add('hidden');
  });
  $('manualAddConfirmBtn').addEventListener('click', handleManualAdd);

  // Modal handlers
  $('cancelExport').addEventListener('click', () => $('exportModal').classList.add('hidden'));
  $('confirmExport').addEventListener('click', doExportCSV);
  $('confirmUpdate').addEventListener('click', doUpdateListings);

  // Pricing mode toggle
  document.querySelectorAll('input[name="pricingMode"]').forEach(r => {
    r.addEventListener('change', () => {
      $('globalMarkup').disabled = r.value !== 'markup';
      $('fixedIncrease').disabled = r.value !== 'fixed';
    });
  });
});

function applySettings(s) {
  if (s.supplier) $('supplierSelect').value = s.supplier;
  if (s.site) $('listingSiteSelect').value = s.site;
  if (s.threads) $('threadCount').value = s.threads;
  if (s.markup) $('globalMarkup').value = s.markup;
}

function handleManualAdd() {
  const text = $('manualAddTextarea').value.trim();
  if (!text) { alert('Please paste item data first.'); return; }

  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  let added = 0;

  for (const line of lines) {
    const parts = line.split(/[,\t]+/).map(p => p.trim());
    if (parts.length < 2) continue;

    const itemId = parts[0];
    const customLabel = parts[1];
    const price = parseFloat(parts[2]) || 0;

    // Skip duplicates
    if (rawItems.some(r => r.itemId === itemId)) continue;

    rawItems.push({
      itemId,
      customLabel,
      title: '',
      price,
      quantity: 0,
    });
    added++;
  }

  if (added) {
    renderRawTable();
    saveState();
    $('manualAddTextarea').value = '';
    $('manualAddSection').classList.add('hidden');
    showNotification('✅ Added ' + added + ' items manually');
  } else {
    alert('No new items added. Check format: ItemID, SKU, Price');
  }
}

function saveState() {
  chrome.storage.local.set({
    tracker_raw: rawItems.slice(0, 5000), // cap storage
    tracker_processed: processedRows.slice(0, 5000),
    tracker_settings: {
      supplier: $('supplierSelect').value,
      site: $('listingSiteSelect').value,
      threads: $('threadCount').value,
      markup: $('globalMarkup').value,
    },
  });
}

// ═══════════════════════════════════════════════════════
// TIMER
// ═══════════════════════════════════════════════════════
function startTimer() {
  startTime = Date.now();
  timerInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    const h = String(Math.floor(elapsed / 3600)).padStart(2, '0');
    const m = String(Math.floor((elapsed % 3600) / 60)).padStart(2, '0');
    const s = String(elapsed % 60).padStart(2, '0');
    $('timerValue').textContent = `${h}:${m}:${s}`;
  }, 1000);
}

function stopTimer() { clearInterval(timerInterval); timerInterval = null; }

function updateStats() {
  $('processedItemsCount').textContent = processedCount;
  $('inStockCount').textContent = inStockCount;
  $('oosCount').textContent = oosCount;
  $('errorCount').textContent = errorCount;
  $('processedCount').textContent = processedRows.length;
  $('rawCount').textContent = rawItems.length;
}

// ═══════════════════════════════════════════════════════
// GET LISTINGS FROM EBAY
// ═══════════════════════════════════════════════════════
async function downloadListings() {
  const btn = $('downloadListingsBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Fetching...';
  $('loadingOverlay').classList.remove('hidden');

  try {
    const resp = await sendMessage({ type: 'download_active_listings' });
    if (resp?.listings?.length) {
      rawItems = resp.listings;
      renderRawTable();
      saveState();
      btn.textContent = `✅ Got ${rawItems.length} listings`;

      // AUTO-REBUILD SKU DICTIONARY - detect UDS- SKUs and store supplier URLs
      let rebuilt = 0;
      const dict = {};
      const _trk = await new Promise(r => chrome.storage.local.get(['hunter_domain','unicornds_primary_market'], r));
      const _amzDom = _trk.hunter_domain || udsMarketDomain(_trk.unicornds_primary_market);
      for (const item of rawItems) {
        const sku = item.customLabel || '';
        if (!sku.includes('UDS')) continue;
        // Parse new format: UDS-AE-{id}, UDS-AZ-{asin}
        const newMatch = sku.match(/UDS-([A-Z]{2})-([A-Za-z0-9]+)/);
        if (newMatch) {
          const src = newMatch[1] === 'AZ' ? 'amazon' : 'aliexpress';
          const pid = newMatch[2];
          const url = src === 'amazon' ? 'https://www.amazon.' + _amzDom + '/dp/' + pid : 'https://www.aliexpress.com/item/' + pid + '.html';
          dict[sku] = { sku, source: src, productId: pid, sourceUrl: url, title: item.title || '', ebayItemId: item.itemId || '', lastSeen: new Date().toISOString() };
          rebuilt++;
        } else {
          // Old format: UDS-{number} or UDS-UK-{number}
          const oldMatch = sku.match(/UDS-(?:[A-Z]{2}-)?(\d+)/);
          if (oldMatch) {
            const pid = oldMatch[1];
            dict[sku] = { sku, source: 'aliexpress', productId: pid, sourceUrl: 'https://www.aliexpress.com/item/' + pid + '.html', title: item.title || '', ebayItemId: item.itemId || '', lastSeen: new Date().toISOString() };
            rebuilt++;
          }
        }
      }
      if (rebuilt > 0) {
        chrome.storage.local.get('unicornds_sku_dictionary', s => {
          const existing = s.unicornds_sku_dictionary || {};
          const merged = { ...existing, ...dict };
          chrome.storage.local.set({ unicornds_sku_dictionary: merged });
          console.log('[Tracker] Rebuilt SKU dictionary:', rebuilt, 'entries. Total:', Object.keys(merged).length);
        });
        showNotification(`🔗 Rebuilt ${rebuilt} SKU links from eBay listings`);
      }
    } else {
      // Try alternative: scrape from eBay active listings page
      btn.textContent = '❌ No listings found';
      alert('Could not fetch listings. Make sure you are logged into eBay.\n\nAlternatively, upload a CSV file with columns: ItemID, CustomLabel, Title, StartPrice, Quantity');
    }
  } catch (e) {
    console.error('Download listings error:', e);
    btn.textContent = '❌ Error';
    alert('Error fetching listings: ' + e.message);
  }

  $('loadingOverlay').classList.add('hidden');
  setTimeout(() => { btn.disabled = false; btn.textContent = '📥 Get Listings from eBay'; }, 3000);
}

function handleFileUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (evt) => {
    const text = evt.target.result;

    if (file.name.endsWith('.json')) {
      try {
        const data = JSON.parse(text);
        rawItems = Array.isArray(data) ? data : (data.items || data.listings || []);
      } catch (e) { alert('Invalid JSON'); return; }
    } else {
      // Parse CSV
      rawItems = parseCSV(text);
    }

    renderRawTable();
    saveState();
  };
  reader.readAsText(file);
}

function parseCSV(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
  const items = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map(c => c.replace(/"/g, '').trim());
    const row = {};
    headers.forEach((h, idx) => { row[h] = cols[idx] || ''; });

    items.push({
      itemId: row['ItemID'] || row['Item ID'] || row['itemId'] || '',
      customLabel: row['CustomLabel'] || row['Custom label (SKU)'] || row['SKU'] || row['customLabel'] || '',
      title: row['Title'] || row['Item title'] || row['title'] || '',
      price: parseFloat(row['StartPrice'] || row['Price'] || row['Start price'] || row['price'] || '0'),
      quantity: parseInt(row['Quantity'] || row['Available quantity'] || row['quantity'] || '0'),
    });
  }

  return items.filter(i => i.itemId);
}

// ═══════════════════════════════════════════════════════
// RENDER TABLES
// ═══════════════════════════════════════════════════════
function renderRawTable() {
  rawTbody.innerHTML = '';
  rawItems.forEach((item, i) => {
    const tr = document.createElement('tr');
    tr.id = 'raw-' + i;
    tr.innerHTML = `
      <td>${i + 1}</td>
      <td>${item.itemId}</td>
      <td>${item.customLabel || '-'}</td>
      <td>${(item.title || '').substring(0, 60)}</td>
      <td>${item.price ? '£' + Number(item.price).toFixed(2) : '-'}</td>
      <td>${item.quantity ?? '-'}</td>`;
    rawTbody.appendChild(tr);
  });
  $('rawCount').textContent = rawItems.length;
}

function renderProcessedTable() {
  processedTbody.innerHTML = '';
  processedRows.forEach((row, i) => {
    const tr = document.createElement('tr');
    tr.className = row.status === 'In Stock' ? 'done' : row.status === 'Out of Stock' ? 'oos' : row.status?.includes('Error') ? 'error' : '';
    const statusClass = row.status === 'In Stock' ? 'status-ok' : row.status === 'Out of Stock' ? 'status-oos' : row.status?.includes('Error') ? 'status-error' : row.status === 'Processing' ? 'status-processing' : 'status-pending';

    const priceClass = row.newPrice > row.ebayPrice ? 'price-up' : row.newPrice < row.ebayPrice ? 'price-down' : 'price-same';

    tr.innerHTML = `
      <td>${row.action || 'Revise'}</td>
      <td>${row.itemId}</td>
      <td>${row.customLabel || '-'}</td>
      <td>£${Number(row.ebayPrice || 0).toFixed(2)}</td>
      <td>${row.sourcePrice ? '£' + Number(row.sourcePrice).toFixed(2) : '-'}</td>
      <td class="${priceClass}">${row.newPrice ? '£' + Number(row.newPrice).toFixed(2) : '-'}</td>
      <td>${row.newQuantity ?? '-'}</td>
      <td><span class="status ${statusClass}">${row.status || 'Pending'}</span></td>`;
    processedTbody.appendChild(tr);
  });
  $('processedCount').textContent = processedRows.length;
  updateStats();
}

// ═══════════════════════════════════════════════════════
// QUICK START
// ═══════════════════════════════════════════════════════
async function quickStart() {
  $('quickStartBtn').disabled = true;
  $('quickStartBtn').textContent = '⏳ Working...';

  // Step 1: Download listings if we don't have them
  if (!rawItems.length) {
    await downloadListings();
  }

  // Step 2: Start processing
  if (rawItems.length) {
    startProcessing();
  }

  $('quickStartBtn').disabled = false;
  $('quickStartBtn').textContent = '⚡ Quick Start';
}

// ═══════════════════════════════════════════════════════
// PROCESSING ENGINE
// ═══════════════════════════════════════════════════════
async function startProcessing() {
  if (isRunning) return;
  if (!rawItems.length) { alert('No items to process. Download listings or upload CSV first.'); return; }

  isRunning = true;
  isPaused = false;
  processedCount = 0;
  inStockCount = 0;
  oosCount = 0;
  errorCount = 0;

  $('startBtn').disabled = true;
  $('pauseBtn').disabled = false;
  startTimer();

  const supplier = $('supplierSelect').value;
  const site = $('listingSiteSelect').value;
  const threads = parseInt($('threadCount').value) || 3;
  const startPos = parseInt($('positionInput').value) || 0;
  const markup = parseFloat($('globalMarkup').value) || 25;

  // Filter items that have a SKU (CustomLabel) - these are linked to a supplier
  // Auto-detect supplier from UDS prefix - no need to rely on dropdown
  const itemsToProcess = rawItems.slice(startPos).filter(item => {
    if (!item.customLabel) return false;
    // If it has UDS- prefix, we can auto-detect supplier
    if (item.customLabel.includes('UDS')) return true;
    // Otherwise only process if supplier matches the dropdown selection
    if (supplier === 'amazon' && /^B0[A-Z0-9]{8}$/i.test(item.customLabel)) return true;
    if (supplier === 'aliexpress' && /^\d{10,}$/.test(item.customLabel)) return true;
    return false;
  });

  if (!itemsToProcess.length) {
    alert('No items with Custom Labels (SKUs) found. The tracker needs SKUs to look up products on the supplier site.');
    stopProcessing();
    return;
  }

  console.log(`[Tracker] Starting: ${itemsToProcess.length} items, ${threads} threads, ${supplier}, markup ${markup}%`);

  // Process in parallel batches
  let index = 0;

  async function processNext() {
    while (index < itemsToProcess.length && isRunning) {
      if (isPaused) { await sleep(500); continue; }

      const item = itemsToProcess[index];
      index++;

      // Mark raw row as processing
      const rawRow = document.getElementById('raw-' + (startPos + index - 1));
      if (rawRow) rawRow.classList.add('processing');

      try {
        const result = await checkSupplierStock(item, supplier, site, markup);
        processedRows.push(result);
        processedCount++;

        if (result.status === 'In Stock') inStockCount++;
        else if (result.status === 'Out of Stock') oosCount++;
        else errorCount++;

        if (rawRow) { rawRow.classList.remove('processing'); rawRow.classList.add('done'); }
      } catch (e) {
        const errRow = {
          action: 'Error',
          itemId: item.itemId,
          customLabel: item.customLabel,
          ebayPrice: item.price,
          sourcePrice: null,
          newPrice: null,
          newQuantity: null,
          status: 'Error: ' + e.message,
        };
        processedRows.push(errRow);
        processedCount++;
        errorCount++;

        if (rawRow) { rawRow.classList.remove('processing'); rawRow.classList.add('error'); }
      }

      renderProcessedTable();

      // Save every 10 items
      if (processedCount % 10 === 0) saveState();

      // Small delay between items to avoid rate limiting
      await sleep(1500);
    }
  }

  // Launch threads
  const workers = [];
  for (let t = 0; t < threads; t++) {
    workers.push(processNext());
    await sleep(500); // Stagger thread starts
  }

  await Promise.all(workers);
  stopProcessing();
  saveState();
}

function togglePause() {
  isPaused = !isPaused;
  $('pauseBtn').textContent = isPaused ? '▶ Resume' : '⏸ Pause';
  $('pauseBtn').className = isPaused ? 'btn btn-success' : 'btn btn-warning';
}

function stopProcessing() {
  isRunning = false;
  isPaused = false;
  stopTimer();
  $('startBtn').disabled = false;
  $('pauseBtn').disabled = true;
  $('pauseBtn').textContent = '⏸ Pause';
  updateStats();
}

// ═══════════════════════════════════════════════════════
// CHECK SUPPLIER STOCK
// ═══════════════════════════════════════════════════════
async function checkSupplierStock(item, supplier, site, markup) {
  const sku = item.customLabel;

  // Parse UDS SKU format - supports UDS-AE-{id}, UDS-AZ-{asin}, UDS-UK-{id}, UDS-{id}
  // Also handles variant suffixes: UDS-AE-{id}_V3
  let productUrl = '';
  let detectedSupplier = supplier;
  const cleanSku = sku.replace(/_V\d+$/, ''); // Strip variant suffix

  // New format: UDS-AE-{id} or UDS-AZ-{asin}
  const newMatch = cleanSku.match(/UDS-([A-Z]{2})-([A-Za-z0-9]+)/);
  if (newMatch) {
    const sourceCode = newMatch[1];
    const pid = newMatch[2];
    if (sourceCode === 'AZ') {
      detectedSupplier = 'amazon';
      productUrl = `https://www.amazon.${site}/dp/${pid}?th=1&psc=1`;
    } else {
      // AE, UK, DE, FR, etc - all AliExpress
      detectedSupplier = 'aliexpress';
      productUrl = `https://www.aliexpress.com/item/${pid}.html`;
    }
  } else {
    // Old format: UDS-{number} - assume AliExpress
    const oldMatch = cleanSku.match(/UDS-(\d+)/);
    if (oldMatch) {
      detectedSupplier = 'aliexpress';
      productUrl = `https://www.aliexpress.com/item/${oldMatch[1]}.html`;
    } else if (supplier === 'amazon') {
      // Raw ASIN
      productUrl = `https://www.amazon.${site}/dp/${sku}?th=1&psc=1`;
    } else {
      // Raw AliExpress ID
      productUrl = `https://www.aliexpress.com/item/${sku}.html`;
    }
  }

  console.log(`[Tracker] Checking: ${sku} → ${productUrl}`);

  try {
    // Send message to background to open tab, scrape, and return data
    const resp = await sendMessage({
      type: 'tracker_check_product',
      supplier: detectedSupplier,
      sku,
      productUrl,
      site,
    });

    if (resp?.blocked) {
      // IP blocked - show countdown
      await handleIPBlock(resp.waitSeconds || 120);
      // Retry after block
      return checkSupplierStock(item, supplier, site, markup);
    }

    if (!resp?.available) {
      // Uncertain (page likely failed to load / blocked) -- do NOT end the listing this round.
      if (resp?.uncertain) {
        return {
          action: 'Error',
          itemId: item.itemId,
          customLabel: sku,
          ebayPrice: item.price,
          sourcePrice: resp?.price || null,
          newPrice: null,
          newQuantity: null,
          status: 'Uncertain \u2014 skipped',
        };
      }
      return {
        action: 'EndItem',
        itemId: item.itemId,
        customLabel: sku,
        ebayPrice: item.price,
        sourcePrice: resp?.price || null,
        newPrice: null,
        newQuantity: 0,
        status: resp?.skuChanged ? 'SKU Changed' : 'Out of Stock',
      };
    }

    // Calculate new price
    const sourcePrice = resp.price || 0;
    let newPrice = sourcePrice * (1 + markup / 100);

    // Apply rounding
    const rounding = $('roundingOption')?.value;
    if (rounding && rounding !== 'none') {
      const cents = parseFloat(rounding);
      newPrice = Math.floor(newPrice) + cents;
      if (newPrice < sourcePrice * (1 + markup / 100) - 1) newPrice += 1;
    }

    // Apply price ending
    const ending = $('priceEndingInput')?.value;
    if (ending) {
      const endings = ending.split(',').map(e => parseFloat('0.' + e.trim())).filter(e => !isNaN(e));
      if (endings.length) {
        const base = Math.floor(newPrice);
        const currentCents = newPrice - base;
        // Find nearest ending
        let nearest = endings[0];
        let minDiff = Math.abs(currentCents - endings[0]);
        for (const e of endings) {
          if (Math.abs(currentCents - e) < minDiff) { nearest = e; minDiff = Math.abs(currentCents - e); }
        }
        newPrice = base + nearest;
      }
    }

    newPrice = Math.round(newPrice * 100) / 100;
    const fixedQty = parseInt($('fixedQuantity')?.value) || 5;

    return {
      action: 'Revise',
      itemId: item.itemId,
      customLabel: sku,
      ebayPrice: item.price,
      sourcePrice: sourcePrice,
      newPrice: newPrice,
      newQuantity: fixedQty,
      status: 'In Stock',
      brand: resp.brand || '',
    };
  } catch (e) {
    console.error(`[Tracker] Error checking ${sku}:`, e);
    return {
      action: 'Error',
      itemId: item.itemId,
      customLabel: sku,
      ebayPrice: item.price,
      sourcePrice: null,
      newPrice: null,
      newQuantity: null,
      status: 'Error: ' + (e.message || 'Unknown'),
    };
  }
}

async function handleIPBlock(seconds) {
  $('blockModal').classList.remove('hidden');
  const countdown = $('blockCountdown');

  for (let i = seconds; i > 0; i--) {
    countdown.textContent = i;
    await sleep(1000);
    if (!isRunning) break;
  }

  $('blockModal').classList.add('hidden');
}

// ═══════════════════════════════════════════════════════
// RETRY FAILED
// ═══════════════════════════════════════════════════════
async function retryFailed() {
  const failedItems = processedRows.filter(r => r.status?.includes('Error') || r.status === 'Out of Stock');
  if (!failedItems.length) { alert('No failed items to retry.'); return; }

  // Remove failed from processed
  processedRows = processedRows.filter(r => !r.status?.includes('Error'));
  renderProcessedTable();

  // Re-add as raw items for processing
  const retryRaw = failedItems.map(f => ({
    itemId: f.itemId,
    customLabel: f.customLabel,
    title: '',
    price: f.ebayPrice,
    quantity: 0,
  }));

  rawItems = retryRaw;
  renderRawTable();
  startProcessing();
}

// ═══════════════════════════════════════════════════════
// EXPORT MODAL
// ═══════════════════════════════════════════════════════
function showExportModal() {
  if (!processedRows.length) { alert('No processed items to export.'); return; }

  // Populate preview
  const previewTbody = $('previewTable').querySelector('tbody');
  previewTbody.innerHTML = '';
  const previewItems = processedRows.slice(0, 5);
  for (const row of previewItems) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${row.action}</td><td>${row.itemId}</td><td>${row.customLabel}</td>
      <td>${row.newPrice ? '£' + row.newPrice.toFixed(2) : '-'}</td>
      <td>${row.newQuantity ?? '-'}</td><td>${row.status}</td>`;
    previewTbody.appendChild(tr);
  }

  // Show error count
  const errors = processedRows.filter(r => r.status !== 'In Stock').length;
  $('exportModal').classList.remove('hidden');
}

function doExportCSV() {
  const updatePrice = $('updatePriceCheckbox').checked;
  const updateStock = $('updateStockCheckbox').checked;
  const failAction = document.querySelector('input[name="failAction"]:checked')?.value || 'end';

  const headers = ['Action', 'ItemID', 'CustomLabel', 'StartPrice', 'Quantity'];
  const rows = [headers.join(',')];

  for (const row of processedRows) {
    let action = 'Revise';
    let price = updatePrice && row.newPrice ? row.newPrice.toFixed(2) : '';
    let qty = updateStock ? (row.newQuantity ?? '') : '';

    if (row.status === 'Out of Stock' || row.status?.includes('Error')) {
      if (failAction === 'end') {
        action = 'End';
        price = '';
        qty = '';
      } else {
        qty = '0';
      }
    }

    rows.push([action, row.itemId, row.customLabel, price, qty].join(','));
  }

  const csv = rows.join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `unicornds_tracker_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);

  $('exportModal').classList.add('hidden');
}

async function doUpdateListings() {
  const updatePrice = $('updatePriceCheckbox').checked;
  const updateStock = $('updateStockCheckbox').checked;
  const failAction = document.querySelector('input[name="failAction"]:checked')?.value || 'end';

  const updates = processedRows.map(row => {
    if (row.status === 'Out of Stock' || row.status?.includes('Error')) {
      return failAction === 'end'
        ? { action: 'EndItem', itemId: row.itemId, reason: 'NotAvailable' }
        : { action: 'Revise', itemId: row.itemId, quantity: 0 };
    }
    const update = { action: 'Revise', itemId: row.itemId };
    if (updatePrice && row.newPrice) update.price = row.newPrice;
    if (updateStock && row.newQuantity != null) update.quantity = row.newQuantity;
    return update;
  });

  $('confirmUpdate').disabled = true;
  $('confirmUpdate').textContent = '⏳ Updating...';

  try {
    const resp = await sendMessage({ type: 'tracker_update_listings', updates });
    if (resp?.success) {
      alert(`✅ ${resp.updated || updates.length} listings updated on eBay!`);
      // Mark as updated
      processedRows.forEach(r => { if (r.status === 'In Stock') r.status = 'Updated'; });
      renderProcessedTable();
      saveState();
    } else {
      alert('Error updating: ' + (resp?.error || 'Unknown'));
    }
  } catch (e) {
    alert('Update failed: ' + e.message);
  }

  $('confirmUpdate').disabled = false;
  $('confirmUpdate').textContent = '📤 Update on eBay';
  $('exportModal').classList.add('hidden');
}

// ═══════════════════════════════════════════════════════
// IMPORT / EXPORT PROCESSED
// ═══════════════════════════════════════════════════════
function importProcessed() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json,.csv';
  input.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = evt => {
      try {
        if (file.name.endsWith('.json')) {
          processedRows = JSON.parse(evt.target.result);
        } else {
          processedRows = parseCSV(evt.target.result).map(r => ({
            action: r.action || 'Revise',
            itemId: r.itemId || r.ItemID,
            customLabel: r.customLabel || r.CustomLabel,
            ebayPrice: parseFloat(r.price || r.StartPrice || 0),
            newPrice: parseFloat(r.newPrice || r.StartPrice || 0),
            newQuantity: parseInt(r.quantity || r.Quantity || 0),
            status: r.status || 'Imported',
          }));
        }
        renderProcessedTable();
        saveState();
      } catch (e) { alert('Import error: ' + e.message); }
    };
    reader.readAsText(file);
  });
  input.click();
}

function exportCSV() {
  if (!processedRows.length) { alert('Nothing to export.'); return; }
  showExportModal();
}

// ═══════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function sendMessage(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, resp => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      resolve(resp);
    });
  });
}

function showNotification(text) {
  const el = document.createElement('div');
  el.style.cssText = 'position:fixed;top:20px;right:20px;z-index:99999;background:rgba(15,15,26,0.95);color:#fff;padding:14px 20px;border-radius:10px;border:1px solid #7C3AED;font-family:-apple-system,sans-serif;font-size:14px;box-shadow:0 4px 20px rgba(0,0,0,0.4);animation:slideIn .3s ease;';
  el.textContent = text;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}
