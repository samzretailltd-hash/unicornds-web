/**
 * UnicornDS — Walmart Product Scraper + Full Floating Panel
 * Runs on: https://www.walmart.com/ip/*
 *
 * Full parity with content_amazon.js:
 *   - JSON-first scrape (single variant)
 *   - Floating panel: VeRO badge, seller badge (who's selling), duplicate
 *     badge, demand score, Check on eBay, List on eBay (safety-checked),
 *     AI Titles, Add to Bulk Lister.
 *   - Walmart pricing profile (source:'walmart' -> _wmt keys).
 */

console.log('[UnicornDS] Walmart scraper loaded');

let lastScrapedData = null;
// Per-market fee + currency (filled from calculate_profit; UK defaults until then)
// Default currency is detected from the marketplace host so US/EU pages don't
// briefly show £ before the profit calc returns.
let UDS_FEE = { rate: 0.128, fixed: 0.30, currency: (function(){try{return self.UDSCurrency.symbolFor(self.UDSCurrency.detectSourceCurrency('', location.hostname));}catch(e){return '£';}})() };
function udsWmtSrcCurrency(sampleText) {
  try { return self.UDSCurrency.detectSourceCurrency(sampleText || '', window.location.hostname); }
  catch (e) { return 'USD'; }
}
const getStorageVal = (key) => new Promise(r => chrome.storage.local.get(key, s => r(s[key])));

// ═══════════════════════════════════════════════════════
// __NEXT_DATA__
// ═══════════════════════════════════════════════════════
function getNextData() {
  const el = document.getElementById('__NEXT_DATA__');
  if (!el || !el.textContent) return null;
  try { return JSON.parse(el.textContent); } catch (_) { return null; }
}
function findProduct(nextData) {
  if (!nextData) return null;
  try {
    const p = nextData.props?.pageProps?.initialData?.data?.product;
    if (p && (p.usItemId || p.name)) return p;
  } catch (_) {}
  let found = null; const seen = new Set();
  (function walk(node) {
    if (found || !node || typeof node !== 'object' || seen.has(node)) return;
    seen.add(node);
    if (Array.isArray(node)) { node.forEach(walk); return; }
    if ((node.usItemId || node.itemId) && (node.name || node.imageInfo)) { found = node; return; }
    for (const v of Object.values(node)) walk(v);
  })(nextData);
  return found;
}

// ═══════════════════════════════════════════════════════
// IMAGES
// ═══════════════════════════════════════════════════════
function upscaleImage(url) {
  if (!url) return '';
  let u = url.split('?')[0];
  if (u.startsWith('//')) u = 'https:' + u;
  if (!/walmartimages\.com/i.test(u)) return '';
  return u + '?odnHeight=2000&odnWidth=2000&odnBg=FFFFFF';
}
function getImages(product) {
  const urls = []; const seen = new Set();
  const add = (raw) => { const u = upscaleImage(raw); if (u && !seen.has(u)) { seen.add(u); urls.push(u); } };
  if (product?.imageInfo) {
    (product.imageInfo.allImages || []).forEach(img => add(img.url || img.assetSizeUrls?.DEFAULT || ''));
    if (urls.length === 0) { add(product.imageInfo.mainImageUrl); add(product.imageInfo.thumbnailUrl); }
  }
  if (urls.length === 0) document.querySelectorAll('[data-testid="media-thumbnail"] img, [data-seo-id="hero-image"]').forEach(img => add(img.getAttribute('src') || ''));
  console.log('[UnicornDS] Walmart images:', urls.length);
  return urls;
}

// ═══════════════════════════════════════════════════════
// VARIATIONS  (size / colour / style)
// Defensive: returns empty -> single-variant listing (no regression) if the
// Walmart variant schema isn't present or changes.
// Output shape matches Amazon: [{ name, price, image }]
// ═══════════════════════════════════════════════════════
function getVariations(product) {
  const variations = [];
  const variantImages = {};
  const pushImg = (key, img) => {
    if (!key || !img) return;
    if (!variantImages[key]) variantImages[key] = [];
    if (!variantImages[key].includes(img)) variantImages[key].push(img);
  };
  try {
    const vmap = product && product.variantsMap;
    const crit = product && product.variantCriteria;

    // PRIMARY: variantsMap — concrete buyable SKUs (price + image per combo)
    if (vmap && typeof vmap === 'object') {
      for (const key of Object.keys(vmap)) {
        const v = vmap[key];
        if (!v || typeof v !== 'object') continue;
        const avail = (v.availabilityStatusV2 && v.availabilityStatusV2.value) ||
                      v.availabilityStatus || v.availabilityStatusDisplayValue || '';
        if (/OUT_OF_STOCK|UNAVAILABLE|RETIRED/i.test(avail) || v.available === false) continue;

        const sel = v.selectedVariants || v.variants || {};
        const values = Object.values(sel).filter(Boolean).map(String);
        const name = values.join(' / ') || v.name || '';
        if (!name) continue;

        let price = v.priceInfo && v.priceInfo.currentPrice && v.priceInfo.currentPrice.price;
        price = (typeof price === 'number') ? price : (parseFloat(price) || '');

        let image = (v.imageInfo && (v.imageInfo.thumbnailUrl ||
                    (v.imageInfo.allImages && v.imageInfo.allImages[0] && (v.imageInfo.allImages[0].url || v.imageInfo.allImages[0].assetSizeUrls)))) ||
                    (v.images && v.images[0]) || '';
        image = upscaleImage(image) || image || '';

        variations.push({ name: name, price: price === '' ? '' : String(price), image: image });
        values.forEach(val => pushImg(val, image));
      }
    }

    // FALLBACK: variantCriteria — option lists (when no usable variantsMap)
    if (variations.length === 0 && Array.isArray(crit)) {
      const multi = crit.length > 1;
      crit.forEach(group => {
        const gname = group && group.name ? group.name : '';
        const list = (group && (group.variantList || group.values)) || [];
        list.forEach(opt => {
          if (!opt) return;
          if (/OUT_OF_STOCK|UNAVAILABLE/i.test(opt.availabilityStatus || '')) return;
          const oname = opt.name || opt.value || '';
          if (!oname) return;
          let image = opt.swatchImageUrl || (opt.images && opt.images[0]) || '';
          image = upscaleImage(image) || image || '';
          variations.push({ name: (multi ? (gname + ': ') : '') + oname, price: '', image: image });
          pushImg(oname, image);
        });
      });
    }
  } catch (e) {
    console.warn('[UnicornDS] Walmart variation parse error:', e.message);
  }
  console.log('[UnicornDS] Walmart variations:', variations.length,
    variations.length ? '-> ' + variations.slice(0, 4).map(v => v.name + (v.price ? '=' + v.price : '')).join(', ') : '(single variant)');
  return { variations: variations, variantImages: variantImages };
}

// ═══════════════════════════════════════════════════════
// FIELDS
// ═══════════════════════════════════════════════════════
function getTitle(product) { return (product?.name || document.getElementById('main-title')?.textContent || '').trim(); }
function filterTitle(title, brand) {
  let t = title || '';
  if (brand && brand.length > 1) t = t.replace(new RegExp(brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '').trim();
  t = t.replace(/®|™|©/g, '').replace(/\b([A-Z]{3}[0-9][A-Z0-9-]*)\b/g, '').replace(/[,]{2,}/g, ',').replace(/\s\s+/g, ' ').replace(/^[\s,-]+|[\s,-]+$/g, '').trim();
  if (t.length > 80) t = t.substring(0, 80).trim();
  return t;
}
// ── STOCK (top-level availability) ─────────────────────
// Walmart availabilityStatus values: IN_STOCK | OUT_OF_STOCK | RETIRED
function getWmtStock(product) {
  const raw = (product && ((product.availabilityStatusV2 && product.availabilityStatusV2.value) ||
              product.availabilityStatus || product.availabilityStatusDisplayValue)) || '';
  const txt = String(raw).toUpperCase();
  if (/OUT_OF_STOCK|UNAVAILABLE|RETIRED/.test(txt)) return { inStock: false, statusText: 'Out of Stock' };
  if (/IN_STOCK|AVAILABLE/.test(txt)) return { inStock: true, statusText: 'In Stock' };
  // Fall back to the DOM only if JSON gave us nothing.
  const domTxt = (document.body.innerText || '').toLowerCase();
  if (/out of stock|currently out of stock|not available/.test(domTxt)) return { inStock: false, statusText: 'Out of Stock' };
  const hasAdd = !!document.querySelector('[data-automation-id="atc"], [data-testid="add-to-cart-section"]');
  if (hasAdd) return { inStock: true, statusText: 'In Stock' };
  return { inStock: false, statusText: 'Unknown', uncertain: true };  // safe default
}

function getPrice(product) {
  const p = product?.priceInfo?.currentPrice?.price;
  if (typeof p === 'number' && p > 0) return p;
  const el = document.querySelector('[data-seo-id="hero-price"], [itemprop="price"]');
  if (el) { const v = self.UDSCurrency.parsePrice(el.textContent || '', udsWmtSrcCurrency(el.textContent)); if (v > 0) return v; }
  return 0;
}
function getBrand(product) {
  let b = product?.brand || '';
  if (!b) { const el = document.querySelector('[data-seo-id="brand-name"]'); if (el) b = el.textContent.replace(/visit the/i, '').replace(/store/i, '').trim(); }
  return (b || '').trim();
}
function stripHtml(html) { if (!html) return ''; const d = document.createElement('div'); d.innerHTML = html; return (d.textContent || '').replace(/\s+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim(); }
function getDescriptionHTML(product) {
  const parts = [];
  if (product?.shortDescription) parts.push(product.shortDescription);
  if (product?.longDescription && product.longDescription !== product.shortDescription) parts.push(product.longDescription);
  if (parts.length === 0) { const dom = document.querySelector('#top-highlights-module'); if (dom) parts.push(dom.innerHTML); }
  return parts.join('\n');
}
function getBulletPoints(product) {
  const list = []; let html = '';
  const dom = document.querySelector('#top-highlights-module ul');
  if (dom) { html = dom.outerHTML; dom.querySelectorAll('li').forEach(li => { const t = li.textContent.trim(); if (t) list.push(t); }); }
  if (list.length === 0 && product?.shortDescription) {
    const tmp = document.createElement('div'); tmp.innerHTML = product.shortDescription;
    const lis = tmp.querySelectorAll('li');
    if (lis.length) { html = tmp.innerHTML; lis.forEach(li => { const t = li.textContent.trim(); if (t) list.push(t); }); }
  }
  return { list, html };
}
function getItemSpecifics(product) {
  const specs = []; const seen = new Set();
  const add = (label, value) => { label = String(label || '').replace(/:/g, '').trim().toLowerCase(); value = String(value || '').trim(); if (label && value && !seen.has(label)) { seen.add(label); specs.push({ label, value }); } };
  const arr = product?.specifications || product?.specificationHighlights || [];
  if (Array.isArray(arr)) arr.forEach(s => add(s.name || s.displayName, s.value || s.displayValue));
  if (specs.length === 0) document.querySelectorAll('[data-testid="item-at-a-glance-genAI"] li').forEach(li => { const p = li.querySelectorAll('span'); if (p.length >= 2) add(p[0].textContent, p[1].textContent); });
  return specs;
}
function getCategories(product) { const path = product?.category?.path || []; return Array.isArray(path) ? path.map(c => c.name).filter(Boolean) : []; }
function getItemId(product) { if (product?.usItemId) return String(product.usItemId); const m = location.pathname.match(/\/ip\/(?:[^/]+\/)?(\d+)/); return m ? m[1] : ''; }
function getSellerInfo(product) {
  const domEl = document.querySelector('[data-testid="product-seller-info"]');
  const domSeller = domEl?.getAttribute('aria-label') || domEl?.textContent || '';
  // Tri-state: true = sold & shipped by Walmart.com (1P), false = confirmed 3P, null = unknown
  const det = self.UDSWmtSeller.detect(product, domSeller);
  const seller = (det.seller || domSeller || '').replace(/^Sold and shipped by\s*/i, '').trim();
  return { seller, isWalmartSold: det.firstParty };
}
function getDemandSignals(product) {
  const badges = [];
  document.querySelectorAll('[data-testid="badgeTagComponent"]').forEach(b => { const t = b.textContent.trim(); if (t) badges.push(t); });
  return { rating: product?.averageRating || 0, reviewCount: product?.numberOfReviews || 0, badges };
}

// ═══════════════════════════════════════════════════════
// FULL SCRAPE — same shape as Amazon scrapeProduct()
// ═══════════════════════════════════════════════════════
function scrapeProduct() {
  const product = findProduct(getNextData()) || {};
  const title = getTitle(product);
  if (!title) { console.warn('[UnicornDS] Walmart: no title found'); return null; }
  const brand = getBrand(product);
  const filtered = filterTitle(title, brand);
  const price = getPrice(product);
  const images = getImages(product);
  const bullets = getBulletPoints(product);
  const itemId = getItemId(product);
  const seller = getSellerInfo(product);
  const demand = getDemandSignals(product);
  const descText = stripHtml(getDescriptionHTML(product));
  const specs = getItemSpecifics(product);
  const varData = getVariations(product);
  const stock = getWmtStock(product);

  const data = {
    title, cleanedTitle: filtered, custom_title: filtered, filteredTitle: filtered,
    price, brand,
    sku: itemId, productId: itemId, itemID: itemId,
    upc: product.upc || '',
    descriptionHTML: getDescriptionHTML(product),
    descriptionText: descText,
    descriptionAndFeatures: filtered + '\n' + bullets.list.join('\n') + '\n' + descText,
    bullet_points: bullets.list, bullet_points_html: bullets.html,
    images, main_hd_images: images, main_sd_images: images,
    variantImages: varData.variantImages,
    tableSpecifics: specs, itemSpecifics: specs, filteredItemSpecifics: specs,
    categories: getCategories(product),
    shippingWeight: (specs.find(s => /weight/.test(s.label)) || {}).value || '',
    mpn: product.model || product.manufacturerProductId || '',
    ean: product.gtin13 || product.gtin || '',
    inStock: stock.inStock, stockStatus: stock.statusText, qtyUnknown: !!stock.uncertain,
    soldByWalmart: seller.isWalmartSold,
    source: 'walmart', sourceCurrency: udsWmtSrcCurrency(''), url: window.location.href, domain_host: window.location.host,
    extra: { seller: seller.seller, isWalmartSold: seller.isWalmartSold, rating: demand.rating, reviewCount: demand.reviewCount, demandBadges: demand.badges },
    variations: varData.variations, listingType: 'paid',
  };
  lastScrapedData = data;
  chrome.storage.local.set({ unicornds_last_product: data });
  console.log('[UnicornDS] Walmart scraped:', { title: filtered, price, images: images.length, walmartSold: seller.isWalmartSold });
  return data;
}

// ═══════════════════════════════════════════════════════
// PANEL
// ═══════════════════════════════════════════════════════
function showStatus(t, err) {
  const el = document.getElementById('unicornds-status'); if (!el) return;
  el.textContent = t; el.style.background = err ? 'rgba(231,76,60,0.9)' : 'rgba(0,0,0,0.85)';
  el.classList.add('visible'); if (!err) setTimeout(() => el.classList.remove('visible'), 5000);
}

function injectFloatingPanel() {
  if (!location.pathname.includes('/ip/') || document.getElementById('unicornds-float-container')) return;
  const c = document.createElement('div');
  c.id = 'unicornds-float-container';
  c.innerHTML = `
    <style>
      #unicornds-float-container { position:fixed; bottom:24px; right:24px; z-index:999999; font-family:-apple-system,sans-serif; width:320px; }
      #unicornds-panel { background:rgba(30,27,75,0.97); border:1px solid #2a2a4a; border-radius:16px; padding:14px; box-shadow:0 8px 32px rgba(0,0,0,0.5); }
      #unicornds-list-btn { display:flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:12px; background:linear-gradient(135deg,#7C3AED,#9B59B6); color:#fff; border:none; border-radius:10px; font-size:14px; font-weight:700; cursor:pointer; box-shadow:0 4px 20px rgba(124,58,237,0.4); transition:all 0.2s; }
      #unicornds-list-btn:hover { transform:translateY(-1px); }
      #unicornds-list-btn.loading { opacity:0.7; pointer-events:none; }
      .uds-row { display:flex; gap:6px; align-items:center; margin-top:8px; }
      .uds-input { flex:1; padding:6px 8px; background:#1a1a2e; border:1px solid #3a3a5a; border-radius:6px; color:#F59E0B; font-size:13px; font-weight:600; text-align:center; }
      .uds-label { font-size:11px; color:#888; white-space:nowrap; }
      .uds-btn-sm { padding:8px; width:100%; background:#1a1a3e; border:1px solid #3a3a5a; border-radius:8px; color:#ddd; font-size:12px; font-weight:600; cursor:pointer; text-align:center; margin-top:6px; transition:all 0.2s; }
      .uds-btn-sm:hover { background:#2a2a5a; border-color:#7C3AED; }
      .uds-btn-sm.active { background:#7C3AED; border-color:#9B59B6; color:#fff; }
      #unicornds-titles-list { margin-top:8px; max-height:200px; overflow-y:auto; }
      .uds-title-item { padding:8px 10px; background:#0d1b3e; border:1px solid #2a2a4a; border-radius:6px; margin-bottom:4px; cursor:pointer; font-size:12px; color:#ddd; transition:all 0.2s; }
      .uds-title-item:hover { border-color:#7C3AED; }
      .uds-title-item.selected { border-color:#F59E0B; background:#1a1a3e; }
      .uds-title-item .chars { font-size:10px; color:#666; margin-top:2px; }
      #unicornds-status { margin-top:8px; padding:8px; background:#1a1a2e; border-radius:6px; color:#fff; font-size:11px; text-align:center; display:none; }
      #unicornds-status.visible { display:block; }
      .uds-collapse-btn { position:absolute; top:-12px; right:10px; background:#2a2a4a; border:1px solid #3a3a5a; color:#aaa; border-radius:50%; width:24px; height:24px; font-size:12px; cursor:pointer; display:flex; align-items:center; justify-content:center; }
      .uds-src-badge { display:inline-block; padding:2px 6px; background:#0071DC; border-radius:4px; font-size:9px; color:#fff; font-weight:700; margin-left:4px; }
      .uds-badges { display:flex; gap:4px; margin-bottom:8px; flex-wrap:wrap; }
      .uds-badge-vero { padding:4px 8px; background:#DC2626; border-radius:6px; font-size:11px; color:#fff; font-weight:700; animation:uds-pulse 1.5s infinite; }
      .uds-badge-safe { padding:4px 8px; background:#059669; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-dup { padding:4px 8px; background:#D97706; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-new { padding:4px 8px; background:#2563EB; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-seller-wmt { padding:4px 8px; background:#0071DC; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-seller-3p { padding:4px 8px; background:#D97706; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-seller-unk { padding:4px 8px; background:#4B5563; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      @keyframes uds-pulse { 0%,100% { opacity:1; } 50% { opacity:0.6; } }
    </style>
    <div id="unicornds-panel" style="position:relative">
      <button class="uds-collapse-btn">−</button>
      <div id="unicornds-panel-body">
        <div id="unicornds-badges" class="uds-badges"></div>
        <div id="unicornds-demand" style="background:#0f0e2a;border:1px solid #2d2860;border-radius:8px;padding:8px 12px;margin:6px 0;display:none;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="font-size:11px;color:#a5a0cc;">Demand Score</span>
            <span id="uds-demand-score" style="font-size:14px;font-weight:800;"></span>
          </div>
          <div id="uds-demand-bar" style="height:4px;border-radius:2px;background:#1a1535;margin-top:4px;overflow:hidden;">
            <div id="uds-demand-fill" style="height:100%;border-radius:2px;transition:width 0.5s;"></div>
          </div>
          <div id="uds-demand-breakdown" style="font-size:9px;color:#6b6899;margin-top:4px;"></div>
        </div>
        <button id="unicornds-check-ebay-btn" class="uds-btn-sm" style="background:#1e3a8a;border-color:#3b82f6;color:#fff;margin-bottom:8px;padding:10px;font-size:12px">🔍 Check on eBay</button>
        <button id="unicornds-list-btn"><span style="font-size:16px">🦄</span><span id="unicornds-btn-text">List on eBay</span><span class="uds-src-badge">Walmart</span></button>
        <div class="uds-row">
          <span class="uds-label" id="uds-sell-label">Sell £</span><input type="text" id="unicornds-price-input" class="uds-input" placeholder="0.00" style="flex:1"/>
          <span class="uds-label">Ad%</span><input type="text" id="unicornds-promoted-input" class="uds-input" value="0.0" style="width:50px;flex:none"/>
        </div>
        <div id="unicornds-profit-display" style="background:#0f0e2a;border:1px solid #2a2a4a;border-radius:6px;padding:6px 10px;margin:4px 0;font-size:10px;color:#a5a0cc;display:none;">
          <div style="display:flex;justify-content:space-between;">
            <span>Cost: <span id="uds-cost" style="color:#e0d8ff">£0.00</span></span>
            <span>Fees: <span id="uds-fees" style="color:#F59E0B">£0.00</span></span>
            <span>Profit: <span id="uds-profit" style="color:#10B981;font-weight:700">£0.00</span></span>
          </div>
        </div>
        <button class="uds-btn-sm" id="unicornds-gen-titles">✨ Generate AI Titles</button>
        <button class="uds-btn-sm" id="unicornds-add-bulk" style="background:#059669;border-color:#10B981;color:#fff">📋 Add to Bulk Lister</button>
        <div id="unicornds-titles-list"></div>
        <div id="unicornds-status"></div>
      </div>
    </div>`;
  document.body.appendChild(c);

  document.getElementById('unicornds-list-btn').addEventListener('click', handleListOnEbay);
  document.getElementById('unicornds-gen-titles').addEventListener('click', generateTitlesInline);
  document.getElementById('unicornds-add-bulk').addEventListener('click', addToBulkLister);
  document.getElementById('unicornds-check-ebay-btn').addEventListener('click', handleCheckOnEbay);

  function updateProfitDisplay() {
    const sellPrice = parseFloat(document.getElementById('unicornds-price-input')?.value) || 0;
    const adRate = parseFloat(document.getElementById('unicornds-promoted-input')?.value) || 0;
    const costPrice = parseFloat(lastScrapedData?.price) || 0;
    const profitDiv = document.getElementById('unicornds-profit-display');
    if (!profitDiv || costPrice <= 0 || sellPrice <= 0) { if (profitDiv) profitDiv.style.display = 'none'; return; }
    // Show the SAME currency Walmart shows (no conversion — seller is single-currency).
    const cur = self.UDSCurrency.symbolFor(udsWmtSrcCurrency(''));
    const totalFees = (sellPrice * UDS_FEE.rate) + UDS_FEE.fixed + sellPrice * (adRate / 100);
    const profit = sellPrice - costPrice - totalFees;
    document.getElementById('uds-cost').textContent = cur + costPrice.toFixed(2);
    document.getElementById('uds-fees').textContent = cur + totalFees.toFixed(2);
    const profitEl = document.getElementById('uds-profit');
    profitEl.textContent = cur + profit.toFixed(2) + ' (' + (costPrice > 0 ? (profit / costPrice * 100) : 0).toFixed(0) + '%)';
    profitEl.style.color = profit > 0 ? '#10B981' : '#EF4444';
    profitDiv.style.display = 'block';
  }
  document.getElementById('unicornds-price-input').addEventListener('input', updateProfitDisplay);
  document.getElementById('unicornds-promoted-input').addEventListener('input', updateProfitDisplay);
  setTimeout(updateProfitDisplay, 500);

  document.querySelector('.uds-collapse-btn').addEventListener('click', function () {
    const body = document.getElementById('unicornds-panel-body'); body.hidden = !body.hidden; this.textContent = body.hidden ? '+' : '−';
  });

  // Prefill sell price from the WALMART pricing profile
  const cost = parseFloat(lastScrapedData?.price) || 0;
  if (cost > 0) {
    chrome.runtime.sendMessage({ type: 'calculate_profit', costPrice: cost, source: 'walmart', sourceCurrency: udsWmtSrcCurrency('') }, resp => {
      if (resp?.profit) {
        if (resp.profit.feeRate != null) UDS_FEE = { rate: resp.profit.feeRate, fixed: resp.profit.feeFixed, currency: self.UDSCurrency.symbolFor(udsWmtSrcCurrency('')) };
        const lbl = document.getElementById('uds-sell-label'); if (lbl) lbl.textContent = 'Sell ' + UDS_FEE.currency;
        const el = document.getElementById('unicornds-price-input'); if (el) { el.value = resp.profit.sellPrice.toFixed(2); updateProfitDisplay(); }
      }
    });
  }
  chrome.storage.local.get(['unicornds_promo_rate_wmt', 'unicornds_promo_rate', 'unicornds_ad_rate'], s => {
    const promoRate = [s.unicornds_promo_rate_wmt, s.unicornds_promo_rate, s.unicornds_ad_rate].map(v => parseFloat(v)).find(v => !isNaN(v)) ?? 0;
    const adEl = document.getElementById('unicornds-promoted-input'); if (adEl) { adEl.value = promoRate.toFixed(1); updateProfitDisplay(); }
  });
}

// ═══════════════════════════════════════════════════════
// VERO + DUPLICATE + SELLER + DEMAND  (parity with Amazon)
// ═══════════════════════════════════════════════════════
async function checkVeroAndDuplicate() {
  const badges = document.getElementById('unicornds-badges');
  if (!badges || !lastScrapedData) return;
  const brand = lastScrapedData.brand || '';
  const title = lastScrapedData.title || '';
  const itemId = lastScrapedData.sku || '';

  // VERO
  try {
    const veroEnabled = await getStorageVal('unicornds_vero_enabled');
    if (veroEnabled !== false) {
      let veroBrands = await getStorageVal('unicornds_vero_brands');
      if (!veroBrands || !veroBrands.length) {
        try {
          const resp = await fetch(chrome.runtime.getURL('data/VeroList.txt'));
          const text = await resp.text();
          veroBrands = text.split('\n').map(b => b.trim().toLowerCase()).filter(Boolean);
          chrome.storage.local.set({ unicornds_vero_brands: veroBrands });
        } catch (e) { veroBrands = []; }
      }
      if (veroBrands.length) {
        const combined = (brand + ' ' + title).toLowerCase().replace(/[-–—]/g, ' ');
        const brandOnly = String(brand || '').toLowerCase().replace(/[-–—]/g, ' ');
        const isVero = veroBrands.some(v => {
          const vLower = v.replace(/[-–—]/g, ' ');
          if (vLower.includes(' ')) return combined.includes(vLower);
          try {
            const escaped = vLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const re = new RegExp('\\b' + escaped + '\\b', 'i');
            // Ambiguous brand words (mac, gain, tide, apple...) are also ordinary words
            // in titles -- match those against the BRAND field only.
            const UDS_AMBIGUOUS = ['ammo','apple','boba','boss','coach','dawn','dove','downy','elk','era','gain','ivory','joy','mac','olay','puma','sap','tide'];
            if (UDS_AMBIGUOUS.indexOf(vLower) !== -1) return re.test(brandOnly);
            return re.test(combined);
          }
          catch { return combined.includes(vLower); }
        });
        badges.innerHTML += isVero ? '<span class="uds-badge-vero">⚠️ VERO BRAND</span>' : '<span class="uds-badge-safe">✅ Not VERO</span>';
        if (isVero) console.log('[UnicornDS] ⚠️ VERO detected:', brand);
      }
    }
  } catch (e) { console.warn('[UnicornDS] VERO check error:', e); }

  // DUPLICATE (check both raw item id and UDS-WM-{id})
  try {
    const skuList = await getStorageVal('unicornds_listed_skus') || [];
    const isDup = skuList.includes(itemId) || skuList.includes('UDS-WM-' + itemId);
    badges.innerHTML += isDup ? '<span class="uds-badge-dup">⚠️ ALREADY LISTED</span>' : '<span class="uds-badge-new">🆕 New Product</span>';
    if (isDup) console.log('[UnicornDS] ⚠️ Duplicate:', itemId);
  } catch (e) { console.warn('[UnicornDS] Duplicate check error:', e); }

  // SELLER — who is selling this product
  try {
    const ex = lastScrapedData.extra || {};
    if (ex.isWalmartSold === true) {
      badges.innerHTML += '<span class="uds-badge-seller-wmt">🏷️ Sold by Walmart</span>';
      console.log('[UnicornDS] Seller: Walmart 1P');
    } else if (ex.isWalmartSold === false) {
      const name = (ex.seller || '3rd-party').slice(0, 18);
      badges.innerHTML += '<span class="uds-badge-seller-3p">🚚 ' + name + ' (3P)</span>';
      console.log('[UnicornDS] Seller: Marketplace 3P —', ex.seller);
    } else {
      badges.innerHTML += '<span class="uds-badge-seller-unk">❔ Seller unconfirmed</span>';
      console.log('[UnicornDS] Seller: unknown (no reliable signal)');
    }
  } catch (e) { console.warn('[UnicornDS] Seller check error:', e); }

  // DEMAND SCORE
  try {
    const ex = lastScrapedData.extra || {};
    const reviews = parseInt(ex.reviewCount) || 0;
    const rating = parseFloat(ex.rating) || 0;
    const badgeText = (ex.demandBadges || []).join(' ').toLowerCase();
    const isBestSeller = /best\s?seller|popular pick/.test(badgeText);
    const hasBoughtText = /bought/.test(badgeText);

    const reviewScore = Math.min(reviews / 500, 1) * 40;
    const ratingScore = (rating / 5) * 25;
    const badgeBonus = isBestSeller ? 25 : 0;
    const boughtBonus = hasBoughtText ? 10 : 0;
    const demandScore = Math.min(Math.round(reviewScore + ratingScore + badgeBonus + boughtBonus), 100);

    const demandDiv = document.getElementById('unicornds-demand');
    const scoreEl = document.getElementById('uds-demand-score');
    const fillEl = document.getElementById('uds-demand-fill');
    const breakdownEl = document.getElementById('uds-demand-breakdown');
    if (demandDiv && scoreEl) {
      const color = demandScore >= 70 ? '#10B981' : demandScore >= 40 ? '#F59E0B' : '#6b7280';
      const label = demandScore >= 70 ? '🔥 Hot' : demandScore >= 40 ? '🌤 Warm' : '❄️ Cold';
      scoreEl.textContent = label + ' ' + demandScore + '/100'; scoreEl.style.color = color;
      fillEl.style.width = demandScore + '%'; fillEl.style.background = color;
      breakdownEl.textContent = 'Reviews: ' + reviews.toLocaleString() + ' · Rating: ' + rating.toFixed(1) + (isBestSeller ? ' · Bestseller' : '') + (hasBoughtText ? ' · Trending' : '');
      demandDiv.style.display = 'block';
      console.log('[UnicornDS] Demand score:', demandScore, '(' + label + ')');
    }
  } catch (e) { console.warn('[UnicornDS] Demand score error:', e); }
}

// ═══════════════════════════════════════════════════════
// CHECK ON EBAY  (EAN/UPC > MPN > brand+title)
// ═══════════════════════════════════════════════════════
function handleCheckOnEbay() {
  const btn = document.getElementById('unicornds-check-ebay-btn'); if (!btn) return;
  const originalText = btn.textContent;
  const data = scrapeProduct();
  if (!data?.title) { showStatus('Could not read product details', true); return; }

  let query = '', identifier = '';
  const eanClean = String(data.ean || '').replace(/\s/g, '');
  const upcClean = String(data.upc || '').replace(/\s/g, '');
  if (eanClean && /^\d{8,14}$/.test(eanClean)) { query = eanClean; identifier = 'EAN'; }
  else if (upcClean && /^\d{8,14}$/.test(upcClean)) { query = upcClean; identifier = 'UPC'; }
  else if (data.mpn && data.mpn.length > 3 && data.mpn.toLowerCase() !== 'does not apply') { query = data.mpn; identifier = 'MPN'; }
  else {
    const brand = (data.brand && data.brand !== 'Unbranded') ? data.brand : '';
    let titleClean = (data.title || '').replace(/\([^)]*\)/g, ' ').replace(/[|\-–—,:;]/g, ' ').replace(/[^\w\s]/g, ' ').replace(/\s+/g, ' ').trim();
    if (brand) titleClean = titleClean.replace(new RegExp(brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '').trim();
    const words = titleClean.split(/\s+/).filter(w => w.length > 2).slice(0, 4);
    query = (brand ? brand + ' ' : '') + words.join(' '); identifier = 'Title';
  }
  if (!query || query.length < 3) { showStatus('Could not build search query', true); return; }

  chrome.storage.local.get(['domain', 'unicornds_primary_market'], (s) => {
    const marketToDomain = { 'com':'com','co_uk':'co.uk','de':'de','com_au':'com.au','ca':'ca','fr':'fr','it':'it','es':'es','nl':'nl','at':'at','be':'be','ch':'ch','ie':'ie','in':'in' };
    const domain = s.domain || marketToDomain[s.unicornds_primary_market] || 'co.uk';
    const url = `https://www.ebay.${domain}/sch/i.html?_nkw=${encodeURIComponent(query)}&LH_ItemCondition=1000&_sop=12`;
    chrome.runtime.sendMessage({ type: 'openNewTab', url, options: { active: true } });
    btn.textContent = '✓ Searched by ' + identifier;
    showStatus('Searched eBay: "' + query + '" (' + identifier + ')');
    setTimeout(() => { btn.textContent = originalText; }, 4000);
  });
}

// ═══════════════════════════════════════════════════════
// ADD TO BULK LISTER
// ═══════════════════════════════════════════════════════
function addToBulkLister() {
  const url = window.location.href.split('?')[0];
  const btn = document.getElementById('unicornds-add-bulk');
  chrome.storage.local.get('bulk_links', s => {
    let existing = (s.bulk_links || '').trim();
    if (existing.includes(url)) { btn.textContent = '⚠️ Already Added'; setTimeout(() => { btn.textContent = '📋 Add to Bulk Lister'; }, 2000); return; }
    if (existing) existing += '\n';
    existing += url;
    chrome.storage.local.set({ bulk_links: existing }, () => {
      const count = existing.split('\n').filter(l => l.trim()).length;
      btn.textContent = '✅ Added! (' + count + ' total)'; btn.style.background = '#7C3AED';
      setTimeout(() => { btn.textContent = '📋 Add to Bulk Lister'; btn.style.background = '#059669'; }, 2000);
    });
  });
}

// ═══════════════════════════════════════════════════════
// GENERATE AI TITLES
// ═══════════════════════════════════════════════════════
function generateTitlesInline() {
  const btn = document.getElementById('unicornds-gen-titles');
  btn.textContent = '⏳ Generating...'; btn.classList.add('active');
  const data = scrapeProduct();
  if (!data?.title) { btn.textContent = '✨ Generate AI Titles'; btn.classList.remove('active'); return; }
  const specs = (data.filteredItemSpecifics || []).map(s => s.label + ': ' + s.value).join(', ');
  chrome.runtime.sendMessage({
    type: 'call_openai',
    systemPrompt: 'You are an eBay SEO expert. Generate 5 optimized eBay listing titles.\nRules: max 80 chars each, remove brand names, remove "1pc/Hot Sale/Free Shipping",\nkeep material/size/quantity/features, Title Case, no emojis.\nFirst title = BEST.\nReturn JSON: {"titles": ["t1","t2","t3","t4","t5"]}',
    userMessage: 'Product: ' + data.title + (specs ? '\nSpecs: ' + specs : ''),
    jsonMode: true,
  }, (resp) => {
    btn.textContent = '✨ Generate AI Titles'; btn.classList.remove('active');
    if (!resp?.result) { showStatus('AI failed - check API key', true); return; }
    try {
      const titles = (JSON.parse(resp.result).titles) || [];
      const list = document.getElementById('unicornds-titles-list'); list.innerHTML = '';
      titles.forEach((title, i) => {
        const div = document.createElement('div');
        div.className = 'uds-title-item' + (i === 0 ? ' selected' : '');
        div.innerHTML = (i === 0 ? '⭐ ' : '') + title + '<div class="chars">' + title.length + '/80</div>';
        div.addEventListener('click', () => {
          list.querySelectorAll('.uds-title-item').forEach(d => d.classList.remove('selected'));
          div.classList.add('selected');
          if (lastScrapedData) { lastScrapedData.custom_title = title; lastScrapedData.cleanedTitle = title; }
          showStatus('✅ Title: ' + title.substring(0, 40) + '...');
        });
        list.appendChild(div);
      });
      if (titles[0] && lastScrapedData) { lastScrapedData.custom_title = titles[0]; lastScrapedData.cleanedTitle = titles[0]; }
    } catch (e) { showStatus('Parse error', true); }
  });
}

// ═══════════════════════════════════════════════════════
// LIST ON EBAY  (same safety checks + message as Amazon)
// ═══════════════════════════════════════════════════════
async function handleListOnEbay() {
  const btn = document.getElementById('unicornds-list-btn');
  const btnText = document.getElementById('unicornds-btn-text');
  if (!btn || btn.classList.contains('loading')) return;
  btn.classList.add('loading'); btnText.textContent = 'Scraping...';

  const data = scrapeProduct();
  if (!data?.title) { showStatus('Scrape failed', true); btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; return; }

  // ── STRICT: only list items sold & shipped by Walmart.com (first-party) ──
  // Override (allow 3P): chrome.storage.local.set({ unicornds_walmart_3p_allow: true })
  const _fp = data.extra ? data.extra.isWalmartSold : null;
  const _cfg = await chrome.storage.local.get('unicornds_walmart_3p_allow');
  if (_cfg.unicornds_walmart_3p_allow !== true && _fp === false) {
    showStatus('🚫 Blocked — sold by a third-party seller (' + ((data.extra && data.extra.seller) || 'unknown') + '), not Walmart.com. Strict mode lists only items sold & shipped by Walmart. To allow 3P: enable it in settings.', true);
    btn.classList.remove('loading'); btnText.textContent = '🚫 3P — Blocked';
    setTimeout(() => { btnText.textContent = 'List on eBay'; }, 6000);
    return;
  }

  const productData = {
    ...data,
    custom_price: document.getElementById('unicornds-price-input')?.value || '',
    promoted_listing_ad_rate: document.getElementById('unicornds-promoted-input')?.value || '0',
  };
  const costCheck = parseFloat(data.price) || 0;
  const sellCheck = parseFloat(productData.custom_price) || 0;
  if (costCheck <= 0) { showStatus('⚠️ Cost price is ' + UDS_FEE.currency + '0 — cannot list. Check the page has a price.', true); btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; return; }
  if (sellCheck <= 0) { showStatus('⚠️ Sell price is empty — enter a sell price first.', true); btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; return; }
  if (sellCheck < costCheck) {
    if (!confirm('⚠️ Sell price (' + UDS_FEE.currency + sellCheck.toFixed(2) + ') is BELOW cost (' + UDS_FEE.currency + costCheck.toFixed(2) + '). You will LOSE money. List anyway?')) { btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; return; }
  }

  btnText.textContent = 'Opening eBay...';
  chrome.runtime.sendMessage({ type: 'list_to_ebay', product_data: productData }, res => {
    if (res?.success) { showStatus('✓ eBay tab opened!'); btnText.textContent = '✓ Started'; setTimeout(() => { btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; }, 3000); }
    else if (res?.blocked) { showStatus('🔒 ' + (res.error || 'Login required'), true); btn.classList.remove('loading'); btnText.textContent = '🔒 Login First'; setTimeout(() => { btnText.textContent = 'List on eBay'; }, 5000); }
    else { showStatus('Failed: ' + (res?.error || 'Unknown'), true); btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; }
  });
}

// ═══════════════════════════════════════════════════════
// MESSAGES
// ═══════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'list_item_to_ebay' || request.type === 'get_supplier_product_data') {
    const data = scrapeProduct();
    sendResponse({ autoListing: { product_data: data } });
    return true;
  }
});

// ═══════════════════════════════════════════════════════
// INIT — auth gate + SPA handling
// ═══════════════════════════════════════════════════════
function initWalmart() {
  if (!location.pathname.includes('/ip/')) return;
  chrome.storage.local.get('unicornds_session', (s) => {
    if (!s?.unicornds_session?.idToken) { console.log('[UnicornDS] Not logged in — Walmart panel not injected'); return; }
    const run = () => setTimeout(() => { scrapeProduct(); injectFloatingPanel(); checkVeroAndDuplicate(); }, 1200);
    if (document.readyState === 'complete') run(); else window.addEventListener('load', run);
  });
}
initWalmart();

let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    document.getElementById('unicornds-float-container')?.remove();
    lastScrapedData = null;
    initWalmart();
  }
}).observe(document, { subtree: true, childList: true });
