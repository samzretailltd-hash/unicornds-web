/**
 * UnicornDS - AliExpress Content Script (ISOLATED world)
 *
 * 3 extraction methods, tried in order:
 *   1. postMessage bridge to injection.js (MAIN world - reads JS vars)
 *   2. Read <script id="__NEXT_DATA__"> tag textContent (works in ISOLATED world!)
 *   3. DOM selectors fallback (title, price, images from HTML)
 */

console.log('[UnicornDS v2.2] AliExpress content script loaded on', window.location.href);

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function isProductPage() {
  return /\/item\/\d+/.test(window.location.pathname);
}

// ═══════════════════════════════════════════════════════
// METHOD 1: INJECTION BRIDGE (postMessage to MAIN world)
// ═══════════════════════════════════════════════════════

function waitForInjectorResponse(tag, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const handler = (event) => {
      // Security (MIN-03): only accept messages from THIS window's own context,
      // not from arbitrary frames/origins, to prevent spoofed scraped data.
      if (event.source !== window) return;
      if (event.origin !== window.location.origin) return;
      if (event.data && event.data.for === tag) {
        clearTimeout(timer);
        window.removeEventListener('message', handler);
        resolve(event.data.data);
      }
    };
    const timer = setTimeout(() => {
      window.removeEventListener('message', handler);
      reject(new Error('timeout'));
    }, timeoutMs);
    window.addEventListener('message', handler);
  });
}

async function tryInjectionBridge() {
  try {
    console.log('[UnicornDS] Trying injection bridge...');
    window.postMessage({ from: 'aliexpress-scraper' }, '*');
    const rawString = await waitForInjectorResponse('aliexpress-scraper', 5000);
    if (!rawString) return null;

    let raw = typeof rawString === 'string' ? JSON.parse(rawString) : rawString;
    const data = raw.data || raw.result || raw;

    if (data.HEADER_IMAGE_PC || data.GLOBAL_DATA || data.productInfoComponent) {
      console.log('[UnicornDS] Injection bridge SUCCESS');
      return buildProductFromRaw(data);
    }
    return null;
  } catch (e) {
    console.log('[UnicornDS] Injection bridge failed:', e.message);
    return null;
  }
}

// ═══════════════════════════════════════════════════════
// METHOD 2: READ <script id="__NEXT_DATA__"> FROM DOM
// Content scripts CAN read DOM element textContent!
// ═══════════════════════════════════════════════════════

async function tryNextDataScript() {
  try {
    console.log('[UnicornDS] Trying __NEXT_DATA__ script tag...');
    const scriptEl = document.querySelector('script#__NEXT_DATA__');
    if (!scriptEl) {
      console.log('[UnicornDS] No __NEXT_DATA__ script tag found');
      return null;
    }

    const json = JSON.parse(scriptEl.textContent);
    const pageProps = json?.props?.pageProps;
    if (!pageProps) return null;

    // AliExpress nests data in various ways
    const initialData = pageProps.initialData || pageProps.data || pageProps;
    const data = initialData.data || initialData.result || initialData;

    if (data.HEADER_IMAGE_PC || data.GLOBAL_DATA || data.productInfoComponent || data.titleModule) {
      console.log('[UnicornDS] __NEXT_DATA__ SUCCESS');
      return buildProductFromRaw(data);
    }

    return null;
  } catch (e) {
    console.log('[UnicornDS] __NEXT_DATA__ failed:', e.message);
    return null;
  }
}

// ═══════════════════════════════════════════════════════
// METHOD 3: DOM SELECTORS FALLBACK
// ═══════════════════════════════════════════════════════

async function tryDOMFallback() {
  try {
    console.log('[UnicornDS] Trying DOM fallback...');

    // Title
    const title = (
      document.querySelector('h1[data-pl="product-title"]')?.textContent ||
      document.querySelectorAll('h1')[1]?.textContent ||
      document.querySelector('.product-title-text')?.textContent ||
      ''
    ).trim();

    if (!title || title.toLowerCase() === 'aliexpress') { console.log('[UnicornDS] DOM: no product title found'); return null; }

    // Price - try multiple selectors
    // AliExpress current price class: price-default--current--HASH
    const priceEl =
      document.querySelector('[class*="price"][class*="current"]') ||
      document.querySelector('.product-price-value') ||
      document.querySelector('[data-pl="product-price"]') ||
      document.querySelector('.uniform-banner-box-price') ||
      document.querySelector('[class*="snow-price"]') ||
      document.querySelector('.product-price-current');
    let priceText = priceEl?.textContent?.trim() || '';
    // If no specific element, try to find any text with price symbols followed by numbers
    // Note: AliExpress uses ￡ (fullwidth pound U+FFE1) not £ (U+00A3)
    if (!priceText) {
      const allPrices = document.querySelectorAll('[class*="price"]');
      for (const p of allPrices) {
        const t = p.textContent.trim();
        if (/[£￡$€]\s*\d+[.,]\d{2}/.test(t)) { priceText = t; break; }
      }
    }
    // Locale-aware parse (EU comma vs UK/US dot). Was: strip non-digits -> €1,43 became 143.
    let price = self.UDSCurrency.parsePrice(priceText, udsDetectSrcCurrency(priceText));
    console.log('[UnicornDS] DOM price:', price, 'from:', priceText?.substring(0, 20));

    // Images - use the shared extraction function
    let images = extractImagesFromDOM();
    console.log('[UnicornDS] DOM fallback images:', images.length);

    // Product ID from URL
    const idMatch = window.location.pathname.match(/\/item\/(\d+)/);
    const productId = idMatch ? idMatch[1] : '';

    // Specs - try multiple selector patterns
    const specs = [];
    // Pattern 1: Modern AliExpress
    document.querySelectorAll('[class*="specification--prop"], [class*="product-specs-item"], [class*="sku-property"]').forEach(row => {
      const key = row.querySelector('[class*="title"], [class*="name"], [class*="label"]')?.textContent?.trim();
      const val = row.querySelector('[class*="desc"], [class*="value"], [class*="detail"]')?.textContent?.trim();
      if (key && val && key.length < 50 && val.length < 200) specs.push({ label: key, value: val });
    });
    // Pattern 2: Table-based specs
    if (specs.length === 0) {
      document.querySelectorAll('table tr, .product-property-item, [class*="attr"] li').forEach(row => {
        const cells = row.querySelectorAll('td, th, span, div');
        if (cells.length >= 2) {
          const key = cells[0]?.textContent?.trim();
          const val = cells[1]?.textContent?.trim();
          if (key && val && key.length < 50 && val.length < 200) specs.push({ label: key, value: val });
        }
      });
    }
    console.log('[UnicornDS] DOM specs found:', specs.length);

    console.log('[UnicornDS] DOM SUCCESS - title:', title.substring(0, 50));

    return {
      title, cleanedTitle: cleanTitle(title), custom_title: cleanTitle(title),
      price, custom_price: '',
      itemID: productId, sku: productId, productId,
      images, main_hd_images: images,
      filteredItemSpecifics: specs, itemSpecifics: specs,
      descriptionText: specs.map(s => s.label + ': ' + s.value).join('\n'),
      description: '', brand: '', mpn: '',
      bullet_points: [], variations: [], skuImagesMap: {},
      source: 'aliexpress', url: window.location.href,
      marketplace: detectMarketplace(),
      stockStatus: { inStock: true, status: 'In stock' },
      scrapedAt: new Date().toISOString(),
    };
  } catch (e) {
    console.error('[UnicornDS] DOM fallback failed:', e);
    return null;
  }
}

// ═══════════════════════════════════════════════════════
// BUILD PRODUCT FROM RAW DATA (methods 1 & 2)
// ═══════════════════════════════════════════════════════

function buildProductFromRaw(data) {
  try {
    let title =
      data.GLOBAL_DATA?.globalData?.subject ||
      data.productInfoComponent?.subject ||
      data.titleModule?.subject ||
      data.title ||
      data.subject ||
      '';

    // Deep search for title in nested structures
    if (!title && typeof data === 'object') {
      for (const key of Object.keys(data)) {
        const val = data[key];
        if (val && typeof val === 'object') {
          if (val.subject) { title = val.subject; break; }
          if (val.title) { title = val.title; break; }
          if (val.globalData?.subject) { title = val.globalData.subject; break; }
        }
      }
    }

    const productId =
      data.GLOBAL_DATA?.globalData?.productId ||
      data.productInfoComponent?.idStr ||
      data.actionModule?.productId ||
      data.commonModule?.productId ||
      extractIdFromUrl();

    let images = data.HEADER_IMAGE_PC?.imagePathList ||
                  data.imageComponent?.imagePathList ||
                  data.imageModule?.imagePathList || [];
    images = images.map(normaliseImageUrl).filter(Boolean);

    let priceString = '';
    try {
      priceString = data.PRICE?.targetSkuPriceInfo?.salePriceString ||
                    data.priceModule?.formatedActivityPrice ||
                    data.priceModule?.formatedPrice || '';
    } catch (e) {}
    const price = parsePrice(priceString);

    const rawSpecs = data.PRODUCT_PROP_PC?.showedProps ||
                      data.productPropComponent?.props ||
                      data.specsModule?.props || [];
    const itemSpecifics = rawSpecs.map(s => ({
      label: s.attrName || '', value: s.attrValue || '',
    })).filter(s => s.label && s.value);

    const brandSpec = itemSpecifics.find(s => s.label.toLowerCase() === 'brand');
    const variations = extractVariations(data);

    if (!title && !productId) return null;

    return {
      title, cleanedTitle: cleanTitle(title), custom_title: cleanTitle(title),
      price, custom_price: '',
      itemID: String(productId), sku: String(productId), productId: String(productId),
      images, main_hd_images: images,
      filteredItemSpecifics: itemSpecifics, itemSpecifics,
      descriptionText: itemSpecifics.map(s => s.label + ': ' + s.value).join('\n'),
      description: '',
      descriptionUrl: data.DESC?.pcDescUrl || data.descriptionModule?.descUrl || '',
      brand: brandSpec?.value || '', mpn: '',
      bullet_points: [], variations, skuImagesMap: data.HEADER_IMAGE_PC?.skuImagesMap || {},
      variantImages: extractVariantImageMap(data),
      source: 'aliexpress', url: window.location.href,
      marketplace: detectMarketplace(),
      stockStatus: { inStock: true, status: 'In stock' },
      scrapedAt: new Date().toISOString(),
    };
  } catch (e) {
    console.error('[UnicornDS] buildProductFromRaw error:', e);
    return null;
  }
}

// ═══════════════════════════════════════════════════════
// MAIN SCRAPE - tries all 3 methods
// ═══════════════════════════════════════════════════════

let lastScrapedData = null;
// Market fee+currency for the seller's TARGET eBay store (filled from calculate_profit).
// Default currency is detected from the marketplace host so US/EU pages don't
// briefly show £ before the profit calc returns.
let UDS_FEE = { rate: 0.128, fixed: 0.30, currency: (function(){try{return self.UDSCurrency.symbolFor(self.UDSCurrency.detectSourceCurrency('', location.hostname));}catch(e){return '£';}})() };
// Currency the AliExpress page prices are written in (source side).
function udsDetectSrcCurrency(sampleText) {
  try { return self.UDSCurrency.detectSourceCurrency(sampleText || '', window.location.hostname); }
  catch (e) { return 'GBP'; }
}

async function scrapeProduct() {
  console.log('[UnicornDS] === SCRAPE START ===');

  // Method 1: Injection bridge
  let product = await tryInjectionBridge();
  if (product) console.log('[UnicornDS] Method 1 (bridge): title=' + !!product.title, 'images=' + (product.images?.length || 0));

  // Method 2: __NEXT_DATA__ script tag
  if (!product) {
    product = await tryNextDataScript();
    if (product) console.log('[UnicornDS] Method 2 (__NEXT_DATA__): title=' + !!product.title, 'images=' + (product.images?.length || 0));
  }

  // Method 3: DOM fallback
  if (!product) {
    product = await tryDOMFallback();
    if (product) console.log('[UnicornDS] Method 3 (DOM): title=' + !!product.title, 'images=' + (product.images?.length || 0));
  }

  // TITLE RECOVERY: bridge found images but no title - get from DOM
  if (product && (!product.title || product.title === '') && product.images && product.images.length > 0) {
    console.log('[UnicornDS v2.2] Got images but no title - getting title from DOM');
    const domTitle = (
      document.querySelector('h1[data-pl="product-title"]')?.textContent ||
      document.querySelectorAll('h1')[1]?.textContent ||
      document.querySelector('.product-title-text')?.textContent ||
      ''
    ).trim();
    if (domTitle && domTitle.toLowerCase() !== 'aliexpress') {
      product.title = domTitle;
      product.cleanedTitle = cleanTitle(domTitle);
      product.custom_title = cleanTitle(domTitle);
      console.log('[UnicornDS v2.2] ✅ DOM title:', domTitle.substring(0, 60));
    }
    // Get SKU from URL
    if (!product.sku) {
      product.sku = extractIdFromUrl();
      product.productId = extractIdFromUrl();
      product.itemID = extractIdFromUrl();
    }
    // Get price from DOM
    if (!product.price) {
      const priceEl = document.querySelector('[class*="price"][class*="current"]') ||
                       document.querySelector('.product-price-value') ||
                       document.querySelector('[data-pl="product-price"]') ||
                       document.querySelector('.uniform-banner-box-price');
      if (priceEl) {
        product.price = self.UDSCurrency.parsePrice(priceEl.textContent, udsDetectSrcCurrency(priceEl.textContent));
        console.log('[UnicornDS] Recovery price:', product.price);
      }
    }
  }

  if (!product || !product.title) {
    console.error('[UnicornDS] No product or title after all methods');
    chrome.runtime.sendMessage({
      type: 'aliexpress_scrape_failed', url: window.location.href,
      reason: 'Could not extract product data',
    });
    return null;
  }

  // ALWAYS supplement missing data from DOM
  // Price from DOM
  if (!product.price || product.price === 0) {
    const priceEl = document.querySelector('[class*="price"][class*="current"]') ||
                     document.querySelector('.product-price-value') ||
                     document.querySelector('[data-pl="product-price"]') ||
                     document.querySelector('.uniform-banner-box-price');
    if (priceEl) {
      product.price = self.UDSCurrency.parsePrice(priceEl.textContent, udsDetectSrcCurrency(priceEl.textContent));
      console.log('[UnicornDS] DOM price supplement:', product.price);
    }
  }

  // Specs from DOM
  if (!product.filteredItemSpecifics || product.filteredItemSpecifics.length === 0) {
    const specs = [];
    document.querySelectorAll('[class*="specification"] [class*="prop"], [class*="sku-property"], [class*="product-specs"]').forEach(row => {
      const key = row.querySelector('[class*="title"], [class*="name"]')?.textContent?.trim();
      const val = row.querySelector('[class*="desc"], [class*="value"]')?.textContent?.trim();
      if (key && val) specs.push({ label: key, value: val });
    });
    if (specs.length > 0) {
      product.filteredItemSpecifics = specs;
      product.itemSpecifics = specs;
      product.descriptionText = specs.map(s => s.label + ': ' + s.value).join('\n');
      console.log('[UnicornDS] DOM specs:', specs.length);
    }
  }

  // Title from DOM
  if (!product.title) {
    product.title = (
      document.querySelector('h1[data-pl="product-title"]')?.textContent ||
      document.querySelector('.product-title-text')?.textContent ||
      document.querySelector('h1')?.textContent || ''
    ).trim();
    product.cleanedTitle = cleanTitle(product.title);
    product.custom_title = cleanTitle(product.title);
  }

  // SKU / product ID from URL
  if (!product.sku) {
    product.sku = extractIdFromUrl();
    product.productId = extractIdFromUrl();
    product.itemID = extractIdFromUrl();
  }
  // ALWAYS supplement with DOM images - JSON only has gallery, DOM has gallery + variant
  const domImages = extractImagesFromDOM();
  if (domImages.length > 0) {
    if (!product.images || product.images.length === 0) {
      // No images at all - use DOM
      product.images = domImages;
      product.main_hd_images = domImages;
      console.log('[UnicornDS] Images from DOM:', domImages.length);
    } else if (domImages.length > product.images.length) {
      // DOM has more (includes variant images) - use DOM instead
      product.images = domImages;
      product.main_hd_images = domImages;
      console.log('[UnicornDS] DOM has more images (' + domImages.length + ' vs ' + product.images.length + ') - using DOM');
    } else {
      console.log('[UnicornDS] Using', product.images.length, 'images from JSON');
    }
  } else {
    console.log('[UnicornDS] DOM scan found 0 images, keeping', product.images?.length || 0, 'from JSON');
  }

  console.log('[UnicornDS] === SCRAPE RESULT ===');
  console.log('[UnicornDS] Title:', product.title?.substring(0, 50));
  console.log('[UnicornDS] Images:', product.images?.length || 0);
  if (product.images?.[0]) console.log('[UnicornDS] First:', product.images[0]);

  // ── Fetch AliExpress rich description from descriptionUrl ──
  // AliExpress lazy-loads description from a separate endpoint. Without this,
  // listings end up with only specs as description (the buildFallbackDescription).
  // Try up to 3 times because the endpoint can be slow/flaky.
  if (product.descriptionUrl && (!product.description || product.description.length < 50)) {
    console.log('[UnicornDS] Fetching description from:', product.descriptionUrl);
    let html = '';
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const u = product.descriptionUrl.startsWith('//') ? 'https:' + product.descriptionUrl : product.descriptionUrl;
        const res = await fetch(u, { credentials: 'omit' });
        if (res.ok) {
          html = await res.text();
          if (html && html.length > 50) {
            console.log('[UnicornDS] ✅ Description fetched (attempt ' + attempt + '):', html.length, 'chars');
            break;
          }
        }
      } catch (e) {
        console.warn('[UnicornDS] Description fetch attempt ' + attempt + ' failed:', e.message);
      }
      // Brief wait before retry
      if (attempt < 3) await new Promise(r => setTimeout(r, 800));
    }
    if (html && html.length > 50) {
      // Strip script tags + AliExpress-specific tracking but keep formatting
      html = html.replace(/<script[\s\S]*?<\/script>/gi, '')
                 .replace(/<style[\s\S]*?<\/style>/gi, '')
                 .replace(/<noscript[\s\S]*?<\/noscript>/gi, '');
      product.description = html;
      product.descriptionAndFeatures = html; // alias used by AI generator
    } else {
      console.log('[UnicornDS] ⚠️ Description fetch failed after 3 attempts — falling back to specs');
    }
  }

  // Record which currency the scraped cost is in, so background can convert to the seller's market.
  try {
    const _sampleEl = document.querySelector('[class*="price"][class*="current"]') || document.querySelector('.product-price-value');
    product.sourceCurrency = udsDetectSrcCurrency(_sampleEl ? _sampleEl.textContent : '');
  } catch (e) { product.sourceCurrency = udsDetectSrcCurrency(''); }
  lastScrapedData = product;
  chrome.runtime.sendMessage({ type: 'aliexpress_product_scraped', data: product });
  updateFloatingButton(product);
  return product;
}

// Extract images from DOM
function extractImagesFromDOM() {
  const images = [];
  const seenHashes = new Set();

  // Product images are on aliexpress-media.com (NOT alicdn.com - those are badges)
  // URL format: https://ae-pic-a1.aliexpress-media.com/kf/HASH.jpg?has_lang=1&ver=2_220x220q75.jpg_.avif
  // Full size:  https://ae-pic-a1.aliexpress-media.com/kf/HASH.jpg

  function isProductImage(src) {
    return src.includes('aliexpress-media.com') || 
           (src.includes('alicdn.com') && src.includes('/kf/'));
  }

  function cleanImageUrl(src) {
    let url = src;
    if (url.startsWith('//')) url = 'https:' + url;

    // For aliexpress-media.com: replace size in query param with 960x960
    // Original: kf/HASH.jpg?has_lang=1&ver=2_220x220q75.jpg_.avif
    // We want:  kf/HASH.jpg?has_lang=1&ver=2_960x960q75.jpg_.webp
    if (url.includes('aliexpress-media.com')) {
      url = url.replace(/\d+x\d+q\d+/g, '960x960q75');
      return url;
    }

    // For alicdn.com: strip size suffixes
    url = url.split('?')[0];
    url = url.replace(/\/(\d+)x(\d+)\.(jpg|jpeg|png|webp)$/i, '.$3');
    url = url.replace(/\.(jpg|jpeg|png)_\d+x\d+\.\w+$/i, '.$1');
    url = url.replace(/_\d+x\d+\.(jpg|jpeg|png|webp)$/i, '');
    return url;
  }

  function addImage(src) {
    if (!src || !isProductImage(src)) return;
    const clean = cleanImageUrl(src);
    if (!clean) return;
    const hash = clean.match(/\/kf\/([^/.?]+)/)?.[1];
    if (hash && seenHashes.has(hash)) return;
    if (hash) seenHashes.add(hash);
    if (!images.includes(clean)) images.push(clean);
  }

  // STEP 1: Product slider images ONLY (scoped to product area, not recommended products)
  // The product slider is inside .pdp-info-left, images in .slider--img containers
  const productSliderSelectors = [
    '.pdp-info-left [class*="slider--img"] img',
    '.main-image--wrap [class*="slider--img"] img',
    '[class*="image-view"] [class*="slider--img"] img',
  ];
  for (const sel of productSliderSelectors) {
    document.querySelectorAll(sel).forEach(el => {
      // Skip video icon images
      if (el.className && el.className.includes('videoIcon')) return;
      const src = el.src || el.dataset?.src;
      if (!src) return;
      // Convert aliexpress-media.com thumbnails to full-size alicdn.com
      const hashMatch = src.match(/\/kf\/([A-Za-z0-9]+\.(?:jpg|jpeg|png))/i);
      if (hashMatch) {
        addImage('https://ae01.alicdn.com/kf/' + hashMatch[1]);
      } else {
        addImage(src);
      }
    });
  }
  console.log('[UnicornDS] Product slider images:', images.length);

  // STEP 2: SKU/variant images (adds any variant thumbnails not already in slider)
  document.querySelectorAll('[class*="sku-item--image"] img').forEach(el => {
    if (el.className && el.className.includes('videoIcon')) return;
    const src = el.src || el.dataset?.src;
    if (!src) return;
    const hashMatch = src.match(/\/kf\/([A-Za-z0-9]+\.(?:jpg|jpeg|png))/i);
    if (hashMatch) {
      addImage('https://ae01.alicdn.com/kf/' + hashMatch[1]);
    } else {
      addImage(src);
    }
  });
  if (images.length > 0) console.log('[UnicornDS] Total after variant images:', images.length);

  // STEP 3: imagePathList from JSON (fallback if DOM found nothing)
  if (images.length === 0) {
    document.querySelectorAll('script').forEach(script => {
      const text = script.textContent || '';
      const match = text.match(/"imagePathList"\s*:\s*\[([^\]]+)\]/);
      if (match) {
        try {
          JSON.parse('[' + match[1] + ']').forEach(u => {
            if (typeof u === 'string') addImage(u);
          });
        } catch (e) {}
      }
    });
    console.log('[UnicornDS] JSON imagePathList fallback:', images.length);
  }

  // STEP 4: Last resort - scan page imgs
  if (images.length === 0) {
    document.querySelectorAll('img').forEach(img => {
      if (img.src && (img.src.includes('aliexpress-media.com') || (img.src.includes('alicdn.com') && img.src.includes('/kf/')))) {
        if (img.naturalWidth > 200 || img.width > 200) {
          addImage(img.src);
        }
      }
    });
    console.log('[UnicornDS] Fallback page scan:', images.length);
  }

  if (images.length > 0) console.log('[UnicornDS] First product image:', images[0]);
  else console.warn('[UnicornDS] NO product images found');
  return images;
}

// ═══════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════

function extractIdFromUrl() {
  const m = window.location.pathname.match(/\/item\/(\d+)/);
  return m ? m[1] : '';
}

function normaliseImageUrl(path) {
  return toFullSizeUrl(path);
}

/**
 * Convert AliExpress image URL to full-size.
 * 
 * Pattern 1: https://ae01.alicdn.com/kf/HASH/154x64.png → /kf/HASH.png (keep original ext)
 * Pattern 2: https://ae01.alicdn.com/kf/HASH.jpg_640x640.jpg → /kf/HASH.jpg
 * Pattern 3: //ae01.alicdn.com/kf/HASH.jpg → https://ae01.alicdn.com/kf/HASH.jpg
 */
function toFullSizeUrl(src) {
  if (!src) return null;
  let url = src;
  if (url.startsWith('//')) url = 'https:' + url;
  else if (!url.startsWith('http')) url = 'https://' + url;

  // For aliexpress-media.com: replace size with 960x960
  if (url.includes('aliexpress-media.com')) {
    url = url.replace(/\d+x\d+q\d+/g, '960x960q75');
    return url;
  }

  // Strip query params
  url = url.split('?')[0];

  // Strip ALL existing size suffixes
  url = url.replace(/\/(\d+x\d+)\.(jpg|jpeg|png|webp)$/i, '');
  url = url.replace(/\.(jpg|jpeg|png)_\d+x\d+\.\w+$/i, '.$1');
  url = url.replace(/_\d+x\d+\.(jpg|jpeg|png|webp)$/i, '');

  // Ensure URL ends with an extension
  if (!/\.(jpg|jpeg|png|webp)$/i.test(url)) {
    url = url + '.jpg';
  }

  return url;
}

function parsePrice(s, currency) {
  // Locale-aware: €1,43 -> 1.43 (was wrongly 143). currency optional ('EUR'/'GBP'...).
  return self.UDSCurrency.parsePrice(s, currency || udsDetectSrcCurrency(typeof s === 'string' ? s : ''));
}

function cleanTitle(t) {
  if (!t) return '';
  return t.replace(/\b(hot\s*sale|free\s*shipping|new\s*arrival|best\s*seller|wholesale|dropship(ping)?)\b/gi, ' ')
          .replace(/[!]{2,}/g, ' ').replace(/\s+/g, ' ').trim();
}

function detectMarketplace() {
  const h = window.location.hostname.toLowerCase();
  if (h.includes('.us')) return 'us';
  if (h.includes('.co.uk')) return 'co_uk';
  if (h.startsWith('de.')) return 'de';
  if (h.startsWith('fr.')) return 'fr';
  return 'com';
}

function extractVariations(data) {
  const variations = [];
  try {
    const skuProps = data.SKU?.skuProperties || data.skuComponent?.productSKUPropertyList || data.skuModule?.productSKUPropertyList || [];
    const propMap = {};
    skuProps.forEach(prop => {
      (prop.skuPropertyValues || []).forEach(val => {
        propMap[prop.skuPropertyId + ':' + val.propertyValueIdLong] = {
          propName: prop.skuPropertyName,
          valueName: val.propertyValueDefinitionName || '',
          image: val.skuPropertyImagePath || val.skuPropertyImageSummPath || '',
        };
      });
    });
    const paths = data.SKU?.skuPaths || [];
    const priceMap = data.PRICE?.skuPriceInfoMap || {};
    paths.forEach(sku => {
      const attrs = (sku.skuAttr || '').split(';').filter(Boolean);
      const props = {};
      let varImage = '';
      attrs.forEach(a => {
        if (propMap[a]) {
          props[propMap[a].propName] = propMap[a].valueName;
          if (propMap[a].image && !varImage) varImage = propMap[a].image;
        }
      });
      variations.push({
        skuId: sku.skuIdStr, properties: props,
        price: priceMap[sku.skuIdStr]?.salePriceString || '',
        salable: sku.salable !== false,
        image: varImage,
      });
    });
  } catch (e) {}
  return variations;
}

function extractVariantImageMap(data) {
  const variantImages = {};
  try {
    // Method 1: skuImagesMap from JSON
    const skuImgMap = data.HEADER_IMAGE_PC?.skuImagesMap || {};
    const skuProps = data.SKU?.skuProperties || data.skuComponent?.productSKUPropertyList || data.skuModule?.productSKUPropertyList || [];

    // Build ID → name mapping for the image property (usually Color)
    const idToName = {};
    skuProps.forEach(prop => {
      (prop.skuPropertyValues || []).forEach(val => {
        idToName[val.propertyValueIdLong] = val.propertyValueDefinitionName || val.propertyValueName || '';
        // Also map the combined id
        idToName[prop.skuPropertyId + ':' + val.propertyValueIdLong] = val.propertyValueDefinitionName || val.propertyValueName || '';
      });
    });

    // Map skuImagesMap IDs to names with image URLs
    for (const [key, urls] of Object.entries(skuImgMap)) {
      const name = idToName[key] || key;
      if (name && Array.isArray(urls) && urls.length > 0) {
        variantImages[name] = urls.map(u => {
          if (u.startsWith('//')) return 'https:' + u;
          return u;
        });
      }
    }

    // Method 2: SKU property images
    if (Object.keys(variantImages).length === 0) {
      skuProps.forEach(prop => {
        (prop.skuPropertyValues || []).forEach(val => {
          const imgPath = val.skuPropertyImagePath || val.skuPropertyImageSummPath;
          const name = val.propertyValueDefinitionName || val.propertyValueName || '';
          if (imgPath && name) {
            const url = imgPath.startsWith('//') ? 'https:' + imgPath : imgPath;
            variantImages[name] = [url];
          }
        });
      });
    }

    // Method 3: DOM swatch images
    if (Object.keys(variantImages).length === 0) {
      document.querySelectorAll('[class*="sku-item--image"] img').forEach(el => {
        if (el.className && el.className.includes('videoIcon')) return;
        const src = el.src || el.dataset?.src;
        const name = el.alt || el.title || el.closest('[title]')?.title || '';
        if (src && name) {
          const url = src.startsWith('//') ? 'https:' + src : src;
          if (!variantImages[name]) variantImages[name] = [];
          variantImages[name].push(url);
        }
      });
    }
  } catch (e) { console.warn('[UnicornDS] AliExpress variant image error:', e.message); }
  console.log('[UnicornDS] AliExpress variant images:', Object.keys(variantImages).length, 'variants');
  return variantImages;
}

// ═══════════════════════════════════════════════════════
// FLOATING BUTTON
// ═══════════════════════════════════════════════════════

function injectFloatingButton() {
  if (!isProductPage() || document.getElementById('unicornds-float-container')) return;

  const c = document.createElement('div');
  c.id = 'unicornds-float-container';
  c.innerHTML = `
    <style>
      #unicornds-float-container { position:fixed; bottom:24px; right:24px; z-index:999999; font-family:-apple-system,sans-serif; width:320px; }
      #unicornds-panel { background:rgba(15,15,26,0.97); border:1px solid #2a2a4a; border-radius:16px; padding:14px; box-shadow:0 8px 32px rgba(0,0,0,0.5); }
      #unicornds-list-btn { display:flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:12px;
        background:linear-gradient(135deg,#7B2FBE,#9B59B6); color:#fff; border:none; border-radius:10px;
        font-size:14px; font-weight:700; cursor:pointer; box-shadow:0 4px 20px rgba(123,47,190,0.4); transition:all 0.2s; }
      #unicornds-list-btn:hover { transform:translateY(-1px); }
      #unicornds-list-btn.loading { opacity:0.7; pointer-events:none; }
      .uds-row { display:flex; gap:6px; align-items:center; margin-top:8px; }
      .uds-input { flex:1; padding:6px 8px; background:#1a1a2e; border:1px solid #3a3a5a; border-radius:6px; color:#FFD700; font-size:13px; font-weight:600; text-align:center; }
      .uds-label { font-size:11px; color:#888; white-space:nowrap; }
      .uds-btn-sm { padding:8px; width:100%; background:#1a1a3e; border:1px solid #3a3a5a; border-radius:8px; color:#ddd; font-size:12px; font-weight:600; cursor:pointer; text-align:center; margin-top:6px; transition:all 0.2s; }
      .uds-btn-sm:hover { background:#2a2a5a; border-color:#7C3AED; }
      .uds-btn-sm.active { background:#7C3AED; border-color:#9B59B6; color:#fff; }
      #unicornds-titles-list { margin-top:8px; max-height:200px; overflow-y:auto; }
      .uds-title-item { padding:8px 10px; background:#0d1b3e; border:1px solid #2a2a4a; border-radius:6px; margin-bottom:4px; cursor:pointer; font-size:12px; color:#ddd; transition:all 0.2s; }
      .uds-title-item:hover { border-color:#7C3AED; }
      .uds-title-item.selected { border-color:#FFD700; background:#1a1a3e; }
      .uds-title-item .chars { font-size:10px; color:#666; margin-top:2px; }
      #unicornds-status { margin-top:8px; padding:8px; background:#1a1a2e; border-radius:6px; color:#fff; font-size:11px; text-align:center; display:none; }
      #unicornds-status.visible { display:block; }
      .uds-collapse-btn { position:absolute; top:-12px; right:10px; background:#2a2a4a; border:1px solid #3a3a5a; color:#aaa; border-radius:50%; width:24px; height:24px; font-size:12px; cursor:pointer; display:flex; align-items:center; justify-content:center; }
      .uds-badges { display:flex; gap:4px; margin-bottom:6px; flex-wrap:wrap; }
      .uds-badge-vero { padding:4px 8px; background:#DC2626; border-radius:6px; font-size:11px; color:#fff; font-weight:700; animation:uds-pulse 1.5s infinite; }
      .uds-badge-safe { padding:4px 8px; background:#059669; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-dup { padding:4px 8px; background:#D97706; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      .uds-badge-new { padding:4px 8px; background:#2563EB; border-radius:6px; font-size:11px; color:#fff; font-weight:700; }
      @keyframes uds-pulse { 0%,100% { opacity:1; } 50% { opacity:0.6; } }
    </style>
    <div id="unicornds-panel" style="position:relative">
      <button class="uds-collapse-btn">−</button>
      <div id="unicornds-panel-body">
        <div id="unicornds-badges" class="uds-badges"></div>
        <button id="unicornds-list-btn"><span style="font-size:16px">🦄</span><span id="unicornds-btn-text">List on eBay</span></button>
        <div class="uds-row">
          <span class="uds-label">Sell</span><input type="text" id="unicornds-price-input" class="uds-input" placeholder="0.00" style="flex:1"/>
          <span class="uds-label">Ad%</span><input type="text" id="unicornds-promoted-input" class="uds-input" value="10.0" style="width:50px;flex:none"/>
        </div>
        <div id="unicornds-profit-display" style="background:#0f0e2a;border:1px solid #2a2a4a;border-radius:6px;padding:6px 10px;margin:4px 0;font-size:10px;color:#a5a0cc;display:none;">
          <div style="display:flex;justify-content:space-between;margin-bottom:2px;">
            <span>Cost: <span id="uds-cost" style="color:#e0d8ff">£0.00</span></span>
            <span>Fees: <span id="uds-fees" style="color:#F59E0B">£0.00</span></span>
            <span>Profit: <span id="uds-profit" style="color:#10B981;font-weight:700">£0.00 (0%)</span></span>
          </div>
        </div>
        <button class="uds-btn-sm" id="unicornds-check-ebay" style="background:#1e3a8a;border-color:#3b82f6;color:#fff">🔍 Check on eBay</button>
        <button class="uds-btn-sm" id="unicornds-gen-titles">✨ Generate AI Titles</button>
        <button class="uds-btn-sm" id="unicornds-add-bulk" style="background:#059669;border-color:#10B981;color:#fff">📋 Add to Bulk Lister</button>
        <div id="unicornds-titles-list"></div>
        <div id="unicornds-status"></div>
      </div>
    </div>`;
  document.body.appendChild(c);
  document.getElementById('unicornds-list-btn').addEventListener('click', handleListOnEbay);
  document.getElementById('unicornds-gen-titles').addEventListener('click', generateTitlesInline);
  document.getElementById('unicornds-check-ebay').addEventListener('click', handleCheckOnEbay);
  
  // Live profit breakdown updater
  function updateProfitDisplay() {
    const sellPrice = parseFloat(document.getElementById('unicornds-price-input')?.value) || 0;
    const adRate = parseFloat(document.getElementById('unicornds-promoted-input')?.value) || 0;
    const costPrice = lastScrapedData?.price || 0;
    const profitDiv = document.getElementById('unicornds-profit-display');
    if (!profitDiv || costPrice <= 0 || sellPrice <= 0) { if (profitDiv) profitDiv.style.display = 'none'; return; }
    
    // Show the SAME currency AliExpress shows (no conversion — seller is single-currency).
    const srcCur = (lastScrapedData && lastScrapedData.sourceCurrency) || udsDetectSrcCurrency('');
    const cur = self.UDSCurrency.symbolFor(srcCur);
    const ebayFVF = (sellPrice * UDS_FEE.rate) + UDS_FEE.fixed;
    const promoFee = sellPrice * (adRate / 100);
    const totalFees = ebayFVF + promoFee;
    const profit = sellPrice - costPrice - totalFees;
    const profitPct = costPrice > 0 ? (profit / costPrice * 100) : 0;

    document.getElementById('uds-cost').textContent = cur + costPrice.toFixed(2);
    document.getElementById('uds-fees').textContent = cur + totalFees.toFixed(2);
    const profitEl = document.getElementById('uds-profit');
    profitEl.textContent = cur + profit.toFixed(2) + ' (' + profitPct.toFixed(0) + '%)';
    profitEl.style.color = profit > 0 ? '#10B981' : '#EF4444';
    profitDiv.style.display = 'block';
  }
  
  document.getElementById('unicornds-price-input').addEventListener('input', updateProfitDisplay);
  document.getElementById('unicornds-promoted-input').addEventListener('input', updateProfitDisplay);
  setTimeout(updateProfitDisplay, 500);
  document.getElementById('unicornds-add-bulk').addEventListener('click', () => {
    const url = window.location.href;
    const btn = document.getElementById('unicornds-add-bulk');
    chrome.storage.local.get('bulk_links', s => {
      let existing = s.bulk_links || '';
      if (existing.includes(url.split('?')[0].split('.html')[0])) {
        btn.textContent = '⚠️ Already Added';
        setTimeout(() => { btn.textContent = '📋 Add to Bulk Lister'; }, 2000);
        return;
      }
      existing = existing.trim();
      if (existing) existing += '\n';
      existing += url.split('?')[0];
      chrome.storage.local.set({ bulk_links: existing }, () => {
        const count = existing.split('\n').filter(l => l.trim()).length;
        btn.textContent = '✅ Added! (' + count + ' total)';
        btn.style.background = '#7C3AED';
        setTimeout(() => { btn.textContent = '📋 Add to Bulk Lister'; btn.style.background = '#059669'; }, 2000);
      });
    });
  });
  document.querySelector('.uds-collapse-btn').addEventListener('click', function() {
    const body = document.getElementById('unicornds-panel-body');
    body.hidden = !body.hidden;
    this.textContent = body.hidden ? '+' : '−';
  });
}

// ── Generate titles inline on the AliExpress page ───────
function handleCheckOnEbay() {
  const btn = document.getElementById('unicornds-check-ebay');
  if (!btn) return;
  const originalText = btn.textContent;

  // Get product data
  const title = lastScrapedData?.title || lastScrapedData?.cleanedTitle || '';
  if (!title || title.length < 5) {
    btn.textContent = '⚠️ Scrape product first';
    btn.style.background = '#7f1d1d';
    setTimeout(() => { btn.textContent = originalText; btn.style.background = '#1e3a8a'; }, 3000);
    return;
  }

  // Clean AliExpress title for eBay search
  // Remove common Chinese seller spam words and numbers
  let query = title
    .replace(/\d+\s*(pcs?|pieces?|set|lot|pack)\b/gi, ' ')
    .replace(/\b(hot|sale|new|free shipping|dropshipping|wholesale|in stock|fast)\b/gi, ' ')
    .replace(/\b(high quality|best price|top|popular|latest|original)\b/gi, ' ')
    .replace(/\b(for|with|and|the|from)\b/gi, ' ')
    .replace(/[|\-–—,:;\/\\()[\]{}'"!@#$%^&*+=~`]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Take first 5 meaningful words (skip short words)
  const words = query.split(/\s+/).filter(w => w.length > 2).slice(0, 5);
  query = words.join(' ');

  if (!query || query.length < 5) {
    btn.textContent = '⚠️ Title too short';
    setTimeout(() => { btn.textContent = originalText; }, 3000);
    return;
  }

  btn.textContent = '🔍 Searching...';

  chrome.storage.local.get(['domain', 'unicornds_primary_market'], (s) => {
    const marketToDomain = {
      'com':'com', 'co_uk':'co.uk', 'de':'de', 'com_au':'com.au',
      'ca':'ca', 'fr':'fr', 'it':'it', 'es':'es',
    };
    const domain = s.domain || marketToDomain[s.unicornds_primary_market] || 'co.uk';
    const url = `https://www.ebay.${domain}/sch/i.html?_nkw=${encodeURIComponent(query)}&LH_ItemCondition=1000&_sop=12`;
    chrome.runtime.sendMessage({ type: 'openNewTab', url, options: { active: true } });
    btn.textContent = '✅ Searched: "' + query.substring(0, 30) + '..."';
    setTimeout(() => { btn.textContent = originalText; btn.style.background = '#1e3a8a'; }, 4000);
  });
}

async function generateTitlesInline() {
  const btn = document.getElementById('unicornds-gen-titles');
  btn.textContent = '⏳ Generating...';
  btn.classList.add('active');

  let data = lastScrapedData;
  if (!data) data = await scrapeProduct();
  if (!data?.title) { btn.textContent = '✨ Generate AI Titles'; btn.classList.remove('active'); return; }

  const specs = (data.filteredItemSpecifics || []).map(s => s.label + ': ' + s.value).join(', ');

  // Localize preview titles to the seller's eBay marketplace language (matches the real listing).
  const _mkt = await new Promise(r => chrome.storage.local.get('unicornds_primary_market', x => r(x.unicornds_primary_market || detectMarketplace() || 'co_uk')));
  const _langMap = { de:'German', at:'German', ch:'German', fr:'French', be:'French', it:'Italian', es:'Spanish', nl:'Dutch' };
  const _lang = _langMap[_mkt];
  const _langLine = _lang ? '\nWrite ALL titles in ' + _lang + '. Translate from the source language if needed. Keep universal terms (LED, USB, Bluetooth) unchanged.\n' : '';

  chrome.runtime.sendMessage({
    type: 'call_openai',
    systemPrompt: 'You are an eBay SEO expert. Generate 5 optimized eBay listing titles.\n' +
      'Rules: max 80 chars each, remove Chinese brands, remove "1pc/Hot Sale/Free Shipping",\n' +
      'keep material/size/quantity/features, Title Case, no emojis.\n' +
      'First title should be the BEST.\n' + _langLine +
      'Return JSON: {"titles": ["t1","t2","t3","t4","t5"]}',
    userMessage: 'Product: ' + data.title + (specs ? '\nSpecs: ' + specs : ''),
    jsonMode: true,
  }, (resp) => {
    btn.textContent = '✨ Generate AI Titles';
    btn.classList.remove('active');

    if (!resp?.result) { showStatus('AI failed - check API key', true); return; }

    try {
      const parsed = JSON.parse(resp.result);
      const titles = parsed.titles || [];
      const list = document.getElementById('unicornds-titles-list');
      list.innerHTML = '';

      titles.forEach((title, i) => {
        const div = document.createElement('div');
        div.className = 'uds-title-item' + (i === 0 ? ' selected' : '');
        div.innerHTML = (i === 0 ? '⭐ ' : '') + title + '<div class="chars">' + title.length + '/80</div>';
        div.onclick = () => {
          list.querySelectorAll('.uds-title-item').forEach(d => d.classList.remove('selected'));
          div.classList.add('selected');
          // Save selected title
          if (lastScrapedData) {
            lastScrapedData.custom_title = title;
            lastScrapedData.cleanedTitle = title;
          }
          showStatus('✅ Title selected: ' + title.substring(0, 40) + '...');
        };
        list.appendChild(div);
      });

      // Auto-select first (best) title
      if (titles[0] && lastScrapedData) {
        lastScrapedData.custom_title = titles[0];
        lastScrapedData.cleanedTitle = titles[0];
      }
    } catch (e) {
      showStatus('Parse error', true);
    }
  });
}

function updateFloatingButton(data) {
  if (!data) return;
  // Use background.js shared pricing module instead of duplicating fee tables (Fixes C1)
  const costPrice = data.price || 0;
  if (costPrice <= 0) return;

  chrome.runtime.sendMessage({ type: 'calculate_profit', costPrice, source: 'aliexpress', sourceCurrency: data.sourceCurrency }, resp => {
    if (resp?.profit) {
      // Cache the seller's target-market fee + currency for the live profit display.
      const srcSym = self.UDSCurrency.symbolFor(data.sourceCurrency);
      if (resp.profit.feeRate != null) {
        UDS_FEE = { rate: resp.profit.feeRate, fixed: resp.profit.feeFixed, currency: srcSym };
      }
      const priceEl = document.getElementById('unicornds-price-input');
      if (priceEl) priceEl.value = resp.profit.sellPrice.toFixed(2);

      // Currency label = the currency shown on AliExpress
      const labelEl = document.querySelector('.uds-label');
      if (labelEl && labelEl.textContent.includes('Sell')) {
        labelEl.textContent = 'Sell ' + srcSym;
      }
    }
  });

  // Update Ad% from settings
  chrome.storage.local.get(['unicornds_promo_rate_ali', 'unicornds_promo_rate', 'unicornds_ad_rate'], s => {
    const promoRate = [s.unicornds_promo_rate_ali, s.unicornds_promo_rate, s.unicornds_ad_rate].map(v => parseFloat(v)).find(v => !isNaN(v)) ?? 0;
    const adEl = document.getElementById('unicornds-promoted-input');
    if (adEl && adEl.value === '2.0') adEl.value = promoRate.toFixed(1);
  });
}

function showStatus(t, err) {
  const el = document.getElementById('unicornds-status');
  if (!el) return;
  el.textContent = t;
  el.style.background = err ? 'rgba(231,76,60,0.9)' : 'rgba(0,0,0,0.85)';
  el.classList.add('visible');
  if (!err) setTimeout(() => el.classList.remove('visible'), 5000);
}

async function handleListOnEbay() {
  const btn = document.getElementById('unicornds-list-btn');
  const btnText = document.getElementById('unicornds-btn-text');
  if (!btn || btn.classList.contains('loading')) return;

  btn.classList.add('loading');
  btnText.textContent = 'Scraping...';

  let data = lastScrapedData;
  if (!data) data = await scrapeProduct();

  if (!data?.title) {
    showStatus('Scrape failed', true);
    btn.classList.remove('loading');
    btnText.textContent = 'List on eBay';
    return;
  }

  const productData = {
    title: data.title, cleanedTitle: data.cleanedTitle, custom_title: data.cleanedTitle,
    images: data.images, main_hd_images: data.images,
    price: data.price, custom_price: document.getElementById('unicornds-price-input')?.value || '',
    sku: data.sku, source: 'aliexpress', url: data.url, sourceCurrency: data.sourceCurrency,
    description: data.description, descriptionText: data.descriptionText,
    bullet_points: [], filteredItemSpecifics: data.filteredItemSpecifics,
    brand: data.brand, listingType: 'paid', variations: data.variations,
    promoted_listing_ad_rate: document.getElementById('unicornds-promoted-input')?.value || '0',
  };

  // SAFETY CHECK: Block listing if cost or sell price is 0
  const costCheck = parseFloat(data.price) || 0;
  const sellCheck = parseFloat(productData.custom_price) || 0;
  if (costCheck <= 0) {
    showStatus('⚠️ Cost price is ' + UDS_FEE.currency + '0 — cannot list. Check the product page has a price.', true);
    btn.classList.remove('loading');
    btnText.textContent = 'List on eBay';
    return;
  }
  if (sellCheck <= 0) {
    showStatus('⚠️ Sell price is empty — enter a sell price first.', true);
    btn.classList.remove('loading');
    btnText.textContent = 'List on eBay';
    return;
  }
  if (sellCheck < costCheck) {
    const _sym = self.UDSCurrency.symbolFor(data.sourceCurrency);
    if (!confirm('⚠️ Sell price (' + _sym + sellCheck.toFixed(2) + ') is BELOW cost (' + _sym + costCheck.toFixed(2) + '). You will LOSE money. List anyway?')) {
      btn.classList.remove('loading');
      btnText.textContent = 'List on eBay';
      return;
    }
  }

  btnText.textContent = 'Opening eBay...';
  chrome.runtime.sendMessage({ type: 'list_to_ebay', product_data: productData }, res => {
    if (res?.success) {
      showStatus('✓ eBay tab opened!');
      btnText.textContent = '✓ Started';
      setTimeout(() => { btn.classList.remove('loading'); btnText.textContent = 'List on eBay'; }, 3000);
    } else if (res?.blocked) {
      // Not logged in or tier blocked — show clear message
      showStatus('🔒 ' + (res.error || 'Login required'), true);
      btn.classList.remove('loading');
      btnText.textContent = '🔒 Login First';
      setTimeout(() => { btnText.textContent = 'List on eBay'; }, 5000);
    } else {
      showStatus('Failed: ' + (res?.error || 'Unknown'), true);
      btn.classList.remove('loading');
      btnText.textContent = 'List on eBay';
    }
  });
}

// ═══════════════════════════════════════════════════════
// MESSAGES
// ═══════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'scrape_aliexpress_product') {
    scrapeProduct()
      .then(d => sendResponse({ success: !!d, data: d }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }
  if (msg.type === 'get_aliexpress_product_id') {
    sendResponse({ productId: extractIdFromUrl() });
  }
});

// ═══════════════════════════════════════════════════════
// SPA NAVIGATION
// ═══════════════════════════════════════════════════════

let lastUrl = window.location.href;
const obs = new MutationObserver(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href;
    if (isProductPage()) {
      lastScrapedData = null;
      sleep(3000).then(() => { scrapeProduct(); injectFloatingButton(); checkVeroAndDuplicateAE(); });
    }
  }
});
if (document.body) obs.observe(document.body, { childList: true, subtree: true });

// ═══════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════

if (isProductPage()) {
  chrome.runtime.sendMessage({ type: 'page-loaded-and-stable' });
  (async () => {
    // Auth check — don't inject panel if not logged in
    const _s = await new Promise(r => chrome.storage.local.get('unicornds_session', r));
    if (!_s?.unicornds_session?.idToken) {
      console.log('[UnicornDS] Not logged in — AliExpress panel not injected');
      return;
    }
    await sleep(3000);
    await scrapeProduct();
    injectFloatingButton();
    checkVeroAndDuplicateAE();
  })();
}

// ═══════════════════════════════════════════════════════
// VERO + DUPLICATE CHECK (AliExpress)
// ═══════════════════════════════════════════════════════
async function checkVeroAndDuplicateAE() {
  await sleep(500);
  const badges = document.getElementById('unicornds-badges');
  if (!badges) return;
  if (badges.children.length > 0) return; // already checked

  const title = document.querySelector('h1')?.textContent?.trim() || '';
  const sku = extractIdFromUrl();

  // VERO check
  try {
    const veroEnabled = await getStorageValAE('unicornds_vero_enabled');
    if (veroEnabled !== false) {
      let veroBrands = await getStorageValAE('unicornds_vero_brands');
      if (!veroBrands || !veroBrands.length) {
        try {
          const resp = await fetch(chrome.runtime.getURL('data/VeroList.txt'));
          const text = await resp.text();
          veroBrands = text.split('\n').map(b => b.trim().toLowerCase()).filter(Boolean);
          chrome.storage.local.set({ unicornds_vero_brands: veroBrands });
        } catch (e) { veroBrands = []; }
      }

      if (veroBrands.length) {
        const titleLower = title.toLowerCase().replace(/[-–—]/g, ' ');
        // Word-boundary match (was substring: "mac" wrongly matched "machine"/"macro").
        // Very short brand words are skipped here because AliExpress titles have no
        // reliable brand field -- they would fire constantly on ordinary words.
        // AliExpress has no reliable brand field, so ambiguous brand words are only
        // treated as VERO when the title is NOT an accessory ("for X", "case", "dock").
        const UDS_AMBIGUOUS = ['ammo','apple','boba','boss','coach','dawn','dove','downy','elk','era','gain','ivory','joy','mac','olay','puma','sap','tide'];
        const UDS_ACCESSORY = ['for','fits','compatible','works with','suitable for','mount','case','cover','strap','band','holder','stand','bracket','bag','pouch','sleeve','protector','guard','bumper','cable','charger','adapter','dock','cradle','hub','replacement','aftermarket','generic','tripod','filter','lens','cap','remote'];
        const udsIsAccessory = UDS_ACCESSORY.some(w => titleLower.includes(w));
        const isVero = veroBrands.some(v => {
          const vLower = v.replace(/[-–—]/g, ' ');
          if (vLower.includes(' ')) return titleLower.includes(vLower);
          try {
            const escaped = vLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const hit = new RegExp('\\b' + escaped + '\\b', 'i').test(titleLower);
            if (!hit) return false;
            if (UDS_AMBIGUOUS.indexOf(vLower) !== -1 && udsIsAccessory) return false;
            return true;
          } catch { return titleLower.includes(vLower); }
        });
        if (isVero) {
          badges.innerHTML += '<span class="uds-badge-vero">⚠️ VERO BRAND</span>';
          console.log('[UnicornDS] ⚠️ VERO detected in title');
        } else {
          badges.innerHTML += '<span class="uds-badge-safe">✅ Not VERO</span>';
        }
      }
    }
  } catch (e) {}

  // Duplicate check
  try {
    let skuList = await getStorageValAE('unicornds_listed_skus') || [];
    if (skuList.includes(sku)) {
      badges.innerHTML += '<span class="uds-badge-dup">⚠️ ALREADY LISTED</span>';
    } else {
      badges.innerHTML += '<span class="uds-badge-new">🆕 New Product</span>';
    }
  } catch (e) {}
}

function getStorageValAE(key) {
  return new Promise(r => chrome.storage.local.get(key, s => r(s[key])));
}
