# UnicornDS — Changelog

## v7.23.0 — 21 Jun 2026
### Added
- **eBay UK restricted-words protection**: built-in block-words list (official eBay UK export, updated 31 May 2026 — 1,197 terms). Listings containing high-risk words (perfume, batteries, baby items, supplements, tools, etc.) are flagged before listing so you can edit or skip them, reducing blocked/removed listings.
- Two protection levels: **Protective** (default, broadest) and **General**. Optional hard-block mode.


All notable changes to the UnicornDS Chrome extension are documented here.

## v7.22.0 — 21 June 2026

### ✨ New
- **Smarter, higher-converting eBay descriptions.** The AI description generator now produces a structured, mobile-first layout: a benefit strip, a clean specifications table, a compatibility/size table, a "Why buy from us" comparison table, and a short buyer FAQ — all proven to lift conversion.
- **Localized trust & support per marketplace.** Every listing ends with a branded delivery / returns / support row in the buyer's own language and region — 🇬🇧 UK support, 🇺🇸 US support, 🇩🇪 Deutschland-Support, 🇫🇷 Support France, and more — matched to the eBay market you sell on.
- **Built-in eBay compliance guard.** A sanitizer strips any banned content (JavaScript, forms, iframes, event handlers) before a description is posted, so listings can't be hidden for active-content violations.

### ⚙️ Notes
- Support-badge wording is configurable — set it to buyer-protection wording if you don't offer live local-language support.

## v7.21.0 — 21 June 2026

### ✨ New
- **Walmart product variations** — size, colour and style options now import automatically, each with its own price and image (multi-variant eBay listings instead of a single variant).
- **Walmart strict mode** — only list products **sold *and shipped* by Walmart.com**. Third-party marketplace sellers (including "Fulfilled by Walmart" / WFS) are detected and blocked, so you avoid unreliable stock, price swings and nested dropshippers. Third-party items are skipped in the product hunter too.
- **Multi-currency support** — correct symbols and decimals for €, $, CHF and C$. Fixes European comma prices (e.g. `€1,43` was being read as `143`).
- **Native-language listings** — titles and descriptions are written in the marketplace's language automatically (German for .de, French for .fr, and so on), based on the eBay market you sell on.

### 🛠 Order Manager fixes
- **Delivered orders now show correctly** — they were getting stuck on "pending" because the status check read dispatch text before delivery. Delivered is now detected first, and re-syncing promotes existing orders to **Completed** when eBay marks them delivered.
- **All your orders import reliably** — orders are now saved progressively during a sync, so a slow or interrupted sync no longer loses everything. Rows that were previously dropped are now kept.
- **More accurate earnings** — the per-order earnings limit was raised (30 → 60 per sync, orders missing earnings fetched first), and the amount parser was fixed so totals over £1,000 are read correctly (e.g. `£1,234.56` is no longer read as `£1.23`).

### ⚙️ Under the hood
- Added eBay fee rates for Austria, Belgium, Ireland and Switzerland (AT, BE, IE, CH).
- Security and stability hardening; quieter console output in production.

---

## v7.20.0 — Previous release
- Walmart support (beta), order count badge on the popup, and earlier improvements.
