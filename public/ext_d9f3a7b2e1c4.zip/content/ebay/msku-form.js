/**
 * UnicornDS - MSKU Variation Form
 * Runs on: bulkedit.ebay.co.uk/msku* (inside iframe dialog on listing form)
 *
 * Flow:
 *   1. Reads variation data from chrome.storage (set by listing-form.js)
 *   2. Clicks "+ Add" -> UNCHECKS all existing -> checks "Add your own" -> types "MNP" -> Save
 *   3. Clicks MNP tag -> for each variant: types name in input -> clicks Add
 *   4. Clicks "Continue" -> fills price/qty/SKU/EAN per row
 *   5. Sets photos to "Use default photos"
 *   6. Clicks "Save and close" -> signals done via chrome.storage
 */

if (!window.__unicornds_msku_loaded) {
window.__unicornds_msku_loaded = true;

console.log('[UnicornDS] msku-form.js loaded on', window.location.href.substring(0, 80));

const sleep = ms => new Promise(r => setTimeout(r, ms));

function fireEvents(el) {
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

function setInput(el, value) {
  el.focus();
  el.value = value;
  fireEvents(el);
}

// Check if data was stored by listing-form.js
chrome.storage.local.get('unicornds_msku_data', async (s) => {
  if (s.unicornds_msku_data) {
    const data = s.unicornds_msku_data;
    console.log('[UnicornDS] MSKU: Found stored data,', data.variations.length, 'variations');
    console.log('[UnicornDS] MSKU: Variant images:', Object.keys(data.variantImages || {}).length, 'variants');
    chrome.storage.local.remove('unicornds_msku_data');
    await sleep(2000);
    await fillVariations(data);
  } else {
    console.log('[UnicornDS] MSKU: No stored data found, waiting...');
  }
});

// Fallback: listen for direct messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'fill_msku_variations') {
    console.log('[UnicornDS] MSKU: Received message with', msg.variations.length, 'variations');
    fillVariations({ variations: msg.variations, variantImages: msg.variantImages || {}, price: msg.price, quantity: msg.quantity, sku: msg.sku });
    sendResponse({ received: true });
  }
});

async function fillVariations(data) {
  const variations = data.variations;
  const sellPrice = data.price;
  const quantity = data.quantity;
  const baseSku = data.sku;
  console.log('[UnicornDS] MSKU: === Starting variation fill ===');
  console.log('[UnicornDS] MSKU: Price:', sellPrice, 'Qty:', quantity, 'SKU:', baseSku);
  console.log('[UnicornDS] MSKU: Variations:', variations.map(v => v.name).join(', '));

  await sleep(2000);

  // =======================================================
  // STEP 1: Click "+ Add" to open attribute selector popup
  // =======================================================
  const addBtn = Array.from(document.querySelectorAll('a, button, span')).find(el => {
    const t = el.textContent.trim();
    return t === '+ Add';
  });
  if (addBtn) {
    addBtn.click();
    console.log('[UnicornDS] MSKU: Clicked + Add');
    await sleep(1500);
  }

  // =======================================================
  // STEP 2: UNCHECK all pre-selected attribute checkboxes
  // Then check ONLY "Add your own attribute" + type "MNP"
  // =======================================================

  // First: uncheck ALL existing attribute checkboxes
  const allCheckboxes = document.querySelectorAll('input[type="checkbox"]');
  for (const cb of allCheckboxes) {
    const label = cb.closest('label') || cb.parentElement;
    const labelText = label ? label.textContent.trim() : '';
    // Skip the "Add your own" checkbox - we'll handle it separately
    if (labelText.includes('Add your own')) continue;
    if (cb.checked) {
      cb.click();
      console.log('[UnicornDS] MSKU: Unchecked "' + labelText.substring(0, 30) + '"');
      await sleep(200);
    }
  }

  // Now check "Add your own attribute"
  let ownAttrCb = null;
  for (const cb of allCheckboxes) {
    const label = cb.closest('label') || cb.parentElement;
    if (label && label.textContent.includes('Add your own')) {
      ownAttrCb = cb;
      break;
    }
  }
  if (ownAttrCb && !ownAttrCb.checked) {
    ownAttrCb.click();
    console.log('[UnicornDS] MSKU: Checked "Add your own attribute"');
    await sleep(500);
  }

  // Type "MNP" in the custom attribute input
  const customInput = document.querySelector('#msku-custom-parent-attribute-input');
  if (customInput) {
    setInput(customInput, 'MNP');
    console.log('[UnicornDS] MSKU: Typed "MNP" in attribute input');
  } else {
    // Fallback: find text input near "Add your own" area
    const allInputs = document.querySelectorAll('input[type="text"]');
    for (const inp of allInputs) {
      const parent = inp.closest('div');
      if (parent && (parent.textContent.includes('unique attribute') || parent.textContent.includes('Add your own'))) {
        setInput(inp, 'MNP');
        console.log('[UnicornDS] MSKU: Typed "MNP" in attribute input (fallback)');
        break;
      }
    }
  }
  await sleep(500);

  // Click Save
  const saveBtn = Array.from(document.querySelectorAll('button')).find(b =>
    b.textContent.trim() === 'Save'
  );
  if (saveBtn) {
    saveBtn.click();
    console.log('[UnicornDS] MSKU: Clicked Save for attribute');
    await sleep(2000);
  }

  // =======================================================
  // STEP 3: Click on MNP tag to make sure its options show
  // =======================================================
  // Find and click the MNP attribute tag so its Options section appears
  const attrTags = document.querySelectorAll('[class*="msku-parent-tag"], [class*="attribute"] a, [class*="attribute"] button, [class*="attribute"] span');
  for (const tag of attrTags) {
    if (tag.textContent.trim().includes('MNP')) {
      tag.click();
      console.log('[UnicornDS] MSKU: Clicked MNP attribute tag');
      await sleep(1000);
      break;
    }
  }
  // Also try clicking any element that contains just "MNP"
  if (!document.querySelector('[class*="msku-parent-tag"][class*="select"]')) {
    const allElements = document.querySelectorAll('a, button, span, li, div');
    for (const el of allElements) {
      if (el.textContent.trim() === 'MNP' || el.textContent.trim() === 'MNP x') {
        el.click();
        console.log('[UnicornDS] MSKU: Clicked MNP element');
        await sleep(1000);
        break;
      }
    }
  }

  // =======================================================
  // STEP 4: Add each variant name via "Create your own" input
  // =======================================================
  for (let i = 0; i < variations.length; i++) {
    const v = variations[i];
    console.log('[UnicornDS] MSKU: Adding variant', i + 1, ':', v.name);

    // Find the "Create your own" input - it has id="msku-custom-option-input"
    let optionInput = document.querySelector('#msku-custom-option-input');
    
    if (!optionInput) {
      // Try clicking "+ Create your own" link first
      const createLink = Array.from(document.querySelectorAll('a, button, span')).find(el =>
        el.textContent.trim().includes('Create your own')
      );
      if (createLink) {
        createLink.click();
        await sleep(500);
        optionInput = document.querySelector('#msku-custom-option-input');
      }
    }

    if (optionInput) {
      // Clear and type variant name
      optionInput.value = '';
      setInput(optionInput, v.name);
      await sleep(300);

      // Click the "Add" link next to the input
      // Find all elements with text "Add" that are NOT the "+ Add" attribute button
      const allAdds = Array.from(document.querySelectorAll('a, button, span')).filter(b => {
        return b.textContent.trim() === 'Add';
      });
      // Pick the one closest to the option input (usually the last "Add" on page)
      const addOptBtn = allAdds.length > 0 ? allAdds[allAdds.length - 1] : null;
      if (addOptBtn) {
        addOptBtn.click();
        console.log('[UnicornDS] MSKU: Clicked Add for "' + v.name + '"');
      } else {
        // Fallback: press Enter
        optionInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
        optionInput.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, key: 'Enter', keyCode: 13 }));
        console.log('[UnicornDS] MSKU: Pressed Enter for "' + v.name + '"');
      }
      await sleep(700);
    } else {
      console.warn('[UnicornDS] MSKU: Could not find option input for variant "' + v.name + '"');
    }
  }

  console.log('[UnicornDS] MSKU: All variant names added');
  await sleep(1000);

  // =======================================================
  // STEP 5: Click Continue to go to table view
  // =======================================================
  const continueBtn = Array.from(document.querySelectorAll('button')).find(b =>
    b.textContent.trim() === 'Continue'
  );
  if (continueBtn) {
    continueBtn.click();
    console.log('[UnicornDS] MSKU: Clicked Continue');
    await sleep(3000);
  }

  // Wait for table to appear (may take a few seconds)
  let table = null;
  for (let waitAttempt = 0; waitAttempt < 10; waitAttempt++) {
    table = document.querySelector('table');
    if (table && table.querySelectorAll('tbody tr').length > 0) {
      console.log('[UnicornDS] MSKU: Table found after', waitAttempt, 'waits');
      break;
    }
    console.log('[UnicornDS] MSKU: Waiting for table... attempt', waitAttempt + 1);
    await sleep(1000);
  }

  // =======================================================
  // STEP 5.5: Upload per-variant photos (after Continue, before price)
  // =======================================================
  const variantImages = data.variantImages || {};
  const hasVariantImages = Object.keys(variantImages).length > 0;

  if (hasVariantImages) {
    console.log('[UnicornDS] MSKU: Uploading variant images for', Object.keys(variantImages).length, 'variants');

    const photoSelect = document.getElementById('msku-photos_options');
    if (photoSelect) {
      photoSelect.value = 'MNP';
      fireEvents(photoSelect);
      console.log('[UnicornDS] MSKU: Selected MNP for per-variant photos');
      await sleep(3000);

      // Find the picupload variations iframe
      let targetIframe = null;
      const iframes = document.querySelectorAll('iframe');
      for (const iframe of iframes) {
        const src = iframe.src || iframe.name || '';
        if (src.includes('picupload') && src.includes('variation')) {
          targetIframe = iframe;
          break;
        }
      }
      if (!targetIframe) {
        for (const iframe of iframes) {
          if ((iframe.src || '').includes('picupload')) {
            targetIframe = iframe;
            break;
          }
        }
      }

      if (targetIframe) {
        console.log('[UnicornDS] MSKU: Found picupload iframe:', (targetIframe.src || targetIframe.name || '').substring(0, 60));
      } else {
        console.warn('[UnicornDS] MSKU: No picupload iframe found');
      }

      // Listen for upload results
      let uploadResolve = null;
      window.addEventListener('message', (event) => {
        if (event.data?.type === 'unicornds_upload_result') {
          console.log('[UnicornDS] MSKU: Upload result:', event.data.success ? '✅ ' + event.data.variantName : '❌ ' + event.data.error);
          if (uploadResolve) uploadResolve(event.data);
        }
      });

      const variationList = document.getElementById('msku-photos_variations');
      if (variationList) {
        const varItems = variationList.querySelectorAll('li');
        console.log('[UnicornDS] MSKU: Found', varItems.length, 'photo slots');

        for (let i = 0; i < varItems.length; i++) {
          const li = varItems[i];
          const varName = li.textContent.trim().replace(/\s*\(\d+\/\d+\s*photos?\)\s*$/i, '').trim();

          // Click the <a> tag inside the li (eBay's click handler is on <a>)
          const anchor = li.querySelector('a');
          if (anchor) {
            anchor.click();
          } else {
            li.click();
          }
          
          // Wait for this li to get the 'select' class (eBay switches active variant)
          for (let wait = 0; wait < 10; wait++) {
            if (li.classList.contains('select')) break;
            await sleep(500);
          }
          await sleep(1000); // Extra wait for iframe to be ready
          console.log('[UnicornDS] MSKU: Clicked photo slot:', varName, '- selected:', li.classList.contains('select'));

          // Match image
          let imgUrl = '';
          if (variantImages[varName]) {
            imgUrl = variantImages[varName][0];
          } else {
            for (const [key, urls] of Object.entries(variantImages)) {
              if (varName.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(varName.toLowerCase())) {
                imgUrl = urls[0]; break;
              }
            }
          }
          if (!imgUrl) { console.log('[UnicornDS] MSKU: No image for "' + varName + '"'); continue; }
          

          // Download image
          const b64 = await new Promise(resolve => {
            chrome.runtime.sendMessage({ type: 'url-to-b64', url: imgUrl }, resp => {
              
              resolve(resp?.b64Image || resp?.b64 || null);
            });
          });
          if (!b64) { console.warn('[UnicornDS] MSKU: Download failed for "' + varName + '" URL:', imgUrl.substring(0, 60)); continue; }

          if (targetIframe && targetIframe.contentWindow) {
            // KEY FIX: RELOAD the iframe to get a fresh init with correct currentQueue
            // When iframe reloads, eBay's parent code sends init with currentQueue = selected variant
            const varClass = 'picupload-variations__MNP__' + varName.replace(/\s+/g, '_');
            targetIframe.className = 'photo-iframe-picupload-variations photo-framework select ' + varClass;
            
            // Force iframe reload by toggling src
            const origSrc = targetIframe.src;
            targetIframe.src = 'about:blank';
            await sleep(500);
            targetIframe.src = origSrc;
            console.log('[UnicornDS] MSKU: Reloaded iframe for "' + varName + '"');
            
            // Wait for iframe to fully load and receive init message
            await sleep(4000);
            
            // Re-find the iframe reference (it reloaded)
            const newIframes = document.querySelectorAll('iframe');
            let newIframe = null;
            for (const f of newIframes) {
              if ((f.src || '').includes('picupload') && (f.src || '').includes('variation')) {
                newIframe = f;
                break;
              }
            }
            if (!newIframe) {
              for (const f of newIframes) {
                if ((f.src || '').includes('picupload')) { newIframe = f; break; }
              }
            }

            if (newIframe && newIframe.contentWindow) {
              const uploadPromise = new Promise(resolve => {
                uploadResolve = resolve;
                setTimeout(() => resolve({ success: false, error: 'timeout' }), 10000);
              });
              newIframe.contentWindow.postMessage({
                type: 'unicornds_upload_variant_image', imageB64: b64, variantName: varName
              }, '*');
              const result = await uploadPromise;
              console.log('[UnicornDS] MSKU: ' + (result.success ? '✅' : '❌') + ' Photo for "' + varName + '"');
              
              if (result.success) {
                for (let w = 0; w < 15; w++) {
                  const countEl = li.querySelector('.pics-count');
                  if (countEl && parseInt(countEl.textContent) > 0) {
                    console.log('[UnicornDS] MSKU: Photo confirmed for "' + varName + '" count:', countEl.textContent);
                    break;
                  }
                  await sleep(500);
                }
              }
              await sleep(1000);
            } else {
              console.warn('[UnicornDS] MSKU: Reloaded iframe not found for "' + varName + '"');
            }
          } else {
            console.warn('[UnicornDS] MSKU: Cannot find picupload iframe');
          }
        }
      } else {
        console.warn('[UnicornDS] MSKU: No variation photo list found');
      }
    } else {
      console.warn('[UnicornDS] MSKU: Photo options dropdown not found');
    }
  }

  // =======================================================
  // STEP 6: Fill price, quantity, SKU, EAN per row
  // =======================================================
  if (!table) {
    table = document.querySelector('table');
    console.log('[UnicornDS] MSKU: Final table check:', table ? 'FOUND' : 'NOT FOUND');
  }
  if (table) {
    const rows = table.querySelectorAll('tbody tr');
    console.log('[UnicornDS] MSKU: Table has', rows.length, 'rows');

    // Debug: log all inputs in first row
    if (rows.length > 0) {
      const firstRowInputs = rows[0].querySelectorAll('input');
      console.log('[UnicornDS] MSKU: First row inputs:');
      firstRowInputs.forEach((inp, i) => {
        console.log('[UnicornDS] MSKU:   ' + i + ': name=' + inp.name + ' id=' + inp.id + ' type=' + inp.type + ' value=' + inp.value);
      });
    }

    // Fill each row individually (supports different prices per variant)
    // Inputs have NO name/id - identified by POSITION in row:
    //   textInputs[0] = SKU
    //   textInputs[1] = Quantity
    //   textInputs[2] = Price
    // NOTE: eBay table has alternating real/detail rows - only real rows have inputs
    let variantIdx = 0; // tracks which variation we're on (separate from row index)
    for (let r = 0; r < rows.length; r++) {
      const textInputs = rows[r].querySelectorAll('input[type="text"]');
      
      if (textInputs.length >= 3) {
        // This is a real variant row - match to variation by variantIdx
        let rowPrice = sellPrice;
        if (variations[variantIdx] && variations[variantIdx].price) {
          const vPrice = parseFloat(String(variations[variantIdx].price).replace(/[^0-9.]/g, ''));
          if (vPrice > 0) rowPrice = vPrice;
        }

        // SKU = textInputs[0]
        setInput(textInputs[0], baseSku + '_V' + (variantIdx + 1));
        // Quantity = textInputs[1]
        setInput(textInputs[1], String(quantity));
        // Price = textInputs[2]
        setInput(textInputs[2], String(rowPrice));
        console.log('[UnicornDS] MSKU: Variant', variantIdx, '- SKU:', baseSku + '_V' + (variantIdx+1), 'Qty:', quantity, 'Price:', rowPrice);
        variantIdx++;
      } else if (textInputs.length === 2) {
        let rowPrice = sellPrice;
        if (variations[variantIdx] && variations[variantIdx].price) {
          const vPrice = parseFloat(String(variations[variantIdx].price).replace(/[^0-9.]/g, ''));
          if (vPrice > 0) rowPrice = vPrice;
        }
        setInput(textInputs[0], String(quantity));
        setInput(textInputs[1], String(rowPrice));
        console.log('[UnicornDS] MSKU: Variant', variantIdx, '- Qty:', quantity, 'Price:', rowPrice, '(2 inputs)');
        variantIdx++;
      }
      // Skip detail rows (0 text inputs) silently
      await sleep(200);
    }

    // Click "Does not apply" for all EAN/Product Identifier fields
    // eBay uses various elements: buttons, links, checkboxes
    let eanHandled = 0;

    // Method 1: Look for "Does not apply" buttons
    const eanButtons = Array.from(document.querySelectorAll('button, a, [role="button"]')).filter(b =>
      b.textContent.trim().toLowerCase().includes('does not apply') ||
      b.textContent.trim().toLowerCase().includes('doesn\'t apply')
    );
    for (const eanBtn of eanButtons) {
      eanBtn.click();
      await sleep(300);
      eanHandled++;
    }

    // Method 2: Look for "Add EAN" or "Product identifiers" links and click "Does not apply"
    if (eanHandled === 0) {
      const eanLinks = Array.from(document.querySelectorAll('a, button, [role="link"]')).filter(el => {
        const txt = el.textContent.trim().toLowerCase();
        return txt.includes('add ean') || txt.includes('product identifier') || txt.includes('add upc');
      });
      for (const link of eanLinks) {
        link.click();
        await sleep(500);
        // After clicking, look for "Does not apply" option that appeared
        const dnaBtn = Array.from(document.querySelectorAll('button, a, [role="button"], [role="option"]')).find(b =>
          b.textContent.trim().toLowerCase().includes('does not apply') ||
          b.textContent.trim().toLowerCase().includes('doesn\'t apply')
        );
        if (dnaBtn) { dnaBtn.click(); await sleep(300); eanHandled++; }
      }
    }

    // Method 3: Look for checkbox inputs near "EAN" or "Does not apply" text
    if (eanHandled === 0) {
      const allLabels = Array.from(document.querySelectorAll('label'));
      for (const label of allLabels) {
        const txt = label.textContent.trim().toLowerCase();
        if (txt.includes('does not apply') || txt.includes('doesn\'t apply')) {
          const checkbox = label.querySelector('input[type="checkbox"]') || label.previousElementSibling;
          if (checkbox && checkbox.type === 'checkbox' && !checkbox.checked) {
            checkbox.click();
            await sleep(200);
            eanHandled++;
          }
        }
      }
    }

    // Method 4: Fill EAN text inputs with "Does not apply"
    if (eanHandled === 0) {
      const allInputs = table.querySelectorAll('input[type="text"]');
      // EAN input is usually the 4th text input per row (after SKU, qty, price)
      let rIdx = 0;
      for (let r = 0; r < rows.length; r++) {
        const rowInputs = rows[r].querySelectorAll('input[type="text"]');
        if (rowInputs.length >= 4) {
          // 4+ inputs: SKU, Qty, Price, EAN
          setInput(rowInputs[3], 'Does not apply');
          eanHandled++;
        }
      }
    }

    if (eanHandled > 0) {
      console.log('[UnicornDS] MSKU: Set EAN "Does not apply" for', eanHandled, 'items');
    } else {
      console.log('[UnicornDS] MSKU: No EAN fields found (may not be required for this category)');
    }

    // If per-row didn't work, try bulk buttons
    const emptyPriceInputs = table.querySelectorAll('input[name*="prc"]');
    let hasEmptyPrice = false;
    emptyPriceInputs.forEach(inp => { if (!inp.value) hasEmptyPrice = true; });
    
    if (hasEmptyPrice) {
      console.log('[UnicornDS] MSKU: Trying bulk price/qty...');
      const enterPriceBtn = Array.from(document.querySelectorAll('button')).find(b =>
        b.textContent.trim() === 'Enter price'
      );
      if (enterPriceBtn) {
        enterPriceBtn.click();
        await sleep(500);
        const priceInput = document.querySelector('input[name*="prc"]');
        if (priceInput) {
          setInput(priceInput, String(sellPrice));
          await sleep(300);
          const savePrc = Array.from(document.querySelectorAll('button')).find(b =>
            b.textContent.trim() === 'Save'
          );
          if (savePrc) savePrc.click();
          await sleep(1000);
        }
      }

      const enterQtyBtn = Array.from(document.querySelectorAll('button')).find(b =>
        b.textContent.trim() === 'Enter quantity'
      );
      if (enterQtyBtn) {
        enterQtyBtn.click();
        await sleep(500);
        const qtyInput = document.querySelector('input[name*="qty"]');
        if (qtyInput) {
          setInput(qtyInput, String(quantity));
          await sleep(300);
          const saveQty = Array.from(document.querySelectorAll('button')).find(b =>
            b.textContent.trim() === 'Save'
          );
          if (saveQty) saveQty.click();
          await sleep(1000);
        }
      }
    }

    console.log('[UnicornDS] MSKU: Table rows filled');
  } else {
    console.warn('[UnicornDS] MSKU: !! Table NOT FOUND - variations may not have prices/qty');
  }

  // =======================================================
  // STEP 8: Click "Save and close" - closes the dialog
  // =======================================================
  const saveCloseBtn = Array.from(document.querySelectorAll('button')).find(b =>
    b.textContent.trim() === 'Save and close'
  );
  if (saveCloseBtn) {
    saveCloseBtn.click();
    console.log('[UnicornDS] MSKU: Clicked "Save and close"');
  }

  console.log('[UnicornDS] MSKU: === Variation fill DONE ===');

  // Signal completion to listing-form.js via chrome.storage
  try {
    chrome.storage.local.set({ unicornds_msku_done: { success: true, timestamp: Date.now() } });
    console.log('[UnicornDS] MSKU: Signalled completion');
  } catch(e) {}

  // Notify background
  try {
    chrome.runtime.sendMessage({ type: 'msku_complete' });
  } catch(e) {}
}

} // end guard
