/**
 * Unicorn DS - Compliance Checker v1.0
 * Checks products against eBay UK policies before listing:
 * 1. VERO brand detection (protected brands)
 * 2. Knife/blade keyword detection (eBay knives policy)
 * 3. CE/UKCA risky category detection (electronics, toys, batteries)
 * 4. Counterfeit brand name detection
 *
 * Returns: { safe: boolean, warnings: [...], blocks: [...] }
 */

const ComplianceChecker = {

  // ═══════════════════════════════════════════════════════
  // 1. KNIFE / BLADE DETECTION
  // ═══════════════════════════════════════════════════════
  KNIFE_BLOCKED: [
    'kitchen knife', 'chef knife', 'carving knife', 'paring knife', 'bread knife',
    'utility knife', 'santoku', 'cleaver', 'boning knife', 'fillet knife',
    'steak knife', 'oyster knife', 'cake knife', 'electric knife',
    'pocket knife', 'folding knife', 'swiss army', 'clasp knife',
    'multi-tool', 'multitool', 'leatherman', 'stanley knife', 'craft knife', 'box cutter',
    'razor blade', 'surgical blade', 'scalpel',
    'throwing knife', 'combat knife', 'tactical knife', 'survival knife',
    'hunting knife', 'bowie knife', 'dagger', 'stiletto knife',
    'butterfly knife', 'balisong', 'switchblade', 'flick knife', 'gravity knife',
    'push dagger', 'knuckle duster', 'knuckleduster',
    'samurai sword', 'katana', 'machete', 'sword stick', 'zombie knife',
    'shuriken', 'throwing star', 'blowpipe', 'crossbow',
  ],

  KNIFE_ALLOWED_WITH_AGE: [
    'scissors', 'pizza cutter', 'food processor', 'letter opener',
    'manicure', 'nail clipper', 'dermaplaning', 'straight razor',
    'axe', 'hatchet', 'chainsaw', 'saw blade', 'chisel',
    'rotary cutter', 'rotary blade', 'craft rotary',
    'butter knife', 'cheese knife', 'fish knife', 'cutlery set',
    'sommelier', 'waiters friend', 'corkscrew',
    'spear', 'javelin', 'pickaxe', 'mattock', 'billhook',
  ],

  // ═══════════════════════════════════════════════════════
  // 2. CE/UKCA RISKY CATEGORIES
  // ═══════════════════════════════════════════════════════
  CE_RISKY_KEYWORDS: [
    // Electronics
    'charger', 'charging cable', 'usb cable', 'power adapter', 'power supply',
    'led light', 'led strip', 'led lamp', 'led bulb',
    'headphones', 'earphones', 'earbuds', 'bluetooth speaker',
    'smart watch', 'smartwatch', 'fitness tracker',
    'drone', 'rc car', 'remote control',
    'hair dryer', 'hair straightener', 'curling iron',
    'electric shaver', 'electric toothbrush',
    'power bank', 'portable charger',
    'wifi', 'router', 'antenna', 'walkie talkie', 'radio transmitter',
    'voltage converter', 'transformer',
    // Batteries
    'lithium battery', 'li-ion battery', 'lipo battery', '18650',
    'battery pack', 'rechargeable battery',
    // Toys
    'toy', 'action figure', 'doll', 'plush toy', 'stuffed animal',
    'building blocks', 'lego compatible', 'toy gun', 'nerf',
    'toy car', 'toy train', 'toy robot', 'toy drone',
    'baby toy', 'toddler toy', 'infant toy', 'teething',
    'fidget spinner', 'fidget toy', 'slime', 'putty',
    // PPE
    'safety goggles', 'safety glasses', 'hard hat', 'helmet',
    'safety gloves', 'work gloves', 'hi-vis', 'high visibility',
    'face mask', 'respirator', 'ear defenders', 'ear plugs',
    'safety boots', 'steel toe',
    // E-mobility
    'electric scooter', 'e-scooter', 'e-bike', 'ebike',
    'hoverboard', 'segway', 'electric skateboard',
    // Machinery
    'angle grinder', 'drill', 'jigsaw', 'circular saw',
    'pressure washer', 'air compressor',
    // Scales / measuring
    'digital scale', 'kitchen scale', 'weighing scale',
    'thermometer', 'hygrometer', 'multimeter',
  ],

  // ═══════════════════════════════════════════════════════
  // 3. COUNTERFEIT / BRAND DETECTION
  // ═══════════════════════════════════════════════════════
  PROTECTED_BRANDS: [
    // Tech
    'apple', 'iphone', 'ipad', 'airpods', 'macbook', 'samsung', 'galaxy',
    'google', 'pixel', 'microsoft', 'xbox', 'playstation', 'sony', 'nintendo',
    'switch', 'huawei', 'oneplus', 'oppo', 'xiaomi', 'bose', 'beats',
    'jbl', 'marshall', 'bang & olufsen', 'dyson', 'gopro', 'dji', 'canon', 'nikon',
    // Fashion
    'nike', 'adidas', 'puma', 'reebok', 'new balance', 'converse', 'vans',
    'gucci', 'louis vuitton', 'prada', 'chanel', 'hermes', 'burberry',
    'versace', 'balenciaga', 'dior', 'fendi', 'valentino', 'ysl',
    'ralph lauren', 'tommy hilfiger', 'calvin klein', 'armani', 'hugo boss',
    'north face', 'patagonia', 'supreme', 'off-white', 'stone island',
    'canada goose', 'moncler', 'lacoste',
    // Sports
    'premier league', 'champions league', 'nfl', 'nba', 'mlb',
    'manchester united', 'liverpool', 'chelsea', 'arsenal', 'real madrid',
    'barcelona', 'bayern munich', 'juventus', 'psg',
    // Beauty
    'mac cosmetics', 'urban decay', 'nars', 'too faced', 'benefit',
    'charlotte tilbury', 'estee lauder', 'clinique', 'lancome',
    'chanel perfume', 'dior perfume', 'tom ford', 'jo malone',
    // Watches
    'rolex', 'omega', 'tag heuer', 'breitling', 'cartier',
    'patek philippe', 'audemars piguet', 'tissot', 'casio g-shock',
    // Other
    'disney', 'marvel', 'dc comics', 'star wars', 'pokemon', 'hello kitty',
    'lego', 'barbie', 'hot wheels', 'fisher price', 'hasbro',
    'ray-ban', 'oakley', 'pandora', 'swarovski', 'tiffany',
  ],

  // Words that suggest counterfeit when combined with a brand
  COUNTERFEIT_SIGNALS: [
    'style', 'inspired', 'dupe', 'replica', 'lookalike', 'fake',
    'imitation', 'knock off', 'knockoff', 'copy', 'clone',
  ],

  // Words that mean "accessory FOR this brand" - NOT counterfeit
  ACCESSORY_SIGNALS: [
    'compatible', 'for', 'fits', 'works with', 'suitable for',
    'case', 'cover', 'cable', 'charger', 'charging', 'adapter',
    'screen protector', 'tempered glass', 'holder', 'stand', 'mount',
    'strap', 'band', 'replacement', 'aftermarket', 'generic',
    'oem', 'third party', 'universal', 'type',
  ],

  // ═══════════════════════════════════════════════════════
  // MAIN CHECK FUNCTION
  // ═══════════════════════════════════════════════════════
  check(productData) {
    const title = (productData.custom_title || productData.title || '').toLowerCase();
    const description = (productData.ai_description || productData.description || '').toLowerCase();
    const combined = title + ' ' + description;
    const category = (productData.category || productData.categoryName || '').toLowerCase();

    const result = {
      safe: true,
      warnings: [],  // Yellow - proceed with caution
      blocks: [],    // Red - do NOT list
    };

    // ── CHECK 1: KNIVES / BLADES ──
    for (const keyword of this.KNIFE_BLOCKED) {
      if (combined.includes(keyword)) {
        result.blocks.push({
          type: 'knife',
          severity: 'block',
          message: '🔪 BANNED: "' + keyword + '" - eBay prohibits this type of blade/weapon',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/knives-policy?id=5047',
        });
        result.safe = false;
        break; // One match is enough
      }
    }

    for (const keyword of this.KNIFE_ALLOWED_WITH_AGE) {
      if (combined.includes(keyword)) {
        result.warnings.push({
          type: 'knife_restricted',
          severity: 'warning',
          message: '⚠️ AGE RESTRICTED: "' + keyword + '" - requires age-verified delivery + UK stock only',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/knives-policy?id=5047',
        });
        break;
      }
    }

    // ── CHECK 2: CE/UKCA RISKY CATEGORIES ──
    const ceMatches = [];
    for (const keyword of this.CE_RISKY_KEYWORDS) {
      if (combined.includes(keyword)) {
        ceMatches.push(keyword);
      }
    }
    if (ceMatches.length > 0) {
      result.warnings.push({
        type: 'ce_ukca',
        severity: 'warning',
        message: '⚡ CE/UKCA WARNING: Contains "' + ceMatches.slice(0, 3).join('", "') + '" - may need CE/UKCA marking + UK economic operator. Direct AliExpress shipping may be seized at customs.',
        policy: 'https://www.ebay.co.uk/help/selling/selling/CE-mark-EU?id=5225',
        keywords: ceMatches,
      });
    }

    // ── CHECK 3: COUNTERFEIT / BRAND DETECTION ──
    const brandMatches = [];
    for (const brand of this.PROTECTED_BRANDS) {
      // Check if brand name appears as a whole word (not part of another word)
      const regex = new RegExp('\\b' + brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
      if (regex.test(combined)) {
        brandMatches.push(brand);
      }
    }

    if (brandMatches.length > 0) {
      // Check if it's a generic accessory (cable for iPhone, case for Samsung, etc.)
      let isAccessory = false;
      for (const signal of this.ACCESSORY_SIGNALS) {
        if (combined.includes(signal)) {
          isAccessory = true;
          break;
        }
      }

      // Check if it's clearly counterfeit (brand + fake/replica/dupe signal)
      let isCounterfeit = false;
      for (const signal of this.COUNTERFEIT_SIGNALS) {
        if (combined.includes(signal)) {
          isCounterfeit = true;
          break;
        }
      }

      if (isCounterfeit && !isAccessory) {
        // Definitely counterfeit - BLOCK
        result.blocks.push({
          type: 'counterfeit',
          severity: 'block',
          message: '🚫 COUNTERFEIT RISK: Brand "' + brandMatches[0] + '" with terms suggesting fake/replica. eBay will remove this.',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/fake-items-policy?id=4276',
          brands: brandMatches,
        });
        result.safe = false;
      } else if (isAccessory) {
        // Generic accessory for a brand - ALLOW with info
        result.warnings.push({
          type: 'brand_accessory',
          severity: 'info',
          message: '✅ ACCESSORY: "' + brandMatches[0] + '" detected but title indicates generic accessory. OK to list - make sure title says "for/compatible with" not the brand itself.',
          brands: brandMatches,
        });
      } else {
        // Brand name without clear context - WARN
        result.warnings.push({
          type: 'brand_detected',
          severity: 'warning',
          message: '⚠️ BRAND DETECTED: "' + brandMatches.join('", "') + '" - only list if genuine. AliExpress items with these brands are often counterfeit.',
          policy: 'https://www.ebay.co.uk/help/policies/prohibited-restricted-items/fake-items-policy?id=4276',
          brands: brandMatches,
        });
      }
    }

    // ── CHECK 4: VERO BRANDS (loaded from VeroList.txt) ──
    // This is checked separately via the existing VERO system
    // Just add a note if VERO list is available
    if (productData._veroChecked && productData._veroBlocked) {
      result.blocks.push({
        type: 'vero',
        severity: 'block',
        message: '🛑 VERO BLOCKED: "' + productData._veroBrand + '" is a VeRO-protected brand. Listing will be removed by eBay.',
        brands: [productData._veroBrand],
      });
      result.safe = false;
    }

    return result;
  },

  // ═══════════════════════════════════════════════════════
  // FORMAT FOR DISPLAY
  // ═══════════════════════════════════════════════════════
  formatForConsole(result) {
    if (result.safe && result.warnings.length === 0) {
      console.log('[UnicornDS] ✅ Compliance check: SAFE - no policy issues detected');
      return;
    }

    if (result.blocks.length > 0) {
      console.warn('[UnicornDS] 🚨 COMPLIANCE BLOCK - DO NOT LIST:');
      result.blocks.forEach(b => console.warn('[UnicornDS]   ' + b.message));
    }

    if (result.warnings.length > 0) {
      console.warn('[UnicornDS] ⚠️ COMPLIANCE WARNINGS:');
      result.warnings.forEach(w => console.warn('[UnicornDS]   ' + w.message));
    }
  },

  // Format for notification overlay on the page
  formatForNotification(result) {
    if (result.safe && result.warnings.length === 0) return null;

    const lines = [];
    result.blocks.forEach(b => lines.push(b.message));
    result.warnings.forEach(w => lines.push(w.message));
    return lines.join('\n');
  },
};

// Export for use in background.js and content scripts
if (typeof module !== 'undefined') module.exports = ComplianceChecker;
